#!/bin/bash
#
# backup_settings.sh — Backup user-configurable files for Im Mesh Client
#
# Creates a compressed archive: backup_YYYYMMDD_HHMMSS.tar.gz
#
# Files backed up:
#   settings.json                — main configuration
#   cert.pem / key.pem           — TLS certificates (if present)
#   auto_responder/              — AR conversation folders (configs + responder scripts)
#   sched_messages/              — scheduled message command files
#   telegram_forwarder/configs/  — Telegram Forwarder conversation configs
#
# Usage:
#   ./backup_settings.sh              # Creates backup_YYYYMMDD_HHMMSS.tar.gz in current dir
#   ./backup_settings.sh /path/to/   # Creates backup file in specified directory

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

DEST_DIR="${1:-$SCRIPT_DIR}"
DATESTAMP="$(date +%Y%m%d_%H%M%S)"
ARCHIVE="${DEST_DIR}/backup_${DATESTAMP}.tar.gz"

GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

echo -e "${GREEN}Im Mesh Client — Backup${NC}"
echo "=============================="
echo "Backup file: $ARCHIVE"
echo ""

# Build list of items to include (only those that exist)
ITEMS=()
[ -f "settings.json" ]                    && ITEMS+=("settings.json")
[ -f "cert.pem" ]                         && ITEMS+=("cert.pem")
[ -f "key.pem" ]                          && ITEMS+=("key.pem")
[ -d "auto_responder" ]                   && ITEMS+=("auto_responder")
[ -d "sched_messages" ]                   && ITEMS+=("sched_messages")
[ -d "telegram_forwarder/configs" ]       && ITEMS+=("telegram_forwarder/configs")

if [ ${#ITEMS[@]} -eq 0 ]; then
    echo -e "${YELLOW}Nothing to back up (no settings.json, auto_responder/, sched_messages/, telegram_forwarder/configs/, cert.pem, or key.pem found).${NC}"
    exit 0
fi

echo "Items to back up:"
for item in "${ITEMS[@]}"; do
    echo "  + $item"
done
echo ""

mkdir -p "$DEST_DIR"
tar -czf "$ARCHIVE" "${ITEMS[@]}"

echo -e "${GREEN}✓ Backup created: $ARCHIVE${NC}"
echo "  Size: $(du -sh "$ARCHIVE" | cut -f1)"
