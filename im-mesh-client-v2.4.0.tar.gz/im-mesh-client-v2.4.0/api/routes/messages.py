"""Message sending routes."""

import logging
from datetime import datetime
from typing import Optional
from fastapi import APIRouter, HTTPException, Depends, Query

from core.session_manager import Session
from api.models import SendTextMessageRequest, SendBinaryMessageRequest, SendImageRequest, MessageResponse

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api", tags=["messages"])


def create_message_routes(get_session_dep, telegram_forwarder=None) -> APIRouter:
    """Create message sending routes."""

    @router.post("/messages/send")
    async def send_text_message(
        request: SendTextMessageRequest,
        session: Session = Depends(get_session_dep)
    ):
        """Send a text message through the session."""
        try:
            channel_idx = int(request.channel or 0)
            to_node = request.to_node or ''
            result = await session.gateway.send_text_message(
                text=request.text,
                to_node=request.to_node,
                channel=request.channel,
                want_ack=request.want_ack
            )

            sent_ok = result and isinstance(result, dict) and result.get('success') or bool(result)

            # Publish text_sent to MessageRouter so TF and other subscribers pick it up
            if sent_ok:
                try:
                    local_id = None
                    local_long = None
                    local_short = None
                    mc = session.gateway.meshtastic_client
                    if mc and mc.my_node_info and isinstance(mc.my_node_info, dict):
                        node_num = mc.my_node_info.get('nodeNum') or mc.my_node_info.get('num')
                        if node_num:
                            local_id = f"!{node_num:08x}"
                    if local_id and mc and mc.nodes_db and local_id in mc.nodes_db:
                        nd = mc.nodes_db[local_id]
                        local_long = nd.get('long_name')
                        local_short = nd.get('short_name')
                    ch_name = None
                    try:
                        if mc and mc.channels_db:
                            ch_name = mc.channels_db.get(channel_idx, {}).get('name') or f"ch{channel_idx}"
                    except Exception:
                        ch_name = f"ch{channel_idx}"
                    await session.gateway.message_router.route_message({
                        'message_type': 'text_sent',
                        'text': request.text,
                        'from_node': local_id,
                        'from_name': local_long,
                        'from_short': local_short,
                        'to_node': to_node or None,
                        'channel': channel_idx,
                        'channel_name': ch_name,
                        'direction': 'sent',
                        'is_broadcast': not bool(to_node),
                        'timestamp': datetime.now().isoformat(),
                    })
                except Exception as tg_err:
                    logger.warning("MessageRouter text_sent publish error: %s", tg_err)

            if sent_ok and isinstance(result, dict):
                return MessageResponse(
                    success=True,
                    message="Message sent successfully",
                    data={'packet_id': result.get('packet_id')}
                )
            elif sent_ok:
                return MessageResponse(success=True, message="Message sent successfully")
            else:
                return MessageResponse(success=False, message="Failed to send message")

        except Exception as e:  # API safety net: HTTP 500
            logger.warning(f"Error sending message: {e}")
            raise HTTPException(status_code=500, detail=str(e))

    @router.post("/messages/send-binary")
    async def send_binary_message(
        request: SendBinaryMessageRequest,
        session: Session = Depends(get_session_dep)
    ):
        """Send a single binary message via portnum 288 (CUSTOM_IMAGE_APP).

        Used for image segments that should travel as binary data rather than
        text messages.  The payload string is UTF-8 encoded before sending.
        """
        try:
            result = await session.gateway.send_binary_message(
                data=request.data,
                to_node=request.to_node,
                channel=request.channel,
                want_ack=request.want_ack
            )

            if result and isinstance(result, dict) and result.get('success'):
                return MessageResponse(
                    success=True,
                    message="Binary message sent successfully",
                    data={'packet_id': result.get('packet_id')}
                )
            elif result:
                return MessageResponse(success=True, message="Binary message sent successfully")
            else:
                return MessageResponse(success=False, message="Failed to send binary message")

        except Exception as e:  # API safety net: HTTP 500
            logger.warning(f"Error sending binary message: {e}")
            raise HTTPException(status_code=500, detail=str(e))

    @router.post("/messages/send-image")
    async def send_image_segments(
        request: SendImageRequest,
        session: Session = Depends(get_session_dep)
    ):
        """Send image segments through the session."""
        try:
            success = await session.gateway.send_image_segments(
                segments=request.segments,
                to_node=request.to_node,
                channel=request.channel,
                delay_ms=request.delay_ms,
                send_method=request.send_method
            )
            return MessageResponse(
                success=success,
                message="Image segments sent successfully" if success else "Failed to send some segments"
            )
        except Exception as e:  # API safety net: HTTP 500
            logger.warning(f"Error sending image segments: {e}")
            raise HTTPException(status_code=500, detail=str(e))

    @router.get("/messages/recent")
    async def get_recent_messages(
        since: Optional[str] = Query(None, description="ISO timestamp to fetch messages after"),
        session: Session = Depends(get_session_dep)
    ):
        """
        Get recent messages from the server buffer.
        
        Used by clients to retrieve messages missed during a WebSocket disconnection.
        Pass ?since=<ISO timestamp> to get only messages after that time.
        Without 'since', returns all buffered messages (up to 200).
        """
        try:
            message_router = session.gateway.message_router
            if since:
                messages = message_router.get_messages_since(since)
            else:
                messages = list(message_router._recent_messages)

            # Filter to only text/binary messages (not acks, node_updates, etc.)
            # CRITICAL: Exclude binary_complete and image_complete — these contain
            # concatenated payloads from fragment_reassembler.  Individual segments
            # are already delivered as 'binary' messages.  Sending the concatenated
            # blob causes addMessage() to store it in IndexedDB, polluting the
            # segment search and producing garbled image reassembly.
            user_messages = [
                m for m in messages
                if m.get('message_type') in ('text', 'binary')
            ]

            return {
                'success': True,
                'data': {
                    'messages': user_messages,
                    'count': len(user_messages)
                }
            }
        except Exception as e:  # API safety net: HTTP 500
            logger.warning(f"Error fetching recent messages: {e}")
            raise HTTPException(status_code=500, detail=str(e))

    return router
