"""Channel and device routes."""

import logging
from fastapi import APIRouter, HTTPException, Depends, Cookie, Header, Request
from typing import Optional

from core.session_manager import SessionManager, Session
from core.constants import (NODE_REFRESH_MIN, NODE_REFRESH_MAX, MSG_DELAY_MIN, MSG_DELAY_MAX,
                             SEG_DELAY_MIN, SEG_DELAY_MAX, CHAR_LIMIT_MIN, CHAR_LIMIT_MAX)
from api.models import MessageResponse

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api", tags=["channels"])


def create_channel_routes(session_manager: SessionManager, get_session_dep) -> APIRouter:
    """Create channel and device management routes."""

    @router.get("/connection")
    async def get_connection_status(
        session_id: Optional[str] = Cookie(None),
        x_session_id: Optional[str] = Header(None)
    ):
        """Get connection status for the session."""
        try:
            sid = x_session_id or session_id
            if not sid:
                raise HTTPException(status_code=400, detail="No session ID provided")
            session = await session_manager.get_session(sid)
            if not session:
                raise HTTPException(status_code=404, detail="Session not found")
            status = await session.gateway.get_connection_status()
            return MessageResponse(success=True, message="Connection status retrieved successfully", data=status)
        except HTTPException:
            raise
        except Exception as e:  # API safety net: HTTP 500
            logger.warning(f"Error getting connection status: {e}")
            raise HTTPException(status_code=500, detail=str(e))

    @router.get("/channels")
    async def get_channels(session: Session = Depends(get_session_dep)):
        """Get channel configuration for the session."""
        try:
            channels = await session.gateway.get_channels()
            return MessageResponse(
                success=True,
                message="Channels retrieved successfully",
                data={"channels": channels, "count": len(channels)}
            )
        except Exception as e:  # API safety net: HTTP 500
            logger.warning(f"Error getting channels: {e}")
            raise HTTPException(status_code=500, detail=str(e))

    @router.post("/channels/refresh")
    async def refresh_channels(session: Session = Depends(get_session_dep)):
        """Request fresh channel configuration from device."""
        try:
            success = await session.gateway.refresh_channels()
            return MessageResponse(
                success=success,
                message="Channel refresh requested" if success else "Failed to request channel refresh"
            )
        except Exception as e:  # API safety net: HTTP 500
            logger.warning(f"Error refreshing channels: {e}")
            raise HTTPException(status_code=500, detail=str(e))

    @router.post("/device/refresh")
    async def refresh_device_info(session: Session = Depends(get_session_dep)):
        """Request fresh device and node information."""
        try:
            success = await session.gateway.refresh_device_info()
            return MessageResponse(
                success=success,
                message="Device refresh requested" if success else "Failed to request device refresh"
            )
        except Exception as e:  # API safety net: HTTP 500
            logger.warning(f"Error refreshing device info: {e}")
            raise HTTPException(status_code=500, detail=str(e))

    @router.get("/device/settings")
    async def get_device_settings(session: Session = Depends(get_session_dep)):
        """Get device configuration settings."""
        try:
            settings = await session.gateway.get_device_settings()
            return MessageResponse(
                success=True,
                message="Device settings retrieved successfully",
                data={"settings": settings}
            )
        except Exception as e:  # API safety net: HTTP 500
            logger.warning(f"Error getting device settings: {e}")
            raise HTTPException(status_code=500, detail=str(e))

    @router.get("/app/settings")
    async def get_app_settings(session: Session = Depends(get_session_dep)):
        """Get application settings including node refresh interval and send delays."""
        try:
            settings = session.gateway.settings
            return MessageResponse(
                success=True,
                message="App settings retrieved",
                data={
                    "node_refresh_interval": getattr(settings.meshtastic, 'node_refresh_interval', 15),
                    "message_delay": getattr(settings.meshtastic, 'message_delay', 5.0),
                    "segment_delay": getattr(settings.encoding, 'segment_delay', 15),
                    "character_limit": getattr(settings.meshtastic, 'character_limit', 220),
                }
            )
        except Exception as e:  # API safety net: HTTP 500
            logger.warning(f"Error getting app settings: {e}")
            raise HTTPException(status_code=500, detail=str(e))

    @router.post("/app/settings")
    async def update_app_settings(request: Request, session: Session = Depends(get_session_dep)):
        """Update application settings (node_refresh_interval, message_delay, segment_delay)."""
        try:
            body = await request.json()
            settings = session.gateway.settings

            if 'node_refresh_interval' in body:
                session.gateway.node_refresh_interval = int(body['node_refresh_interval'])
                settings.meshtastic.node_refresh_interval = session.gateway.node_refresh_interval
                logger.info(f"Node refresh interval set to {session.gateway.node_refresh_interval} minutes")

            if 'message_delay' in body:
                session.gateway.msg_delay = float(body['message_delay'])
                settings.meshtastic.message_delay = session.gateway.msg_delay
                logger.info(f"Message delay set to {session.gateway.msg_delay}s")

            if 'segment_delay' in body:
                session.gateway.segment_delay = int(body['segment_delay'])
                settings.encoding.segment_delay = session.gateway.segment_delay
                logger.info(f"Segment delay set to {session.gateway.segment_delay}s")

            if 'character_limit' in body:
                session.gateway.char_limit = int(body['character_limit'])
                settings.meshtastic.character_limit = session.gateway.char_limit
                logger.info(f"Character limit set to {session.gateway.char_limit} bytes")

            settings.save()

            return MessageResponse(
                success=True,
                message="Settings updated",
                data={
                    "node_refresh_interval": session.gateway.node_refresh_interval,
                    "message_delay": session.gateway.msg_delay,
                    "segment_delay": session.gateway.segment_delay,
                    "character_limit": session.gateway.char_limit,
                }
            )
        except Exception as e:  # API safety net: HTTP 500
            logger.warning(f"Error updating app settings: {e}")
            raise HTTPException(status_code=500, detail=str(e))

    @router.get("/fragments")
    async def get_fragments(session: Session = Depends(get_session_dep)):
        """Get active fragment status."""
        try:
            fragments = await session.gateway.get_fragments()
            return MessageResponse(
                success=True,
                message="Fragments retrieved successfully",
                data={"fragments": fragments, "count": len(fragments)}
            )
        except Exception as e:  # API safety net: HTTP 500
            logger.warning(f"Error getting fragments: {e}")
            raise HTTPException(status_code=500, detail=str(e))

    @router.post("/device/reboot")
    async def reboot_device(session: Session = Depends(get_session_dep)):
        """Reboot the connected Meshtastic device."""
        try:
            success = await session.gateway.reboot_device(delay_secs=5)
            return MessageResponse(
                success=success,
                message="Reboot command sent (device will reboot in 5 seconds)" if success else "Failed to send reboot command"
            )
        except Exception as e:  # API safety net: HTTP 500
            logger.warning(f"Error rebooting device: {e}")
            raise HTTPException(status_code=500, detail=str(e))

    return router
