"""Node management routes."""

import logging
from datetime import datetime, timezone, timedelta
from fastapi import APIRouter, HTTPException, Depends, Query
from typing import Optional

from core.session_manager import Session
from core.constants import normalize_node_id
from api.models import MessageResponse

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api", tags=["nodes"])


def create_node_routes(get_session_dep, session_manager=None, raw_settings=None, get_optional_session_dep=None) -> APIRouter:
    """Create node management routes."""

    @router.get("/node/self")
    async def get_self_node(
        session: Session = Depends(get_session_dep),
        force: bool = Query(False, description="Re-fetch node data from device before responding")
    ):
        """Get information about the gateway's own node.

        Pass ?force=true to re-query the device (useful after reboot).
        """
        try:
            if force:
                await session.gateway.refresh_node_data()
            node_info = await session.gateway.meshtastic_client.get_node_info()
            return MessageResponse(
                success=True,
                message="Self node info retrieved",
                data={"node": node_info}
            )
        except Exception as e:
            logger.warning(f"Error getting self node info: {e}")
            raise HTTPException(status_code=500, detail=str(e))

    @router.get("/nodes")
    async def get_nodes(
        session: Session = Depends(get_session_dep),
        force: bool = Query(False, description="Re-fetch node data from device before responding")
    ):
        """Get all known nodes for the session.

        Pass ?force=true to re-query the device and return fresh data.
        """
        try:
            if force:
                logger.info("Forced node data refresh requested via GET /api/nodes")
                await session.gateway.refresh_node_data()
            nodes = await session.gateway.get_node_list()

            # Include our own node ID so the frontend can filter it out
            my_node_id = None
            try:
                node_info = await session.gateway.meshtastic_client.get_node_info()
                raw_id = node_info.get('node_id')
                if raw_id and raw_id != 'unknown':
                    my_node_id = normalize_node_id(raw_id)
            except (AttributeError, RuntimeError, ConnectionError):
                pass

            # Filter own node server-side so it's excluded even on first load
            # (before the frontend has _myNodeId cached).
            # Normalize both sides: interface keys may be int, hex, or !hex.
            if my_node_id and nodes:
                nodes = [n for n in nodes if normalize_node_id(n.get('id') or n.get('num') or '') != my_node_id]

            return MessageResponse(
                success=True,
                message="Nodes retrieved successfully",
                data={
                    "nodes": nodes or [],
                    "count": len(nodes) if nodes else 0,
                    "my_node_id": my_node_id
                }
            )
        except Exception as e:  # API safety net: HTTP 500
            logger.warning(f"Error getting nodes: {e}")
            raise HTTPException(status_code=500, detail=str(e))

    @router.get("/nodes/favorites")
    async def get_favorite_nodes(session: Session = Depends(get_session_dep)):
        """Get favorite nodes for the session."""
        try:
            favorites = await session.gateway.get_favorite_nodes()
            return MessageResponse(
                success=True,
                message="Favorite nodes retrieved successfully",
                data={"favorites": favorites, "count": len(favorites)}
            )
        except Exception as e:  # API safety net: HTTP 500
            logger.warning(f"Error getting favorite nodes: {e}")
            raise HTTPException(status_code=500, detail=str(e))

    @router.post("/nodes/{node_id}/favorite")
    async def set_node_favorite(
        node_id: str, favorite: bool = True,
        session: Session = Depends(get_session_dep)
    ):
        """Mark/unmark a node as favorite."""
        try:
            success = await session.gateway.set_node_favorite(node_id, favorite)
            if success:
                return MessageResponse(
                    success=True,
                    message=f"Node {'favorited' if favorite else 'unfavorited'} successfully"
                )
            return MessageResponse(success=False, message="Failed to update node favorite status")
        except Exception as e:  # API safety net: HTTP 500
            logger.warning(f"Error setting node favorite: {e}")
            raise HTTPException(status_code=500, detail=str(e))

    # ---------------------------------------------------------------------------
    # Node list export
    # ---------------------------------------------------------------------------
    _EXPORT_ALL_FIELDS = [
        'id', 'num', 'name', 'longName', 'shortName', 'hwModel', 'role',
        'snr', 'rssi', 'lastHeard', 'lastSeen', 'hopsAway', 'position',
        'battery', 'voltage', 'channelUtil', 'airTxUtil',
    ]
    # Map export field names → actual keys used in node dicts
    _EXPORT_FIELD_MAP = {
        'id': 'id', 'num': 'num', 'name': 'name',
        'longName': 'longName', 'shortName': 'shortName',
        'hwModel': 'hwModelString', 'role': 'role',
        'snr': 'snr', 'rssi': 'rssi',
        'lastHeard': 'lastHeard', 'lastSeen': 'lastSeen',
        'hopsAway': 'hopsAway', 'position': 'position',
        'battery': 'batteryLevel', 'voltage': 'voltage',
        'channelUtil': 'channelUtilization', 'airTxUtil': 'airUtilTx',
    }
    _ONLINE_WINDOW = timedelta(minutes=15)

    _export_session_dep = get_optional_session_dep if get_optional_session_dep is not None else get_session_dep

    @router.get("/nodes/export")
    async def export_nodes(
        include: Optional[str] = Query(None, description="Comma-separated fields to include"),
        exclude: Optional[str] = Query(None, description="Comma-separated fields to exclude"),
        host:    Optional[str] = Query(None, description="Device IP to look up session by host"),
        port:    Optional[int] = Query(None, description="Device port (default 4403)"),
        session: Optional[Session] = Depends(_export_session_dep)
    ):
        """Export the full node list as structured JSON.

        Use ?include=id,name,snr to limit fields, or ?exclude=position to drop fields.
        Use ?host=IP to identify the session without a session header.
        isFavorite is never included. 'online' = lastSeen/lastHeard within 15 minutes.
        """
        # export_enabled guard
        if raw_settings is not None:
            if not raw_settings.get('web', {}).get('export_enabled', True):
                raise HTTPException(status_code=403, detail="Node export is disabled in settings.")

        # Host-based session lookup (no session cookie/header required)
        if host and session_manager is not None:
            sid = session_manager.find_session_by_host_port(host, port or 4403)
            if not sid:
                raise HTTPException(status_code=404, detail=f"No active session found for {host}:{port or 4403}")
            session = await session_manager.get_session(sid)
            if not session:
                raise HTTPException(status_code=404, detail=f"Session {sid} not found or expired")

        if session is None:
            raise HTTPException(status_code=401, detail="No active session. Provide X-Session-ID header or ?host= param.")

        try:
            nodes = await session.gateway.get_node_list() or []

            # Determine which export fields to return
            if include:
                requested = [f.strip() for f in include.split(',') if f.strip()]
                fields = [f for f in requested if f in _EXPORT_ALL_FIELDS]
            else:
                fields = list(_EXPORT_ALL_FIELDS)

            if exclude:
                drop = {f.strip() for f in exclude.split(',') if f.strip()}
                fields = [f for f in fields if f not in drop]

            now = datetime.now(timezone.utc)
            cutoff = now - _ONLINE_WINDOW
            online_count = 0
            export_nodes = []

            for n in nodes:
                # Determine online status
                last = n.get('lastHeard') or n.get('lastSeen')
                is_online = False
                if last:
                    try:
                        if isinstance(last, (int, float)):
                            is_online = datetime.fromtimestamp(last, tz=timezone.utc) >= cutoff
                        else:
                            ts = datetime.fromisoformat(str(last).replace('Z', '+00:00'))
                            is_online = ts >= cutoff
                    except (ValueError, TypeError, OSError):
                        pass
                if is_online:
                    online_count += 1

                row = {}
                for f in fields:
                    actual_key = _EXPORT_FIELD_MAP.get(f, f)
                    val = n.get(actual_key)
                    if val is None:
                        val = n.get(f)
                    row[f] = val
                export_nodes.append(row)

            return {
                "summary": {
                    "total": len(export_nodes),
                    "online": online_count,
                    "timestamp": now.strftime('%Y-%m-%dT%H:%M:%SZ'),
                    "fields": fields,
                },
                "nodes": export_nodes,
            }
        except HTTPException:
            raise
        except Exception as e:
            logger.warning(f"Error exporting nodes: {e}")
            raise HTTPException(status_code=500, detail=str(e))

    # ---------------------------------------------------------------------------
    # Node device config read / write
    # ---------------------------------------------------------------------------

    @router.get("/node/device-config")
    async def get_device_config(session: Session = Depends(get_session_dep)):
        """Read the local node's full device configuration."""
        try:
            config = await session.gateway.get_device_config()
            if config is None:
                raise HTTPException(status_code=503, detail="Not connected or config unavailable")
            return {"success": True, "data": config}
        except HTTPException:
            raise
        except Exception as e:
            logger.warning(f"Error reading device config: {e}")
            raise HTTPException(status_code=500, detail=str(e))

    @router.post("/node/device-config")
    async def write_device_config(payload: dict, session: Session = Depends(get_session_dep)):
        """Write selected config sections to the local node, then reboot.

        Body: { "sections": ["owner","lora",...], "owner": {...}, "lora": {...}, ... }
        """
        try:
            sections = payload.get("sections", [])
            if not sections:
                raise HTTPException(status_code=400, detail="No sections specified")
            result = await session.gateway.write_device_config(sections, payload)
            if not result.get("success") and not result.get("written"):
                raise HTTPException(status_code=500, detail=result.get("error", "Write failed"))
            resp = {"success": True, "message": "Config written. Device rebooting in 5 seconds.", "written": result.get("written", [])}
            if result.get("errors"):
                resp["warnings"] = result["errors"]
            return resp
        except HTTPException:
            raise
        except Exception as e:
            logger.warning(f"Error writing device config: {e}")
            raise HTTPException(status_code=500, detail=str(e))

    @router.get("/nodes/{node_id}")
    async def get_node_detail(node_id: str, session: Session = Depends(get_session_dep)):
        """Get detailed information for a specific node."""
        try:
            nodes = await session.gateway.get_node_list()
            node = next((n for n in (nodes or []) if n.get('id') == node_id or n.get('num') == node_id), None)
            if node is None:
                raise HTTPException(status_code=404, detail=f"Node {node_id} not found")
            return MessageResponse(
                success=True,
                message="Node detail retrieved successfully",
                data={"node": node}
            )
        except HTTPException:
            raise
        except Exception as e:  # API safety net: HTTP 500
            logger.warning(f"Error getting node detail: {e}")
            raise HTTPException(status_code=500, detail=str(e))

    return router
