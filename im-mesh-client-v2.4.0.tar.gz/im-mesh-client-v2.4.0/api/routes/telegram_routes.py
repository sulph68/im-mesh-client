"""api/routes/telegram_routes.py — REST endpoints for Telegram integration management."""

import logging

from fastapi import APIRouter, HTTPException, Depends
from pydantic import BaseModel

from core.session_manager import Session
from api.models import MessageResponse
from core.path_utils import resolve_project_path
from core.network_utils import hosts_match
from telegram_forwarder.telegram_forwarder import (
    TelegramForwarder,
    list_conversation_configs, save_conversation_config, delete_conversation_config,
)

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/telegram", tags=["telegram"])


def _get_telegram_dir(tg_settings: dict) -> str:
    return resolve_project_path(tg_settings.get('directory', './telegram_forwarder'))


class ConversationConfigData(BaseModel):
    conversation_key: str
    label: str = ""
    chat_id: str
    enabled: bool = True
    direction: str = "all"           # all / sent / received
    filter_type: str = "all"         # all / regex
    filter_regex: str = ""
    include_nodes: list = []
    exclude_nodes: list = []


class TestMessageData(BaseModel):
    chat_id: str
    message: str = ""


def create_telegram_routes(get_session_dep, app_settings: dict) -> APIRouter:
    """Create Telegram management routes."""

    tg_settings = app_settings.get('telegram', {})

    @router.get("/global")
    async def get_global(session: Session = Depends(get_session_dep)):
        """Return host-applicability and enabled state for the Telegram button."""
        tg_host_raw = tg_settings.get('host', '127.0.0.1')
        tg_host = tg_host_raw.rsplit(':', 1)[0] if ':' in tg_host_raw else tg_host_raw
        session_host = getattr(getattr(session.settings, 'meshtastic', None), 'host', '') or ''
        applicable = hosts_match(tg_host, session_host)
        settings_enabled = bool(tg_settings.get('enabled', False))
        return MessageResponse(success=True, message="OK", data={
            "applicable": applicable,
            "settings_enabled": settings_enabled,
        })

    @router.get("/status")
    async def get_status(session: Session = Depends(get_session_dep)):
        """Get Telegram integration status."""
        token = tg_settings.get('bot_token', '')
        enabled = tg_settings.get('enabled', False)
        return MessageResponse(
            success=True,
            message="OK",
            data={
                "bot_token_configured": bool(token),
                "enabled": bool(enabled)
            }
        )

    @router.get("/conversations")
    async def list_conversations(session: Session = Depends(get_session_dep)):
        """List per-source Telegram conversation configs."""
        telegram_dir = _get_telegram_dir(tg_settings)
        configs = list_conversation_configs(telegram_dir)
        return MessageResponse(success=True, message="OK", data={"conversations": configs})

    @router.post("/conversations")
    async def create_conversation(
        data: ConversationConfigData,
        session: Session = Depends(get_session_dep)
    ):
        """Create or update a per-conversation Telegram config."""
        conv_key = data.conversation_key
        if not conv_key or '/' in conv_key or '\\' in conv_key or '..' in conv_key:
            raise HTTPException(status_code=400, detail="Invalid conversation key")
        telegram_dir = _get_telegram_dir(tg_settings)
        config = {
            "conversation_key": conv_key,
            "label": data.label,
            "chat_id": data.chat_id,
            "enabled": data.enabled,
            "direction": data.direction,
            "filter_type": data.filter_type,
            "filter_regex": data.filter_regex,
            "include_nodes": data.include_nodes,
            "exclude_nodes": data.exclude_nodes,
        }
        save_conversation_config(telegram_dir, config)
        return MessageResponse(success=True, message="Saved", data={"config": config})

    @router.delete("/conversations/{conv_key}")
    async def delete_conversation(conv_key: str, session: Session = Depends(get_session_dep)):
        """Delete a per-conversation Telegram config."""
        if not conv_key or '/' in conv_key or '\\' in conv_key or '..' in conv_key:
            raise HTTPException(status_code=400, detail="Invalid conversation key")
        telegram_dir = _get_telegram_dir(tg_settings)
        deleted = delete_conversation_config(telegram_dir, conv_key)
        if not deleted:
            raise HTTPException(status_code=404, detail="Config not found")
        return MessageResponse(success=True, message="Deleted", data={})

    @router.post("/test")
    async def test_telegram(
        data: TestMessageData,
        session: Session = Depends(get_session_dep)
    ):
        """Send a test message to a Telegram chat ID to verify bot connectivity."""
        bot_token = tg_settings.get('bot_token', '')
        if not bot_token:
            raise HTTPException(status_code=400, detail="No bot_token configured in settings.json")
        try:
            try:
                from telegram import Bot
            except ImportError:
                if TelegramForwarder._find_telegram_in_system():
                    from telegram import Bot
                else:
                    raise HTTPException(status_code=500, detail="python-telegram-bot not found in any Python installation on this system")
            test_text = data.message.strip() if data.message.strip() else "✅ Im Mesh Client — Telegram Forwarder test message. Connection successful!"
            async with Bot(token=bot_token) as bot:
                await bot.send_message(chat_id=data.chat_id, text=test_text)
            logger.info("Telegram test message sent to chat_id=%s", data.chat_id)
            return MessageResponse(success=True, message="Test message sent", data={})
        except HTTPException:
            raise
        except Exception as e:
            logger.error("Telegram test send error: %s", e)
            raise HTTPException(status_code=502, detail=f"Telegram error: {e}")

    return router
