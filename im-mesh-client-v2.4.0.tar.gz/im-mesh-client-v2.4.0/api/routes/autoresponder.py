"""api/routes/autoresponder.py — REST endpoints for auto responder management."""

import logging
import os
import re
import shutil

from fastapi import APIRouter, HTTPException, Depends
from pydantic import BaseModel
from typing import Optional

from core.session_manager import Session
from api.models import MessageResponse
from core.path_utils import resolve_project_path
from core.auto_responder_config import (
    enable_conversation, disable_conversation,
    ensure_conversation_folder, read_conversation,
    get_global_enabled, set_global_enabled,
    read_conv_config, write_conv_config,
    append_to_conversation, generate_rule_id,
)
from core.network_utils import is_local_host, hosts_match

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/autoresponder", tags=["autoresponder"])


def _get_ar_dir(ar_settings: dict) -> str:
    return resolve_project_path(ar_settings.get('working_directory', './auto_responder'))


def _safe_folder_name(name: str) -> str:
    if not name or '/' in name or '\\' in name or '..' in name:
        raise HTTPException(status_code=400, detail="Invalid folder name")
    return name


class CreateConversationData(BaseModel):
    folder_name: str
    label: str = ""
    trigger: str = "any"
    pattern: str = ""
    enabled: bool = True
    monitor_type: str = ""
    channel_idx: int = 0
    node_id: str = ""
    responder_mode: str = "eliza"
    fixed_response: str = ""


class ConvConfigData(BaseModel):
    label: str = ""
    trigger: str = "any"
    pattern: str = ""
    monitor_type: str = ""
    channel_idx: int = 0
    node_id: str = ""
    responder_mode: str = "eliza"
    fixed_response: str = ""


class TestTriggerData(BaseModel):
    message: str
    responder_mode: Optional[str] = None
    fixed_response: Optional[str] = None
    trigger: Optional[str] = None
    pattern: Optional[str] = None


class GlobalEnabledData(BaseModel):
    enabled: bool


def create_autoresponder_routes(get_session_dep, app_settings: dict, auto_responder=None) -> APIRouter:
    """Create auto responder management routes."""

    ar_settings = app_settings.get('auto_responder', {})

    @router.get("/global")
    async def get_global_status(session: Session = Depends(get_session_dep)):
        """Return enabled state and host-applicability for the Auto Responder button."""
        ar_host_raw = ar_settings.get('host', '127.0.0.1')
        ar_host = ar_host_raw.rsplit(':', 1)[0] if ':' in ar_host_raw else ar_host_raw
        session_host = getattr(getattr(session.settings, 'meshtastic', None), 'host', '') or ''
        applicable = hosts_match(ar_host, session_host)
        settings_enabled = bool(ar_settings.get('enabled', False))
        ar_dir = _get_ar_dir(ar_settings)
        runtime_enabled = get_global_enabled(ar_dir)

        return MessageResponse(success=True, message="OK", data={
            "applicable": applicable,
            "settings_enabled": settings_enabled,
            "enabled": runtime_enabled,
        })

    @router.put("/global")
    async def set_global(
        data: GlobalEnabledData,
        session: Session = Depends(get_session_dep)
    ):
        """Set the runtime global enabled state for the Auto Responder."""
        ar_dir = _get_ar_dir(ar_settings)
        set_global_enabled(ar_dir, data.enabled)
        return MessageResponse(success=True, message="Global state updated", data={"enabled": data.enabled})

    @router.get("/status")
    async def get_status(session: Session = Depends(get_session_dep)):
        return MessageResponse(success=True, message="OK", data={"status": "active"})

    @router.get("/conversations")
    async def list_conversations(session: Session = Depends(get_session_dep)):
        """List all configured auto-responder conversation folders."""
        ar_dir = _get_ar_dir(ar_settings)
        conversations = []
        if os.path.isdir(ar_dir):
            for name in sorted(os.listdir(ar_dir)):
                fpath = os.path.join(ar_dir, name)
                if not os.path.isdir(fpath):
                    continue
                disabled = name.endswith('_disabled')
                base = name.removesuffix('_disabled')
                fpath_for_config = fpath
                conv_config = read_conv_config(fpath_for_config)
                # has_responder: true if per-conv script OR global fallback script exists
                global_script = os.path.join(ar_dir, 'responder')
                has_per_conv = os.path.isfile(os.path.join(fpath, 'responder'))
                has_global = os.path.isfile(global_script)
                conversations.append({
                    "folder": base,
                    "raw_folder": name,
                    "enabled": not disabled,
                    "has_responder": has_per_conv or has_global,
                    "label": conv_config.get('label', ''),
                    "trigger": conv_config.get('trigger', 'any'),
                    "pattern": conv_config.get('pattern', ''),
                    "monitor_type": conv_config.get('monitor_type', ''),
                    "channel_idx": conv_config.get('channel_idx', 0),
                    "node_id": conv_config.get('node_id', ''),
                    "responder_mode": conv_config.get('responder_mode', 'eliza'),
                    "fixed_response": conv_config.get('fixed_response', ''),
                })
        return MessageResponse(success=True, message="OK", data={"conversations": conversations})

    @router.post("/conversations")
    async def create_conversation(
        data: CreateConversationData,
        session: Session = Depends(get_session_dep)
    ):
        """Create a new auto-responder conversation folder.

        The server appends an 8-char UUID suffix to the client-provided base name
        so that multiple rules can coexist for the same channel or node.
        """
        _safe_folder_name(data.folder_name)
        ar_dir = _get_ar_dir(ar_settings)
        # Append UUID suffix to make this rule unique even if same channel/node target
        folder_name = f"{data.folder_name}_{generate_rule_id()}"
        folder_path = ensure_conversation_folder(ar_dir, folder_name)
        # Save trigger config (includes label and extended fields)
        write_conv_config(folder_path, {
            'label': data.label, 'trigger': data.trigger, 'pattern': data.pattern,
            'monitor_type': data.monitor_type, 'channel_idx': data.channel_idx,
            'node_id': data.node_id, 'responder_mode': data.responder_mode,
            'fixed_response': data.fixed_response,
        })
        # If not enabled, immediately disable (rename to _disabled)
        if not data.enabled:
            disable_conversation(ar_dir, folder_name)
        return MessageResponse(success=True, message="Created", data={"folder": folder_name, "path": folder_path})

    @router.put("/conversations/{name}/enable")
    async def enable_conv(name: str, session: Session = Depends(get_session_dep)):
        _safe_folder_name(name)
        ar_dir = _get_ar_dir(ar_settings)
        enable_conversation(ar_dir, name)
        return MessageResponse(success=True, message="Enabled", data={"folder": name})

    @router.put("/conversations/{name}/disable")
    async def disable_conv(name: str, session: Session = Depends(get_session_dep)):
        _safe_folder_name(name)
        ar_dir = _get_ar_dir(ar_settings)
        disable_conversation(ar_dir, name)
        return MessageResponse(success=True, message="Disabled", data={"folder": name + '_disabled'})

    class RenameConversationData(BaseModel):
        new_name: str

    @router.post("/conversations/{name}/rename")
    async def rename_conversation(
        name: str,
        data: RenameConversationData,
        session: Session = Depends(get_session_dep)
    ):
        """Rename a conversation folder (changes the channel/node target)."""
        _safe_folder_name(name)
        _safe_folder_name(data.new_name)
        if name == data.new_name:
            return MessageResponse(success=True, message="No change", data={"folder": name})
        ar_dir = _get_ar_dir(ar_settings)
        # Find existing folder (may be _disabled)
        src_path = None
        is_disabled = False
        for suffix in ('', '_disabled'):
            candidate = os.path.join(ar_dir, name + suffix)
            if os.path.isdir(candidate):
                src_path = candidate
                is_disabled = suffix == '_disabled'
                break
        if not src_path:
            raise HTTPException(status_code=404, detail="Conversation not found")
        # Target folder name (preserve enabled/disabled state)
        dest_suffix = '_disabled' if is_disabled else ''
        dest_path = os.path.join(ar_dir, data.new_name + dest_suffix)
        if os.path.exists(dest_path):
            raise HTTPException(status_code=409, detail="Target conversation already exists")
        os.rename(src_path, dest_path)
        return MessageResponse(success=True, message="Renamed", data={"folder": data.new_name})


    @router.delete("/conversations/{name}")
    async def delete_conversation(name: str, session: Session = Depends(get_session_dep)):
        _safe_folder_name(name)
        ar_dir = _get_ar_dir(ar_settings)
        # Try both enabled and disabled forms
        for suffix in ('', '_disabled'):
            folder_path = os.path.join(ar_dir, name + suffix)
            if os.path.isdir(folder_path):
                shutil.rmtree(folder_path)
                return MessageResponse(success=True, message="Deleted", data={})
        raise HTTPException(status_code=404, detail="Conversation not found")

    @router.get("/conversations/{name}/config")
    async def get_conv_config(name: str, session: Session = Depends(get_session_dep)):
        _safe_folder_name(name)
        ar_dir = _get_ar_dir(ar_settings)
        for suffix in ('', '_disabled'):
            folder_path = os.path.join(ar_dir, name + suffix)
            if os.path.isdir(folder_path):
                config = read_conv_config(folder_path)
                return MessageResponse(success=True, message="OK", data=config)
        raise HTTPException(status_code=404, detail="Conversation not found")

    @router.put("/conversations/{name}/config")
    async def set_conv_config(
        name: str,
        data: ConvConfigData,
        session: Session = Depends(get_session_dep)
    ):
        _safe_folder_name(name)
        ar_dir = _get_ar_dir(ar_settings)
        for suffix in ('', '_disabled'):
            folder_path = os.path.join(ar_dir, name + suffix)
            if os.path.isdir(folder_path):
                write_conv_config(folder_path, {
                    'label': data.label, 'trigger': data.trigger, 'pattern': data.pattern,
                    'monitor_type': data.monitor_type, 'channel_idx': data.channel_idx,
                    'node_id': data.node_id, 'responder_mode': data.responder_mode,
                    'fixed_response': data.fixed_response,
                })
                return MessageResponse(success=True, message="Config saved", data={
                    'trigger': data.trigger, 'pattern': data.pattern,
                    'responder_mode': data.responder_mode,
                    'fixed_response': data.fixed_response,
                })
        raise HTTPException(status_code=404, detail="Conversation not found")

    @router.post("/conversations/{name}/test")
    async def test_trigger(
        name: str,
        data: TestTriggerData,
        session: Session = Depends(get_session_dep)
    ):
        """Simulate an incoming message to test the auto responder trigger + response.

        Optional override fields (responder_mode, fixed_response, trigger, pattern) allow
        testing unsaved form state without persisting to disk.
        """
        _safe_folder_name(name)
        if auto_responder is None:
            raise HTTPException(status_code=503, detail="Auto Responder not available")
        if not data.message.strip():
            raise HTTPException(status_code=400, detail="Message cannot be empty")

        # Locate conversation folder (enabled or disabled)
        ar_dir = _get_ar_dir(ar_settings)
        folder_path = None
        for suffix in ('', '_disabled'):
            fp = os.path.join(ar_dir, name + suffix)
            if os.path.isdir(fp):
                folder_path = fp
                break
        if folder_path is None:
            raise HTTPException(status_code=404, detail="Conversation not found")

        # Load saved config and apply any UI overrides from the request
        conv_config = read_conv_config(folder_path)
        if data.responder_mode is not None:
            conv_config['responder_mode'] = data.responder_mode
        if data.fixed_response is not None:
            conv_config['fixed_response'] = data.fixed_response
        if data.trigger is not None:
            conv_config['trigger'] = data.trigger
        if data.pattern is not None:
            conv_config['pattern'] = data.pattern

        # Check trigger (using the (possibly overridden) trigger config)
        message = data.message.strip()
        if conv_config.get('trigger') == 'regex':
            pattern = conv_config.get('pattern', '').strip()
            if pattern:
                try:
                    if not re.search(pattern, message, re.IGNORECASE):
                        return MessageResponse(
                            success=True,
                            message="Test complete",
                            data={"response": None, "triggered": False,
                                  "reason": "Regex pattern did not match"}
                        )
                except re.error as e:
                    raise HTTPException(status_code=400, detail=f"Invalid regex: {e}")

        # Write the test message to conversation.txt so script/eliza can read it,
        # then restore it afterwards to avoid polluting real history.
        effective_mode = conv_config.get('responder_mode', 'eliza')
        conv_path = os.path.join(folder_path, 'conversation.txt')
        lines_before = 0
        if effective_mode in ('script', 'eliza'):
            if os.path.isfile(conv_path):
                with open(conv_path, 'r', encoding='utf-8', errors='replace') as fh:
                    lines_before = sum(1 for _ in fh)
            append_to_conversation(folder_path, 'test_user', message,
                                   auto_responder._history_context)

        # Invoke the responder with the (possibly overridden) config
        logger.info("AR test: mode=%s conv=%s msg=%r", effective_mode, name, message)
        response_parts = await auto_responder._invoke(folder_path, conv_config, incoming_message=message)

        # Restore conversation.txt — remove the temporary test line(s)
        if effective_mode in ('script', 'eliza') and os.path.isfile(conv_path):
            try:
                with open(conv_path, 'r', encoding='utf-8', errors='replace') as fh:
                    all_lines = fh.readlines()
                with open(conv_path, 'w', encoding='utf-8') as fh:
                    fh.writelines(all_lines[:lines_before])
            except Exception as e:
                logger.warning("AR test: could not restore conversation.txt: %s", e)

        # Flatten list of parts back to a single display string for the test UI
        response = '\n'.join(response_parts) if response_parts else None
        return MessageResponse(
            success=True,
            message="Test complete",
            data={"response": response, "triggered": response is not None,
                  "parts": response_parts}
        )

    @router.get("/conversations/{name}/log")
    async def get_log(name: str, session: Session = Depends(get_session_dep)):
        _safe_folder_name(name)
        ar_dir = _get_ar_dir(ar_settings)
        # Check both enabled and disabled
        for suffix in ('', '_disabled'):
            folder_path = os.path.join(ar_dir, name + suffix)
            if os.path.isdir(folder_path):
                content = read_conversation(folder_path)
                return MessageResponse(success=True, message="OK", data={"log": content})
        raise HTTPException(status_code=404, detail="Conversation not found")

    @router.delete("/conversations/{name}/log")
    async def clear_log(name: str, session: Session = Depends(get_session_dep)):
        _safe_folder_name(name)
        ar_dir = _get_ar_dir(ar_settings)
        for suffix in ('', '_disabled'):
            folder_path = os.path.join(ar_dir, name + suffix)
            if os.path.isdir(folder_path):
                log_path = os.path.join(folder_path, 'conversation.txt')
                if os.path.exists(log_path):
                    os.remove(log_path)
                return MessageResponse(success=True, message="Log cleared", data={})
        raise HTTPException(status_code=404, detail="Conversation not found")

    return router
