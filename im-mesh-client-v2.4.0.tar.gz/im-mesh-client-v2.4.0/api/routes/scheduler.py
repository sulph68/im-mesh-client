"""api/routes/scheduler.py — REST endpoints for scheduled message management."""

import logging
import os
from typing import Any, Optional, Union

from fastapi import APIRouter, HTTPException, Depends
from pydantic import BaseModel, field_validator, model_validator

from core.session_manager import Session
from api.models import MessageResponse
from core.path_utils import resolve_project_path
from core.network_utils import hosts_match
from core.scheduler_config import (
    load_all_entries, create_entry, save_entry, delete_entry,
    get_global_enabled, set_global_enabled,
)

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/scheduler", tags=["scheduler"])


def _get_sched_root(settings: dict) -> str:
    """Return the sched_messages root directory, respecting working_directory if set."""
    wd = settings.get('working_directory', '').strip()
    if wd:
        return resolve_project_path(wd)
    return resolve_project_path(settings.get('config_dir', './sched_messages'))


def _get_config_dir(settings: dict) -> str:
    """Resolve the sched_messages config directory from settings."""
    return os.path.join(_get_sched_root(settings), 'config')


def _get_commands_dir(settings: dict) -> str:
    wd = settings.get('working_directory', '').strip()
    if wd:
        return os.path.join(resolve_project_path(wd), 'commands')
    return resolve_project_path(settings.get('commands', './sched_messages/commands'))


_SCHED_FIELDS = ("minute", "hour", "day_of_month", "day_of_week")
_SCHED_DEFAULT = {"minute": "0", "hour": "9", "day_of_month": "*", "day_of_week": "*"}


def _normalise_schedule(v: Any) -> dict:
    """Accept schedule as dict, list[str], or space-separated string → dict."""
    if isinstance(v, dict):
        return v
    if isinstance(v, list):
        parts = [str(x) for x in v]
    elif isinstance(v, str):
        parts = v.split()
    else:
        return _SCHED_DEFAULT.copy()
    padded = (parts + ["*", "*", "*", "*"])[:4]
    return dict(zip(_SCHED_FIELDS, padded))


class EntryData(BaseModel):
    enabled: bool = True
    label: str = ""
    name: str = ""  # kept for backward compatibility; label takes precedence in UI
    schedule: Union[dict, list, str] = _SCHED_DEFAULT
    type: str = "message"
    message: str = ""
    command: str = ""
    to_node: Optional[str] = None
    channel: int = 0
    portnum: int = 1
    port: Optional[int] = None  # JS sends 'port'; accepted as alias for portnum

    @field_validator("schedule", mode="before")
    @classmethod
    def coerce_schedule(cls, v: Any) -> dict:
        return _normalise_schedule(v)

    @model_validator(mode="after")
    def coerce_port(self) -> "EntryData":
        """If JS sent 'port' instead of 'portnum', honour it."""
        if self.port is not None:
            self.portnum = self.port
        return self


class GlobalEnabledData(BaseModel):
    enabled: bool


def create_scheduler_routes(get_session_dep, app_settings: dict, scheduler=None) -> APIRouter:
    """Create scheduler management routes."""

    sched_settings = app_settings.get('sched_message', {})

    @router.get("/entries")
    async def list_entries(session: Session = Depends(get_session_dep)):
        config_dir = _get_config_dir(sched_settings)
        entries = load_all_entries(config_dir)
        return MessageResponse(success=True, message="OK", data={"entries": entries})

    @router.post("/entries")
    async def create_entry_endpoint(
        data: EntryData,
        session: Session = Depends(get_session_dep)
    ):
        config_dir = _get_config_dir(sched_settings)
        entry = create_entry(config_dir, data.model_dump())
        return MessageResponse(success=True, message="Entry created", data={"entry": entry})

    @router.put("/entries/{entry_id}")
    async def update_entry(
        entry_id: str,
        data: EntryData,
        session: Session = Depends(get_session_dep)
    ):
        config_dir = _get_config_dir(sched_settings)
        entries = load_all_entries(config_dir)
        existing = next((e for e in entries if e.get('id') == entry_id), None)
        if not existing:
            raise HTTPException(status_code=404, detail="Entry not found")
        updated = {**existing, **data.model_dump(), "id": entry_id}
        save_entry(config_dir, updated)
        return MessageResponse(success=True, message="Entry updated", data={"entry": updated})

    @router.delete("/entries/{entry_id}")
    async def delete_entry_endpoint(
        entry_id: str,
        session: Session = Depends(get_session_dep)
    ):
        config_dir = _get_config_dir(sched_settings)
        deleted = delete_entry(config_dir, entry_id)
        if not deleted:
            raise HTTPException(status_code=404, detail="Entry not found")
        return MessageResponse(success=True, message="Entry deleted", data={})

    @router.post("/entries/{entry_id}/run")
    async def run_entry_now(
        entry_id: str,
        session: Session = Depends(get_session_dep)
    ):
        """Immediately fire a scheduled entry (Run Now)."""
        config_dir = _get_config_dir(sched_settings)
        entries = load_all_entries(config_dir)
        entry = next((e for e in entries if e.get('id') == entry_id), None)
        if not entry:
            raise HTTPException(status_code=404, detail="Entry not found")
        if scheduler is None:
            raise HTTPException(status_code=503, detail="Scheduler not available")
        await scheduler._fire(entry)
        label = entry.get('label') or entry.get('id', entry_id)
        return MessageResponse(success=True, message=f"Entry '{label}' fired", data={"entry_id": entry_id})

    @router.get("/global")
    async def get_global(session: Session = Depends(get_session_dep)):
        config_dir = _get_config_dir(sched_settings)
        enabled = get_global_enabled(config_dir)

        sched_host_raw = sched_settings.get('host', '127.0.0.1')
        # Strip port component if present
        sched_host = sched_host_raw.rsplit(':', 1)[0] if ':' in sched_host_raw else sched_host_raw
        session_host = getattr(getattr(session.settings, 'meshtastic', None), 'host', '') or ''
        applicable = hosts_match(sched_host, session_host)
        settings_enabled = bool(sched_settings.get('enabled', False))

        return MessageResponse(success=True, message="OK", data={
            "enabled": enabled,
            "applicable": applicable,
            "settings_enabled": settings_enabled,
        })

    @router.put("/global")
    async def set_global(
        data: GlobalEnabledData,
        session: Session = Depends(get_session_dep)
    ):
        config_dir = _get_config_dir(sched_settings)
        set_global_enabled(config_dir, data.enabled)
        return MessageResponse(success=True, message="Global state updated", data={"enabled": data.enabled})

    @router.get("/commands")
    async def list_commands(session: Session = Depends(get_session_dep)):
        commands_dir = _get_commands_dir(sched_settings)
        commands = []
        if os.path.isdir(commands_dir):
            for fname in os.listdir(commands_dir):
                if '/' in fname or '\\' in fname:
                    continue
                fpath = os.path.join(commands_dir, fname)
                if os.path.isfile(fpath) and os.access(fpath, os.X_OK):
                    commands.append(fname)
        return MessageResponse(success=True, message="OK", data={"commands": commands})

    return router
