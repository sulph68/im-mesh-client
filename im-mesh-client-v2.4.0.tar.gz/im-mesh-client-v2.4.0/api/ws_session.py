"""
WebSocket session lifecycle mixin for WebSocketAPI.

Contains auth negotiation, client message handling, session status,
and buffered message flushing — the per-connection lifecycle steps.
"""

import re
import json
import logging
from typing import Optional
from fastapi import WebSocket, WebSocketDisconnect
from datetime import datetime

from core.session_manager import Session

logger = logging.getLogger(__name__)

_UUID_RE = re.compile(r'^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$', re.IGNORECASE)


class WebSocketSessionMixin:
    """Mixin providing session lifecycle methods for WebSocketAPI."""

    async def _negotiate_auth(self, websocket: WebSocket) -> Optional[str]:
        """
        Negotiate session authentication from the first WebSocket message.
        
        Returns:
            Validated session_id string, or None if auth failed (connection closed).
        """
        try:
            data = await websocket.receive_text()
            message = json.loads(data)
            
            if message.get('type') != 'auth' or 'session_id' not in message:
                await websocket.send_text(json.dumps({
                    'type': 'error',
                    'message': 'Authentication required: send session_id'
                }))
                await websocket.close()
                return None
            
            sid = message['session_id']
            
            if not isinstance(sid, str) or not _UUID_RE.match(sid):
                await websocket.send_text(json.dumps({
                    'type': 'error',
                    'message': 'Invalid session ID format'
                }))
                await websocket.close()
                return None
            
            return sid
            
        except (json.JSONDecodeError, KeyError):
            await websocket.send_text(json.dumps({
                'type': 'error',
                'message': 'Invalid authentication message'
            }))
            await websocket.close()
            return None
        except (WebSocketDisconnect, Exception) as e:
            logger.info(f"WebSocket disconnected during auth: {e}")
            return None

    async def _flush_buffered_messages(self, session: Session, session_id: str):
        """
        Deliver buffered messages that arrived while no WebSocket was connected.
        
        The MessageRouter keeps a rolling buffer of recent messages. When a new
        WebSocket connects, we send any buffered text/binary/ack messages that
        arrived after the last successful WebSocket delivery, so the client
        receives messages it missed during disconnection.
        Also delivers any scheduled messages cached while the browser was offline.
        """
        try:
            message_router = session.gateway.message_router
            
            # Get messages since the last successful WS send for this session
            since = self._last_ws_send_time.get(session_id)
            if since:
                buffered = message_router.get_messages_since(since)
            else:
                # No previous WS delivery tracked - send ALL buffered messages.
                # The buffer is capped at 200 messages, so this is bounded.
                buffered = list(message_router._recent_messages)
            
            # Filter to user-facing message types only.
            user_types = ('text', 'binary', 'ack')
            user_msgs = [m for m in buffered if m.get('message_type') in user_types]
            
            # Map message_type to WS type (same mapping as subscriptions)
            type_map = {
                'text': 'message',
                'binary': 'message',
                'ack': 'ack',
            }
            
            if user_msgs:
                logger.info(f"Flushing {len(user_msgs)} buffered messages to session {session_id}")
                for msg in user_msgs:
                    ws_type = type_map.get(msg.get('message_type'), 'message')
                    await self._send_to_session(session_id, {
                        'type': ws_type,
                        'data': msg
                    })
            
            # Flush scheduled message history cache (messages sent while browser was offline)
            if self.scheduler:
                sched_history = self.scheduler.get_history_and_drain(session_id)
                if sched_history:
                    logger.info(f"Flushing {len(sched_history)} cached scheduled messages to session {session_id}")
                    await self._send_to_session(session_id, {
                        'type': 'scheduled_history',
                        'data': {'messages': sched_history},
                    })

            # Flush AR message history cache (responses sent while browser was offline)
            ar_history = self._drain_ar_history(session_id)
            if ar_history:
                logger.info(f"Flushing {len(ar_history)} cached AR messages to session {session_id}")
                await self._send_to_session(session_id, {
                    'type': 'ar_history',
                    'data': {'messages': ar_history},
                })

            # Flush assembled image_complete events buffered while browser was offline
            image_history = message_router.get_image_complete_history()
            if image_history:
                logger.info(f"Flushing {len(image_history)} cached image_complete events to session {session_id}")
                for img_msg in image_history:
                    await self._send_to_session(session_id, {
                        'type': 'image_complete',
                        'data': img_msg,
                    })

        except (KeyError, TypeError, ValueError) as e:
            logger.warning(f"Error flushing buffered messages: {e}")
    
    async def _handle_client_messages(self, websocket: WebSocket, session: Session):
        """Handle messages from WebSocket client."""
        while True:
            try:
                data = await websocket.receive_text()
                message = json.loads(data)
                
                message_type = message.get('type')
                
                if message_type == 'ping':
                    # Respond to ping
                    await websocket.send_text(json.dumps({
                        'type': 'pong',
                        'timestamp': datetime.now().isoformat()
                    }))
                
                elif message_type == 'request_update':
                    # Send current session status
                    await self._send_session_status(websocket, session)
                
                elif message_type == 'subscribe':
                    # Handle subscription requests
                    event_type = message.get('event')
                    if event_type:
                        logger.info(f"WebSocket subscribed to {event_type} for session {session.id}")
                
                else:
                    logger.warning(f"Unknown WebSocket message type: {message_type}")
                
            except json.JSONDecodeError:
                logger.warning("Invalid JSON received from WebSocket client")
            except WebSocketDisconnect:
                logger.info(f"WebSocket client disconnected for session {session.id}")
                break
            except (ConnectionError, RuntimeError) as e:
                # Code 1000 = normal close, not an error
                if '1000' in str(e) or '1001' in str(e):
                    logger.info(f"WebSocket closed normally for session {session.id}")
                else:
                    logger.warning(f"Error handling WebSocket message: {e}")
                break
    
    async def _send_session_status(self, websocket: WebSocket, session: Session):
        """Send current session status to WebSocket client."""
        try:
            # Get current session status
            connection_status = await session.gateway.get_connection_status()
            stats = await session.gateway.get_stats()
            
            await websocket.send_text(json.dumps({
                'type': 'status_update',
                'data': {
                    'session_id': session.id,
                    'connection': connection_status,
                    'stats': stats,
                    'timestamp': datetime.now().isoformat()
                }
            }))
            
        except (ConnectionError, RuntimeError, TypeError) as e:
            logger.warning(f"Error sending session status: {e}")
