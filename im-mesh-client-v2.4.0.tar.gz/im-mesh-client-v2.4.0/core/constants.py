"""
Shared constants and utilities for Meshtastic Web Client.
"""


# Default connection settings
DEFAULT_MESHTASTIC_PORT = 4403
DEFAULT_WEB_PORT = 8082

# Timing constants (seconds)
CONNECTION_SETTLE_DELAY = 3     # Wait after TCP connect for handshake
NODE_POPULATE_DELAY = 5         # Wait for node list to populate
RECONNECT_INTERVAL = 10         # Delay between reconnect attempts
CONNECTION_CHECK_INTERVAL = 5   # Health check interval when connected
SESSION_COOKIE_MAX_AGE = 86400  # 24 hours

# Radio send pacing (seconds).
# Minimum delay between consecutive sendText/sendData calls to the firmware.
# The LoRa radio is half-duplex; sending a new packet while the firmware is
# still retransmitting the previous one (wantAck cycle) causes the new packet
# to be silently dropped or queued behind retransmits.  A 2-second gap gives
# the firmware time to complete one TX+ACK cycle before we hand it the next
# packet.  This is enforced server-side in Gateway regardless of how fast the
# frontend queues messages.
MIN_SEND_INTERVAL = 5.0  # seconds between consecutive sends

# Image segment constraints
MIN_SEGMENT_LENGTH = 200
MAX_SEGMENT_LENGTH = 300
DEFAULT_SEGMENT_LENGTH = 200

# Message character limit (maximum chars per Meshtastic text message on most presets).
DEFAULT_CHAR_LIMIT = 220

# Runtime config clamp ranges (used in channels route and Gateway setters)
NODE_REFRESH_MIN =  5      # minutes
NODE_REFRESH_MAX = 60      # minutes
MSG_DELAY_MIN    =  1.0    # seconds
MSG_DELAY_MAX    = 30.0    # seconds
SEG_DELAY_MIN    =  5      # seconds
SEG_DELAY_MAX    = 60      # seconds
CHAR_LIMIT_MIN   = 100     # bytes
CHAR_LIMIT_MAX   = 230     # bytes


# Meshtastic port number constants
# See: https://docs.rs/meshtastic_protobufs/latest/meshtastic_protobufs/meshtastic/enum.PortNum.html
class PortNum:
    """Meshtastic application port numbers."""
    UNKNOWN_APP = 0
    TEXT_MESSAGE_APP = 1
    REMOTE_HARDWARE_APP = 2
    POSITION_APP = 3
    NODEINFO_APP = 4
    ROUTING_APP = 5
    ADMIN_APP = 6
    TEXT_MESSAGE_COMPRESSED_APP = 7
    WAYPOINT_APP = 8
    AUDIO_APP = 9
    DETECTION_SENSOR_APP = 10
    ALERT_APP = 11
    KEY_VERIFICATION_APP = 12
    REPLY_APP = 32
    IP_TUNNEL_APP = 33
    PAXCOUNTER_APP = 34
    SERIAL_APP = 64
    STORE_FORWARD_APP = 65
    RANGE_TEST_APP = 66
    TELEMETRY_APP = 67
    ZPS_APP = 68
    SIMULATOR_APP = 69
    TRACEROUTE_APP = 70
    NEIGHBORINFO_APP = 71
    ATAK_PLUGIN = 72
    MAP_REPORT_APP = 73
    POWERSTRESS_APP = 74
    RETICULUM_TUNNEL_APP = 76
    PRIVATE_APP = 256
    ATAK_FORWARDER = 257
    MAX_APP = 511
    CUSTOM_IMAGE_APP = 288       # Custom portnum for image segments


# --- Portnum classification for packet filtering ---

# Always process immediately: user-facing messages and ACKs
ALWAYS_PROCESS_PORTNUMS = frozenset({
    PortNum.TEXT_MESSAGE_APP,      # 1   - text messages
    PortNum.ROUTING_APP,           # 5   - ACK/NAK tracking (essential)
    PortNum.CUSTOM_IMAGE_APP,      # 288 - custom image segments
})

# Always ignore: portnums with no user-facing value for this UI
IGNORED_PORTNUMS = frozenset({
    PortNum.ADMIN_APP,                    # 6
    PortNum.TEXT_MESSAGE_COMPRESSED_APP,   # 7  - firmware auto-decompresses to portnum 1
    PortNum.WAYPOINT_APP,                 # 8
    PortNum.AUDIO_APP,                    # 9
    PortNum.DETECTION_SENSOR_APP,         # 10
    PortNum.ALERT_APP,                    # 11
    PortNum.KEY_VERIFICATION_APP,         # 12
    PortNum.REPLY_APP,                    # 32
    PortNum.IP_TUNNEL_APP,                # 33
    PortNum.PAXCOUNTER_APP,               # 34
    PortNum.SERIAL_APP,                   # 64
    PortNum.STORE_FORWARD_APP,            # 65 - store & forward protocol, not user messages
    PortNum.RANGE_TEST_APP,               # 66
    PortNum.ZPS_APP,                      # 68 - position estimation, not messaging
    PortNum.SIMULATOR_APP,                # 69
    PortNum.TRACEROUTE_APP,               # 70
    PortNum.NEIGHBORINFO_APP,             # 71
    PortNum.ATAK_PLUGIN,                  # 72
    PortNum.MAP_REPORT_APP,               # 73
    PortNum.POWERSTRESS_APP,              # 74
    PortNum.RETICULUM_TUNNEL_APP,         # 76
    PortNum.PRIVATE_APP,                  # 256 - generic private app, not our image protocol
    PortNum.ATAK_FORWARDER,               # 257
})

# Rate-limited: node info portnums only processed after node refresh interval
RATE_LIMITED_PORTNUMS = frozenset({
    PortNum.REMOTE_HARDWARE_APP,   # 2  - remote hardware info
    PortNum.POSITION_APP,          # 3  - position updates
    PortNum.NODEINFO_APP,          # 4  - node info broadcasts
    PortNum.TELEMETRY_APP,         # 67 - device telemetry
})


# String-to-int mapping for pypubsub portnum conversion
PORTNUM_MAP = {
    'UNKNOWN_APP': PortNum.UNKNOWN_APP,
    'TEXT_MESSAGE_APP': PortNum.TEXT_MESSAGE_APP,
    'REMOTE_HARDWARE_APP': PortNum.REMOTE_HARDWARE_APP,
    'POSITION_APP': PortNum.POSITION_APP,
    'NODEINFO_APP': PortNum.NODEINFO_APP,
    'ROUTING_APP': PortNum.ROUTING_APP,
    'ADMIN_APP': PortNum.ADMIN_APP,
    'TEXT_MESSAGE_COMPRESSED_APP': PortNum.TEXT_MESSAGE_COMPRESSED_APP,
    'WAYPOINT_APP': PortNum.WAYPOINT_APP,
    'AUDIO_APP': PortNum.AUDIO_APP,
    'DETECTION_SENSOR_APP': PortNum.DETECTION_SENSOR_APP,
    'ALERT_APP': PortNum.ALERT_APP,
    'KEY_VERIFICATION_APP': PortNum.KEY_VERIFICATION_APP,
    'REPLY_APP': PortNum.REPLY_APP,
    'IP_TUNNEL_APP': PortNum.IP_TUNNEL_APP,
    'PAXCOUNTER_APP': PortNum.PAXCOUNTER_APP,
    'SERIAL_APP': PortNum.SERIAL_APP,
    'STORE_FORWARD_APP': PortNum.STORE_FORWARD_APP,
    'RANGE_TEST_APP': PortNum.RANGE_TEST_APP,
    'TELEMETRY_APP': PortNum.TELEMETRY_APP,
    'ZPS_APP': PortNum.ZPS_APP,
    'SIMULATOR_APP': PortNum.SIMULATOR_APP,
    'TRACEROUTE_APP': PortNum.TRACEROUTE_APP,
    'NEIGHBORINFO_APP': PortNum.NEIGHBORINFO_APP,
    'ATAK_PLUGIN': PortNum.ATAK_PLUGIN,
    'MAP_REPORT_APP': PortNum.MAP_REPORT_APP,
    'POWERSTRESS_APP': PortNum.POWERSTRESS_APP,
    'RETICULUM_TUNNEL_APP': PortNum.RETICULUM_TUNNEL_APP,
    'PRIVATE_APP': PortNum.PRIVATE_APP,
    'ATAK_FORWARDER': PortNum.ATAK_FORWARDER,
    'CUSTOM_IMAGE_APP': PortNum.CUSTOM_IMAGE_APP,
}


# Broadcast address constant
BROADCAST_ADDR_HEX = 'FFFFFFFF'
BROADCAST_ADDR_INT = 4294967295  # 0xFFFFFFFF


def normalize_node_id(node_id) -> str:
    """Normalize a node ID to the canonical '!{8-char hex}' format.

    Handles int, string with/without '!' prefix, and passthrough for
    already-normalized values.

    Args:
        node_id: Node ID as int, hex string, or '!hex' string.

    Returns:
        Normalized string like '!3d8309d0', or the original string
        if it cannot be converted.
    """
    if node_id is None:
        return ''
    if isinstance(node_id, int):
        return f"!{node_id:08x}"
    s = str(node_id)
    # Already normalized
    if s.startswith('!') and len(s) == 9:
        return s.lower()
    # Hex string without '!' prefix
    if s.startswith('!'):
        return s.lower()
    # Try to parse as hex
    try:
        return f"!{int(s, 16):08x}"
    except (ValueError, TypeError):
        pass
    # Try to parse as decimal int string
    try:
        return f"!{int(s):08x}"
    except (ValueError, TypeError):
        return s


# Message router constants
MAX_RECENT_MESSAGES = 200  # Rolling buffer size for recent messages


# Frontend-equivalent timing constants (documented for cross-reference)
# These mirror the values in app_core.js constructor:
#   _messageQueueDelay = 3000ms, _wsReconnectDelay = 10000ms,
#   _heartbeatIntervalMs = 30000ms, _statsRefreshMs = 60000ms


def is_broadcast(to_node) -> bool:
    """Check if a destination address is a broadcast.
    
    Args:
        to_node: Destination node ID (str, int, or None)
        
    Returns:
        True if the destination is broadcast (None, ^ffffffff, or 4294967295)
    """
    if to_node is None:
        return True
    to_str = str(to_node).upper().lstrip('!')
    return to_str == BROADCAST_ADDR_HEX or to_str == str(BROADCAST_ADDR_INT)
