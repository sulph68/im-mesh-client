"""
Thin wrapper around nltk.chat.eliza for the Auto Responder Eliza fallback.

Usage:
    from core.eliza_chatbot import eliza_respond
    reply = eliza_respond("I am feeling sad")

Requires: nltk>=3.8  (pip install nltk)
The eliza_chatbot object is from nltk.chat.eliza and uses nltk.chat.util.Chat.
"""


def eliza_respond(text: str) -> str:
    """
    Generate an Eliza 1966 response to the given input text.

    Args:
        text: User input string.

    Returns:
        Eliza's response as a string, or a default message if unavailable.
    """
    try:
        from nltk.chat.eliza import eliza_chatbot
        response = eliza_chatbot.respond(text)
        return response if response else "Please tell me more."
    except ImportError:
        return "Please tell me more."
