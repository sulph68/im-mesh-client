"""
Node and channel data extraction mixin for MeshtasticClientReal.

Provides methods for querying node info, channel config, device settings,
and helper methods for extracting data from Meshtastic protobuf/dict structures.

This is a mixin class - it accesses self.interface, self.connected, self.host,
self.port, self.my_node_info, self.nodes_db, self.channels_db via the host class.
"""

import asyncio
import base64
import logging
from typing import Optional, Dict, Any, List

logger = logging.getLogger(__name__)


class NodeDataMixin:
    """Mixin providing node/channel data extraction and query methods."""

    # ----- Static helpers for extracting data from Meshtastic node structures -----

    @staticmethod
    def _safe_get(obj, key, default=None):
        """Safely get a value from a dict or object attribute."""
        if isinstance(obj, dict):
            return obj.get(key, default)
        return getattr(obj, key, default)

    @classmethod
    def _extract_user_info(cls, node_info) -> dict:
        """Extract user info (longName, shortName, hwModel) from a node_info structure.

        Handles both dict and protobuf object formats.
        Returns dict with keys: longName, shortName, hwModel (may be None).
        """
        result = {'longName': None, 'shortName': None, 'hwModel': 'Unknown'}

        user = cls._safe_get(node_info, 'user')
        if user:
            for key in ('longName', 'shortName', 'hwModel'):
                val = cls._safe_get(user, key)
                if val is not None:
                    result[key] = val

        # Fallback: direct attributes on node_info
        for key in ('longName', 'shortName', 'hwModel'):
            if result[key] is None or (key == 'hwModel' and result[key] == 'Unknown'):
                val = cls._safe_get(node_info, key)
                if val is not None:
                    result[key] = val

        return result

    @classmethod
    def _extract_sub_dict(cls, node_info, sub_key: str, attrs: list) -> dict:
        """Extract a sub-dictionary (e.g. 'position', 'deviceMetrics') from node_info.

        Handles dict, protobuf object, and None cases.
        Returns dict of non-None values, or empty dict.
        """
        sub = cls._safe_get(node_info, sub_key)
        if not sub:
            return {}
        result = {}
        for attr in attrs:
            val = cls._safe_get(sub, attr)
            if val is not None:
                result[attr] = val
        return result

    @classmethod
    def _extract_scalar_attrs(cls, node_info, attrs: list) -> dict:
        """Extract scalar top-level attributes from node_info.

        Returns dict of non-None values.
        """
        result = {}
        for attr in attrs:
            val = cls._safe_get(node_info, attr)
            if val is not None:
                result[attr] = val
        return result

    # ----- PSK encoding -----

    @staticmethod
    def _encode_psk(psk) -> Optional[str]:
        """Safely encode a PSK value to base64 string."""
        if psk is None:
            return None
        try:
            if isinstance(psk, bytes):
                return base64.b64encode(psk).decode('ascii')
            elif isinstance(psk, str):
                psk.encode('utf-8')  # Verify valid UTF-8
                return psk
        except (UnicodeDecodeError, UnicodeEncodeError):
            pass
        # Fallback: force to base64
        if isinstance(psk, str):
            return base64.b64encode(psk.encode('latin-1')).decode('ascii')
        return base64.b64encode(bytes(psk)).decode('ascii')

    # ----- Channel processing -----

    def _process_channel(self, index: int, channel) -> Dict[str, Any]:
        """Extract and normalize a single channel's data."""
        channel_data = {
            'index': index,
            'name': f"Channel {index}",
            'id': getattr(channel, 'id', None),
            'uplink': getattr(channel, 'uplink', False),
            'downlink': getattr(channel, 'downlink', False),
        }

        if hasattr(channel, 'settings') and channel.settings:
            settings = channel.settings

            # Resolve name: settings > channel-level > default
            settings_name = getattr(settings, 'name', '')
            channel_name = getattr(channel, 'name', '')
            if settings_name:
                channel_data['name'] = settings_name
            elif channel_name:
                channel_data['name'] = channel_name

            channel_data.update({
                'psk': self._encode_psk(getattr(settings, 'psk', None)),
                'modemPreset': getattr(settings, 'modemPreset', None),
                'id': getattr(settings, 'id', channel_data['id']),
                'uplink': getattr(settings, 'uplink_enabled', channel_data['uplink']),
                'downlink': getattr(settings, 'downlink_enabled', channel_data['downlink']),
            })

        # Determine role: Primary (idx 0), Secondary (configured), Unconfigured
        has_name = channel_data['name'] != f"Channel {index}"
        has_psk = channel_data.get('psk') and channel_data['psk'] not in ['', 'AQ==']

        if index == 0:
            channel_data['role'] = 'Primary'
        elif has_name or has_psk:
            channel_data['role'] = 'Secondary'
        else:
            channel_data['role'] = 'Unconfigured'

        return channel_data

    # ----- Node data building -----

    def _build_node_data(self, node_id: str, node_info) -> Dict[str, Any]:
        """Build a normalized node data dict from raw interface node info."""
        node_data = {'id': node_id, 'num': node_id}

        # Names
        user_info = self._extract_user_info(node_info)
        long_name = user_info['longName']
        short_name = user_info['shortName']
        node_data['name'] = long_name or short_name or f"Node-{node_id}"
        node_data['shortName'] = short_name
        node_data['longName'] = long_name

        # Scalar attributes (snr, rssi, lastHeard, etc.)
        scalars = self._extract_scalar_attrs(node_info,
            ['snr', 'rssi', 'lastHeard', 'lastSeen', 'hopsAway', 'role',
             'hwModel', 'hwModelString', 'batteryLevel', 'voltage'])
        node_data.update(scalars)

        # Role fallback from user sub-dict
        hw_model = user_info.get('hwModel', 'Unknown')
        if 'role' not in node_data:
            user = self._safe_get(node_info, 'user')
            if user:
                role = self._safe_get(user, 'role')
                if role is not None:
                    node_data['role'] = role

        # Position data
        pos_data = self._extract_sub_dict(node_info, 'position',
            ['latitude', 'longitude', 'altitude', 'time', 'locationSource'])
        if pos_data:
            node_data['position'] = pos_data

        # Device metrics with top-level backward compat
        met_data = self._extract_sub_dict(node_info, 'deviceMetrics',
            ['batteryLevel', 'voltage', 'channelUtilization', 'airUtilTx', 'uptimeSeconds'])
        if met_data:
            node_data['deviceMetrics'] = met_data
            for key in ('batteryLevel', 'voltage'):
                if key in met_data:
                    node_data[key] = met_data[key]

        # Normalize lastHeard / lastSeen
        if 'lastHeard' in node_data:
            node_data['lastSeen'] = node_data['lastHeard']
        elif 'lastSeen' in node_data:
            node_data['lastHeard'] = node_data['lastSeen']

        # Hardware model and favorites
        node_data['hwModel'] = hw_model
        node_data['hwModelString'] = hw_model
        node_data['isFavorite'] = self._safe_get(node_info, 'isFavorite', False)

        return node_data

    # ----- Query methods -----

    async def get_node_info(self) -> Dict[str, Any]:
        """Get information about the connected node.

        Priority order for data sources:
        1. my_node_info if it is a full node dict (from interface.getMyNodeInfo())
        2. interface.nodes lookup by node number
        3. nodes_db lookup (already-processed cache)

        Acquires _interface_lock to prevent concurrent interface access.
        """
        try:
            if not self.interface or not self.connected:
                return {'connected': False, 'host': self.host, 'port': self.port}

            async with self._interface_lock:
                node_info: Dict[str, Any] = {
                    'connected': True,
                    'host': self.host,
                    'port': self.port,
                }

                my_num = None

                # --- Step 1: extract identity from my_node_info ---
                if self.my_node_info:
                    if isinstance(self.my_node_info, dict):
                        # getMyNodeInfo() returned a full node dict
                        my_num = (self.my_node_info.get('num')
                                  or self.my_node_info.get('myNodeNum'))
                        user = self.my_node_info.get('user') or {}
                        metrics = self.my_node_info.get('deviceMetrics') or {}
                        pos = self.my_node_info.get('position') or {}

                        # Role: use `is not None` guards because CLIENT=0 is falsy.
                        # getMyNodeInfo() calls MessageToDict() which *omits* default/zero
                        # enum values (CLIENT = 0), so user.role is missing from the dict.
                        # Authoritative source: interface.localNode.localConfig.device.role
                        _role = self.my_node_info.get('role')
                        if _role is None:
                            _role = user.get('role')
                        if _role is None:
                            try:
                                local_node = getattr(self.interface, 'localNode', None)
                                if local_node is not None:
                                    lc = getattr(local_node, 'localConfig', None)
                                    if lc is not None and hasattr(lc, 'device'):
                                        _role = int(lc.device.role)
                                        logger.debug(f"get_node_info: role from localConfig.device.role = {_role}")
                            except Exception as e:
                                logger.debug(f"get_node_info: could not read localConfig role: {e}")

                        node_info.update({
                            'node_id': my_num or 'unknown',
                            'long_name': user.get('longName') or 'unknown',
                            'short_name': user.get('shortName') or 'unknown',
                            'hw_model': user.get('hwModel') or user.get('hwModelString') or 'unknown',
                            'firmware_version': metrics.get('firmwareVersion') or 'unknown',
                            'battery_level': metrics.get('batteryLevel'),
                            'voltage': metrics.get('voltage'),
                            'channel_utilization': metrics.get('channelUtilization'),
                            'air_util_tx': metrics.get('airUtilTx'),
                            'role': _role,
                            'latitude': pos.get('latitude'),
                            'longitude': pos.get('longitude'),
                            'altitude': pos.get('altitude'),
                            'last_heard': (self.my_node_info.get('lastHeard')
                                           or self.my_node_info.get('lastSeen')),
                        })
                    else:
                        # Protobuf MyNodeInfo — only carries myNodeNum
                        my_num = (getattr(self.my_node_info, 'myNodeNum', None)
                                  or getattr(self.my_node_info, 'num', None))
                        node_info['node_id'] = my_num or 'unknown'

                # --- Step 2: enrich from interface.nodes if identity is still thin ---
                has_name = node_info.get('long_name') and node_info['long_name'] != 'unknown'
                iface_nodes = getattr(self.interface, 'nodes', None)

                if not has_name and iface_nodes:
                    # Determine the correct key: integer, str, or hex-string variants
                    candidates = []
                    if my_num is not None:
                        candidates = [my_num, str(my_num)]
                        if isinstance(my_num, int):
                            candidates.append(f'!{my_num:08x}')
                    # Also try brute-force if candidates miss: pick the first key
                    # that matches the numeric value
                    raw_node = None
                    for k in candidates:
                        raw_node = iface_nodes.get(k)
                        if raw_node is not None:
                            break
                    if raw_node is None and my_num is not None:
                        for k, v in iface_nodes.items():
                            k_num = k if isinstance(k, int) else None
                            try:
                                if not k_num and str(k).startswith('!'):
                                    k_num = int(str(k)[1:], 16)
                                elif not k_num:
                                    k_num = int(k)
                            except (ValueError, TypeError):
                                pass
                            if k_num == my_num:
                                raw_node = v
                                break

                    if raw_node is not None:
                        built = self._build_node_data(my_num, raw_node)
                        node_info.update({
                            'long_name': built.get('longName') or 'unknown',
                            'short_name': built.get('shortName') or 'unknown',
                            'hw_model': built.get('hwModel') or built.get('hwModelString') or 'unknown',
                        })
                        metrics = built.get('deviceMetrics') or {}
                        pos = built.get('position') or {}
                        node_info.update({
                            'battery_level': (node_info.get('battery_level')
                                              or metrics.get('batteryLevel')
                                              or built.get('batteryLevel')),
                            'voltage': (node_info.get('voltage')
                                        or metrics.get('voltage')
                                        or built.get('voltage')),
                            'channel_utilization': node_info.get('channel_utilization') or metrics.get('channelUtilization'),
                            'air_util_tx': node_info.get('air_util_tx') or metrics.get('airUtilTx'),
                            'role': node_info.get('role') if node_info.get('role') is not None else built.get('role'),
                            'latitude': node_info.get('latitude') or pos.get('latitude'),
                            'longitude': node_info.get('longitude') or pos.get('longitude'),
                            'altitude': node_info.get('altitude') or pos.get('altitude'),
                            'last_heard': (node_info.get('last_heard')
                                           or built.get('lastHeard')
                                           or built.get('lastSeen')),
                        })

                # --- Step 3: fall back to nodes_db if still thin ---
                if not has_name and my_num is not None:
                    cached = self.nodes_db.get(my_num) or self.nodes_db.get(str(my_num))
                    if cached:
                        node_info.setdefault('long_name', cached.get('long_name', 'unknown'))
                        node_info.setdefault('short_name', cached.get('short_name', 'unknown'))
                        node_info.setdefault('hw_model', cached.get('hw_model', 'unknown'))

                # --- Online node count ---
                if iface_nodes:
                    node_info['online_local_nodes'] = len(iface_nodes)

                logger.debug(
                    f"get_node_info: my_num={my_num} has_name={has_name} "
                    f"keys={[k for k,v in node_info.items() if v not in (None,'unknown')]}"
                )

            return node_info

        except (AttributeError, KeyError, TypeError) as e:
            logger.warning(f"Error getting node info: {e}")
            logger.debug(f"my_node_info type={type(self.my_node_info)}, value={self.my_node_info!r}")
            return {'connected': False, 'host': self.host, 'port': self.port, 'error': str(e)}

    def is_connected(self) -> bool:
        """Check if connected to Meshtastic device.
        
        NOTE: This is a lightweight check that does NOT acquire the lock.
        It only reads boolean/pointer attributes which are safe for polling.
        """
        return self.connected and self.interface and self.interface.isConnected

    async def get_channel_info(self) -> List[Dict[str, Any]]:
        """Get channel configuration from device.
        
        Acquires _interface_lock to prevent concurrent interface access.
        """
        try:
            if not self.connected or not self.interface:
                logger.warning("Cannot get channels - not connected or no interface")
                return []

            async with self._interface_lock:
                local_node = getattr(self.interface, 'localNode', None)
                if not local_node:
                    logger.info("Using cached channel data")
                    return list(self.channels_db.values())

                raw_channels = getattr(local_node, 'channels', None)
                if not raw_channels:
                    logger.warning("Local node has no channels")
                    return list(self.channels_db.values())

                channels = []
                for index, channel in enumerate(raw_channels):
                    try:
                        channels.append(self._process_channel(index, channel))
                    except (AttributeError, KeyError, TypeError, ValueError) as e:
                        logger.warning(f"Error processing channel {index}: {e}")
                        channels.append({
                            'index': index, 'name': f"Channel {index}",
                            'role': 'Unknown', 'error': str(e)
                        })

            logger.info(f"Processed {len(channels)} channels")
            return channels

        except (AttributeError, RuntimeError, ConnectionError) as e:
            logger.error(f"Critical error in get_channel_info: {e}")
            return []

    async def get_device_settings(self) -> Dict[str, Any]:
        """Get device configuration settings.
        
        Delegates to get_node_info() which acquires _interface_lock.
        """
        try:
            if not self.connected or not self.interface:
                return {"error": "Not connected to device"}

            settings = {
                "device_type": "meshtastic_node",
                "connection": {
                    "host": self.host,
                    "port": self.port,
                    "connected": True
                },
                "node_info": await self.get_node_info(),
                "capabilities": [
                    "text_messaging",
                    "binary_messaging",
                    "channel_config",
                    "node_discovery"
                ]
            }

            return settings

        except (AttributeError, ConnectionError, RuntimeError) as e:
            logger.warning(f"Failed to get device settings: {e}")
            return {"error": str(e)}

    async def request_node_info_update(self) -> None:
        """Request fresh node information from the device.
        
        Acquires _interface_lock to prevent concurrent interface access.
        """
        if not self.connected or not self.interface:
            logger.warning("Cannot request node info - not connected")
            return

        try:
            async with self._interface_lock:
                logger.info("Requesting node info update from device")
                # The interface should automatically handle this
            await asyncio.sleep(1)  # Give time for updates

        except (ConnectionError, OSError, RuntimeError) as e:
            logger.warning(f"Failed to request node info update: {e}")

    async def request_channel_update(self) -> None:
        """Request fresh channel configuration from the device.
        
        Delegates to _request_initial_data() which acquires _interface_lock.
        """
        if not self.connected or not self.interface:
            logger.warning("Cannot request channel info - not connected")
            return

        try:
            logger.info("Requesting channel configuration update from device")
            await self._request_initial_data()  # Refresh channel data (acquires lock)

        except (ConnectionError, OSError, RuntimeError, AttributeError) as e:
            logger.warning(f"Failed to request channel update: {e}")

    async def get_node_list(self) -> List[Dict[str, Any]]:
        """Get list of all known nodes from interface.
        
        Changed from sync to async to acquire _interface_lock.
        """
        try:
            if not self.connected or not self.interface:
                logger.warning("Cannot get nodes - not connected or no interface")
                return []

            async with self._interface_lock:
                if not (hasattr(self.interface, 'nodes') and self.interface.nodes):
                    logger.warning("Interface has no nodes or nodes attribute missing")
                    return []

                nodes = []
                for node_id, node_info in self.interface.nodes.items():
                    try:
                        nodes.append(self._build_node_data(node_id, node_info))
                    except (KeyError, AttributeError, TypeError, ValueError) as e:
                        logger.warning(f"Error processing node {node_id}: {e}")
                        nodes.append({
                            'id': node_id, 'num': node_id,
                            'name': f"Node-{node_id}",
                            'hwModelString': 'Unknown', 'error': str(e)
                        })

            logger.info(f"Processed {len(nodes)} nodes from interface")
            return nodes

        except (AttributeError, RuntimeError, ConnectionError) as e:
            logger.exception(f"Critical error in get_node_list: {e}")
            return []

    async def request_node_update(self) -> None:
        """Request node information update - alias for request_node_info_update."""
        await self.request_node_info_update()

    async def refresh_node_data(self) -> None:
        """Force a full re-fetch of node and channel data from the device.

        Re-runs initial data loading so that my_node_info and nodes_db reflect
        the current device state (e.g. after a reboot).
        """
        if hasattr(self.meshtastic_client, 'refresh_node_data'):
            await self.meshtastic_client.refresh_node_data()
        else:
            logger.warning("refresh_node_data not available on meshtastic client")
