"""
Device configuration read/write mixin for MeshtasticClientReal.

Extracted from node_data.py to keep node_data.py focused on node/channel data queries.
NodeConfigRWMixin relies on attributes from MeshtasticClientReal.__init__:
    self.connected, self.interface, self._interface_lock, self.my_node_info
"""

import asyncio
import base64
import logging
from typing import Optional, Dict, Any, List

logger = logging.getLogger(__name__)


def _safe_set(proto_obj, proto_field: str, data: dict, data_key: str, cast_type):
    """Set a protobuf field from a dict if the key exists, with type casting."""
    if data_key in data and data[data_key] is not None:
        try:
            setattr(proto_obj, proto_field, cast_type(data[data_key]))
        except (ValueError, TypeError) as e:
            logger.debug(f"_safe_set: could not set {proto_field}={data[data_key]!r}: {e}")


class NodeConfigRWMixin:
    """Device config read/write methods: get_device_config() and write_device_config()."""

    async def get_device_config(self) -> Optional[Dict[str, Any]]:
        """Read the local node's full device configuration from the interface.

        Returns a dict with keys: owner, device, lora, position, channels, mqtt, store_forward.
        Returns None if not connected or localNode is unavailable.
        """
        try:
            if not self.connected or not self.interface:
                return None
            async with self._interface_lock:
                local_node = getattr(self.interface, 'localNode', None)
                if local_node is None:
                    return None

                # ---- owner / node info ----
                my_info = self.my_node_info or {}
                user = my_info.get('user', {}) if isinstance(my_info.get('user'), dict) else {}
                owner = {
                    'longName': user.get('longName') or my_info.get('longName', ''),
                    'shortName': user.get('shortName') or my_info.get('shortName', ''),
                }

                # ---- device config ----
                device_cfg = getattr(local_node, 'localConfig', None)
                device = {}
                lora = {}
                position = {}
                if device_cfg:
                    d = device_cfg.device
                    device = {
                        'role': int(d.role),
                        'serialEnabled': bool(d.serial_enabled),
                        'nodeInfoBroadcastSecs': int(d.node_info_broadcast_secs),
                    }
                    lo = device_cfg.lora
                    lora = {
                        'usePreset': bool(lo.use_preset),
                        'modemPreset': int(lo.modem_preset),
                        'bandwidth': int(lo.bandwidth),
                        'spreadFactor': int(lo.spread_factor),
                        'codingRate': int(lo.coding_rate),
                        'frequencyOffset': float(lo.frequency_offset),
                        'region': int(lo.region),
                        'hopLimit': int(lo.hop_limit),
                        'txEnabled': bool(lo.tx_enabled),
                        'txPower': int(lo.tx_power),
                        'channelNum': int(lo.channel_num),
                        'overrideDutyCycle': bool(lo.override_duty_cycle),
                        'overrideFrequency': float(lo.override_frequency),
                    }
                    pos = device_cfg.position
                    position = {
                        'fixedPosition': pos.fixed_position,
                        'lat': None,
                        'lng': None,
                        'alt': None,
                    }
                    # Fixed position lat/lng comes from my_node_info
                    node_pos = my_info.get('position') or {}
                    if isinstance(node_pos, dict):
                        position['lat'] = node_pos.get('latitude') or node_pos.get('latitudeI', 0) / 1e7
                        position['lng'] = node_pos.get('longitude') or node_pos.get('longitudeI', 0) / 1e7
                        position['alt'] = node_pos.get('altitude', 0)
                    elif pos.fixed_position:
                        position['lat'] = getattr(pos, 'latitude_i', 0) / 1e7
                        position['lng'] = getattr(pos, 'longitude_i', 0) / 1e7
                        position['alt'] = getattr(pos, 'altitude', 0)

                # ---- module config ----
                module_cfg = getattr(local_node, 'moduleConfig', None)
                mqtt = {}
                store_forward = {}
                if module_cfg:
                    m = module_cfg.mqtt
                    mqtt = {
                        'enabled': m.enabled,
                        'address': m.address,
                        'username': m.username,
                        'password': m.password,
                        'encryptionEnabled': m.encryption_enabled,
                        'jsonEnabled': m.json_enabled,
                        'tlsEnabled': m.tls_enabled,
                        'root': m.root,
                        'proxyToClientEnabled': m.proxy_to_client_enabled,
                        'mapReportingEnabled': m.map_reporting_enabled,
                    }
                    sf = module_cfg.store_forward
                    store_forward = {
                        'enabled': sf.enabled,
                        'heartbeat': sf.heartbeat,
                        'records': sf.records,
                        'historyReturnMax': sf.history_return_max,
                        'historyReturnWindow': sf.history_return_window,
                        'isServer': sf.is_server,
                    }

                # ---- channels ----
                channels = []
                raw_channels = getattr(local_node, 'channels', None) or []
                for ch in raw_channels:
                    settings = getattr(ch, 'settings', None)
                    psk_b64 = ''
                    if settings and settings.psk:
                        try:
                            psk_b64 = base64.b64encode(settings.psk).decode('utf-8')
                        except Exception:
                            psk_b64 = ''
                    channels.append({
                        'index': int(ch.index),
                        'role': int(ch.role),
                        'name': settings.name if settings else '',
                        'psk': psk_b64,
                        'uplinkEnabled': bool(settings.uplink_enabled) if settings else False,
                        'downlinkEnabled': bool(settings.downlink_enabled) if settings else False,
                    })

                return {
                    'owner': owner,
                    'device': device,
                    'lora': lora,
                    'position': position,
                    'channels': channels,
                    'mqtt': mqtt,
                    'store_forward': store_forward,
                }
        except Exception as e:
            logger.warning(f"Error reading device config: {e}")
            return None

    async def write_device_config(self, sections: list, payload: dict) -> Dict[str, Any]:
        """Write selected config sections to the local node, then reboot.

        All synchronous meshtastic API calls (writeConfig, setOwner, etc.) are run
        inside a thread-executor so the asyncio event loop is never blocked during
        the radio write/ACK cycle.

        Args:
            sections: List of section names to write (e.g. ['owner','lora']).
            payload:  Dict containing per-section data under matching keys.

        Returns:
            { 'success': bool, 'written': [...], 'error': str }
        """
        try:
            if not self.connected or not self.interface:
                return {'success': False, 'error': 'Not connected'}

            loop = asyncio.get_running_loop()
            interface_ref = self.interface   # capture before releasing the event-loop

            def _do_write_sync():
                """Blocking meshtastic writes — executed in a thread executor."""
                import time
                node = getattr(interface_ref, 'localNode', None)
                if node is None:
                    return {'success': False, 'error': 'localNode not available', 'written': []}

                # Ensure session passkey is available before any admin commands.
                # ensureSessionKey() is fire-and-forget; sleep 0.5s to let the
                # device respond before we send any admin packets (writeConfig,
                # setOwner, reboot all require the passkey on firmware 2.5+).
                try:
                    node.ensureSessionKey()
                    time.sleep(0.5)
                except Exception as _sk_exc:
                    logger.debug(f"[config write] ensureSessionKey: {_sk_exc}")

                written = []
                errors  = []

                if 'owner' in sections:
                    d = payload.get('owner', {})
                    long_name  = (d.get('longName')  or '').strip()
                    short_name = (d.get('shortName') or '').strip()
                    if long_name or short_name:
                        try:
                            logger.info(f"[config write] setOwner longName={long_name!r} shortName={short_name!r}")
                            node.setOwner(long_name=long_name or None, short_name=short_name or None)
                            written.append('owner')
                            logger.info("[config write] setOwner dispatched")
                        except Exception as exc:
                            err = f"owner: {exc}"
                            logger.warning(f"[config write] {err}")
                            errors.append(err)
                    else:
                        logger.warning("[config write] setOwner skipped — both names empty")

                if 'device' in sections:
                    d = payload.get('device', {})
                    try:
                        if 'role' in d and d['role'] is not None:
                            node.localConfig.device.role = int(d['role'])
                        if 'nodeInfoBroadcastSecs' in d and d['nodeInfoBroadcastSecs'] is not None:
                            node.localConfig.device.node_info_broadcast_secs = int(d['nodeInfoBroadcastSecs'])
                        logger.info(f"[config write] writeConfig('device') role={d.get('role')} nodeInfoSecs={d.get('nodeInfoBroadcastSecs')}")
                        node.writeConfig('device')
                        written.append('device')
                        logger.info("[config write] writeConfig('device') dispatched")
                    except Exception as exc:
                        err = f"device: {exc}"
                        logger.warning(f"[config write] {err}")
                        errors.append(err)

                if 'lora' in sections:
                    d = payload.get('lora', {})
                    try:
                        lo = node.localConfig.lora
                        _safe_set(lo, 'use_preset',         d, 'usePreset',         bool)
                        _safe_set(lo, 'modem_preset',       d, 'modemPreset',       int)
                        _safe_set(lo, 'bandwidth',          d, 'bandwidth',         int)
                        _safe_set(lo, 'spread_factor',      d, 'spreadFactor',      int)
                        _safe_set(lo, 'coding_rate',        d, 'codingRate',        int)
                        _safe_set(lo, 'frequency_offset',   d, 'frequencyOffset',   float)
                        _safe_set(lo, 'region',             d, 'region',            int)
                        _safe_set(lo, 'hop_limit',          d, 'hopLimit',          int)
                        _safe_set(lo, 'tx_enabled',         d, 'txEnabled',         bool)
                        _safe_set(lo, 'tx_power',           d, 'txPower',           int)
                        _safe_set(lo, 'channel_num',        d, 'channelNum',        int)
                        _safe_set(lo, 'override_duty_cycle',d, 'overrideDutyCycle', bool)
                        _safe_set(lo, 'override_frequency', d, 'overrideFrequency', float)
                        logger.info(f"[config write] writeConfig('lora') region={d.get('region')} hopLimit={d.get('hopLimit')}")
                        node.writeConfig('lora')
                        written.append('lora')
                        logger.info("[config write] writeConfig('lora') dispatched")
                    except Exception as exc:
                        err = f"lora: {exc}"
                        logger.warning(f"[config write] {err}")
                        errors.append(err)

                if 'position' in sections:
                    d = payload.get('position', {})
                    try:
                        if d.get('fixedPosition'):
                            lat = float(d.get('lat', 0))
                            lng = float(d.get('lng', 0))
                            alt = int(d.get('alt', 0))
                            logger.info(f"[config write] setFixedPosition lat={lat} lng={lng} alt={alt}")
                            node.setFixedPosition(lat, lng, alt)
                        else:
                            logger.info("[config write] removeFixedPosition")
                            node.removeFixedPosition()
                        written.append('position')
                        logger.info("[config write] position dispatched")
                    except Exception as exc:
                        err = f"position: {exc}"
                        logger.warning(f"[config write] {err}")
                        errors.append(err)

                if 'channels' in sections:
                    for ch_data in payload.get('channels', []):
                        idx = int(ch_data.get('index', 0))
                        try:
                            if node.channels and 0 <= idx < len(node.channels):
                                ch       = node.channels[idx]
                                settings = ch.settings
                                if 'name' in ch_data:
                                    settings.name = str(ch_data['name'])
                                if ch_data.get('psk') is not None:
                                    try:
                                        settings.psk = base64.b64decode(ch_data['psk'])
                                    except Exception as psk_exc:
                                        logger.warning(f"[config write] channel {idx} PSK decode error: {psk_exc}")
                                if 'role' in ch_data:
                                    ch.role = int(ch_data['role'])
                                if 'uplinkEnabled' in ch_data:
                                    settings.uplink_enabled = bool(ch_data['uplinkEnabled'])
                                if 'downlinkEnabled' in ch_data:
                                    settings.downlink_enabled = bool(ch_data['downlinkEnabled'])
                                logger.info(f"[config write] writeChannel({idx})")
                                node.writeChannel(idx)
                                logger.info(f"[config write] writeChannel({idx}) dispatched")
                            else:
                                logger.warning(f"[config write] channel index {idx} out of range")
                        except Exception as exc:
                            err = f"channel[{idx}]: {exc}"
                            logger.warning(f"[config write] {err}")
                            errors.append(err)
                    written.append('channels')

                if 'mqtt' in sections:
                    d = payload.get('mqtt', {})
                    try:
                        m = node.moduleConfig.mqtt
                        _safe_set(m, 'enabled',                d, 'enabled',              bool)
                        _safe_set(m, 'address',                d, 'address',              str)
                        _safe_set(m, 'username',               d, 'username',             str)
                        _safe_set(m, 'password',               d, 'password',             str)
                        _safe_set(m, 'encryption_enabled',     d, 'encryptionEnabled',    bool)
                        _safe_set(m, 'json_enabled',           d, 'jsonEnabled',          bool)
                        _safe_set(m, 'tls_enabled',            d, 'tlsEnabled',           bool)
                        _safe_set(m, 'root',                   d, 'root',                 str)
                        _safe_set(m, 'proxy_to_client_enabled',d, 'proxyToClientEnabled', bool)
                        _safe_set(m, 'map_reporting_enabled',  d, 'mapReportingEnabled',  bool)
                        logger.info(f"[config write] writeConfig('mqtt') enabled={d.get('enabled')}")
                        node.writeConfig('mqtt')
                        written.append('mqtt')
                        logger.info("[config write] writeConfig('mqtt') dispatched")
                    except Exception as exc:
                        err = f"mqtt: {exc}"
                        logger.warning(f"[config write] {err}")
                        errors.append(err)

                if 'store_forward' in sections:
                    d = payload.get('store_forward', {})
                    try:
                        sf = node.moduleConfig.store_forward
                        _safe_set(sf, 'enabled',              d, 'enabled',             bool)
                        _safe_set(sf, 'heartbeat',            d, 'heartbeat',           bool)
                        _safe_set(sf, 'records',              d, 'records',             int)
                        _safe_set(sf, 'history_return_max',   d, 'historyReturnMax',    int)
                        _safe_set(sf, 'history_return_window',d, 'historyReturnWindow', int)
                        _safe_set(sf, 'is_server',            d, 'isServer',            bool)
                        logger.info(f"[config write] writeConfig('store_forward') enabled={d.get('enabled')}")
                        node.writeConfig('store_forward')
                        written.append('store_forward')
                        logger.info("[config write] writeConfig('store_forward') dispatched")
                    except Exception as exc:
                        err = f"store_forward: {exc}"
                        logger.warning(f"[config write] {err}")
                        errors.append(err)

                if written:
                    try:
                        logger.info(f"[config write] Sending reboot command (5s delay). Written sections: {written}")
                        node.reboot(secs=5)
                        logger.info("[config write] Reboot command dispatched")
                    except Exception as exc:
                        logger.warning(f"[config write] reboot failed: {exc}")

                if errors:
                    return {'success': len(written) > 0, 'written': written, 'errors': errors}
                return {'success': True, 'written': written}

            async with self._interface_lock:
                result = await loop.run_in_executor(None, _do_write_sync)

            logger.info(f"[config write] result={result}")
            return result

        except Exception as e:
            logger.exception(f"Unexpected error in write_device_config: {e}")
            return {'success': False, 'error': str(e)}
