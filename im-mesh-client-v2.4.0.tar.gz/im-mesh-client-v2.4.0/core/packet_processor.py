"""
Packet processing mixin for MeshtasticClientReal.

Handles received packet normalization, decoded payload processing,
message type dispatch, self-echo filtering, and deduplication.

This is a mixin class - it accesses self.interface, self._processed_packet_ids,
self._processed_packet_id_set, self._event_loop, self._pending_packets,
self.packet_callbacks via the host class.
"""

import asyncio
import logging
from datetime import datetime

from .constants import PortNum, PORTNUM_MAP, IGNORED_PORTNUMS, normalize_node_id
from .log_utils import tagged_logger

logger = logging.getLogger(__name__)


class PacketProcessorMixin:
    """Mixin providing packet receive processing and dispatch."""

    @property
    def _log(self):
        if not hasattr(self, '_log_adapter'):
            host = getattr(self, 'host', '?')
            port = getattr(self, 'port', '?')
            self._log_adapter = tagged_logger(logger, f"{host}:{port}")
        return self._log_adapter

    def _pubsub_receive_handler(self, packet, interface=None):
        """pypubsub callback for meshtastic.receive (and all subtopics).

        This is a BOUND METHOD stored as an instance attribute, ensuring pypubsub
        holds a strong reference and it won't be garbage collected.
        Called from the Meshtastic library's publishingThread.

        CRITICAL: pypubsub is a process-global singleton. When multiple sessions
        each create a TCPInterface, ALL subscribers receive ALL packets from ALL
        interfaces. We MUST filter by interface identity to only process packets
        from our own connection.

        Additionally, pypubsub topic hierarchy can deliver the same packet multiple
        times (once per matching topic level). We dedup by packet 'id' field.
        """
        try:
            if not isinstance(packet, dict):
                return

            # Extract packet metadata early for logging
            pkt_id = packet.get('id')
            decoded = packet.get('decoded', {})
            portnum = decoded.get('portnum', '') if isinstance(decoded, dict) else ''
            from_id = packet.get('fromId', '?')
            to_id = packet.get('toId', '?')
            is_important = portnum in ('TEXT_MESSAGE_APP', 'ROUTING_APP', 'CUSTOM_IMAGE_APP',
                                       PortNum.TEXT_MESSAGE_APP, PortNum.ROUTING_APP, PortNum.CUSTOM_IMAGE_APP)

            # CRITICAL: Filter by interface - only process packets from OUR connection.
            if interface is not None and self.interface is not None:
                if interface is not self.interface:
                    return  # Packet from a different session's interface

            # Dedup: pypubsub delivers same packet for parent + child topics
            # EXCEPTION: Never dedup ROUTING_APP packets - they carry ACK/NAK responses
            # that may share an ID with the original sent packet. Dropping these causes
            # false "no ack" on the UI.
            is_routing = portnum == 'ROUTING_APP' or portnum == PortNum.ROUTING_APP

            if pkt_id is not None and not is_routing:
                if pkt_id in self._processed_packet_id_set:
                    if is_important:
                        self._log.debug(f"PUBSUB DEDUP: from={from_id} portnum={portnum} id={pkt_id} (already processed)")
                    return  # Already processed this packet
                # Add to both structures; deque auto-evicts oldest when full
                if len(self._processed_packet_ids) == self._processed_packet_ids.maxlen:
                    evicted = self._processed_packet_ids[0]
                    self._processed_packet_id_set.discard(evicted)
                self._processed_packet_ids.append(pkt_id)
                self._processed_packet_id_set.add(pkt_id)

            # Log ALL received packets at INFO for text/binary/routing so drops are visible
            if is_important:
                self._log.info(f"PUBSUB RX: from={from_id} to={to_id} portnum={portnum} id={pkt_id}")
            else:
                self._log.debug(f"PUBSUB RX: from={from_id} to={to_id} portnum={portnum} id={pkt_id}")
            self._on_receive(packet, interface)
        except (KeyError, AttributeError, TypeError, ValueError) as e:
            self._log.warning(f"Data error in _pubsub_receive_handler: {e}")
        except Exception as e:  # Broad fallback: catch-all for unknown packet formats
            self._log.exception(f"Unexpected error in _pubsub_receive_handler: {e}")

    def _pubsub_connection_handler(self, interface, topic=None):
        """pypubsub callback for meshtastic.connection.established."""
        try:
            # Filter by interface - only process events from our connection
            if interface is not None and self.interface is not None:
                if interface is not self.interface:
                    return
            self._log.info("PUBSUB: Connection established")
            self._on_connection(interface, topic)
        except (AttributeError, TypeError) as e:
            self._log.warning(f"Error in _pubsub_connection_handler: {e}")

    def _pubsub_connection_lost_handler(self, interface):
        """pypubsub callback for meshtastic.connection.lost."""
        try:
            # Filter by interface - only process events from our connection
            if interface is not None and self.interface is not None:
                if interface is not self.interface:
                    return
            self._log.warning("PUBSUB: Connection lost")
            self._on_connection_lost(interface)
        except (AttributeError, TypeError) as e:
            self._log.warning(f"Error in _pubsub_connection_lost_handler: {e}")

    def _on_receive(self, packet, interface=None):
        """Handle received packet from Meshtastic device via pypubsub.

        IMPORTANT: This is called from the Meshtastic library's publishing thread,
        NOT from the asyncio event loop. We must use run_coroutine_threadsafe to
        dispatch async work to the main event loop.
        """
        try:
            if not isinstance(packet, dict):
                self._log.warning(f"Unexpected packet type: {type(packet)}")
                return

            # Early filter: drop ignored portnums before any processing
            decoded = packet.get('decoded', {})
            if isinstance(decoded, dict):
                portnum_raw = decoded.get('portnum', '')
                portnum_int = self._portnum_to_int(portnum_raw) if portnum_raw else None
                if portnum_int is not None and portnum_int in IGNORED_PORTNUMS:
                    self._log.debug(f"Dropping ignored portnum {portnum_int} from {packet.get('fromId', '?')}")
                    return

            # Filter echoed packets from self (except ROUTING_APP for ACK tracking)
            if self._is_self_echo(packet):
                return

            # Build normalized packet dict
            packet_dict = self._build_packet_dict(packet)

            # Process decoded payload into typed message
            if decoded:
                self._process_decoded_payload(packet_dict, packet, decoded)

            # Dispatch to async callback pipeline
            self._dispatch_packet(packet_dict)

        except (KeyError, AttributeError, TypeError, ValueError) as e:
            self._log.warning(f"Data error handling received packet: {e}")
        except Exception as e:  # Broad fallback: catch-all for unknown packet formats
            self._log.exception(f"Unexpected error handling received packet: {e}")

    def _get_my_node_id(self) -> str:
        """Get our own node ID string (e.g. '!3d8309d0')."""
        if not self.interface:
            return None
        # Try myInfo first
        if hasattr(self.interface, 'myInfo') and self.interface.myInfo:
            my_info = self.interface.myInfo
            my_node_num = my_info.get('my_node_num') if isinstance(my_info, dict) else getattr(my_info, 'my_node_num', None)
            if my_node_num is not None:
                return normalize_node_id(my_node_num)
        # Fall back to localNode
        if hasattr(self.interface, 'localNode') and self.interface.localNode:
            local_node = self.interface.localNode
            if hasattr(local_node, 'nodeNum'):
                return normalize_node_id(local_node.nodeNum)
        return None

    def _is_self_echo(self, packet: dict) -> bool:
        """Check if packet is an echo of our own transmission.

        Returns True if packet should be filtered out. ROUTING_APP from self
        is allowed through for ACK tracking.
        """
        from_id = packet.get('fromId', '')
        my_node_id = self._get_my_node_id()

        if not my_node_id or from_id != my_node_id:
            return False

        decoded = packet.get('decoded', {})
        portnum = decoded.get('portnum', '') if isinstance(decoded, dict) else ''
        if portnum == 'ROUTING_APP' or portnum == PortNum.ROUTING_APP:
            self._log.info(f"Allowing ROUTING_APP from self ({from_id}) for ack tracking")
            return False

        pkt_id = packet.get('id', '?')
        self._log.info(f"SELF-ECHO DROP: from={from_id} portnum={portnum} id={pkt_id}")
        return True

    def _build_packet_dict(self, packet: dict) -> dict:
        """Build a normalized packet dictionary from raw Meshtastic packet."""
        from_id = packet.get('fromId', '')
        packet_dict = {
            'from': packet.get('from'),
            'to': packet.get('to'),
            'from_node': from_id,
            'id': packet.get('id'),
            'rx_time': datetime.now().isoformat(),
            'channel': packet.get('channel', 0),
            'hop_limit': packet.get('hopLimit'),
            'want_ack': packet.get('wantAck', False),
            'rx_snr': packet.get('rxSnr'),
            'rx_rssi': packet.get('rxRssi'),
        }

        # Resolve sender name from node database
        if from_id and self.interface and hasattr(self.interface, 'nodes'):
            node_info = self.interface.nodes.get(from_id, {})
            if isinstance(node_info, dict) and 'user' in node_info:
                user = node_info['user']
                if isinstance(user, dict):
                    packet_dict['from_name'] = user.get('longName', from_id)
                    packet_dict['from_short'] = user.get('shortName', '')

        return packet_dict

    def _process_decoded_payload(self, packet_dict: dict, packet: dict, decoded: dict):
        """Process decoded payload and set message_type and type-specific fields.
        
        Normalizes portnum to int once, then dispatches via a simple if/elif chain.
        """
        portnum_raw = decoded.get('portnum', '')
        payload = decoded.get('payload', b'')
        pn = self._portnum_to_int(portnum_raw)
        from_id = packet_dict.get('from_node', '')

        packet_dict['decoded'] = {
            'portnum': pn,
            'payload': payload,
            'want_response': decoded.get('wantResponse', False)
        }

        if pn == PortNum.TEXT_MESSAGE_APP:
            self._handle_text_message(packet_dict, decoded, payload, from_id, packet.get('channel', 0))
        elif pn == PortNum.CUSTOM_IMAGE_APP:
            self._handle_binary_message(packet_dict, payload, from_id)
        elif pn == PortNum.ROUTING_APP:
            self._handle_routing_message(packet_dict, decoded, packet, from_id)
        elif pn == PortNum.POSITION_APP:
            packet_dict['message_type'] = 'position'
            if 'position' in decoded:
                packet_dict['decoded']['position_data'] = decoded['position']
        elif pn == PortNum.NODEINFO_APP:
            packet_dict['message_type'] = 'node_info'
            if 'user' in decoded:
                packet_dict['decoded']['user_info'] = decoded['user']
        elif pn == PortNum.TELEMETRY_APP:
            packet_dict['message_type'] = 'telemetry'
        else:
            packet_dict['message_type'] = f'portnum_{pn}'
            self._log.debug(f"RX portnum={portnum_raw} ({pn}) from {from_id}")

    @staticmethod
    def _is_readable_text(text: str) -> bool:
        """Check if text is human-readable (not encrypted/garbled data).

        Returns False if more than 30% of characters are non-printable
        (control chars, surrogates, replacement chars, etc.), which indicates
        the payload is encrypted data that could not be decrypted, or raw
        binary data misinterpreted as text.
        """
        if not text:
            return False
        non_printable = 0
        for ch in text:
            cp = ord(ch)
            # Allow printable ASCII, common Unicode, newlines/tabs
            if cp < 32 and cp not in (9, 10, 13):  # control chars except tab/newline/CR
                non_printable += 1
            elif 0xD800 <= cp <= 0xDFFF:  # surrogates
                non_printable += 1
            elif cp == 0xFFFD:  # replacement character
                non_printable += 1
        # If more than 30% non-printable, it's garbled
        return (non_printable / len(text)) < 0.3

    def _handle_text_message(self, packet_dict: dict, decoded: dict, payload, from_id: str, channel: int):
        """Process a TEXT_MESSAGE_APP packet.

        Validates that the decoded text is human-readable. If the payload is
        encrypted data that the Meshtastic library could not decrypt (wrong
        channel key), the raw bytes look like gibberish. We silently drop
        such messages rather than displaying garbled text.
        """
        text = decoded.get('text', '')
        if not text and isinstance(payload, bytes):
            try:
                text = payload.decode('utf-8')
            except (UnicodeDecodeError, AttributeError):
                # Cannot decode as UTF-8 at all - encrypted or binary data
                self._log.debug(f"Dropping non-UTF-8 text payload from {from_id} ch={channel} ({len(payload)} bytes)")
                packet_dict['message_type'] = 'encrypted_or_invalid'
                return

        # Validate the decoded text is readable, not garbled encrypted data
        if not self._is_readable_text(text):
            self._log.debug(f"Dropping garbled/encrypted text from {from_id} ch={channel} len={len(text)}")
            packet_dict['message_type'] = 'encrypted_or_invalid'
            return

        packet_dict['decoded']['text'] = text
        packet_dict['decoded_text'] = text
        packet_dict['message_type'] = 'text'
        self._log.info(f"RX TEXT from {from_id} ch={channel} len={len(text)}: {text[:80]}")

    def _handle_binary_message(self, packet_dict: dict, payload, from_id: str):
        """Process a CUSTOM_IMAGE_APP (portnum 288) binary packet.
        
        Attempts to decode the payload as UTF-8 text. If it looks like an image
        segment (starts with 'IMG'), the decoded string is stored as the payload
        so the frontend can detect and render image segments properly.
        """
        payload_str = None
        if isinstance(payload, bytes):
            try:
                payload_str = payload.decode('utf-8')
            except (UnicodeDecodeError, AttributeError):
                payload_str = None
            packet_dict['decoded']['binary_data'] = payload.hex()
        else:
            payload_str = str(payload)
            packet_dict['decoded']['binary_data'] = payload_str

        # Store the decoded text payload so the frontend can detect image segments
        # (raw bytes get base64-encoded during JSON serialization, losing the text)
        if payload_str:
            packet_dict['decoded']['payload'] = payload_str
        
        packet_dict['message_type'] = 'binary'
        self._log.info(f"RX BINARY from {from_id}: {len(payload) if isinstance(payload, bytes) else 0} bytes"
                     f"{' [IMG segment]' if payload_str and payload_str.startswith('IMG') else ''}")

    def _handle_routing_message(self, packet_dict: dict, decoded: dict, packet: dict, from_id: str):
        """Process a ROUTING_APP (ACK/NAK) packet."""
        packet_dict['message_type'] = 'routing'

        # Extract requestId from multiple possible locations
        request_id = decoded.get('requestId') or decoded.get('request_id')
        if not request_id:
            request_id = packet.get('requestId') or packet.get('request_id')

        routing = decoded.get('routing', {})
        if not request_id and routing:
            if isinstance(routing, dict):
                request_id = routing.get('requestId') or routing.get('request_id')
            else:
                request_id = getattr(routing, 'requestId', None) or getattr(routing, 'request_id', None)

        # Extract and normalize error reason
        if isinstance(routing, dict):
            error_reason = routing.get('errorReason', 'NONE')
        else:
            error_reason = getattr(routing, 'errorReason', 'NONE') if routing else 'NONE'

        if hasattr(error_reason, 'name'):
            error_reason = error_reason.name
        elif isinstance(error_reason, int):
            error_reason = 'NONE' if error_reason == 0 else f'ERROR_{error_reason}'

        # protobuf default 0 means unset
        if request_id == 0:
            request_id = None

        packet_dict['decoded']['request_id'] = request_id
        packet_dict['decoded']['error_reason'] = str(error_reason)
        packet_dict['decoded']['ack_received'] = str(error_reason) in ('NONE', '0')

        self._log.info(f"RX ROUTING from {from_id}: requestId={request_id} error={error_reason}")
        self._log.debug(f"ROUTING raw: requestId_val={decoded.get('requestId')} routing_keys={list(routing.keys()) if isinstance(routing, dict) else 'N/A'}")

    def _dispatch_packet(self, packet_dict: dict):
        """Dispatch processed packet to async callback pipeline."""
        if self._event_loop and self._event_loop.is_running():
            future = asyncio.run_coroutine_threadsafe(self._notify_callbacks(packet_dict), self._event_loop)
            def _on_future_done(f):
                exc = f.exception()
                if exc:
                    self._log.error(f"Error dispatching packet callback: {exc}")
            future.add_done_callback(_on_future_done)
        else:
            msg_type = packet_dict.get('message_type', 'unknown')
            if msg_type in ('text', 'binary', 'routing'):
                self._pending_packets.append(packet_dict)
                self._log.warning(f"Queued {msg_type} packet (no event loop yet), queue size: {len(self._pending_packets)}")
            else:
                self._log.debug(f"Dropped {msg_type} packet (no event loop, startup race condition)")

    def _portnum_to_int(self, portnum) -> int:
        """Convert portnum (string or int) to integer."""
        if isinstance(portnum, int):
            return portnum
        return PORTNUM_MAP.get(str(portnum), PortNum.UNKNOWN_APP)
