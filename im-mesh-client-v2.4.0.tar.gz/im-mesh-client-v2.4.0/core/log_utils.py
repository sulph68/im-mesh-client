"""Logging utilities for per-connection tagged loggers."""
import logging


class TaggedLogger(logging.LoggerAdapter):
    """LoggerAdapter that prepends [host:port] to every log message."""
    def process(self, msg, kwargs):
        tag = self.extra.get('tag', '?')
        return f"[{tag}] {msg}", kwargs


def tagged_logger(base_logger: logging.Logger, tag: str) -> TaggedLogger:
    """Return a TaggedLogger that prefixes messages with [tag]."""
    return TaggedLogger(base_logger, {'tag': tag})
