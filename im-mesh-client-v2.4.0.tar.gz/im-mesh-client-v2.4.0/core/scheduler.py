"""
core/scheduler.py — Scheduled message execution engine.

Runs as an asyncio background task. Wakes every minute, evaluates
all enabled scheduled entries, and fires sends for matching entries.

Usage (in gateway or main startup):
    from core.scheduler import Scheduler
    scheduler = Scheduler(session, config)
    await scheduler.start()
    # later:
    await scheduler.stop()
"""

import asyncio
import collections
import logging
import os
import subprocess
from datetime import datetime
from typing import Callable, Dict, List, Optional

from .scheduler_config import load_all_entries, get_global_enabled
from .cron_parser import matches_cron
from .message_splitter import split_message
from .path_utils import resolve_project_path
from .variable_substitution import resolve_variables
from .constants import DEFAULT_CHAR_LIMIT, MIN_SEND_INTERVAL

logger = logging.getLogger(__name__)


def _get_char_limit(session) -> int:
    """Return the configured character_limit from the session gateway."""
    try:
        return session.gateway.char_limit
    except (AttributeError, TypeError, ValueError):
        return DEFAULT_CHAR_LIMIT


class Scheduler:
    def __init__(self, session_or_getter, settings: dict):
        """
        Args:
            session_or_getter: The active Session object (or a callable returning one)
                               for sending messages via gateway
            settings: The sched_message section of settings.json
        """
        self._session_or_getter = session_or_getter
        self._settings = settings
        self._task = None
        self._running = False

        sched_root = resolve_project_path(settings.get('working_directory', './sched_messages'))
        self._config_dir = os.path.join(sched_root, 'config')
        self._commands_dir = resolve_project_path(
            settings.get('commands', './sched_messages/commands')
        )
        self._max_lines: int = settings.get('max_lines', 5)
        self._max_history: int = settings.get('message_history', 100)

        # Per-session ring buffer: session_id → deque of message dicts
        self._history: Dict[str, collections.deque] = {}

        # Optional async callback: ws_send_callback(session_id, message_dict)
        self.ws_send_callback: Optional[Callable] = None

        # Optional sync callable: is_connected_fn(session_id) -> bool
        # Used to skip caching when browser is already online.
        self.is_connected_fn: Optional[Callable] = None

    def _get_session(self):
        """Return the session (calls getter if callable)."""
        if callable(self._session_or_getter):
            return self._session_or_getter()
        return self._session_or_getter

    def get_history_and_drain(self, session_id: str) -> List[dict]:
        """Return all cached scheduled messages for a session and clear the cache."""
        buf = self._history.pop(session_id, collections.deque())
        return list(buf)

    async def start(self):
        """Start the background scheduler task."""
        self._running = True
        self._task = asyncio.create_task(self._loop())
        logger.info("Scheduler started")

    async def stop(self):
        """Stop the background scheduler task."""
        self._running = False
        if self._task:
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass
        logger.info("Scheduler stopped")

    async def _loop(self):
        """Main scheduler loop: fire at top of each minute, never drift."""
        while self._running:
            now = datetime.now()
            await self._tick(now)
            # Sleep until the next whole minute (at least 1s to avoid double-firing)
            sleep_secs = max(1, 60 - datetime.now().second)
            await asyncio.sleep(sleep_secs)

    async def _tick(self, now: datetime):
        """Evaluate all entries for the current minute."""
        if not get_global_enabled(self._config_dir):
            logger.debug("Scheduler: globally disabled — skipping tick")
            return
        entries = load_all_entries(self._config_dir)
        logger.debug("Scheduler tick at %s — %d entries loaded", now.strftime('%H:%M'), len(entries))
        for entry in entries:
            entry_id = entry.get('id', '?')
            if not entry.get('enabled', True):
                logger.debug("Scheduler: entry %s disabled — skipping", entry_id)
                continue
            schedule = entry.get('schedule', {})
            matched = matches_cron(schedule, now)
            logger.debug(
                "Scheduler: entry %s (ch=%s label=%r) schedule=%s matched=%s",
                entry_id, entry.get('channel', 0), entry.get('label', ''), schedule, matched
            )
            if matched:
                try:
                    await self._fire(entry)
                except Exception as e:
                    logger.error("Scheduler: error firing entry %s: %s", entry_id, e, exc_info=True)

    async def _fire(self, entry: dict):
        """Execute a single scheduled entry."""
        entry_type = entry.get('type', 'message')
        to_node = entry.get('to_node')
        channel = entry.get('channel', 0)
        # Accept both 'portnum' (stored) and 'port' (legacy) keys
        portnum = entry.get('portnum') or entry.get('port') or 1

        session = self._get_session()
        char_limit = _get_char_limit(session)

        # Accept both 'message' (UI) and 'text' (legacy) as text message types
        if entry_type in ('text', 'message'):
            text = entry.get('message', '')
            if not text:
                logger.warning("Scheduler: entry %s has empty message", entry.get('id'))
                return
            # Resolve {{S_VARIABLE}} substitutions using own node data
            try:
                own_node_data = None
                if session and hasattr(session, 'gateway') and session.gateway:
                    try:
                        own_node_data = session.gateway.get_connection_status()
                    except Exception as e:
                        logger.debug(f"[scheduler] get_connection_status: {e}")
                text = resolve_variables(text, trigger_node=None, own_node=own_node_data)
            except Exception as e:
                logger.debug(f"[scheduler] resolve_variables: {e}")
            # One entry = list of split chunks
            parts_per_line = [split_message(text, char_limit)]
        elif entry_type == 'command':
            command = entry.get('command', '')
            cmd_lines = await self._run_command(command)
            if cmd_lines is None:
                return
            # Each output line becomes its own group of parts (split for length)
            parts_per_line = [split_message(line, char_limit) for line in cmd_lines if line.strip()]
        else:
            logger.warning("Unknown entry type: %s", entry_type)
            return

        label = entry.get('label') or entry.get('id', 'Scheduler')
        fired_at = datetime.now().isoformat()
        total_parts = sum(len(p) for p in parts_per_line)
        logger.info("Scheduler firing entry %s (%s groups, %s total) → to_node=%s channel=%s",
                    entry.get('id'), len(parts_per_line), total_parts, to_node, channel)

        session_id = session.id if session else None
        is_online = bool(self.is_connected_fn and self.is_connected_fn(session_id)) if session_id else False

        global_idx = 0
        try:
            msg_delay = session.gateway.msg_delay if session else MIN_SEND_INTERVAL
        except (AttributeError, TypeError, ValueError):
            msg_delay = MIN_SEND_INTERVAL
        for parts in parts_per_line:
            for part in parts:
                if global_idx > 0:
                    await asyncio.sleep(msg_delay)
                await self._send(part, to_node, channel, portnum, session=session)
                msg_data = {
                    'text': part,
                    'from': f'You - \U0001f550 Schedule - {label}',
                    'from_node': None,
                    'to_node': to_node,
                    'channel': channel,
                    'is_broadcast': to_node is None,
                    'timestamp': fired_at,
                    'entry_id': entry.get('id'),
                    'entry_label': label,
                    'fired_at': fired_at,
                    'scheduled': True,
                    # Unique key per part for client-side deduplication
                    'sched_key': f"{entry.get('id')}_{fired_at}_{global_idx}",
                }
                global_idx += 1
                if session_id:
                    if not is_online:
                        self._cache_message(session_id, msg_data)
                    await self._push_to_ws(session_id, msg_data)
                # Publish scheduled_sent so TF and other MessageRouter subscribers pick it up
                try:
                    local_id = None
                    local_long = None
                    local_short = None
                    ch_name = f"ch{channel}"
                    if session:
                        mc = getattr(getattr(session, 'gateway', None), 'meshtastic_client', None)
                        if mc:
                            if mc.my_node_info and isinstance(mc.my_node_info, dict):
                                node_num = mc.my_node_info.get('nodeNum') or mc.my_node_info.get('num')
                                if node_num:
                                    local_id = f"!{node_num:08x}"
                            if local_id and mc.nodes_db and local_id in mc.nodes_db:
                                nd = mc.nodes_db[local_id]
                                local_long = nd.get('long_name')
                                local_short = nd.get('short_name')
                            if mc.channels_db:
                                ch_name = mc.channels_db.get(channel, {}).get('name') or ch_name
                    mr = getattr(getattr(session, 'gateway', None), 'message_router', None)
                    if mr:
                        await mr.route_message({
                            'message_type': 'scheduled_sent',
                            'text': part,
                            'from_node': local_id,
                            'from_name': local_long,
                            'from_short': local_short,
                            'to_node': to_node,
                            'channel': channel,
                            'channel_name': ch_name,
                            'direction': 'sent',
                            'is_broadcast': to_node is None,
                            'timestamp': fired_at,
                            'sched_label': label,
                            'entry_id': entry.get('id'),
                        })
                except Exception as _mr_err:
                    logger.warning("Scheduler MessageRouter publish error: %s", _mr_err)

    def _cache_message(self, session_id: str, msg_data: dict):
        """Add a message to the per-session ring buffer."""
        if session_id not in self._history:
            self._history[session_id] = collections.deque(maxlen=self._max_history)
        self._history[session_id].append(msg_data)

    async def _push_to_ws(self, session_id: str, msg_data: dict):
        """Push a scheduled message to connected WebSocket clients."""
        if self.ws_send_callback is None:
            return
        try:
            await self.ws_send_callback(session_id, {
                'type': 'scheduled_message',
                'data': msg_data,
            })
        except Exception as e:
            logger.warning("Scheduler WS push error: %s", e)

    async def _run_command(self, command: str):
        """Execute command in commands_dir; return list of output lines (one per line) or None on error."""
        if not command or '/' in command or '\\' in command or '..' in command:
            logger.warning("Invalid command name: %r", command)
            return None

        cmd_path = os.path.realpath(os.path.join(self._commands_dir, command))
        if not cmd_path.startswith(os.path.realpath(self._commands_dir)):
            logger.warning("Path traversal attempt: %s", cmd_path)
            return None
        if not os.path.isfile(cmd_path) or not os.access(cmd_path, os.X_OK):
            logger.warning("Command not executable: %s", cmd_path)
            return None

        try:
            result = subprocess.run(
                [cmd_path],
                shell=False,
                capture_output=True,
                text=True,
                timeout=30,
                cwd=self._commands_dir,
            )
            lines = result.stdout.strip().splitlines()
            # Each line is a separate message; honour max_lines limit
            return [l for l in lines[:self._max_lines] if l.strip()]
        except subprocess.TimeoutExpired:
            logger.warning("Command timed out: %s", command)
            return None
        except Exception as e:
            logger.error("Command execution error: %s", e)
            return None

    async def _send(self, text: str, to_node, channel: int, portnum: int, session=None):
        """Send a single message part via the session gateway."""
        if session is None:
            session = self._get_session()
        if not session:
            logger.warning("Scheduler: no active session — skipping send")
            return
        try:
            await session.gateway.send_text_message(
                text=text,
                to_node=to_node,
                channel=channel,
                want_ack=False,
                portnum=portnum,
            )
        except Exception as e:
            logger.error("Scheduler send error: %s", e)

