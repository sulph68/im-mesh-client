"""
core/cron_parser.py — Cron expression matching for scheduled messages.

Supports: '*', exact integers, comma-separated lists, '*/N' step syntax, and 'A-B' ranges.
Fields: minute (0-59), hour (0-23), day_of_month (1-31), day_of_week (0-6, 0=Monday).
"""

import re
from datetime import datetime


def matches_cron(schedule: dict, dt: datetime) -> bool:
    """Return True if *dt* matches the cron *schedule*.

    schedule keys: minute, hour, day_of_month, day_of_week
    day_of_week: 0=Monday ... 6=Sunday (Python's weekday())
    """
    checks = [
        (schedule.get('minute', '*'), dt.minute),
        (schedule.get('hour', '*'), dt.hour),
        (schedule.get('day_of_month', '*'), dt.day),
        (schedule.get('day_of_week', '*'), dt.weekday()),
    ]
    return all(_field_matches(expr, value) for expr, value in checks)


def _field_matches(expr: str, value: int) -> bool:
    """Match a single cron field expression against an integer *value*.

    Supported forms: '*', '5', '8,20', '*/2', '8-12', or combinations via comma.
    """
    expr = str(expr).strip()
    if expr == '*':
        return True
    # Comma-separated list: match if any part matches
    if ',' in expr:
        return any(_field_matches(part.strip(), value) for part in expr.split(','))
    if re.fullmatch(r'\d+', expr):
        return int(expr) == value
    m = re.fullmatch(r'\*/(\d+)', expr)
    if m:
        step = int(m.group(1))
        return value % step == 0
    m = re.fullmatch(r'(\d+)-(\d+)', expr)
    if m:
        return int(m.group(1)) <= value <= int(m.group(2))
    return False
