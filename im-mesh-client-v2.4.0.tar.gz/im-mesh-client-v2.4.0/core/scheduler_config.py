"""
CRUD operations for scheduled message entry JSON files.

Storage layout:
  {config_dir}/{uuid}.json          <- individual entries
  {config_dir}/global_enabled.json  <- {"enabled": bool}

All path operations are relative to the config_dir passed to each function.
No path traversal is permitted outside config_dir.
"""

import json
import os
import uuid as uuid_module


# --- Path safety ---

def _safe_config_path(config_dir: str, entry_id: str) -> str:
    """Return absolute path to entry file; raise ValueError if traversal attempted."""
    if not entry_id or '/' in entry_id or '\\' in entry_id or '..' in entry_id:
        raise ValueError(f"Invalid entry ID: {entry_id!r}")
    path = os.path.realpath(os.path.join(config_dir, f"{entry_id}.json"))
    if not path.startswith(os.path.realpath(config_dir)):
        raise ValueError(f"Path traversal attempt: {path}")
    return path


# --- Entry CRUD ---

def load_all_entries(config_dir: str) -> list:
    """Load all scheduled entry JSON files. Skips malformed files."""
    os.makedirs(config_dir, exist_ok=True)
    entries = []
    for fname in os.listdir(config_dir):
        if not fname.endswith('.json') or fname == 'global_enabled.json':
            continue
        fpath = os.path.join(config_dir, fname)
        try:
            with open(fpath) as f:
                entries.append(json.load(f))
        except (json.JSONDecodeError, OSError):
            pass  # Skip malformed/unreadable files
    return entries


def save_entry(config_dir: str, entry: dict) -> None:
    """Write a single entry dict to disk. entry must have 'id' key."""
    os.makedirs(config_dir, exist_ok=True)
    entry_id = entry.get('id')
    if not entry_id:
        raise ValueError("Entry must have an 'id' field")
    path = _safe_config_path(config_dir, entry_id)
    with open(path, 'w') as f:
        json.dump(entry, f, indent=2)


def delete_entry(config_dir: str, entry_id: str) -> bool:
    """Delete an entry by ID. Returns True if deleted, False if not found."""
    path = _safe_config_path(config_dir, entry_id)
    if os.path.exists(path):
        os.remove(path)
        return True
    return False


def create_entry(config_dir: str, data: dict) -> dict:
    """Create a new entry with a generated UUID. Returns the saved entry."""
    label = data.get("label") or data.get("name", "")
    entry = {
        "id": str(uuid_module.uuid4()),
        "enabled": data.get("enabled", True),
        "label": label,
        "name": label,  # kept for backward compat with old JSON files
        "schedule": data.get("schedule", {"minute": "0", "hour": "9",
                                           "day_of_month": "*", "day_of_week": "*"}),
        "type": data.get("type", "text"),
        "message": data.get("message", ""),
        "command": data.get("command", ""),
        "to_node": data.get("to_node", None),
        "channel": data.get("channel", 0),
        "portnum": data.get("portnum", 1),
    }
    save_entry(config_dir, entry)
    return entry


# --- Global enable/disable ---

def get_global_enabled(config_dir: str) -> bool:
    """Read global enabled state. Defaults to True if file doesn't exist."""
    path = os.path.join(config_dir, 'global_enabled.json')
    try:
        with open(path) as f:
            return json.load(f).get('enabled', True)
    except (FileNotFoundError, json.JSONDecodeError):
        return True


def set_global_enabled(config_dir: str, enabled: bool) -> None:
    """Write global enabled state."""
    os.makedirs(config_dir, exist_ok=True)
    path = os.path.join(config_dir, 'global_enabled.json')
    with open(path, 'w') as f:
        json.dump({'enabled': enabled}, f)
