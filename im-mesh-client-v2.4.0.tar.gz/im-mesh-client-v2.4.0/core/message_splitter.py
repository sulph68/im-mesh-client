"""
core/message_splitter.py — Message splitting utility

Splits long Meshtastic messages into numbered chunks, enforcing a byte-level
size limit to avoid TOO_LARGE errors on multi-byte UTF-8 text.

Constants:
    DEFAULT_LIMIT (int): Default max bytes per final chunk including prefix (220).
    PREFIX_OVERHEAD (int): Reserved bytes for ``[NN/NN] `` prefix (10 bytes, covers
                           up to 9999 parts).

Public API:
    split_message(text: str, limit: int = DEFAULT_LIMIT) -> list[str]
        Returns a list of ready-to-send message strings sized by UTF-8 bytes.
        If the text fits within *limit* bytes the original string is returned
        unchanged.  Otherwise each chunk is prefixed ``[n/x] `` (1-based).
"""

DEFAULT_LIMIT: int = 220
PREFIX_OVERHEAD: int = 10  # "[9999/9999] " worst-case ASCII prefix bytes

# Backward-compatible aliases (used by existing tests and external code).
SPLIT_THRESHOLD: int = DEFAULT_LIMIT
CHUNK_MAX: int = DEFAULT_LIMIT - PREFIX_OVERHEAD  # 210 content bytes
HARD_LIMIT: int = DEFAULT_LIMIT


def split_message(text: str, limit: int = DEFAULT_LIMIT) -> list[str]:
    """Split *text* into Meshtastic-safe byte-bounded chunks.

    Splits at UTF-8 byte boundaries, preferring word boundaries (spaces).
    Falls back to a hard byte-boundary split when no space is found.

    Args:
        text:  The message string to split.
        limit: Maximum UTF-8 byte size of each final output string (prefix
               included).  Defaults to DEFAULT_LIMIT (220).

    Returns:
        A list of strings ready to transmit.  Single-element list when the
        text already fits.  Empty list for empty input.
    """
    if not text:
        return []

    text_bytes = text.encode('utf-8')
    if len(text_bytes) <= limit:
        return [text]

    # Reserve bytes for the "[n/x] " prefix.
    content_limit = max(limit - PREFIX_OVERHEAD, 1)

    content_chunks: list[bytes] = []
    remaining = text_bytes
    while remaining:
        if len(remaining) <= content_limit:
            content_chunks.append(remaining)
            break

        # Try to split at the last ASCII space within the content window.
        split_pos = remaining.rfind(b' ', 0, content_limit + 1)
        if split_pos > 0:
            content_chunks.append(remaining[:split_pos])
            remaining = remaining[split_pos:].lstrip(b' ')
        else:
            # No space: hard split, but step back to a valid UTF-8 boundary.
            pos = content_limit
            while pos > 0 and (remaining[pos] & 0xC0) == 0x80:
                pos -= 1
            content_chunks.append(remaining[:pos])
            remaining = remaining[pos:]

    total = len(content_chunks)
    return [
        "[{}/{}] {}".format(i + 1, total, chunk.decode('utf-8', errors='replace'))
        for i, chunk in enumerate(content_chunks)
    ]
