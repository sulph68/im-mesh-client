"""
core/auto_responder_config.py — Conversation folder management for auto responder.

Folder naming:
  - Node conversations: {nodeid} (without !)
  - Channel conversations: ch{index}_{sanitized_name}
  - With UUID suffix (multiple rules): ch{index}_{name}_{8hex} or {nodeid}_{8hex}

Enabled/disabled: presence of _disabled suffix on folder name.
"""

import json
import os
import re
import uuid
from datetime import datetime


def _sanitize_name(name: str) -> str:
    """Lowercase, replace non-alphanumeric with underscore."""
    return re.sub(r'[^a-z0-9]', '_', name.lower())


def generate_rule_id() -> str:
    """Generate an 8-character hex rule ID from a UUID."""
    return uuid.uuid4().hex[:8]


def get_node_folder_name(node_id: str) -> str:
    """Convert '!3d8309d0' → '3d8309d0'."""
    return node_id.lstrip('!')


def get_channel_folder_name(channel_index: int, channel_name: str) -> str:
    """Convert (0, 'LongFast') → 'ch0_longfast'."""
    return "ch{}_{}".format(channel_index, _sanitize_name(channel_name))


def get_conversation_folder(working_dir: str, folder_name: str) -> str:
    """Return full path to conversation folder. Does NOT check enabled state."""
    return os.path.join(working_dir, folder_name)


def is_conversation_enabled(working_dir: str, folder_name: str) -> bool:
    """Return True if the folder exists and does NOT have _disabled suffix."""
    enabled_path = os.path.join(working_dir, folder_name)
    disabled_path = os.path.join(working_dir, folder_name + '_disabled')
    if os.path.isdir(disabled_path):
        return False
    return os.path.isdir(enabled_path)


def enable_conversation(working_dir: str, folder_name: str) -> None:
    """Rename {folder}_disabled → {folder} if it exists disabled."""
    disabled_path = os.path.join(working_dir, folder_name + '_disabled')
    enabled_path = os.path.join(working_dir, folder_name)
    if os.path.isdir(disabled_path):
        os.rename(disabled_path, enabled_path)


def disable_conversation(working_dir: str, folder_name: str) -> None:
    """Rename {folder} → {folder}_disabled if it exists enabled."""
    enabled_path = os.path.join(working_dir, folder_name)
    disabled_path = os.path.join(working_dir, folder_name + '_disabled')
    if os.path.isdir(enabled_path):
        os.rename(enabled_path, disabled_path)


def ensure_conversation_folder(working_dir: str, folder_name: str) -> str:
    """Create the folder if it doesn't exist. Return its path."""
    path = os.path.join(working_dir, folder_name)
    os.makedirs(path, exist_ok=True)
    return path


def format_sender_display(sender_id: str, node_data: dict = None) -> str:
    """Format a sender identifier for conversation.txt.

    For real node IDs (starting with '!') uses 'LongName <Short@!nodeid>' when
    node_data is provided; falls back gracefully.  Non-node senders (e.g.
    'responder') are returned unchanged.
    """
    if not sender_id.startswith('!') or node_data is None:
        return sender_id
    long_name = (node_data.get('longName') or node_data.get('long_name') or '').strip()
    short_name = (node_data.get('shortName') or node_data.get('short_name') or '').strip()
    if long_name and short_name:
        return f"{long_name} <{short_name}@{sender_id}>"
    if long_name:
        return f"{long_name} <{sender_id}>"
    if short_name:
        return f"{short_name}@{sender_id}"
    return sender_id


def append_to_conversation(folder_path: str, sender: str, message: str,
                            history_context: int = 20) -> None:
    """Append a message line to conversation.txt, then trim to history_context lines.

    Format: TIMESTAMP|SENDER|MESSAGE  (pipe-separated)
    sender: formatted display name (use format_sender_display()) for incoming,
            'responder' for outgoing gateway replies.
    """
    log_path = os.path.join(folder_path, 'conversation.txt')
    timestamp = datetime.now().isoformat(timespec='seconds')
    line = "{}|{}|{}\n".format(timestamp, sender, message)

    with open(log_path, 'a', encoding='utf-8') as f:
        f.write(line)

    with open(log_path, 'r', encoding='utf-8') as f:
        lines = f.readlines()

    if len(lines) > history_context:
        lines = lines[-history_context:]
        with open(log_path, 'w', encoding='utf-8') as f:
            f.writelines(lines)


def read_conversation(folder_path: str) -> str:
    """Read conversation.txt content. Returns '' if file doesn't exist."""
    log_path = os.path.join(folder_path, 'conversation.txt')
    try:
        with open(log_path, 'r', encoding='utf-8') as f:
            return f.read()
    except FileNotFoundError:
        return ''


# --- Per-conversation trigger config ---

def read_conv_config(folder_path: str) -> dict:
    """Read config.json from a conversation folder. Defaults to trigger='any'."""
    path = os.path.join(folder_path, 'config.json')
    try:
        with open(path) as f:
            data = json.load(f)
            return {
                'label': data.get('label', ''),
                'trigger': data.get('trigger', 'any'),
                'pattern': data.get('pattern', ''),
                'monitor_type': data.get('monitor_type', ''),
                'channel_idx': data.get('channel_idx', 0),
                'node_id': data.get('node_id', ''),
                'responder_mode': data.get('responder_mode', 'eliza'),
                'fixed_response': data.get('fixed_response', ''),
            }
    except (FileNotFoundError, json.JSONDecodeError):
        return {
            'label': '', 'trigger': 'any', 'pattern': '',
            'monitor_type': '', 'channel_idx': 0, 'node_id': '',
            'responder_mode': 'eliza', 'fixed_response': '',
        }


def write_conv_config(folder_path: str, config: dict) -> None:
    """Write config.json to a conversation folder."""
    os.makedirs(folder_path, exist_ok=True)
    path = os.path.join(folder_path, 'config.json')
    safe = {
        'label': config.get('label', ''),
        'trigger': config.get('trigger', 'any'),
        'pattern': config.get('pattern', ''),
        'monitor_type': config.get('monitor_type', ''),
        'channel_idx': int(config.get('channel_idx', 0)),
        'node_id': config.get('node_id', ''),
        'responder_mode': config.get('responder_mode', 'eliza'),
        'fixed_response': config.get('fixed_response', ''),
    }
    with open(path, 'w') as f:
        json.dump(safe, f, indent=2)


def find_channel_folder_name(working_dir: str, channel_index: int) -> str:
    """Find a conversation folder base name for a given channel index.

    Returns the base folder name (without _disabled suffix) or '' if not found.
    Backward-compat wrapper — returns only the first match.
    """
    names = find_channel_folder_names(working_dir, channel_index)
    return names[0] if names else ''


def find_channel_folder_names(working_dir: str, channel_index: int) -> list:
    """Find ALL conversation folder base names for a given channel index.

    Returns a sorted list of base names (without _disabled suffix).
    """
    if not os.path.isdir(working_dir):
        return []
    prefix = f'ch{channel_index}_'
    results = []
    for name in sorted(os.listdir(working_dir)):
        if not os.path.isdir(os.path.join(working_dir, name)):
            continue
        base = name.removesuffix('_disabled')
        if base.startswith(prefix):
            results.append(base)
    return results


def find_own_node_folder_names(working_dir: str) -> list:
    """Find ALL conversation folder base names for the 'own_node' monitor type.

    Returns a sorted list of base names (without _disabled suffix).
    Matches folders starting with 'own_node'.
    """
    if not os.path.isdir(working_dir):
        return []
    results = []
    for name in sorted(os.listdir(working_dir)):
        if not os.path.isdir(os.path.join(working_dir, name)):
            continue
        base = name.removesuffix('_disabled')
        if base == 'own_node' or base.startswith('own_node_'):
            results.append(base)
    return results


def find_node_folder_names(working_dir: str, node_id: str) -> list:
    """Find ALL conversation folder base names for a given node ID.

    Returns a sorted list of base names (without _disabled suffix).
    Matches exact `node_id_hex` prefix (e.g. '3d8309d0') or old-style exact match.
    """
    if not os.path.isdir(working_dir):
        return []
    hex_id = node_id.lstrip('!')
    results = []
    for name in sorted(os.listdir(working_dir)):
        if not os.path.isdir(os.path.join(working_dir, name)):
            continue
        base = name.removesuffix('_disabled')
        # Exact match (old-style) OR matches hex prefix with underscore (new UUID suffix)
        if base == hex_id or base.startswith(hex_id + '_'):
            results.append(base)
    return results


# --- Global runtime enable/disable ---

def get_global_enabled(working_dir: str) -> bool:
    """Read runtime global enabled state. Defaults to True if file doesn't exist."""
    path = os.path.join(working_dir, 'global_enabled.json')
    try:
        with open(path) as f:
            return json.load(f).get('enabled', True)
    except (FileNotFoundError, json.JSONDecodeError):
        return True


def set_global_enabled(working_dir: str, enabled: bool) -> None:
    """Write runtime global enabled state."""
    os.makedirs(working_dir, exist_ok=True)
    path = os.path.join(working_dir, 'global_enabled.json')
    with open(path, 'w') as f:
        json.dump({'enabled': enabled}, f)
