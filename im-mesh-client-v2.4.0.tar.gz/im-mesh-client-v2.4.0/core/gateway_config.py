"""
Device config read/write mixin for the Gateway.

Extracted from gateway.py to keep the core file focused on connection lifecycle.
GatewayConfigMixin is mixed into Gateway and relies on attributes set by Gateway.__init__:
    self._operation_lock, self.meshtastic_client, self.message_router
"""

import asyncio
import logging
from typing import Optional, Dict, Any, List

logger = logging.getLogger(__name__)


class GatewayConfigMixin:
    """Device configuration read/write methods and post-reboot reconnect logic."""

    async def get_device_settings(self) -> Dict[str, Any]:
        """Get device configuration settings.
        
        Acquires _operation_lock to serialize radio access.
        """
        try:
            if self.meshtastic_client.is_connected():
                async with self._operation_lock:
                    return await self.meshtastic_client.get_device_settings()
            else:
                logger.warning("Cannot get device settings - not connected to device")
                return {}
        except (AttributeError, ConnectionError, RuntimeError) as e:
            logger.warning(f"Error getting device settings: {e}")
            return {}

    async def refresh_device_info(self) -> bool:
        """Request fresh device and node information.
        
        Acquires _operation_lock to serialize radio access.
        """
        try:
            if self.meshtastic_client.is_connected():
                async with self._operation_lock:
                    # Request node info update
                    await self.meshtastic_client.request_node_update()
                    
                    # Request channel update
                    await self.meshtastic_client.request_channel_update()
                
                return True
            else:
                logger.warning("Cannot refresh device info - not connected to device")
                return False
        except (ConnectionError, OSError, RuntimeError, AttributeError) as e:
            logger.warning(f"Error refreshing device info: {e}")
            return False

    async def get_device_config(self):
        """Read local node device config — owner, lora, position, channels, mqtt, store_forward."""
        return await self.meshtastic_client.get_device_config()

    async def write_device_config(self, sections: list, payload: dict):
        """Write selected device config sections and reboot the node.

        After a successful write (which triggers node.reboot(secs=5)) we
        schedule _reconnect_after_reboot(delay=5) as an independent background
        task.  It runs outside the operation lock so the API call returns
        immediately; the task then proactively tears down the stale TCP socket
        exactly when the device starts rebooting, so _manage_connection() can
        establish a fresh TCPInterface without waiting for passive detection.
        """
        async with self._operation_lock:
            result = await self.meshtastic_client.write_device_config(sections, payload)

        if result.get('success') and result.get('written'):
            asyncio.create_task(self._reconnect_after_reboot(delay=5))

        return result

    async def _reconnect_after_reboot(self, delay: int = 5) -> None:
        """Proactively reset the Meshtastic TCP connection after a device reboot.

        The node.reboot(secs=5) call in write_device_config starts the device
        reboot *delay* seconds from now.  We wait the same interval, then force-
        disconnect so _manage_connection() rebuilds the TCPInterface from scratch
        instead of relying on the passive TCP-drop detection (which is unreliable
        when the old socket is in a half-closed state).
        """
        await asyncio.sleep(delay)
        logger.info("Proactive disconnect: device is rebooting — tearing down TCP interface now")
        try:
            await self.meshtastic_client.disconnect()
        except Exception as exc:
            logger.warning(f"Proactive disconnect error (non-fatal): {exc}")

    async def refresh_node_data(self) -> None:
        """Force a full re-fetch of node/channel data from the device."""
        async with self._operation_lock:
            await self.meshtastic_client.refresh_node_data()
