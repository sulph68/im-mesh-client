"""core/path_utils.py — Shared project-root path resolution.

All components that need to locate files relative to the project root
should use resolve_project_path() rather than duplicating the
os.environ.get('MESH_PROJECT_ROOT', os.getcwd()) pattern.
"""

import os


def resolve_project_path(rel: str) -> str:
    """Return the absolute, real path of *rel* relative to the project root.

    The project root is determined by the ``MESH_PROJECT_ROOT`` environment
    variable; if that is not set, the current working directory is used.

    Args:
        rel: A path fragment relative to the project root, e.g. ``"./telegram"``
             or ``"sched_messages/config"``.

    Returns:
        Absolute real path string (symlinks resolved).
    """
    root = os.environ.get('MESH_PROJECT_ROOT', os.getcwd())
    return os.path.realpath(os.path.join(root, rel))
