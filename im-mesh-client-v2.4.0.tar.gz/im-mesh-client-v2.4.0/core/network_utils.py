"""core/network_utils.py — Shared network helper utilities."""

_LOCALHOST_ALIASES = {'localhost', '127.0.0.1', '::1', '0:0:0:0:0:0:0:1'}


def _canon_host(host: str) -> str:
    """Normalise a hostname so all localhost aliases compare equal."""
    return '127.0.0.1' if host.lower().strip() in _LOCALHOST_ALIASES else host.lower().strip()


def is_local_host(host: str) -> bool:
    """Return True if *host* resolves to the local machine."""
    return _canon_host(host) == '127.0.0.1'


def hosts_match(host_a: str, host_b: str) -> bool:
    """Return True if both host strings refer to the same host (localhost-aware)."""
    return _canon_host(host_a) == _canon_host(host_b)
