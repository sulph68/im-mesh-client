"""
Gateway core for managing Meshtastic connection and message flow.

Central coordinator for all Meshtastic communication and internal routing.
"""

import asyncio
import logging
import time
from typing import Optional, Dict, Any, List
from datetime import datetime
from .meshtastic_client import MeshtasticClient
from .packet_handler import PacketHandler
from .fragment_reassembler import FragmentReassembler
from .message_router import MessageRouter
from .constants import (PortNum, CONNECTION_CHECK_INTERVAL, MIN_SEND_INTERVAL, DEFAULT_CHAR_LIMIT,
                         NODE_REFRESH_MIN, NODE_REFRESH_MAX, MSG_DELAY_MIN, MSG_DELAY_MAX,
                         SEG_DELAY_MIN, SEG_DELAY_MAX, CHAR_LIMIT_MIN, CHAR_LIMIT_MAX)
from .gateway_send import GatewaySendMixin
from .gateway_config import GatewayConfigMixin
from storage.database import Database
from storage.node_store import NodeStore
from config.settings import Settings
from .log_utils import tagged_logger

logger = logging.getLogger(__name__)

class Gateway(GatewaySendMixin, GatewayConfigMixin):
    """
    Central gateway for Meshtastic communication.
    
    Manages the connection to Meshtastic devices, coordinates packet processing,
    and handles message routing throughout the application.
    """
    
    def __init__(self, settings: Settings, database: Database):
        self.settings = settings
        self.database = database
        
        # Determine connection type
        connection_type = getattr(settings.meshtastic, 'connection_type', 'tcp')
        serial_port = getattr(settings.meshtastic, 'serial_port', None)
        
        # Core components
        self.meshtastic_client = MeshtasticClient(
            host=settings.meshtastic.host,
            port=settings.meshtastic.port,
            connection_type=connection_type,
            serial_port=serial_port
        )
        
        self.message_router = MessageRouter()
        self.node_store = NodeStore(database)
        self.fragment_reassembler = FragmentReassembler(database, self.message_router)
        
        # State
        self.running = False
        self._user_disconnected = False  # True when user explicitly disconnects
        self.connection_task: Optional[asyncio.Task] = None
        self._node_refresh_task: Optional[asyncio.Task] = None
        self.reconnect_delay = settings.meshtastic.reconnect_delay
        self.auto_reconnect = True  # Always auto-reconnect unless user-initiated disconnect
        self._connection_ready = asyncio.Event()  # Signals when first connection attempt is done
        self._node_refresh_interval = getattr(settings.meshtastic, 'node_refresh_interval', 15)  # minutes

        # Configurable send delays (read from settings; fall back to constants).
        self._message_delay: float = float(getattr(settings.meshtastic, 'message_delay', MIN_SEND_INTERVAL))
        self._segment_delay: int = int(getattr(settings.encoding, 'segment_delay', 15))
        self._character_limit: int = int(getattr(settings.meshtastic, 'character_limit', DEFAULT_CHAR_LIMIT))
        
        # CRITICAL: Gateway-level operation lock.
        # Serializes ALL high-level operations (send, query, refresh) so that
        # only one action runs against the radio at a time.  The Meshtastic
        # device is a low-bandwidth radio with a single protobuf session;
        # concurrent TCP requests cause connection drops and crashes.
        self._operation_lock = asyncio.Lock()
        
        # Inter-send pacing: track the monotonic time of the last radio send.
        # The LoRa radio is half-duplex; sending a new packet while the
        # firmware is still in a TX+ACK retransmit cycle for the previous
        # packet causes the new packet to be silently dropped.  We enforce
        # a minimum gap of MIN_SEND_INTERVAL seconds between consecutive
        # sendText/sendData calls, sleeping inside _operation_lock so the
        # caller and the radio both get a breather.
        self._last_send_time: float = 0.0  # monotonic timestamp

        # Short-lived cache for get_node_list() to reduce redundant lock
        # acquisitions when the frontend polls /api/nodes every 5 seconds.
        # Invalidated whenever a packet updates node data.
        self._node_list_cache: Optional[List[Dict[str, Any]]] = None
        self._node_list_cache_ts: float = 0.0
        self._NODE_LIST_CACHE_TTL: float = 2.0  # seconds

        self._log = tagged_logger(logger, f"{settings.meshtastic.host}:{settings.meshtastic.port}")

        # PacketHandler must be created after _node_refresh_interval is set
        self.packet_handler = PacketHandler(
            self.node_store,
            self.message_router, self.fragment_reassembler,
            node_refresh_interval=self._node_refresh_interval,
            host=settings.meshtastic.host,
            port=settings.meshtastic.port
        )

    # --- Public property accessors for per-session configuration ---

    @property
    def char_limit(self) -> int:
        """Maximum characters per outbound Meshtastic text message."""
        return self._character_limit

    @char_limit.setter
    def char_limit(self, value: int) -> None:
        self._character_limit = int(max(CHAR_LIMIT_MIN, min(CHAR_LIMIT_MAX, value)))

    @property
    def msg_delay(self) -> float:
        """Minimum inter-send delay in seconds between consecutive radio sends."""
        return self._message_delay

    @msg_delay.setter
    def msg_delay(self, value: float) -> None:
        self._message_delay = float(max(MSG_DELAY_MIN, min(MSG_DELAY_MAX, value)))

    @property
    def segment_delay(self) -> int:
        """Delay in seconds between consecutive image segments."""
        return self._segment_delay

    @segment_delay.setter
    def segment_delay(self, value: int) -> None:
        self._segment_delay = int(max(SEG_DELAY_MIN, min(SEG_DELAY_MAX, value)))

    @property
    def node_refresh_interval(self) -> int:
        """Node refresh polling interval in minutes."""
        return self._node_refresh_interval

    @node_refresh_interval.setter
    def node_refresh_interval(self, value: int) -> None:
        self._node_refresh_interval = int(max(NODE_REFRESH_MIN, min(NODE_REFRESH_MAX, value)))

    async def start(self) -> None:
        """Start the gateway and all its components."""
        try:
            self._log.info("Starting Meshtastic gateway")
            
            # Start fragment reassembler
            await self.fragment_reassembler.start()
            
            # Start packet handler priority queue worker
            await self.packet_handler.start()
            
            # Register packet callback
            self.meshtastic_client.on_packet(self.packet_handler.handle_packet)
            
            # Start connection management
            self.running = True
            self.connection_task = asyncio.create_task(self._manage_connection())
            
            # Start periodic node refresh
            self._node_refresh_task = asyncio.create_task(self._periodic_node_refresh())
            
            self._log.info("Meshtastic gateway started")
            
        except (ConnectionError, OSError, RuntimeError) as e:
            self._log.error(f"Failed to start gateway: {e}")
            raise
    
    async def stop(self) -> None:
        """Stop the gateway and cleanup resources.
        
        Called when the user explicitly disconnects. Sets the user_disconnected
        flag to prevent auto-reconnect.
        """
        try:
            self._log.info("Stopping Meshtastic gateway (user-initiated disconnect)")
            
            self.running = False
            self._user_disconnected = True  # Prevent auto-reconnect
            
            # Cancel connection task
            if self.connection_task:
                self.connection_task.cancel()
                try:
                    await self.connection_task
                except asyncio.CancelledError:
                    pass
                self.connection_task = None
            
            # Cancel node refresh task
            if self._node_refresh_task:
                self._node_refresh_task.cancel()
                try:
                    await self._node_refresh_task
                except asyncio.CancelledError:
                    pass
                self._node_refresh_task = None
            
            # Disconnect from Meshtastic
            if self.meshtastic_client.is_connected():
                await self.meshtastic_client.disconnect()
            
            # Stop packet handler priority queue worker
            await self.packet_handler.stop()
            
            # Stop fragment reassembler
            await self.fragment_reassembler.stop()
            
            # Notify connection status
            await self.message_router.route_connection_status(False)
            
            self._log.info("Meshtastic gateway stopped")
            
        except (ConnectionError, OSError, RuntimeError, asyncio.CancelledError) as e:
            self._log.warning(f"Error stopping gateway: {e}")
    
    async def _refresh_device_data(self) -> None:
        """Refresh node data from the connected device.
        
        Acquires _operation_lock to prevent concurrent radio access.
        """
        async with self._operation_lock:
            try:
                channels = await self.meshtastic_client.get_channel_info()
                if channels:
                    self._log.info(f"Refreshed {len(channels)} channels from device")
                
                nodes = await self.meshtastic_client.get_node_list()
                if nodes:
                    for node in nodes:
                        if 'node_id' not in node and 'id' in node:
                            node['node_id'] = node['id']
                        if 'node_id' in node:
                            await self.node_store.upsert_node(node)
                    self._log.info(f"Refreshed {len(nodes)} nodes")
                
                await self.message_router.route_message({
                    'message_type': 'data_refresh',
                    'timestamp': datetime.now().isoformat(),
                    'channels_count': len(channels) if channels else 0,
                    'nodes_count': len(nodes) if nodes else 0
                })
            except (ConnectionError, OSError, RuntimeError, AttributeError) as e:
                self._log.warning(f"Error refreshing device data: {e}")

    async def _periodic_node_refresh(self) -> None:
        """Background task to periodically refresh node data.
        
        Runs every node_refresh_interval minutes (default 15, configurable 5-60).
        Only refreshes when connected.  Skips refresh if another operation
        is currently holding _operation_lock to avoid queuing up stale requests.
        """
        while self.running:
            try:
                interval_secs = max(5, min(60, self._node_refresh_interval)) * 60
                await asyncio.sleep(interval_secs)
                
                if self.meshtastic_client.is_connected():
                    # Skip if another operation is in progress - don't queue up
                    if self._operation_lock.locked():
                        self._log.debug("Skipping periodic refresh - operation in progress")
                        continue
                    self._log.info(f"Periodic node refresh (every {self._node_refresh_interval}min)")
                    await self._refresh_device_data()
                else:
                    self._log.debug("Skipping periodic refresh - not connected")
                    
            except asyncio.CancelledError:
                break
            except Exception as e:  # Broad: keep periodic refresh loop alive
                self._log.warning(f"Error in periodic node refresh: {e}")
                await asyncio.sleep(60)  # Back off on error

    async def _manage_connection(self) -> None:
        """Background task to manage Meshtastic connection persistently.
        
        Keeps the TCP connection open for the lifetime of the session.
        On connection loss, retries every 10 seconds and refreshes data on reconnect.
        
        Connection and post-connect data refresh are protected by _operation_lock
        to prevent concurrent radio access from API calls during reconnection.
        """
        was_previously_connected = False
        
        while self.running:
            try:
                if not self.meshtastic_client.is_connected():
                    if was_previously_connected:
                        self._log.warning("Connection lost. Attempting reconnect...")
                        await self.message_router.route_connection_status(False, {
                            'error': 'Connection lost',
                            'host': self.settings.meshtastic.host,
                            'port': self.settings.meshtastic.port,
                            'reconnecting': True
                        })
                    
                    self._log.info("Attempting to connect to Meshtastic device")
                    
                    # Acquire operation lock during connect + initial data load
                    # to prevent API calls from hitting a half-initialized interface
                    async with self._operation_lock:
                        success = await self.meshtastic_client.connect(
                            timeout=self.settings.meshtastic.connection_timeout
                        )
                        
                        if success:
                            node_info = await self.meshtastic_client.get_node_info()
                            status_info = dict(node_info) if node_info else {}
                            if was_previously_connected:
                                status_info['reconnected'] = True
                            await self.message_router.route_connection_status(True, status_info)
                            was_previously_connected = True
                            self._connection_ready.set()
                            
                            await self.meshtastic_client.flush_pending_packets()
                    
                    if success:
                        # Refresh device data (acquires its own lock)
                        await self._refresh_device_data()
                        self._log.info("Connected to Meshtastic device")
                    else:
                        await self.message_router.route_connection_status(False, {
                            'error': 'Connection failed',
                            'host': self.settings.meshtastic.host,
                            'port': self.settings.meshtastic.port,
                            'reconnecting': self.auto_reconnect
                        })
                        self._connection_ready.set()
                        
                        if self.auto_reconnect:
                            self._log.info(f"Reconnecting in {self.reconnect_delay}s")
                            await asyncio.sleep(self.reconnect_delay)
                        else:
                            break
                else:
                    await asyncio.sleep(CONNECTION_CHECK_INTERVAL)
                
            except asyncio.CancelledError:
                break
            except (ConnectionError, OSError, TimeoutError, RuntimeError) as e:
                self._log.warning(f"Connection error in management loop: {e}")
                await self.message_router.route_error(
                    'connection_error', str(e),
                    {'host': self.settings.meshtastic.host, 'port': self.settings.meshtastic.port}
                )
                
                if self.auto_reconnect:
                    await asyncio.sleep(self.reconnect_delay)
                else:
                    break
            except Exception as e:  # Broad: keep loop alive for unexpected errors
                self._log.warning(f"Unexpected error in connection management: {e}")
                await self.message_router.route_error(
                    'connection_error', str(e),
                    {'host': self.settings.meshtastic.host, 'port': self.settings.meshtastic.port}
                )
                
                if self.auto_reconnect:
                    await asyncio.sleep(self.reconnect_delay)
                else:
                    break
    
    async def _ensure_connected(self) -> bool:
        """Wait for initial connection to complete.
        
        Does NOT attempt its own reconnection - that is handled exclusively
        by _manage_connection() to prevent duplicate TCP connections.
        
        Returns True if connected, False if not connected.
        """
        try:
            await asyncio.wait_for(self._connection_ready.wait(), timeout=20)
        except asyncio.TimeoutError:
            self._log.warning("Timed out waiting for initial connection - proceeding anyway")
        
        if not self.meshtastic_client.is_connected():
            await self.message_router.route_error(
                'send_error', 'Not connected to Meshtastic device. Waiting for auto-reconnect.'
            )
            return False
        return True
    async def get_node_list(self) -> List[Dict[str, Any]]:
        """Get list of all known nodes.

        Returns a cached result if the cache is still within TTL, otherwise
        acquires _operation_lock and fetches fresh data from the device.
        """
        now = time.monotonic()
        if (self._node_list_cache is not None
                and (now - self._node_list_cache_ts) < self._NODE_LIST_CACHE_TTL):
            return self._node_list_cache
        try:
            async with self._operation_lock:
                nodes = await self.meshtastic_client.get_node_list()
            self._node_list_cache = nodes
            self._node_list_cache_ts = now
            self._log.info(f"Retrieved {len(nodes)} nodes from client")
            return nodes
        except (AttributeError, RuntimeError, ConnectionError) as e:
            self._log.warning(f"Error in gateway get_node_list: {e}")
            return []

    def _invalidate_node_list_cache(self) -> None:
        """Invalidate the node list cache (call on any node data update)."""
        self._node_list_cache = None
        self._node_list_cache_ts = 0.0
    
    async def get_fragments(self) -> List[Dict[str, Any]]:
        """Get status of all active fragments."""
        return await self.fragment_reassembler.get_all_fragments()
    
    async def get_connection_status(self) -> Dict[str, Any]:
        """Get current connection status.
        
        Acquires _operation_lock when fetching node info from the device.
        """
        connected = self.meshtastic_client.is_connected()
        
        status = {
            'connected': connected,
            'host': self.settings.meshtastic.host,
            'port': self.settings.meshtastic.port,
            'auto_reconnect': self.auto_reconnect
        }
        
        if connected:
            async with self._operation_lock:
                node_info = await self.meshtastic_client.get_node_info()
            status.update(node_info)
        
        return status
    
    async def get_favorite_nodes(self) -> List[Dict[str, Any]]:
        """Get favorite nodes."""
        try:
            return await self.node_store.get_favorites()
        except (OSError, RuntimeError, KeyError) as e:
            self._log.warning(f"Error getting favorite nodes: {e}")
            return []
    
    async def set_node_favorite(self, node_id: str, is_favorite: bool = True) -> bool:
        """Set node favorite status."""
        try:
            return await self.node_store.set_favorite(node_id, is_favorite)
        except (OSError, RuntimeError, KeyError) as e:
            self._log.warning(f"Error setting node favorite: {e}")
            return False
    
    async def get_channels(self) -> List[Dict[str, Any]]:
        """Get channel configuration directly from the live device.
        
        Acquires _operation_lock to serialize radio access.
        """
        try:
            if self.meshtastic_client.is_connected():
                async with self._operation_lock:
                    device_channels = await self.meshtastic_client.get_channel_info()
                self._log.info(f"Retrieved {len(device_channels)} channels from device")
                return device_channels
            
            self._log.warning("Cannot get channels - not connected to device")
            return []
            
        except (AttributeError, ConnectionError, RuntimeError) as e:
            self._log.warning(f"Error getting channels: {e}")
            return []
    
    async def refresh_channels(self) -> bool:
        """Request fresh channel configuration from device.
        
        Acquires _operation_lock to serialize radio access.
        """
        try:
            if self.meshtastic_client.is_connected():
                async with self._operation_lock:
                    self._log.info("Requesting channel configuration refresh from device")
                    await self.meshtastic_client.request_channel_update()
                    
                    # Give device time to respond, then re-fetch
                    await asyncio.sleep(2)
                    
                    device_channels = await self.meshtastic_client.get_channel_info()
                self._log.info(f"Channel refresh completed - {len(device_channels)} channels")
                return True
            else:
                self._log.warning("Cannot refresh channels - not connected to device")
                return False
        except (ConnectionError, OSError, RuntimeError, AttributeError) as e:
            self._log.warning(f"Error refreshing channels: {e}")
            return False
