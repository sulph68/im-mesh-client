/**
 * Meshtastic Web Client - Data Module: WS message handler, ACK, loadInitialData, loadNodes, loadChannels
 */

const _ACK_DEBUG = false;  // Set true to enable ACK trace logs

Object.assign(MeshtasticClient.prototype, {

handleWebSocketMessage(data) {
    switch (data.type) {
        case 'auth_success':
                            this.addSystemMessage('Authentication successful - Loading device data...', 'success');
            this.loadInitialData();
            // Dynamically update Schedule button visibility for this session
            if (typeof window.checkSchedulerApplicable === 'function') {
                setTimeout(window.checkSchedulerApplicable, 500);
            }
            // Dynamically update Auto Responder button visibility for this session
            if (typeof window.checkAutoResponderApplicable === 'function') {
                setTimeout(window.checkAutoResponderApplicable, 500);
            }
            // Dynamically update Telegram button visibility for this session
            if (typeof window.checkTelegramApplicable === 'function') {
                setTimeout(window.checkTelegramApplicable, 500);
            }
            // Refresh node info panel immediately on new connection
            if (typeof window.refreshNodeInfo === 'function') {
                setTimeout(window.refreshNodeInfo, 500);
            }
            break;

        case 'connected':
                            break;

        case 'message':
        case 'text':
        case 'binary':
            // 'message' is the primary path from subscription callbacks.
            // 'text' and 'binary' are fallback types from the broadcast path.
            this.addMessage(data.data);
            if (data.data && data.data.text && !data.data.is_image) {
                const fromName = data.data.from || data.data.from_node || 'Unknown';
                this.logCommunication('IN', `[${fromName}] ${(data.data.text || '').substring(0, 80)}`, 'info');
            }
            break;

        case 'node_update':
        case 'position_update':
            this.updateNode(data.data);
            break;

        case 'channel_update':
            this.updateChannels(data.data);
            this.addSystemMessage('Channel information updated', 'info');
            break;

        case 'connection_status':
            this.handleConnectionStatusUpdate(data.data);
            break;

        case 'binary_complete':
            // Fragment reassembly complete - the server concatenated all
            // segment payloads into one string.  Individual segments are
            // ALREADY displayed and stored in IndexedDB as they arrive.
            // Adding this concatenated blob would pollute IndexedDB and
            // cause _reassembleFromDB to pick up the garbled concat
            // instead of the clean individual segments.  So we IGNORE it.
            logger.debug('binary_complete received (ignored - individual segments already stored)');
            break;

        case 'image_complete':
            // Server-side decoded image from fragment reassembly.
            // Only display if it actually contains a decoded image.
            // Do NOT store the concatenated payload — it corrupts IndexedDB segment lookup.
            // Strategy: try to inject into an existing segment-group-box for this checksum.
            // If no group box exists yet (timing race or non-active channel), cache the
            // decoded image by checksum so _checkForImageSegments/_scanForImageSegments can
            // pick it up when the group box is eventually built.  This avoids creating a
            // separate "Image received" message that duplicates the segment group display.
            if (data.data && data.data.decoded_image) {
                const fragId = data.data.fragment_id || '';
                const csMatch = fragId.match(/_([0-9a-fA-F]{8})$/);
                const imgChecksum = csMatch ? csMatch[1] : null;
                let injectedIntoBox = false;
                if (imgChecksum) {
                    const container = document.getElementById('messagesContainer');
                    if (container) {
                        const groupBox = container.querySelector(`.segment-group-box[data-checksum="${imgChecksum}"]`);
                        if (groupBox) {
                            if (!groupBox.querySelector('img')) {
                                const img = document.createElement('img');
                                img.src = `data:image/png;base64,${data.data.decoded_image}`;
                                img.alt = 'Image';
                                img.style.cssText = 'max-width:200px;max-height:200px;border-radius:4px;border:1px solid var(--border);margin-top:0.5rem;display:block;';
                                groupBox.appendChild(img);
                                groupBox.dataset.serverDecoded = 'true';
                                // Cancel any pending auto-reassemble since we have the decoded image
                                if (this._autoReassembleTimers && this._autoReassembleTimers[imgChecksum]) {
                                    clearTimeout(this._autoReassembleTimers[imgChecksum]);
                                    delete this._autoReassembleTimers[imgChecksum];
                                }
                            }
                            injectedIntoBox = true;
                        }
                    }
                }
                if (!injectedIntoBox && imgChecksum) {
                    // Group box not in DOM yet (non-active channel or timing race before
                    // last segment is rendered).  Cache the decoded image so the group
                    // box can absorb it when it is built by _checkForImageSegments or
                    // _scanForImageSegments.  Do NOT fall back to addMessage — that would
                    // create a duplicate "Image received" message alongside the group box.
                    if (!this._serverDecodedImages) this._serverDecodedImages = new Map();
                    this._serverDecodedImages.set(imgChecksum, data.data.decoded_image);
                }
            }
            break;

        case 'ack':
            // Ack/Nak received for a sent message
            this._handleAckReceived(data.data);
            break;

        case 'pong':
            // Heartbeat response - update latency display
            this._handlePong(data);
            break;

        case 'scheduled_message':
            // A scheduled message was just fired — display it with clock emoji
            if (data.data) {
                this.addMessage({ ...data.data, source: 'scheduler' });
                this.logCommunication('OUT', `[Scheduler] Message sent: "${(data.data.text || '').substring(0, 60)}"`, 'success');
            }
            break;

        case 'scheduled_history':
            // Batch of scheduled messages sent while browser was offline
            if (data.data && Array.isArray(data.data.messages)) {
                data.data.messages.forEach(msg => this.addMessage({ ...msg, source: 'scheduler' }));
                this.logCommunication('INFO', `[Scheduler] ${data.data.messages.length} scheduled message(s) delivered from offline buffer`, 'info');
            }
            break;

        case 'ar_history':
            // Batch of AR responses sent while browser was offline
            if (data.data && Array.isArray(data.data.messages)) {
                data.data.messages.forEach(msg => this.addMessage({ ...msg, source: 'ar' }));
                this.logCommunication('INFO', `[AutoResponder] ${data.data.messages.length} AR response(s) delivered from offline buffer`, 'info');
            }
            break;

        case 'ar_message':
            // Auto Responder sent a reply — display it in the message panel
            if (data.data) {
                this.addMessage({ ...data.data, source: 'ar' });
                this.logCommunication('OUT', `[AutoResponder] Response: "${(data.data.text || '').substring(0, 60)}"`, 'success');
            }
            break;

        case 'ar_action':
            // Auto Responder comm-log entry (kept for backward compat; ar_message now handles display)
            if (data.data && !data.data.response_sent) {
                const fromNode = data.data.from_node || '?';
                const trigger = (data.data.triggered_by || '').substring(0, 60);
                this.logCommunication('OUT', `[AutoResponder] Response sent to ${fromNode} (triggered by: "${trigger}")`, 'success');
            }
            break;

        case 'fragment_progress':
            break;

        case 'error':
            console.error('Server error:', data.message || data.data);
            const errMsg = data.message || (data.data && data.data.error_message) || 'Unknown server error';
            this.showMessage(errMsg, 'error');
            // If session not found, stop reconnecting and show login screen
            if (errMsg.includes('Session not found')) {
                this._resetWsReconnect();
                this._wsSessionLost = true;  // Flag to prevent auto-reconnect in onclose
            }
            break;

        case 'system':
            if (data.data && data.data.message) {
                this.addSystemMessage(data.data.message, data.data.level || 'info');
            }
            break;

        default:
    }
},

handleConnectionStatusUpdate(statusData) {
    if (!statusData) return;

    if (statusData.connected) {
        this.updateConnectionStatus('connected', 'Connected');
        this.addSystemMessage('Connection to Meshtastic node established', 'success');

        // Cache own node ID immediately from the connection_info so it's
        // available before the first node list render (prevents showing
        // own node in favourites on page refresh / first load).
        const connInfo = statusData.connection_info || {};
        const rawNodeId = connInfo.node_id;
        if (rawNodeId && rawNodeId !== 'unknown') {
            this._myNodeId = _normalizeNodeId(rawNodeId);
            // Persist so it survives page refresh before loadNodes() fires
            try {
                localStorage.setItem('meshtastic_myNodeId_' + this.sessionId, this._myNodeId);
            } catch (e) { /* quota or private mode */ }
        }

        // Update browser tab title with node name
        this._updateConnectionTitle();

        // If this was a reconnect, data may have been refreshed.
        // The 'reconnected' flag may be at top level OR nested inside connection_info
        // depending on which code path emitted the WS message.
        const isReconnect = statusData.reconnected
                         || (statusData.connection_info && statusData.connection_info.reconnected);
        if (isReconnect) {
            this.addSystemMessage('Data refreshed after reconnection', 'info');
            // Reload data to get fresh info
            this._initialDataLoaded = false;
            this._initialChannelHistoryLoaded = false;
            this.loadInitialData();
            // Re-check schedule button applicability for the (possibly new) session
            if (typeof window.checkSchedulerApplicable === 'function') {
                setTimeout(window.checkSchedulerApplicable, 500);
            }
            // Re-check Auto Responder button applicability
            if (typeof window.checkAutoResponderApplicable === 'function') {
                setTimeout(window.checkAutoResponderApplicable, 500);
            }
            // Re-check Telegram button applicability for the (possibly new) session
            if (typeof window.checkTelegramApplicable === 'function') {
                setTimeout(window.checkTelegramApplicable, 500);
            }
            // Refresh node info panel on reconnect (force re-fetch from device)
            if (typeof window.refreshNodeInfo === 'function') {
                setTimeout(window.refreshNodeInfo, 500);
            }
            // Dismiss reboot overlay if active (device reconnected after save+reboot)
            document.dispatchEvent(new CustomEvent('reboot:done'));
            // Reset attempt counter for next reboot cycle
            this._rebootAttemptCount = 0;
        }
    } else {
        if (statusData.reconnecting) {
            this.updateConnectionStatus('connecting', 'Reconnecting...');
            this.addSystemMessage('Connection lost - reconnecting automatically...', 'warning');
            // Track attempt count locally (each reconnecting:true message = one attempt)
            this._rebootAttemptCount = (this._rebootAttemptCount || 0) + 1;
            // Update reboot overlay progress if active
            document.dispatchEvent(new CustomEvent('reboot:disconnected', {
                detail: { attempt: this._rebootAttemptCount }
            }));
            document.dispatchEvent(new CustomEvent('reboot:log', {
                detail: { message: 'Waiting for device… (attempt ' + this._rebootAttemptCount + ')', color: '#e0a030' }
            }));
        } else {
            this.updateConnectionStatus('disconnected', 'Disconnected');
            this.addConnectionLostMessage();
        }
    }
},

/**
 * Handle an ack/nak received from the mesh network.
 * Any successful ACK (node or destination) upgrades status to "delivered"
 * since "sent" is already set when the API call succeeds.
 *
 * Updates the tick-mark indicator in the DOM and persists to IndexedDB.
 */
_handleAckReceived(ackData) {
    if (!ackData || !ackData.request_id) return;

    const requestId = ackData.request_id;
    const ackOk = ackData.ack_received;
    const errorReason = ackData.error_reason || '';
    const ackType = ackData.ack_type || 'destination';  // 'node' or 'destination'

    _ACK_DEBUG && console.log(`ACK received: requestId=${requestId} ack=${ackOk} type=${ackType} error=${errorReason}`);

    // Dispatch to image segment ACK handler if active
    if (this._imageSegmentAckHandler) {
        this._imageSegmentAckHandler(ackData);
    }

    // Any successful ACK -> delivered.  "Sent" is set at API-call time.
    const ackStatus = ackOk ? 'delivered' : 'failed';
    this._persistAckStatus(requestId, ackOk, errorReason, ackType, ackStatus);

    // Find the message element with this packet_id (may not be in DOM if on different panel)
    const container = document.getElementById('messagesContainer');
    if (!container) return;

    const msgEl = container.querySelector(`[data-packet-id="${requestId}"]`);
    if (!msgEl) {
        _ACK_DEBUG && console.log(`No message element found for packetId=${requestId} (may be on different panel)`);
        return;
    }

    // Update tick-mark indicator (span.ack-ticks inside .message-header)
    const tickSpan = msgEl.querySelector('.ack-ticks');
    if (!tickSpan) return;

    if (ackOk) {
        // Upgrade to delivered (double tick, green)
        tickSpan.className = 'ack-ticks ack-delivered';
        tickSpan.textContent = '\u2713\u2713';
        tickSpan.title = 'Delivered';
        tickSpan.setAttribute('data-ack-status', 'delivered');
    } else {
        tickSpan.className = 'ack-ticks ack-failed';
        tickSpan.textContent = '\u2717';
        tickSpan.title = `Nak: ${errorReason}`;
        tickSpan.setAttribute('data-ack-status', 'failed');
    }
},

/**
 * Persist ack status into IndexedDB message history.
 * Uses the byPacketId index for efficient lookup.
 * Any successful ACK (node or destination) -> 'delivered'.
 */
_persistAckStatus(packetId, ackOk, errorReason, ackType, status) {
    if (!this.storage || !packetId) return;

    const finalStatus = status || (ackOk ? 'delivered' : 'failed');
    this.storage.updateAckStatusAsync(packetId, ackOk, errorReason, ackType, finalStatus).catch(e => {
        console.error('Error persisting ack status:', e);
    });
},

loadInitialData() {
    if (this._initialDataLoaded) {
        return;
    }
    this._initialDataLoaded = true;

    try {
        // Add a small delay to ensure WebSocket auth is complete
        setTimeout(async () => {

            // Update status to show loading
            this.showStatus('Loading nodes and channels...');
            this.addSystemMessage('Loading device data automatically...', 'info');

            try {
                // Load all data in parallel for efficiency
                await Promise.all([
                    this.loadNodes(),
                    this.loadChannels()
                ]);

                this.showStatus('Connected - Data loaded successfully');
                this.addSystemMessage('Device data loaded successfully', 'success');

                // Update title with connected node name
                this._updateConnectionTitle();

                // Re-apply notification badges - buffered messages that
                // arrived via WS flush before the DOM was ready may have
                // incremented _unreadCounts but couldn't update badges
                // because channel/node elements didn't exist yet.
                this._updateNotificationBadges();

            } catch (error) {
                console.error('Error loading initial data:', error);
                this.showMessage('Failed to load initial data: ' + error.message, 'error');
                this.addSystemMessage('Failed to load device data: ' + error.message, 'error');
            }

        }, INITIAL_DATA_DELAY_MS); // Delay for WebSocket stability

    } catch (error) {
        console.error('Error in loadInitialData:', error);
        this.showMessage('Error displaying main app: ' + error.message, 'error');
    }
},

/** Fetch session info and update page title with connected node name. */
async _updateConnectionTitle() {
    if (!this.sessionId) return;
    try {
        const response = await fetch(`/api/sessions/${this.sessionId}`, {
            headers: { 'X-Session-ID': this.sessionId }
        });
        if (!response.ok) return;
        const data = await response.json();
        const conn = data.data?.connection;
        if (!conn) return;

        const nodeName = conn.long_name || conn.short_name || null;
        if (nodeName && nodeName !== 'unknown') {
            document.title = `Im Mesh Client (${nodeName})`;
        } else if (!this._titleRetried) {
            // Node name not available yet - retry once after 10s
            this._titleRetried = true;
            setTimeout(() => this._updateConnectionTitle(), TITLE_UPDATE_DELAY_MS);
        }
    } catch (e) {
        console.error('Error updating connection title:', e);
    }
},

async loadNodes(force = false) {
    if (!this.sessionId) return;

    if (force) {
        this.logCommunication('OUT', 'Forcing node data refresh from device...', 'info');
    } else {
        this.logCommunication('OUT', 'Loading nodes from device', 'info');
    }

    try {
        const url = force ? '/api/nodes?force=true' : '/api/nodes';
        const response = await fetch(url, {
            headers: {
                'X-Session-ID': this.sessionId
            }
        });

        if (response.ok) {
            const data = await response.json();
            if (force) {
                this.logCommunication('IN', `Node refresh complete: ${data.data?.count || 0} nodes updated from device`, 'success');
            } else {
                this.logCommunication('IN', `Nodes loaded: ${data.data?.count || 0} nodes`, 'success');
            }

            if (data.success && data.data.nodes) {
                // Store our own node ID so we can filter it from the list
                if (data.data.my_node_id) {
                    this._myNodeId = _normalizeNodeId(data.data.my_node_id);
                    try {
                        localStorage.setItem('meshtastic_myNodeId_' + this.sessionId, this._myNodeId);
                    } catch (e) { /* quota */ }
                }
                this.updateNodesList(data.data.nodes);

                // If server returned no my_node_id (not ready yet) and we
                // don't have one cached, retry once after 2s when the server
                // should have received getMyNodeInfo() from the radio.
                if (!this._myNodeId && !data.data.my_node_id) {
                    setTimeout(() => this.loadNodes(), 2000);
                }
            }
        } else {
            const errorText = await response.text();
            console.error('Nodes load failed:', errorText);
            this.logCommunication('IN', `Nodes load failed: HTTP ${response.status}`, 'error');
        }
    } catch (error) {
        console.error('Load nodes error:', error);
        this.logCommunication('IN', `Nodes load error: ${error.message}`, 'error');
    } finally {
        if (document.activeElement) document.activeElement.blur();
    }
},

async loadChannels() {
    if (!this.sessionId) return;

    this.logCommunication('OUT', 'Loading channels from device', 'info');

    try {
        const response = await fetch('/api/channels', {
            headers: {
                'X-Session-ID': this.sessionId
            }
        });

        if (response.ok) {
            const data = await response.json();
            this.logCommunication('IN', `Channels loaded: ${data.data?.count || 0} channels`, 'success');

            if (data.success && data.data.channels) {
                this.updateChannelsList(data.data.channels);
            }
        } else {
            const errorText = await response.text();
            console.error('Channels load failed:', errorText);
            this.logCommunication('IN', `Channels load failed: HTTP ${response.status}`, 'error');
        }
    } catch (error) {
        console.error('Load channels error:', error);
        this.logCommunication('IN', `Channels load error: ${error.message}`, 'error');
    } finally {
        if (document.activeElement) document.activeElement.blur();
    }
}
});
