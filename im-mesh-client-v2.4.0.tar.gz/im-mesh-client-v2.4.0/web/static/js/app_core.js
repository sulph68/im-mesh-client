/**
 * Im Mesh Client v2.3 - Multi-tenant
 * Core: Class definition, constructor, init, setup, event listeners.
 * Methods added by js/app_connection.js, js/app_data.js, js/app_nodes.js,
 * js/app_ui.js, js/app_sessions.js, js/app_messages.js, js/app_images.js.
 */

/* ── Named constants (extracted from inline magic numbers) ── */
// Message/segment send delays are mutable: updated at runtime from /api/app/settings.
let MSG_QUEUE_DELAY_MS         = 5000;   // Delay between queued text message sends (default 5s)
const WS_MAX_RECONNECT         = 50;     // Max WebSocket reconnect attempts
const WS_RECONNECT_DELAY_MS    = 10000;  // Delay between reconnect attempts
const HEARTBEAT_INTERVAL_MS    = 30000;  // WebSocket ping interval
const HEARTBEAT_TIMEOUT_MS     = 10000;  // Max wait for pong response
const STATS_REFRESH_MS         = 60000;  // Auto-refresh statistics interval
const NODE_REFRESH_MS          = 15 * 60 * 1000;  // Node list refresh (15 min)
const INITIAL_DATA_DELAY_MS    = 2000;   // Delay before loading initial data
const TITLE_UPDATE_DELAY_MS    = 10000;  // Fallback delay for connection title
const DEDUP_SET_MAX            = 500;    // Max dedup set size before pruning
const DEDUP_SET_PRUNE_TO       = 300;    // Prune dedup set to this size
const ACK_TIMEOUT_MS           = 15000;  // Timeout for text message ACK (15s)
const ACK_TIMEOUT_IMAGE_MS     = 30000;  // Timeout for image segment ACK (30s)
let SEGMENT_INTER_DELAY_MS     = 15000;  // Delay between image segment sends (default 15s)
const SEGMENT_WAIT_TICK_MS     = 500;    // Tick interval during segment wait
let SEGMENT_WAIT_TICKS         = 30;     // Number of ticks (30 * 500ms = 15s)
const COPY_FEEDBACK_MS         = 1500;   // "Copied!" feedback duration
const MSG_SEARCH_DEBOUNCE_MS   = 300;    // Message search debounce
const NODE_SEARCH_DEBOUNCE_MS  = 150;    // Node search debounce
const HISTORY_RELOAD_DELAY_MS  = 200;    // Delay before reloading history after clear

/**
 * Normalize a node ID to canonical '!{8-char hex}' format.
 * Mirrors core/constants.py normalize_node_id().
 */
function _normalizeNodeId(nodeId) {
    if (nodeId == null) return '';
    const s = String(nodeId);
    // Already canonical
    if (s.startsWith('!')) return s.toLowerCase();
    // Hex string without '!'
    const hexVal = parseInt(s, 16);
    if (!isNaN(hexVal) && /^[0-9a-fA-F]+$/.test(s)) {
        return '!' + hexVal.toString(16).padStart(8, '0');
    }
    // Decimal integer string
    const intVal = parseInt(s, 10);
    if (!isNaN(intVal) && String(intVal) === s) {
        return '!' + (intVal >>> 0).toString(16).padStart(8, '0');
    }
    return s;
}

class MeshtasticClient {
    constructor() {
        this.sessionId = null;
        this.ws = null;
        this.connected = false;
        this.storage = null;
        this.selectedNodeId = null;
        this.selectedChannelIndex = 0;
        this.selectedChannelName = 'Ch 0: Primary';
        this.sendTarget = { type: 'channel', id: 0, name: 'Ch 0: Primary' };
        // Flag to detect the very first channel assignment so we load history automatically
        this._initialChannelHistoryLoaded = false;

        // Message queue: ensures messages are sent apart by MSG_QUEUE_DELAY_MS
        this._messageQueue = [];
        this._messageQueueProcessing = false;
        this._messageQueueDelay = MSG_QUEUE_DELAY_MS;
        this._imageSegmentAckHandler = null;  // Set during image segment sends

        // Unread message tracking: { targetKey: count }
        this._unreadCounts = {};
        // Nodes with unread messages (for sorting)
        this._nodesWithUnread = new Set();

        // WebSocket reconnection tracking
        this._wsReconnectTimer = null;
        this._wsReconnectAttempts = 0;
        this._wsMaxReconnectAttempts = WS_MAX_RECONNECT;
        this._wsReconnectDelay = WS_RECONNECT_DELAY_MS;
        this._connectionType = 'tcp';  // 'tcp' or 'serial'

        // WebSocket heartbeat tracking
        this._heartbeatInterval = null;
        this._heartbeatTimeout = null;
        this._heartbeatIntervalMs = HEARTBEAT_INTERVAL_MS;
        this._heartbeatTimeoutMs = HEARTBEAT_TIMEOUT_MS;
        this._lastPongTime = null;
        this._lastLatencyMs = null;

        // Statistics auto-refresh
        this._statsRefreshInterval = null;
        this._statsRefreshMs = STATS_REFRESH_MS;

        // Node data cache for filtering
        this._allNodes = [];
        this._nodeSearchQuery = '';
        this._nodeHeardFilter = 'all';  // 'all', '1d', '3d', '1w', '2w', '1m'

        // Mobile/desktop layout mode
        this._isMobile = null;          // null = auto, true/false = manual override
        this._mobileAutoDetect = true;  // Whether to auto-detect
        this._activeTab = 'chat';       // Current mobile tab: channels, chat, nodes, more

        try {
            this.init();
        } catch (error) {
            console.error('Initialization error:', error);
            this.showMessage('Initialization failed: ' + error.message, 'error');
        }
    }

    init() {
        // Wait for DOM to be ready
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', () => this.setup());
        } else {
            this.setup();
        }
    }

    setup() {
        try {
            this.setupFormHandler();
            this.setupEventListeners();
            this._initMobileLayout();
            this.loadExistingSessions();
            this._tryAutoRestore();

            // Clear (*) notification in title when tab is focused
            window.addEventListener('focus', () => {
                if (document.title.startsWith('(*)')) {
                    document.title = document.title.replace(/^\(\*\)\s*/, '');
                }
            });
        } catch (error) {
            console.error('Setup error:', error);
            this.showMessage('Setup failed: ' + error.message, 'error');
        }
    }

    setupFormHandler() {
        const form = document.getElementById('sessionForm');
        const button = document.querySelector('button[type="submit"]');

        if (form) {
            // Prevent default form submission
            form.addEventListener('submit', (e) => {
                e.preventDefault();
                e.stopPropagation();
                this.handleLogin();
            });
        } else {
            console.error('Form element #sessionForm not found!');
        }

        if (button) {
            // Backup button handler
            button.addEventListener('click', (e) => {
                // Only prevent default if this is a form submit
                if (e.target.type === 'submit') {
                    e.preventDefault();
                    e.stopPropagation();
                    this.handleLogin();
                }
            });
        } else {
            console.error('Submit button not found!');
        }
    }

    setupEventListeners() {
        try {
            this._setupMessageInputListeners();
            this._setupLogListeners();
            this._setupNavigationListeners();
            this._setupImageUploadListeners();
            this._setupSettingsListeners();
            this._setupModalBackdropListeners();
            this._setupNodeSearchListener();
            this._setupKeyboardShortcuts();
        } catch (error) {
            console.error('Event listener setup error:', error);
        }
    }

    /** Message input: Enter-to-send and send button. */
    _setupMessageInputListeners() {
        const messageInput = document.getElementById('messageInput');
        const sendButton = document.getElementById('sendButton');
        if (messageInput) {
            messageInput.addEventListener('keypress', (e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    this.sendMessage();
                }
            });
        }
        if (sendButton) {
            sendButton.addEventListener('click', () => this.sendMessage());
        }
        const clearChatBtn = document.getElementById('clearChatBtn');
        if (clearChatBtn) {
            clearChatBtn.addEventListener('click', () => this.clearCurrentChat());
        }
        // Message search toggle + input
        const msgSearchBtn = document.getElementById('msgSearchBtn');
        const msgSearchInput = document.getElementById('msgSearchInput');
        if (msgSearchBtn && msgSearchInput) {
            msgSearchBtn.addEventListener('click', () => this._toggleMessageSearch());
            let _msgSearchDebounce = null;
            msgSearchInput.addEventListener('input', () => {
                if (_msgSearchDebounce) clearTimeout(_msgSearchDebounce);
                _msgSearchDebounce = setTimeout(() => this._executeMessageSearch(), MSG_SEARCH_DEBOUNCE_MS);
            });
            msgSearchInput.addEventListener('keydown', (e) => {
                if (e.key === 'Escape') {
                    this._closeMessageSearch();
                }
                if (e.key === 'Enter') {
                    e.preventDefault();
                    this._executeMessageSearch();
                }
            });
        }

        // Sidebar collapse toggles (desktop only)
        this._setupSidebarCollapse();
    }

    /** Setup collapsible sidebar panels for desktop mode. */
    _setupSidebarCollapse() {
        const leftBtn = document.getElementById('collapseLeftBtn');
        const rightBtn = document.getElementById('collapseRightBtn');
        const leftSidebar = document.querySelector('.sidebar-left');
        const rightSidebar = document.querySelector('.sidebar-right');

        if (leftBtn && leftSidebar) {
            // Restore saved state
            if (localStorage.getItem('sidebar-left-collapsed') === 'true') {
                leftSidebar.classList.add('collapsed');
                leftBtn.textContent = '▶';
                leftBtn.title = 'Expand channels panel';
            }
            leftBtn.addEventListener('click', () => {
                leftSidebar.classList.toggle('collapsed');
                const collapsed = leftSidebar.classList.contains('collapsed');
                leftBtn.textContent = collapsed ? '▶' : '◀';
                leftBtn.title = collapsed ? 'Expand channels panel' : 'Collapse channels panel';
                localStorage.setItem('sidebar-left-collapsed', collapsed);
            });
        }

        if (rightBtn && rightSidebar) {
            // Restore saved state
            if (localStorage.getItem('sidebar-right-collapsed') === 'true') {
                rightSidebar.classList.add('collapsed');
                rightBtn.textContent = '◀';
                rightBtn.title = 'Expand nodes panel';
            }
            rightBtn.addEventListener('click', () => {
                rightSidebar.classList.toggle('collapsed');
                const collapsed = rightSidebar.classList.contains('collapsed');
                rightBtn.textContent = collapsed ? '◀' : '▶';
                rightBtn.title = collapsed ? 'Expand nodes panel' : 'Collapse nodes panel';
                localStorage.setItem('sidebar-right-collapsed', collapsed);
            });
        }
    }

    /** Communication log: show/toggle/clear buttons, log modal, resize handle. */
    _setupLogListeners() {
        const showLogBtn = document.getElementById('showLogBtn');
        const toggleLogBtn = document.getElementById('toggleLog');
        const clearLogBtn = document.getElementById('clearLog');
        if (showLogBtn) showLogBtn.addEventListener('click', () => this.toggleCommunicationLog());
        if (toggleLogBtn) toggleLogBtn.addEventListener('click', () => this.toggleCommunicationLog());
        if (clearLogBtn) clearLogBtn.addEventListener('click', () => this.clearCommunicationLog());

        const closeLogModalBtn = document.getElementById('closeLogModal');
        if (closeLogModalBtn) closeLogModalBtn.addEventListener('click', () => this._closeLogModal());
        const clearLogModalBtn = document.getElementById('clearLogModal');
        if (clearLogModalBtn) clearLogModalBtn.addEventListener('click', () => this.clearCommunicationLog());

        this._initLogResize();
    }

    /** Disconnect, layout toggle, mobile tab bar. */
    _setupNavigationListeners() {
        const disconnectBtn = document.getElementById('disconnectBtn');
        if (disconnectBtn) disconnectBtn.addEventListener('click', () => this.disconnect());

        const toggleLayoutBtn = document.getElementById('toggleLayoutBtn');
        if (toggleLayoutBtn) toggleLayoutBtn.addEventListener('click', () => this._toggleMobileLayout());

        document.querySelectorAll('.mobile-tab').forEach(tab => {
            tab.addEventListener('click', (e) => {
                const tabName = e.currentTarget.dataset.tab;
                if (tabName) this._switchMobileTab(tabName);
            });
        });
    }

    /** Image upload modal: open/close, file select, encode preview, size change, send. */
    _setupImageUploadListeners() {
        const uploadImageBtn = document.getElementById('uploadImageButton');
        if (uploadImageBtn) uploadImageBtn.addEventListener('click', () => this.openImageUploadModal());

        const closeImageModal = document.getElementById('closeImageModal');
        if (closeImageModal) closeImageModal.addEventListener('click', () => this.closeImageUploadModal());

        const imageFileInput = document.getElementById('imageFileInput');
        if (imageFileInput) imageFileInput.addEventListener('change', (e) => this.handleImageSelected(e));

        const encodePreviewBtn = document.getElementById('encodePreviewBtn');
        if (encodePreviewBtn) encodePreviewBtn.addEventListener('click', () => this.encodeImagePreview());

        const encImageSize = document.getElementById('encImageSize');
        if (encImageSize) {
            encImageSize.addEventListener('change', () => {
                if (this._selectedImageFile) this.encodeImagePreview();
            });
        }

        const confirmImageUpload = document.getElementById('confirmImageUpload');
        if (confirmImageUpload) confirmImageUpload.addEventListener('click', () => this.sendImageSegments());
    }

    /** Settings modal: open/close/save, export/import messages. */
    _setupSettingsListeners() {
        const settingsBtn = document.getElementById('settingsBtn');
        if (settingsBtn) settingsBtn.addEventListener('click', () => this.openSettingsModal());

        const closeSettingsModal = document.getElementById('closeSettingsModal');
        if (closeSettingsModal) closeSettingsModal.addEventListener('click', () => this.closeSettingsModal());

        const cancelSettingsBtn = document.getElementById('cancelSettingsBtn');
        if (cancelSettingsBtn) cancelSettingsBtn.addEventListener('click', () => this.closeSettingsModal());

        const saveSettingsBtn = document.getElementById('saveSettingsBtn');
        if (saveSettingsBtn) saveSettingsBtn.addEventListener('click', () => this.saveSettings());

        const exportMessagesBtn = document.getElementById('exportMessagesBtn');
        if (exportMessagesBtn) exportMessagesBtn.addEventListener('click', () => this.exportMessages());

        const importMessagesBtn = document.getElementById('importMessagesBtn');
        if (importMessagesBtn) importMessagesBtn.addEventListener('click', () => this.importMessages());

        const rebootDeviceBtn = document.getElementById('rebootDeviceBtn');
        if (rebootDeviceBtn) rebootDeviceBtn.addEventListener('click', () => this.rebootDevice());

        // Listen for storage quota exceeded events from MessageDB
        window.addEventListener('messagedb-quota-exceeded', () => {
            const modal = document.getElementById('quotaModal');
            if (modal) modal.style.display = 'flex';
        });
    }

    /** Close any modal on backdrop click (skips modals with data-no-backdrop-close). */
    _setupModalBackdropListeners() {
        document.querySelectorAll('.modal').forEach(modal => {
            if (modal.dataset.noBackdropClose) return;
            modal.addEventListener('click', (e) => {
                if (e.target === modal) modal.style.display = 'none';
            });
        });
    }

    /** Node search input with debounced filtering. */
    _setupNodeSearchListener() {
        const nodeSearchInput = document.getElementById('nodeSearchInput');
        if (nodeSearchInput) {
            let _searchDebounce = null;
            nodeSearchInput.addEventListener('input', (e) => {
                this._nodeSearchQuery = e.target.value.trim().toLowerCase();
                if (_searchDebounce) clearTimeout(_searchDebounce);
                _searchDebounce = setTimeout(() => this._renderFilteredNodes(), NODE_SEARCH_DEBOUNCE_MS);
            });
        }
        // "Last heard" age filter dropdown
        const heardFilter = document.getElementById('nodeHeardFilter');
        if (heardFilter) {
            heardFilter.addEventListener('change', (e) => {
                this._nodeHeardFilter = e.target.value;
                this._renderFilteredNodes();
            });
        }
    }

    /** Escape closes modals; Ctrl+K focus message; Ctrl+Shift+F focus search; Ctrl+Shift+L toggle log. */
    _setupKeyboardShortcuts() {
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') {
                document.querySelectorAll('.modal').forEach(modal => {
                    if (modal.style.display !== 'none') modal.style.display = 'none';
                });
            }
            if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
                e.preventDefault();
                const input = document.getElementById('messageInput');
                if (input) input.focus();
            }
            if ((e.ctrlKey || e.metaKey) && e.shiftKey && e.key === 'F') {
                e.preventDefault();
                // Toggle message search
                this._toggleMessageSearch();
            }
            if ((e.ctrlKey || e.metaKey) && e.shiftKey && e.key === 'L') {
                e.preventDefault();
                const logPanel = document.getElementById('logPanel');
                if (logPanel) {
                    logPanel.style.display = logPanel.style.display === 'none' ? 'block' : 'none';
                }
            }
        });
    }
}
