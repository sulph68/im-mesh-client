/**
 * scheduler_ui.js — Scheduler modal management for v2.4.X
 * v104: cron preview helper + live preview text below schedule fields
 * v102: preview button renamed Show/Hide Preview (no emojis)
 */

(function () {
    'use strict';

    const CONFIG = {
        FEEDBACK_DISMISS_MS: 3000,  // How long to show "saved" feedback banners
    };

    const modal = document.getElementById('schedulerModal');
    const entriesList = document.getElementById('schedulerEntriesList');
    const globalToggle = document.getElementById('schedulerGlobalEnabled');
    const entryForm = document.getElementById('schedulerEntryForm');
    const formFooter = document.getElementById('schedulerFormFooter');

    let currentEntries = [];
    let currentEditId = null;

    function openModal() {
        modal.style.display = 'flex';
        loadGlobal();
        loadEntries();
    }

    function closeModal() {
        modal.style.display = 'none';
        hideForm();
    }

    async function loadGlobal() {
        try {
            const r = await fetch('/api/scheduler/global');
            if (!r.ok) return;
            const d = await r.json();
            globalToggle.checked = !!(d.data && d.data.enabled);
        } catch (_) {}
    }

    async function loadEntries() {
        try {
            const r = await fetch('/api/scheduler/entries');
            if (!r.ok) return;
            const d = await r.json();
            currentEntries = (d.data && d.data.entries) || [];
            renderEntries();
        } catch (_) {}
    }

    /** Fetch available command scripts from the API and populate the dropdown. */
    async function loadCommands(selectedValue) {
        const sel = document.getElementById('schedCommand');
        if (!sel) return;
        try {
            const r = await fetch('/api/scheduler/commands');
            const d = r.ok ? await r.json() : null;
            const commands = (d && d.data && d.data.commands) || [];
            if (commands.length === 0) {
                sel.innerHTML = '<option value="">— No command scripts available —</option>';
            } else {
                sel.innerHTML = commands.map(c =>
                    `<option value="${c}"${c === selectedValue ? ' selected' : ''}>${c}</option>`
                ).join('');
                if (selectedValue && !commands.includes(selectedValue)) {
                    sel.innerHTML += `<option value="${selectedValue}" selected>${selectedValue} (not found)</option>`;
                }
            }
        } catch (_) {
            sel.innerHTML = '<option value="">— Error loading commands —</option>';
        }
    }

    /** Convert a schedule value (string or dict) to "min hr dom dow". */
    function scheduleToString(sched) {
        if (!sched) return '* * * *';
        if (typeof sched === 'string') return sched;
        const min = sched.minute !== undefined ? sched.minute : '*';
        const hr  = sched.hour !== undefined ? sched.hour : '*';
        const dom = sched.day_of_month !== undefined ? sched.day_of_month : '*';
        const dow = sched.day_of_week !== undefined ? sched.day_of_week : '*';
        return `${min} ${hr} ${dom} ${dow}`;
    }

    /** Convert cron fields (min, hour, dom, dow) to a human-readable description. */
    function _cronToHuman(min, hour, dom, dow) {
        const dayNames = ['Sun','Mon','Tue','Wed','Thu','Fri','Sat'];
        function descField(val, unit, names) {
            if (!val || val === '*') return `every ${unit}`;
            if (val.includes(',')) return val.split(',').map(v => v.trim()).map(v => names ? (names[parseInt(v)] || v) : v).join(', ');
            const step = val.match(/^\*\/(\d+)$/);
            if (step) return `every ${step[1]} ${unit}(s)`;
            const range = val.match(/^(\d+)-(\d+)$/);
            if (range) {
                if (names) return `${names[parseInt(range[1])] || range[1]}–${names[parseInt(range[2])] || range[2]}`;
                return `${range[1]}–${range[2]}`;
            }
            if (names) return names[parseInt(val)] || val;
            return val;
        }
        const minDesc = descField(min, 'minute', null);
        const hrDesc = descField(hour, 'hour', null);
        const domDesc = descField(dom, 'day-of-month', null);
        const dowDesc = descField(dow, 'day', dayNames);

        let parts = [];
        if (min !== '*' || hour !== '*') {
            if (min !== '*' && hour !== '*') {
                const hrs = hour.split(',').map(h => {
                    const n = parseInt(h.trim());
                    return isNaN(n) ? h.trim() : `${n % 12 || 12}${n < 12 ? 'am' : 'pm'}`;
                });
                const mins = min.padStart ? min.padStart(2,'0') : min;
                parts.push(`at :${mins} — ${hrs.join(', ')}`);
            } else if (hour !== '*') {
                parts.push(`at ${hrDesc}`);
            } else {
                parts.push(`at minute ${minDesc}`);
            }
        } else {
            parts.push('every minute');
        }
        if (dow !== '*') parts.push(`on ${dowDesc}`);
        if (dom !== '*') parts.push(`on day ${domDesc}`);
        return parts.join(', ');
    }

    function _updateCronPreview() {
        const preview = document.getElementById('schedCronPreview');
        if (!preview) return;
        const min = (document.getElementById('schedMin') || {}).value || '*';
        const hour = (document.getElementById('schedHour') || {}).value || '*';
        const dom = (document.getElementById('schedDom') || {}).value || '*';
        const dow = (document.getElementById('schedDow') || {}).value || '*';
        preview.textContent = `⏱ ${_cronToHuman(min, hour, dom, dow)}`;
    }

    /** Format a target label for display in the entry list. */
    function targetLabel(entry) {
        if (entry.to_node) return `→ ${entry.to_node}`;
        const ch = entry.channel !== undefined && entry.channel !== null ? entry.channel : 0;
        return `→ Ch ${ch}`;
    }

    function renderEntries() {
        if (currentEntries.length === 0) {
            entriesList.innerHTML = '<p style="color:var(--text-muted);font-size:0.9em;">No scheduled entries. Click + Add Entry to create one.</p>';
            return;
        }
        entriesList.innerHTML = currentEntries.map((e, i) => {
            const target = targetLabel(e);
            const disabledTag = e.enabled === false
                ? ' <span style="color:var(--text-muted)">(disabled)</span>'
                : '';
            return `
            <div class="ar-conv-item" style="display:flex; align-items:center; gap:40px; padding:5px 4px;">
                <span style="flex:1; font-size:0.9em;">
                    <strong>${i + 1}) ${e.label || e.id}</strong>
                    <span style="color:var(--accent-color); font-size:0.85em;">${target}</span>${disabledTag}
                </span>
                <button class="btn btn-small btn-outline" onclick="schedulerUI.editEntry('${e.id}')">Edit</button>
            </div>`;
        }).join('');
    }

    function showForm(entry) {
        currentEditId = entry ? (entry.id || null) : null;
        entryForm.style.display = 'block';

        // Footer visibility + Run Now / Delete only for existing entries
        formFooter.style.display = 'flex';
        const runBtn = document.getElementById('runSchedulerEntryNow');
        const delBtn = document.getElementById('deleteSchedulerEntry');
        if (runBtn) runBtn.style.display = currentEditId ? '' : 'none';
        if (delBtn) delBtn.style.display = currentEditId ? '' : 'none';

        document.getElementById('schedEntryId').value = currentEditId || '';
        const uuidDisplay = document.getElementById('schedEntryIdDisplay');
        const uuidCode = document.getElementById('schedEntryIdCode');
        if (uuidDisplay && uuidCode) {
            if (currentEditId) {
                uuidCode.textContent = currentEditId;
                uuidDisplay.style.display = '';
            } else {
                uuidDisplay.style.display = 'none';
            }
        }

        document.getElementById('schedLabel').value = entry ? (entry.label || '') : '';
        const schedule = scheduleToString(entry ? entry.schedule : null).split(' ');
        document.getElementById('schedMin').value = schedule[0] || '*';
        document.getElementById('schedHour').value = schedule[1] || '*';
        document.getElementById('schedDom').value = schedule[2] || '*';
        document.getElementById('schedDow').value = schedule[3] || '*';
        _updateCronPreview();
        const type = entry ? (entry.type || 'message') : 'message';
        document.getElementById('schedType').value = type;
        document.getElementById('schedMessage').value = entry ? (entry.message || '') : '';
        document.getElementById('schedPort').value = entry ? (entry.portnum || entry.port || '1') : '1';
        document.getElementById('schedEnabled').checked = entry ? (entry.enabled !== false) : true;

        let channel = 0;
        let toNode = '';
        if (entry) {
            channel = entry.channel !== undefined && entry.channel !== null ? entry.channel : 0;
            toNode = entry.to_node || '';
        } else {
            const client = window.meshtasticClient;
            if (client && client.sendTarget) {
                const st = client.sendTarget;
                if (st.type === 'node' && st.id) {
                    toNode = st.id;
                    channel = client.selectedChannelIndex || 0;
                } else if (st.type === 'channel') {
                    channel = st.id !== undefined ? st.id : (client.selectedChannelIndex || 0);
                }
            }
        }

        if (window.meshSelectors) {
            window.meshSelectors.loadChannelOptions(document.getElementById('schedChannel'), channel);
            window.meshSelectors.loadNodeOptions(document.getElementById('schedToNode'), toNode);
        } else {
            document.getElementById('schedChannel').value = channel;
            document.getElementById('schedToNode').value = toNode;
        }

        const hint = document.getElementById('schedTargetHint');
        if (hint) {
            if (!entry) {
                const client = window.meshtasticClient;
                const label = client && client.sendTarget ? client.sendTarget.name || 'active chat' : 'active chat';
                hint.textContent = `Pre-filled from current chat: ${label}`;
            } else {
                hint.textContent = '';
            }
        }

        toggleTypeFields(type);
        if (type === 'command') loadCommands(entry ? entry.command : '');
    }

    function hideForm() {
        entryForm.style.display = 'none';
        if (formFooter) formFooter.style.display = 'none';
        currentEditId = null;
    }

    function toggleTypeFields(type) {
        document.getElementById('schedMessageGroup').style.display = type === 'message' ? '' : 'none';
        document.getElementById('schedCommandGroup').style.display = type === 'command' ? '' : 'none';
        if (type === 'command') {
            const sel = document.getElementById('schedCommand');
            if (sel && (sel.options.length === 0 || sel.options[0].value === '')) loadCommands('');
        }
    }

    async function saveEntry() {
        const id = document.getElementById('schedEntryId').value;
        const type = document.getElementById('schedType').value;
        const schedule = [
            document.getElementById('schedMin').value || '*',
            document.getElementById('schedHour').value || '*',
            document.getElementById('schedDom').value || '*',
            document.getElementById('schedDow').value || '*',
        ].join(' ');
        const toNode = (document.getElementById('schedToNode').value || '').trim();
        const body = {
            label: document.getElementById('schedLabel').value,
            schedule,
            type,
            message: type === 'message' ? document.getElementById('schedMessage').value : '',
            command: type === 'command' ? document.getElementById('schedCommand').value : '',
            channel: parseInt(document.getElementById('schedChannel').value, 10) || 0,
            portnum: parseInt(document.getElementById('schedPort').value, 10),
            enabled: document.getElementById('schedEnabled').checked,
        };
        if (toNode) body.to_node = toNode;
        try {
            const url = id ? `/api/scheduler/entries/${id}` : '/api/scheduler/entries';
            const method = id ? 'PUT' : 'POST';
            const r = await fetch(url, {
                method,
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(body),
            });
            if (!r.ok) { alert('Failed to save entry'); return; }
            hideForm();
            loadEntries();
        } catch (e) {
            alert('Error saving entry: ' + e.message);
        }
    }

    async function deleteEntry(id) {
        const targetId = id || currentEditId;
        if (!targetId) return;
        if (!confirm('Delete this scheduled entry?')) return;
        try {
            const r = await fetch(`/api/scheduler/entries/${targetId}`, { method: 'DELETE' });
            if (!r.ok) { alert('Failed to delete entry'); return; }
            hideForm();
            loadEntries();
        } catch (e) {
            alert('Error deleting entry: ' + e.message);
        }
    }

    function editEntry(id) {
        const entry = currentEntries.find(e => e.id === id);
        if (entry) showForm(entry);
    }

    async function runEntry(id) {
        const targetId = id || currentEditId;
        if (!targetId) return;
        // Save current form values first, then fire — so Run Now always uses what's on screen
        try {
            const saved = await _saveEntryById(targetId);
            if (!saved) return;
        } catch (e) {
            alert('Run Now: failed to save entry first: ' + e.message);
            return;
        }
        try {
            const r = await fetch(`/api/scheduler/entries/${targetId}/run`, { method: 'POST' });
            const d = r.ok ? await r.json() : null;
            const msg = (d && d.message) || 'Entry fired';
            const feedback = document.createElement('div');
            feedback.textContent = '✓ Saved & fired: ' + msg;
            feedback.style.cssText = 'color:var(--success-color,green);font-size:0.85em;padding:4px 6px;';
            entriesList.prepend(feedback);
            setTimeout(() => feedback.remove(), CONFIG.FEEDBACK_DISMISS_MS);
        } catch (e) {
            alert('Run Now error: ' + e.message);
        }
    }

    // Build the PUT body for an entry from the current form state and save it.
    // Returns true on success, false on failure.
    async function _saveEntryById(id) {
        const type = document.getElementById('schedType').value;
        const schedule = [
            document.getElementById('schedMin').value || '*',
            document.getElementById('schedHour').value || '*',
            document.getElementById('schedDom').value || '*',
            document.getElementById('schedDow').value || '*',
        ].join(' ');
        const toNode = (document.getElementById('schedToNode').value || '').trim();
        const body = {
            label: document.getElementById('schedLabel').value,
            schedule,
            type,
            message: type === 'message' ? document.getElementById('schedMessage').value : '',
            command: type === 'command' ? document.getElementById('schedCommand').value : '',
            channel: parseInt(document.getElementById('schedChannel').value, 10) || 0,
            portnum: parseInt(document.getElementById('schedPort').value, 10),
            enabled: document.getElementById('schedEnabled').checked,
        };
        if (toNode) body.to_node = toNode;
        const r = await fetch(`/api/scheduler/entries/${id}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(body),
        });
        if (!r.ok) { alert('Failed to save entry before running'); return false; }
        loadEntries();
        return true;
    }

    // Wire buttons
    document.getElementById('closeSchedulerModal').addEventListener('click', closeModal);
    document.getElementById('addSchedulerEntryBtn').addEventListener('click', () => showForm(null));
    document.getElementById('saveSchedulerEntry').addEventListener('click', saveEntry);
    document.getElementById('cancelSchedulerEntry').addEventListener('click', hideForm);
    document.getElementById('schedType').addEventListener('change', e => toggleTypeFields(e.target.value));

    // Live cron preview
    ['schedMin', 'schedHour', 'schedDom', 'schedDow'].forEach(id => {
        const el = document.getElementById(id);
        if (el) el.addEventListener('input', _updateCronPreview);
    });
    document.getElementById('schedulerGlobalEnabled').addEventListener('change', async function () {
        try {
            await fetch('/api/scheduler/global', {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ enabled: this.checked }),
            });
        } catch (_) {}
    });

    const runNowBtn = document.getElementById('runSchedulerEntryNow');
    if (runNowBtn) runNowBtn.addEventListener('click', () => runEntry(currentEditId));

    const deleteBtn = document.getElementById('deleteSchedulerEntry');
    if (deleteBtn) deleteBtn.addEventListener('click', () => deleteEntry(currentEditId));

    const refreshSchedBtn = document.getElementById('refreshSchedulerBtn');
    if (refreshSchedBtn) {
        refreshSchedBtn.addEventListener('click', () => {
            loadGlobal();
            loadEntries();
        });
    }

    const schedBtn = document.getElementById('openSchedMessagesBtn');
    if (schedBtn) schedBtn.addEventListener('click', openModal);

    async function checkApplicable() {
        if (!schedBtn) return;
        try {
            const r = await fetch('/api/scheduler/global');
            if (!r.ok) return;
            const d = await r.json();
            if (d.data && d.data.applicable === false) {
                schedBtn.style.display = 'none';
                schedBtn.disabled = false;
            } else {
                schedBtn.style.display = '';
                const settingsEnabled = d.data && d.data.settings_enabled !== false
                    ? d.data.settings_enabled
                    : false;
                schedBtn.disabled = !settingsEnabled;
                schedBtn.title = settingsEnabled
                    ? 'Scheduled Messages'
                    : 'Scheduled Messages (disabled in settings)';
            }
        } catch (_) {}
    }
    window.checkSchedulerApplicable = checkApplicable;
    setTimeout(checkApplicable, 1500);

    // Backdrop click intentionally disabled — use ✕ button to close

    // Hide scheduler preview when message text changes
    const schedMsgEl = document.getElementById('schedMessage');
    if (schedMsgEl) {
        schedMsgEl.addEventListener('input', function () {
            const preview = document.getElementById('schedMsgPreview');
            if (preview && preview.style.display !== 'none') {
                preview.style.display = 'none';
                const btn = document.getElementById('schedMsgPreviewBtn');
                if (btn) btn.textContent = 'Show Preview';
            }
        });
    }

    function toggleMsgPreview() {
        const text = (document.getElementById('schedMessage') || {}).value || '';
        const previewDiv = document.getElementById('schedMsgPreview');
        const btn = document.getElementById('schedMsgPreviewBtn');
        if (!previewDiv) return;
        if (previewDiv.style.display === 'none') {
            const resolved = text
                .replace(/\{\{S_LONG_NAME\}\}/g, '[own:LongName]')
                .replace(/\{\{S_SHORT_NAME\}\}/g, '[own:Short]')
                .replace(/\{\{S_ID\}\}/g, '[own:!00000000]')
                .replace(/\{\{S_SNR\}\}/g, '[own:SNR]')
                .replace(/\{\{S_RSSI\}\}/g, '[own:RSSI]')
                .replace(/\{\{S_BATTERY\}\}/g, '[own:Bat%]')
                .replace(/\{\{S_VOLTAGE\}\}/g, '[own:V]')
                .replace(/\{\{S_HOPS\}\}/g, '[own:Hops]')
                .replace(/\{\{S_ROLE\}\}/g, '[own:Role]')
                .replace(/\{\{S_HARDWARE\}\}/g, '[own:HW]')
                .replace(/\{\{S_LAT\}\}/g, '[own:Lat]')
                .replace(/\{\{S_LON\}\}/g, '[own:Lon]')
                .replace(/\{\{S_ALT\}\}/g, '[own:Alt]')
                .replace(/\{\{S_UPTIME\}\}/g, '[own:Uptime]')
                .replace(/\{\{S_CH_UTIL\}\}/g, '[own:ChUtil]')
                .replace(/\{\{S_AIR_TX\}\}/g, '[own:AirTx]');
            previewDiv.textContent = resolved || '(empty)';
            previewDiv.style.display = '';
            if (btn) btn.textContent = 'Hide Preview';
        } else {
            previewDiv.style.display = 'none';
            if (btn) btn.textContent = 'Show Preview';
        }
    }

    window.schedulerUI = { openModal, closeModal, editEntry, deleteEntry, runEntry, toggleMsgPreview };
})();

