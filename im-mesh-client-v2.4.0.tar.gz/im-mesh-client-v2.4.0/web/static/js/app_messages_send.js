/**
 * Meshtastic Web Client - Messages Module: Send, queue, ACK timeout, rate limiting
 */

const _MSG_DEBUG = false;  // Set true to enable verbose message trace logs

Object.assign(MeshtasticClient.prototype, {

async sendMessage() {
    const messageInput = document.getElementById('messageInput');
    if (!messageInput) return;

    const text = messageInput.value.trim();
    if (!text) {
        this.showMessage('Please enter a message', 'warning');
        return;
    }

    if (!this.sessionId) {
        this.showMessage('No active session', 'error');
        return;
    }

    const channel = this.sendTarget.type === 'channel' ? this.sendTarget.id : (this.selectedChannelIndex || 0);
    const toNode = (this.sendTarget.type === 'node' && this.sendTarget.id) ? this.sendTarget.id : null;

    // Split long messages into chunks
    const splitter = window.MeshSplitter;
    const chunks = (splitter && text.length > splitter.SPLIT_THRESHOLD)
        ? splitter.splitMessage(text)
        : [text];

    // Clear input and reset split preview immediately for good UX
    messageInput.value = '';
    if (messageInput.tagName === 'TEXTAREA') {
        messageInput.style.height = 'auto';
    }
    const splitPreview = document.getElementById('splitPreview');
    if (splitPreview) {
        if (chunks.length > 1) {
            splitPreview.textContent = `Sent in ${chunks.length} parts`;
            splitPreview.style.display = 'block';
            // Auto-hide after 4 seconds
            setTimeout(() => {
                splitPreview.style.display = 'none';
                splitPreview.textContent = '';
            }, 4000);
        } else {
            splitPreview.style.display = 'none';
            splitPreview.textContent = '';
        }
    }

    // Queue each chunk (or single message) separately
    chunks.forEach((chunk, idx) => {
        const payload = { text: chunk, channel, want_ack: true };
        if (toNode) payload.to_node = toNode;

        this._messageQueue.push({
            payload: payload,
            displayText: chunk,
            targetName: this.sendTarget.name,
            targetKey: this.getMessageStorageKey(),
            channel: channel
        });
    });

    const queueTotal = this._messageQueue.length;
    _MSG_DEBUG && console.log(`Queued ${chunks.length} chunk(s) for "${text.substring(0, 40)}…" (queue size: ${queueTotal})`);

    if (queueTotal > chunks.length) {
        this.showMessage(`Message queued (${queueTotal} in queue)`, 'info');
    }

    // Start processing if not already running
    this._processMessageQueue();
},

/**
 * Process the message queue, sending one message at a time with 3-second
 * spacing between each message to avoid overwhelming the mesh radio.
 */
async _processMessageQueue() {
    if (this._messageQueueProcessing) return;  // Already running
    this._messageQueueProcessing = true;

    try {
        while (this._messageQueue.length > 0) {
            const msg = this._messageQueue.shift();

            try {
                _MSG_DEBUG && console.log(`Sending queued message: "${msg.displayText}" to ${msg.targetName}`);

                const response = await fetch('/api/messages/send', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-Session-ID': this.sessionId
                    },
                    body: JSON.stringify(msg.payload)
                });

                const data = await response.json();

                if (data.success) {
                    // Extract packet_id for ack tracking
                    const packetId = data.data ? data.data.packet_id : null;
                    const wantAck = msg.payload.want_ack || false;

                    // Add sent message to chat display with ack tracking info
                    // "Sent" = API call succeeded (immediate). "Delivered" = ACK from mesh.
                    this.addChatMessage({
                        from: 'You',
                        text: msg.displayText,
                        timestamp: new Date().toISOString(),
                        type: 'sent',
                        to: msg.targetName,
                        channel: msg.channel,
                        _targetKey: msg.targetKey,
                        packet_id: packetId,
                        want_ack: wantAck,
                        ack_status: wantAck ? 'sent' : null
                    });

                    this.logCommunication('OUT', `Sent: "${msg.displayText}" to ${msg.targetName} (id=${packetId})`, 'success');
                    _MSG_DEBUG && console.log(`Message sent successfully (packetId=${packetId})`);

                    // Start 60-second ACK timeout with retry button
                    if (wantAck && packetId) {
                        this._startAckTimeout(packetId, msg);
                    }
                } else {
                    // Send failed - show failed message with retry button
                    this._addFailedMessage(msg, data.message || 'Unknown error');
                    this.logCommunication('OUT', `Send failed: ${data.message}`, 'error');

                    // If connection lost, try to indicate reconnection
                    if (data.message && data.message.includes('not connected')) {
                        this.addConnectionLostMessage();
                    }
                }
            } catch (error) {
                console.error('Send message error:', error);
                // Show failed message with retry button
                this._addFailedMessage(msg, error.message);
                this.logCommunication('OUT', `Send error: ${error.message}`, 'error');
            }

            // Wait 3 seconds before sending the next message (if any remain)
            if (this._messageQueue.length > 0) {
                _MSG_DEBUG && console.log(`Waiting ${this._messageQueueDelay}ms before next message (${this._messageQueue.length} remaining)`);
                await new Promise(resolve => setTimeout(resolve, this._messageQueueDelay));
            }
        }
    } finally {
        // ALWAYS reset the processing flag so future messages can be sent
        this._messageQueueProcessing = false;
    }
},

/**
 * Start a 60-second ACK timeout for a sent message.
 * If no ACK arrives, shows a timeout indicator with a Retry button.
 * "Sent" is already shown (single tick). If no ACK upgrades to "Delivered",
 * the tick gets a timeout style and a Retry button appears.
 */
_startAckTimeout(packetId, originalMsg) {
    setTimeout(() => {
        const container = document.getElementById('messagesContainer');
        if (!container) return;
        const msgEl = container.querySelector(`[data-packet-id="${packetId}"]`);
        if (!msgEl) return;
        const tickSpan = msgEl.querySelector('.ack-ticks');
        if (!tickSpan) return;

        const currentStatus = tickSpan.getAttribute('data-ack-status') || 'sent';
        // Only show timeout if not yet delivered
        if (currentStatus === 'delivered') return;

        tickSpan.className = 'ack-ticks ack-timeout';
        tickSpan.textContent = '\u2713';
        tickSpan.title = 'No delivery ack received';
        tickSpan.setAttribute('data-ack-status', 'timeout');

        // Add retry button after the message content
        let retryContainer = msgEl.querySelector('.ack-retry-container');
        if (!retryContainer) {
            retryContainer = document.createElement('div');
            retryContainer.className = 'ack-retry-container';
            msgEl.appendChild(retryContainer);
        }
        retryContainer.innerHTML = '<span class="ack-timeout-label">No ack received </span>';

        const retryBtn = document.createElement('button');
        retryBtn.className = 'btn-retry-seg';
        retryBtn.textContent = 'Retry';
        retryBtn.addEventListener('click', () => {
            retryBtn.disabled = true;
            retryBtn.textContent = 'Retrying...';
            // Mark old message as failed
            tickSpan.className = 'ack-ticks ack-failed';
            tickSpan.textContent = '\u2717';
            tickSpan.title = 'No ack - retried';
            tickSpan.setAttribute('data-ack-status', 'failed');
            retryContainer.remove();
            // Re-queue as a new message (will create a new DOM entry with new packet_id)
            this._messageQueue.push({
                payload: originalMsg.payload,
                displayText: originalMsg.displayText,
                targetName: originalMsg.targetName,
                targetKey: originalMsg.targetKey,
                channel: originalMsg.channel
            });
            this._processMessageQueue();
        });
        retryContainer.appendChild(retryBtn);
    }, ACK_TIMEOUT_MS);
},

/**
 * Add a failed message to chat with a Retry button.
 */
_addFailedMessage(msg, errorText) {
    const messagesContainer = document.getElementById('messagesContainer');
    if (!messagesContainer) return;

    const messageElement = document.createElement('div');
    messageElement.className = 'message sent';

    const time = new Date().toLocaleTimeString();
    messageElement.innerHTML = `
        <div class="message-header">
            <span class="message-from sent-name">You</span>
            <span class="ack-ticks ack-failed" title="Send failed">\u2717</span>
            <span class="message-time">${time}</span>
        </div>
        <div class="message-content">${this.escapeHtml(msg.displayText)}</div>
        <div class="ack-retry-container"><span class="ack-timeout-label">Send failed: ${this.escapeHtml(errorText)} </span></div>
    `;

    const retryContainer = messageElement.querySelector('.ack-retry-container');
    const retryBtn = document.createElement('button');
    retryBtn.className = 'btn-retry-seg';
    retryBtn.textContent = 'Retry';
    retryBtn.addEventListener('click', () => {
        retryBtn.disabled = true;
        retryBtn.textContent = 'Retrying...';
        // Update the label and tick mark
        const tickSpan = messageElement.querySelector('.ack-ticks');
        if (tickSpan) { tickSpan.textContent = '\u2717'; tickSpan.title = 'Failed - retried'; }
        const label = retryContainer ? retryContainer.querySelector('.ack-timeout-label') : null;
        if (label) label.textContent = 'Send failed - retried ';
        retryBtn.remove();
        // Re-queue as a new message (will create a new DOM entry with new packet_id)
        this._messageQueue.push({
            payload: msg.payload,
            displayText: msg.displayText,
            targetName: msg.targetName,
            targetKey: msg.targetKey,
            channel: msg.channel
        });
        this._processMessageQueue();
    });
    if (retryContainer) {
        retryContainer.appendChild(retryBtn);
    } else {
        messageElement.appendChild(retryBtn);
    }

    messagesContainer.appendChild(messageElement);
    messagesContainer.scrollTop = messagesContainer.scrollHeight;
}

});
