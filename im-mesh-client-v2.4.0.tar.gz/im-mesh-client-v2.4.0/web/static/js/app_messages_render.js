/**
 * Meshtastic Web Client - Messages Module: Chat rendering, message formatting, search, date display
 */

Object.assign(MeshtasticClient.prototype, {

// Render a message element in the chat container
renderChatMessage(messageData, scrollToBottom) {
    const messagesContainer = document.getElementById('messagesContainer');
    if (!messagesContainer) return;

    const messageElement = document.createElement('div');
    const isSent = messageData.type === 'sent';
    const isSystem = messageData.type === 'system';
    const isBinary = messageData.portnum === 288 || messageData.isBinary;
    const isImage = messageData.isImage;
    const isAutomation = messageData.source === 'scheduler' || messageData.source === 'ar';

    let className = 'message';
    if (isSent) className += ' sent';
    else if (isSystem) className += ' system';
    else className += ' received';
    if (isBinary) className += ' binary-msg';
    if (isImage) className += ' image-msg';
    // Purple tint for automation-originated messages
    if (messageData.source === 'scheduler') className += ' msg-automation msg-sched';
    if (messageData.source === 'ar') className += ' msg-automation msg-ar';
    messageElement.className = className;

    const time = this._formatMessageTime(messageData.timestamp);
    const fromName = this.escapeHtml(messageData.from || 'Unknown');
    const text = messageData.text || messageData.decoded_text || messageData.payload || '';

    // Render content by message type
    // Binary messages that contain image segments should render like text
    // image segments, just with a purple label. Check for image segment content.
    const binaryPayloadText = isBinary ? (messageData.rawPayload || messageData.text || '') : '';
    const isBinaryImageSegment = isBinary && !isSent && typeof binaryPayloadText === 'string' && this._isImageSegment(binaryPayloadText);

    if (isBinary && !isSent && !isBinaryImageSegment) {
        this._renderBinaryMessageContent(messageElement, messageData, fromName, time);
    } else if (isBinaryImageSegment) {
        // Render binary image segment like a text message but with purple label
        this._renderBinaryImageSegmentContent(messageElement, messageData, fromName, time, binaryPayloadText);
    } else if (isImage && messageData.imageData) {
        this._renderReceivedImageContent(messageElement, fromName, time, text, messageData.imageData);
    } else if (isImage && isSent) {
        this._renderSentImageContent(messageElement, messageData, fromName, time, text);
    } else {
        this._renderTextMessageContent(messageElement, messageData, fromName, time, text, isSent);
    }

    // ACK indicator for sent messages - tick marks right of username
    // "Sent" (single tick) = API send succeeded, "Delivered" (double tick) = ACK from mesh
    if (isSent && messageData.want_ack) {
        const packetId = messageData.packet_id;
        if (packetId) messageElement.setAttribute('data-packet-id', packetId);

        const storedStatus = messageData.ack_status || 'sent';
        // Inject tick marks into the message-header, right after the username
        const headerEl = messageElement.querySelector('.message-header');
        const fromEl = headerEl ? headerEl.querySelector('.message-from') : null;
        if (fromEl) {
            const tickSpan = document.createElement('span');
            tickSpan.className = 'ack-ticks';
            if (storedStatus === 'delivered' || storedStatus === 'received') {
                tickSpan.className += ' ack-delivered';
                tickSpan.textContent = '\u2713\u2713';
                tickSpan.title = 'Delivered';
            } else if (storedStatus === 'sent') {
                tickSpan.className += ' ack-sent';
                tickSpan.textContent = '\u2713';
                tickSpan.title = 'Sent';
            } else if (storedStatus === 'failed') {
                tickSpan.className += ' ack-failed';
                tickSpan.textContent = '\u2717';
                tickSpan.title = messageData.ack_error ? `Nak: ${messageData.ack_error}` : 'Send failed';
            } else {
                // pending (legacy fallback)
                tickSpan.className += ' ack-pending';
                tickSpan.textContent = '\u2713';
                tickSpan.title = 'Sending...';
            }
            tickSpan.setAttribute('data-ack-status', storedStatus);
            // Insert tick marks right after the username span
            fromEl.after(tickSpan);
        }
    }

    // Add per-message delete button (visible on hover)
    const deleteBtn = document.createElement('button');
    deleteBtn.className = 'btn-delete-msg';
    deleteBtn.textContent = '\u00d7';
    deleteBtn.title = 'Delete this message';
    deleteBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        this._deleteMessage(messageElement);
    });
    messageElement.appendChild(deleteBtn);

    // Store _dbId on the element for deletion (set after async storage)
    if (messageData._dbId) {
        messageElement.dataset.dbId = messageData._dbId;
    }

    messagesContainer.appendChild(messageElement);

    // Check for image segment reassembly on received text, binary image segments,
    // and automation (scheduler/AR) sent messages.
    if ((!isSent || isAutomation) && !isSystem && !isImage) {
        this._checkForImageSegments(messageElement, messageData);
    }

    // Render previously-decoded image if persisted in localStorage
    if (messageData._decodedImage) {
        let resultContainer = messageElement.querySelector('.reassemble-result');
        if (!resultContainer) {
            resultContainer = document.createElement('div');
            resultContainer.className = 'reassemble-result';
            messageElement.appendChild(resultContainer);
        }
        const stats = messageData._decodedStats || {};
        resultContainer.innerHTML = `
            <div class="reassembled-image-info">
                Decoded: ${stats.width || '?'}x${stats.height || '?'}, 
                ${stats.compression_method || 'unknown'}, 
                ${stats.segments_received || '?'} segments
            </div>
            <img src="data:image/png;base64,${messageData._decodedImage}" 
                 alt="Reassembled Image" 
                 class="reassembled-image">
        `;
    }

    if (scrollToBottom) {
        messagesContainer.scrollTop = messagesContainer.scrollHeight;
    }
},

/** Render binary/custom app message content. */
_renderBinaryMessageContent(el, messageData, fromName, time) {
    const payload = messageData.rawPayload || messageData.text || '';
    const displayPayload = typeof payload === 'string' && payload.length > 0
        ? payload
        : '[Binary Data]';
    const sizeInfo = messageData.payloadSize ? `Size: ${messageData.payloadSize} bytes` : '';
    el.innerHTML = `
        <div class="message-header">
            <span class="message-from">${fromName}</span>
            <span class="message-time">${time}</span>
        </div>
        <div class="message-content">${this.escapeHtml(displayPayload)}</div>
        <div class="binary-meta">
            ${sizeInfo ? `<span>${sizeInfo}</span>` : ''}
        </div>
    `;

    // Use event listener instead of inline onclick to avoid issues with
    // special characters in payload breaking the string literal
    const copyBtn = document.createElement('button');
    copyBtn.className = 'copy-payload-btn';
    copyBtn.textContent = 'Copy Payload';
    copyBtn.addEventListener('click', () => {
        this._copyToClipboard(String(payload)).then(() => {
            this.showMessage('Payload copied', 'success');
        });
    });
    el.appendChild(copyBtn);
},

/** Render received decoded image content. */
_renderReceivedImageContent(el, fromName, time, text, imageData) {
    el.innerHTML = `
        <div class="message-header">
            <span class="message-from">${fromName}</span>
            <span class="message-time">${time}</span>
        </div>
        <div class="message-content">${this.escapeHtml(text)}</div>
        <img src="data:image/png;base64,${imageData}" alt="Image" style="max-width: 200px; max-height: 200px; border-radius: 4px; border: 1px solid var(--border); margin-top: 0.5rem;">
    `;
},

/** Render sent image with preview and segment disclosure. */
_renderSentImageContent(el, messageData, fromName, time, text) {
    let previewHtml = '';
    if (messageData.imagePreviewBase64) {
        previewHtml = `<img src="data:image/png;base64,${messageData.imagePreviewBase64}" alt="Sent Image Preview" class="sent-image-preview">`;
    }
    el.innerHTML = `
        <div class="message-header">
            <span class="message-from sent-name">${fromName}</span>
            <span class="message-time">${time}</span>
        </div>
        <div class="message-content">${this.escapeHtml(text)}</div>
        ${previewHtml}
    `;
    if (messageData.segments && messageData.segments.length > 0) {
        const channel = messageData.channel || 0;
        const toNode = messageData.to_node || null;
        const disclosureContainer = document.createElement('div');
        disclosureContainer.className = 'sent-segments-disclosure';
        el.appendChild(disclosureContainer);
        const uid = 'seg-chat-' + Date.now();
        disclosureContainer.id = uid;
        setTimeout(() => this._renderSegmentList(uid, messageData.segments, channel, toNode), 0);

        // Add "Resend All Segments" button for sent images from history
        setTimeout(() => this._addResendAllButton(el, messageData.segments, channel, toNode), 0);
    }
},

/** Render standard text message content. */
_renderTextMessageContent(el, messageData, fromName, time, text, isSent) {
    el.innerHTML = `
        <div class="message-header">
            <span class="message-from${isSent ? ' sent-name' : ''}">${fromName}</span>
            <span class="message-time">${time}</span>
        </div>
        <div class="message-content">${this.escapeHtml(text)}</div>
    `;
},

/**
 * Show a dropdown menu for clearing chat history with granular time options.
 */
clearCurrentChat() {
    if (!this.storage) return;
    const key = this.getMessageStorageKey();
    if (!key) return;

    // Remove any existing dropdown
    const existing = document.querySelector('.clear-chat-dropdown');
    if (existing) { existing.remove(); return; }

    const targetName = this.sendTarget ? this.sendTarget.name : 'this target';

    const dropdown = document.createElement('div');
    dropdown.className = 'clear-chat-dropdown';

    const options = [
        { label: 'Older than 1 hour', hours: 1 },
        { label: 'Older than 3 hours', hours: 3 },
        { label: 'Older than 6 hours', hours: 6 },
        { label: 'Older than 12 hours', hours: 12 },
        { label: 'Older than 1 day', hours: 24 },
        { label: 'Older than 3 days', hours: 72 },
        { label: 'Older than 1 week', hours: 168 },
        { label: 'Older than 2 weeks', hours: 336 },
        { label: 'All messages', hours: 0 }
    ];

    options.forEach(opt => {
        const item = document.createElement('div');
        item.className = 'clear-chat-option';
        item.textContent = opt.label;
        item.addEventListener('click', () => {
            dropdown.remove();
            this._clearChatByTime(key, targetName, opt.hours);
        });
        dropdown.appendChild(item);
    });

    // Position relative to the clear chat button
    const clearBtn = document.getElementById('clearChatBtn');
    if (clearBtn) {
        clearBtn.parentElement.style.position = 'relative';
        clearBtn.parentElement.appendChild(dropdown);
    }

    // Close dropdown on outside click
    const closeHandler = (e) => {
        if (!dropdown.contains(e.target) && e.target !== clearBtn) {
            dropdown.remove();
            document.removeEventListener('click', closeHandler);
        }
    };
    setTimeout(() => document.addEventListener('click', closeHandler), 0);
},

/**
 * Clear chat messages by time range.
 * @param {string} key - Storage key for the target
 * @param {string} targetName - Display name
 * @param {number} hours - Hours older than which to clear (0 = all)
 */
_clearChatByTime(key, targetName, hours) {
    const label = hours === 0 ? 'all' : `messages older than ${hours}h from`;
    if (!confirm(`Clear ${label} "${targetName}"?\n\nThis cannot be undone.`)) {
        return;
    }

    if (hours === 0) {
        // Clear all
        this.storage.clearTargetAsync(key).then(count => {
            _MSG_DEBUG && console.log(`Cleared ${count} messages for ${key}`);
        }).catch(e => {
            console.error('Error clearing messages:', e);
        });
    } else {
        // Clear messages older than N hours
        const cutoffMs = Date.now() - (hours * 60 * 60 * 1000);
        this.storage.clearTargetBeforeAsync(key, cutoffMs).then(count => {
            _MSG_DEBUG && console.log(`Cleared ${count} messages older than ${hours}h for ${key}`);
        }).catch(e => {
            console.error('Error clearing messages:', e);
        });
    }

    // Reload message history to reflect changes
    setTimeout(() => this.loadMessageHistory(), HISTORY_RELOAD_DELAY_MS);
    this.showMessage(`Chat history cleared (${hours === 0 ? 'all' : 'older than ' + hours + 'h'})`, 'success');
},

// ── Message Search ─────────────────────────────────────────────────

/**
 * Toggle the message search input visibility.
 */
_toggleMessageSearch() {
    const input = document.getElementById('msgSearchInput');
    const btn = document.getElementById('msgSearchBtn');
    if (!input) return;

    const isExpanded = input.classList.contains('expanded');
    if (isExpanded) {
        this._closeMessageSearch();
    } else {
        input.style.display = 'block';
        // Force reflow before adding class for transition
        input.offsetWidth;
        input.classList.add('expanded');
        btn.classList.add('active');
        input.focus();
    }
},

/**
 * Close the message search and restore normal chat view.
 */
_closeMessageSearch() {
    const input = document.getElementById('msgSearchInput');
    const btn = document.getElementById('msgSearchBtn');
    if (input) {
        input.classList.remove('expanded');
        btn && btn.classList.remove('active');
        input.value = '';
        // After transition, hide
        setTimeout(() => {
            if (!input.classList.contains('expanded')) {
                input.style.display = 'none';
            }
        }, 300);
    }
    // Remove results bar
    const resultsBar = document.querySelector('.msg-search-results-bar');
    if (resultsBar) resultsBar.remove();

    // Reload normal message history
    if (this._searchActive) {
        this._searchActive = false;
        this.loadMessageHistory();
    }
},

/**
 * Execute a message search using IndexedDB.
 */
async _executeMessageSearch() {
    const input = document.getElementById('msgSearchInput');
    if (!input || !this.storage) return;

    const query = input.value.trim();
    if (!query) {
        // Empty query - restore normal view
        if (this._searchActive) {
            this._searchActive = false;
            const resultsBar = document.querySelector('.msg-search-results-bar');
            if (resultsBar) resultsBar.remove();
            this.loadMessageHistory();
        }
        return;
    }

    this._searchActive = true;
    const targetKey = this.getMessageStorageKey();
    if (!targetKey) return;

    try {
        const results = await this.storage.searchMessagesAsync(targetKey, query, 100);
        this._renderSearchResults(results, query);
    } catch (e) {
        console.error('Message search error:', e);
    }
},

/**
 * Render search results in the messages container.
 * @param {Array} results - matching messages
 * @param {string} query - the search query for highlighting
 */
_renderSearchResults(results, query) {
    const messagesContainer = document.getElementById('messagesContainer');
    if (!messagesContainer) return;

    // Clear current messages
    messagesContainer.innerHTML = '';

    // Add/update results bar
    let resultsBar = document.querySelector('.msg-search-results-bar');
    if (!resultsBar) {
        resultsBar = document.createElement('div');
        resultsBar.className = 'msg-search-results-bar';
        messagesContainer.parentNode.insertBefore(resultsBar, messagesContainer);
    }
    resultsBar.innerHTML = `
        <span><span class="search-count">${results.length}</span> result${results.length !== 1 ? 's' : ''} for "${this.escapeHtml(query)}"</span>
        <span class="search-close" title="Close search">&times;</span>
    `;
    resultsBar.querySelector('.search-close').addEventListener('click', () => this._closeMessageSearch());

    if (results.length === 0) {
        messagesContainer.innerHTML = '<div class="empty-history-hint">No messages found matching your search.</div>';
        return;
    }

    // Render each result (newest first from search, reverse for chronological)
    const chronological = results.reverse();
    for (const msg of chronological) {
        // Highlight matching text
        const highlighted = { ...msg };
        if (highlighted.text) {
            highlighted.text = this._highlightSearchMatch(highlighted.text, query);
        }
        this.renderChatMessage(msg, false);
    }

    // After rendering, highlight the text in rendered elements
    const needle = query.toLowerCase();
    messagesContainer.querySelectorAll('.message-content').forEach(el => {
        const html = el.innerHTML;
        const text = el.textContent;
        if (text.toLowerCase().includes(needle)) {
            el.innerHTML = this._highlightSearchMatch(html, query);
        }
    });

    messagesContainer.scrollTop = messagesContainer.scrollHeight;
},

/**
 * Highlight search matches in text (case-insensitive).
 * @param {string} text - original text/html
 * @param {string} query - search query
 * @returns {string} text with <span class="search-highlight"> wrapping matches
 */
_highlightSearchMatch(text, query) {
    if (!query) return text;
    // Escape regex special chars in query
    const escaped = query.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    const regex = new RegExp(`(${escaped})`, 'gi');
    return text.replace(regex, '<span class="search-highlight">$1</span>');
},

// ── Image Segment Rendering ─────────────────────────────────────
// Image segment detection, parsing, grouping, and reassembly are
// handled by app_images.js (loaded after this file). This file only
// provides the binary image segment renderer used during message
// rendering.

/**
 * Render a binary message that contains image segment data.
 * Similar to text segment rendering but with a purple label.
 */
_renderBinaryImageSegmentContent(el, messageData, fromName, time, payloadText) {
    const parsed = this._parseImageSegment(payloadText);
    let segLabel = parsed
        ? `Image segment ${parsed.segNum}/${parsed.totalSegments}`
        : 'Image Segment';
    if (parsed && parsed.checksum) {
        segLabel += ` [${parsed.checksum}]`;
    }
    el.innerHTML = `
        <div class="message-header">
            <span class="message-from">${fromName}</span>
            <span class="message-time">${time}</span>
        </div>
        <details class="segment-disclosure">
            <summary class="image-segment-info">
                <span class="image-segment-label binary">${segLabel}</span>
            </summary>
            <div class="message-content segment-data">${this.escapeHtml(payloadText)}</div>
        </details>
    `;

    // Copy Payload button inside the disclosure
    const segmentText = parsed ? parsed.fullSegment : payloadText;
    const disclosure = el.querySelector('.segment-disclosure');
    const copyBtn = document.createElement('button');
    copyBtn.className = 'copy-payload-btn';
    copyBtn.textContent = 'Copy Payload';
    copyBtn.addEventListener('click', () => {
        this._copyToClipboard(segmentText).then(() => {
            this.showMessage('Payload copied', 'success');
        });
    });
    disclosure.appendChild(copyBtn);

    // Forward button to re-send received segment into channel
    const fwdBtn = document.createElement('button');
    fwdBtn.className = 'copy-payload-btn btn-forward-seg';
    fwdBtn.textContent = 'Forward to Channel';
    fwdBtn.addEventListener('click', () => {
        this._forwardSegmentToChannel(segmentText);
    });
    disclosure.appendChild(fwdBtn);

    // Store segment data on the element for reassembly
    if (parsed) {
        el.dataset.imageSegment = 'true';
        el.dataset.segNum = parsed.segNum;
        el.dataset.segPayload = parsed.fullSegment;
        if (parsed.checksum) el.dataset.checksum = parsed.checksum;
    }
},

/**
 * Format a message timestamp for display.
 * - Messages from today: show time only (e.g. "3:45:12 PM")
 * - Messages from a previous day: prepend date using the user's chosen format
 *
 * Date format preference is read from localStorage key 'meshtastic_dateFormat':
 *   'dd/mm/yy' (default) → "27/05/25, 3:45 PM"
 *   'mm/dd/yy'           → "05/27/25, 3:45 PM"
 *   'yyyy-mm-dd'         → "2025-05-27, 15:45:12"
 *   'time-only'          → time only regardless of date (legacy behaviour)
 */
_formatMessageTime(timestamp) {
    const d = timestamp ? new Date(timestamp) : new Date();
    const fmt = localStorage.getItem('meshtastic_dateFormat') || 'dd/mm/yy';

    const timeStr = d.toLocaleTimeString();

    if (fmt === 'time-only') return timeStr;

    const today = new Date();
    const isToday = d.getFullYear() === today.getFullYear()
                 && d.getMonth()    === today.getMonth()
                 && d.getDate()     === today.getDate();

    if (isToday) return timeStr;

    let dateStr;
    if (fmt === 'yyyy-mm-dd') {
        const yy   = d.getFullYear();
        const mm   = String(d.getMonth() + 1).padStart(2, '0');
        const dd   = String(d.getDate()).padStart(2, '0');
        const hh   = String(d.getHours()).padStart(2, '0');
        const min  = String(d.getMinutes()).padStart(2, '0');
        const sec  = String(d.getSeconds()).padStart(2, '0');
        return `${yy}-${mm}-${dd} ${hh}:${min}:${sec}`;
    } else if (fmt === 'mm/dd/yy') {
        const mm = String(d.getMonth() + 1).padStart(2, '0');
        const dd = String(d.getDate()).padStart(2, '0');
        const yy = String(d.getFullYear()).slice(-2);
        dateStr = `${mm}/${dd}/${yy}`;
    } else {
        // dd/mm/yy (default)
        const dd = String(d.getDate()).padStart(2, '0');
        const mm = String(d.getMonth() + 1).padStart(2, '0');
        const yy = String(d.getFullYear()).slice(-2);
        dateStr = `${dd}/${mm}/${yy}`;
    }
    return `${dateStr} ${timeStr}`;
}

});
