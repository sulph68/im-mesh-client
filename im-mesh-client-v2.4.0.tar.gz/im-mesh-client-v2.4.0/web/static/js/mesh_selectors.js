/**
 * mesh_selectors.js — Shared channel and node dropdown helpers for v2.4.X
 *
 * Provides loadChannelOptions() and loadNodeOptions() used by both the
 * Scheduler and Auto Responder UIs so the dropdown format is consistent.
 *
 * Channel format:  "Ch N: Name"   (value = channel index as string)
 * Node format:     "Longname <shortname@nodeid>"  (value = node id e.g. "!a1b2c3d4")
 */

(function () {
    'use strict';

    /**
     * Populate a <select> element with channel options.
     * @param {HTMLSelectElement} selectEl  - the select to populate
     * @param {number|string} [current]     - currently selected channel index
     * @param {boolean} [addBroadcast=false]- prepend a "Broadcast" option (value "")
     * @param {number[]} [excludeIndices]   - channel indices to omit (already taken)
     */
    async function loadChannelOptions(selectEl, current, addBroadcast, excludeIndices) {
        if (!selectEl) return;
        const excluded = new Set((excludeIndices || []).map(Number));
        selectEl.innerHTML = '';

        if (addBroadcast) {
            const opt = document.createElement('option');
            opt.value = '';
            opt.textContent = 'Broadcast (all channels)';
            selectEl.appendChild(opt);
        }

        try {
            const r = await fetch('/api/channels');
            if (!r.ok) throw new Error('HTTP ' + r.status);
            const d = await r.json();
            const channels = (d.data && d.data.channels) || [];
            channels.forEach(ch => {
                const idx = ch.index !== undefined ? ch.index : ch.channel_index;
                if (excluded.has(Number(idx))) return; // skip occupied
                let name = ch.name || ch.channel_name || '';
                if (!name || name === `Channel ${idx}`) {
                    name = idx === 0 ? 'Primary' : `Ch ${idx}`;
                }
                const label = `Ch ${idx}: ${name}`;
                const opt = document.createElement('option');
                opt.value = String(idx);
                opt.textContent = label;
                if (current !== undefined && current !== null && String(idx) === String(current)) {
                    opt.selected = true;
                }
                selectEl.appendChild(opt);
            });
        } catch (_) {
            // Fallback: offer Ch 0-7 if API unavailable
            for (let i = 0; i <= 7; i++) {
                if (excluded.has(i)) continue;
                const opt = document.createElement('option');
                opt.value = String(i);
                opt.textContent = i === 0 ? 'Ch 0: Primary' : `Ch ${i}`;
                if (current !== undefined && current !== null && String(i) === String(current)) opt.selected = true;
                selectEl.appendChild(opt);
            }
        }

        // Honor 'current' when explicitly provided; otherwise leave browser default
        if (current !== undefined && current !== null) {
            const target = String(current);
            if ([...selectEl.options].some(o => o.value === target)) {
                selectEl.value = target;
            }
        }
    }

    /**
     * Populate a <select> element with node options.
     * First option is always "Broadcast (channel only)" with value "".
     * @param {HTMLSelectElement} selectEl  - the select to populate
     * @param {string} [current]            - currently selected node id (e.g. "!a1b2c3d4")
     * @param {string[]} [excludeIds]       - node ids to omit (already taken)
     */
    async function loadNodeOptions(selectEl, current, excludeIds) {
        if (!selectEl) return;
        const excluded = new Set(excludeIds || []);
        selectEl.innerHTML = '';

        // First option: no DM target (broadcast)
        const broadcastOpt = document.createElement('option');
        broadcastOpt.value = '';
        broadcastOpt.textContent = 'Broadcast (no direct message)';
        selectEl.appendChild(broadcastOpt);

        try {
            const r = await fetch('/api/nodes');
            if (!r.ok) throw new Error('HTTP ' + r.status);
            const d = await r.json();
            const nodes = (d.data && d.data.nodes) || [];
            nodes.forEach(node => {
                const nodeId = node.id || node.num || '';
                if (excluded.has(nodeId)) return; // skip occupied
                const longName = (node.longName || node.long_name || '').trim();
                const shortName = (node.shortName || node.short_name || '').trim();
                const hexId = nodeId.replace(/^!/, '');
                let label;
                if (longName) {
                    label = shortName
                        ? `${longName} <${shortName}@${hexId}>`
                        : `${longName} <@${hexId}>`;
                } else if (shortName) {
                    label = `${shortName} <@${hexId}>`;
                } else {
                    label = nodeId || hexId;
                }
                const opt = document.createElement('option');
                opt.value = nodeId;
                opt.textContent = label;
                if (current && nodeId === current) opt.selected = true;
                selectEl.appendChild(opt);
            });
        } catch (_) {}

        // Honor 'current' when explicitly provided
        if (current && [...selectEl.options].some(o => o.value === current)) {
            selectEl.value = current;
        }
    }

    window.meshSelectors = { loadChannelOptions, loadNodeOptions };
})();
