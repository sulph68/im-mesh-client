/**
 * Meshtastic Web Client - Images Module: Settings modal, encoding presets, export config
 */

Object.assign(MeshtasticClient.prototype, {

// ============================================
// SETTINGS MODAL METHODS
// ============================================

openSettingsModal() {
    const modal = document.getElementById('settingsModal');
    if (modal) {
        modal.style.display = 'flex';
        // Load server-side settings (refresh interval, delays etc.)
        this._loadNodeRefreshSetting();
        // Load localStorage-backed display settings
        const dfEl = document.getElementById('settingsDateFormat');
        if (dfEl) dfEl.value = localStorage.getItem('meshtastic_dateFormat') || 'dd/mm/yy';
    }
},

/** Fetch current node refresh interval from server and populate the dropdown. */
async _loadNodeRefreshSetting() {
    try {
        const resp = await fetch('/api/app/settings', {
            headers: { 'X-Session-ID': this.sessionId }
        });
        if (resp.ok) {
            const data = await resp.json();
            const interval = data.data?.node_refresh_interval || 15;
            const el = document.getElementById('settingsNodeRefresh');
            if (el) el.value = String(interval);

            // Apply configurable send delays from settings.
            const msgDelaySec = data.data?.message_delay ?? 5;
            const segDelaySec = data.data?.segment_delay ?? 15;
            MSG_QUEUE_DELAY_MS = msgDelaySec * 1000;
            this._messageQueueDelay = MSG_QUEUE_DELAY_MS;
            SEGMENT_INTER_DELAY_MS = segDelaySec * 1000;
            SEGMENT_WAIT_TICKS = Math.ceil(SEGMENT_INTER_DELAY_MS / SEGMENT_WAIT_TICK_MS);

            // Populate delay dropdowns if present.
            const mdEl = document.getElementById('settingsMessageDelay');
            if (mdEl) mdEl.value = String(msgDelaySec);
            const sdEl = document.getElementById('settingsSegmentDelay');
            if (sdEl) sdEl.value = String(segDelaySec);
            const clEl = document.getElementById('settingsCharacterLimit');
            if (clEl) clEl.value = String(data.data?.character_limit ?? 220);
        }
    } catch (e) {
        console.warn('Could not load app settings:', e);
    }
},

closeSettingsModal() {
    const modal = document.getElementById('settingsModal');
    if (modal) modal.style.display = 'none';
},

saveSettings() {
    // Collect all settings to save to server.
    const refreshEl = document.getElementById('settingsNodeRefresh');
    const msgDelayEl = document.getElementById('settingsMessageDelay');
    const segDelayEl = document.getElementById('settingsSegmentDelay');
    const charLimitEl = document.getElementById('settingsCharacterLimit');
    const dateFormatEl = document.getElementById('settingsDateFormat');

    // Date format is purely client-side (localStorage).
    if (dateFormatEl) {
        localStorage.setItem('meshtastic_dateFormat', dateFormatEl.value);
    }

    if (this.sessionId) {
        const payload = {};
        if (refreshEl)   payload.node_refresh_interval = parseInt(refreshEl.value) || 15;
        if (msgDelayEl)  payload.message_delay = parseFloat(msgDelayEl.value) || 5;
        if (segDelayEl)  payload.segment_delay = parseInt(segDelayEl.value) || 15;
        if (charLimitEl) payload.character_limit = parseInt(charLimitEl.value) || 220;

        if (Object.keys(payload).length > 0) {
            fetch('/api/app/settings', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-Session-ID': this.sessionId
                },
                body: JSON.stringify(payload)
            }).then(resp => {
                if (resp.ok) {
                    // Apply delay values immediately in the frontend.
                    if (payload.message_delay !== undefined) {
                        MSG_QUEUE_DELAY_MS = payload.message_delay * 1000;
                        this._messageQueueDelay = MSG_QUEUE_DELAY_MS;
                    }
                    if (payload.segment_delay !== undefined) {
                        SEGMENT_INTER_DELAY_MS = payload.segment_delay * 1000;
                        SEGMENT_WAIT_TICKS = Math.ceil(SEGMENT_INTER_DELAY_MS / SEGMENT_WAIT_TICK_MS);
                    }
                }
            }).catch(e => console.warn('Failed to save settings:', e));
        }
    }

    this.showMessage('Settings saved', 'success');
    this.closeSettingsModal();
},

/**
 * Export all stored messages as a downloadable JSON file.
 * Includes both localStorage data and IndexedDB messages.
 */
async exportMessages() {
    if (!this.storage) {
        this.showMessage('No active session to export from', 'error');
        return;
    }

    this.showMessage('Exporting messages...', 'info');

    try {
        const exportPayload = await this.storage.exportAllAsync();
        exportPayload.host = this.host || 'unknown';
        exportPayload.port = this.port || 'unknown';

        const blob = new Blob([JSON.stringify(exportPayload, null, 2)], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `meshtastic-export-${new Date().toISOString().slice(0, 10)}.json`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);

        const count = exportPayload.messages ? exportPayload.messages.messageCount : 0;
        this.showMessage(`Exported ${count} messages`, 'success');
    } catch (e) {
        console.error('Export error:', e);
        this.showMessage('Export failed: ' + e.message, 'error');
    }
},

/**
 * Import messages from a previously exported JSON file.
 */
async importMessages() {
    if (!this.storage || !this.storage.messageDB) {
        this.showMessage('No active session or database not ready', 'error');
        return;
    }

    // Create a file input to select the JSON file
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = '.json';
    input.addEventListener('change', async (e) => {
        const file = e.target.files[0];
        if (!file) return;

        this.showMessage('Importing messages...', 'info');

        try {
            const text = await file.text();
            const data = JSON.parse(text);

            const result = await this.storage.importMessagesAsync(data);
            this.showMessage(
                `Import complete: ${result.imported} imported, ${result.skipped} skipped (duplicates)`,
                'success'
            );

            // Reload current view to show imported messages
            if (this.sendTarget) {
                this.loadMessageHistory();
            }
        } catch (e) {
            console.error('Import error:', e);
            this.showMessage('Import failed: ' + e.message, 'error');
        }
    });
    input.click();
},

});
