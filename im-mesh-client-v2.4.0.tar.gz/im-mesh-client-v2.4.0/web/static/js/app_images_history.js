/**
 * Meshtastic Web Client - Images Module: Message history, channel/node history, statistics
 */

const _IMG_DEBUG = false;  // Set true to enable image/statistics trace logs

Object.assign(MeshtasticClient.prototype, {

// ============================================
// MESSAGE HISTORY PER CHANNEL/NODE
// ============================================

getMessageStorageKey() {
    if (!this.sendTarget) return null;
    if (this.sendTarget.type === 'node') {
        return `messages_node_${this.sendTarget.id}`;
    }
    return `messages_channel_${this.sendTarget.id}`;
},

async loadMessageHistory() {
    // Load stored messages for the current target from IndexedDB
    const messagesContainer = document.getElementById('messagesContainer');
    if (!messagesContainer || !this.storage) return;

    // Clear current messages
    messagesContainer.innerHTML = '';

    const key = this.getMessageStorageKey();
    if (!key) return;

    let messages;
    try {
        messages = await this.storage.getMessagesAsync(key);
    } catch (e) {
        console.error('Error loading messages:', e);
        messages = [];
    }

    if (!messages || messages.length === 0) {
        messagesContainer.innerHTML = `<div class="empty-history-hint">No message history for ${this.escapeHtml(this.sendTarget.name)}</div>`;
        return;
    }

    // Sort messages by timestamp (oldest first) to ensure correct order
    messages.sort((a, b) => {
        const ta = a.timestamp ? new Date(a.timestamp).getTime() : 0;
        const tb = b.timestamp ? new Date(b.timestamp).getTime() : 0;
        return ta - tb;
    });

    // Split messages into recent (last 12 hours) and older
    const twelveHoursAgo = Date.now() - (12 * 60 * 60 * 1000);
    const recentMessages = [];
    const olderMessages = [];
    for (const msg of messages) {
        const ts = msg.timestamp ? new Date(msg.timestamp).getTime() : 0;
        if (ts >= twelveHoursAgo || ts === 0) {
            recentMessages.push(msg);
        } else {
            olderMessages.push(msg);
        }
    }

    // Store older messages for lazy loading
    this._olderMessages = olderMessages;
    this._currentStorageKey = key;

    // Add "load older messages" label if there are older messages
    if (olderMessages.length > 0) {
        const loadOlderDiv = document.createElement('div');
        loadOlderDiv.className = 'load-older-messages';
        loadOlderDiv.textContent = `Load older messages (${olderMessages.length})`;
        loadOlderDiv.addEventListener('click', () => {
            this._loadOlderMessages(messagesContainer, loadOlderDiv);
        });
        messagesContainer.appendChild(loadOlderDiv);
    }

    // Render recent messages (or all if none are recent)
    const toRender = recentMessages.length > 0 ? recentMessages : messages;
    if (recentMessages.length === 0 && olderMessages.length > 0) {
        // All messages are older than 12h, show them all
        this._olderMessages = [];
    }
    toRender.forEach(msg => {
        this.renderChatMessage(msg, false);
    });

    // Post-render pass: attach reassemble buttons to image segments in history
    this._scanForImageSegments(messagesContainer);

    // Clean up any stale "Image received" fallback messages that were stored
    // before the group-box injection path was in place.  If the channel has
    // segment-group-box elements, the decoded image is already shown there;
    // standalone image-msg bubbles are redundant duplicates.
    if (messagesContainer.querySelector('.segment-group-box')) {
        messagesContainer.querySelectorAll('.message.image-msg:not(.segment-group-box)').forEach(el => el.remove());
    }

    // Scroll to bottom immediately - no animation.
    this._scrollToBottom(messagesContainer);
},

/**
 * Scroll a container to the very bottom instantly (no animation).
 * The bottom of the last message aligns to the base of the pane.
 *
 * Handles async image decoding: attaches onload listeners to all <img>
 * elements and re-scrolls when they finish loading. Also polls for
 * scroll-height changes over 1s to catch any remaining layout shifts.
 */
_scrollToBottom(container) {
    if (!container) return;

    const snap = () => {
        container.scrollTop = container.scrollHeight;
    };

    // First attempt after DOM settles
    requestAnimationFrame(snap);

    // Re-scroll when any image finishes decoding (changes scrollHeight)
    const images = container.querySelectorAll('img');
    images.forEach(img => {
        if (!img.complete) {
            img.addEventListener('load', snap, { once: true });
        }
    });

    // Poll for scrollHeight changes over 1s (5 checks at 200ms intervals)
    // to catch layout shifts from CSS, fonts, or late image decode.
    let prevHeight = container.scrollHeight;
    let checks = 0;
    const poll = setInterval(() => {
        checks++;
        const curHeight = container.scrollHeight;
        if (curHeight !== prevHeight) {
            prevHeight = curHeight;
            snap();
        }
        if (checks >= 5) clearInterval(poll);
    }, 200);
},

/**
 * Load older messages (>12h) when the user clicks "Load older messages".
 * Inserts them above the recent messages in chronological order.
 */
_loadOlderMessages(container, labelElement) {
    if (!this._olderMessages || this._olderMessages.length === 0) return;

    // Remove the "load older" label
    labelElement.remove();

    // Remember current scroll height to preserve scroll position
    const prevScrollHeight = container.scrollHeight;

    // Create a document fragment with older messages
    const fragment = document.createDocumentFragment();
    const tempContainer = document.createElement('div');

    this._olderMessages.forEach(msg => {
        const msgEl = document.createElement('div');
        tempContainer.appendChild(msgEl);
    });

    // Insert older messages at the top (after any existing load-older label)
    const firstMessage = container.querySelector('.message');
    this._olderMessages.forEach(msg => {
        // Use renderChatMessage which appends to messagesContainer
        // We need to render then move, so temporarily render
        this.renderChatMessage(msg, false);
    });

    // The messages were appended at the end - move them before the first recent message
    // Actually, renderChatMessage appends to container. We need to re-order.
    // Simpler approach: re-render everything in order
    container.innerHTML = '';
    const allMessages = [...this._olderMessages, ...this._recentMessagesCache || []];

    // Re-sort and re-render isn't ideal. Better approach: prepend before first message.
    // Let's clear and re-render properly.
    this._olderMessages = [];

    // Reload full history without the 12h filter
    this._loadFullHistory(container);
},

/**
 * Reload full message history without the 12-hour filter.
 */
async _loadFullHistory(container) {
    const key = this._currentStorageKey || this.getMessageStorageKey();
    if (!key) return;

    container.innerHTML = '';

    let messages;
    try {
        messages = await this.storage.getMessagesAsync(key);
    } catch (e) {
        console.error('Error loading messages:', e);
        messages = [];
    }

    if (!messages || messages.length === 0) return;

    messages.sort((a, b) => {
        const ta = a.timestamp ? new Date(a.timestamp).getTime() : 0;
        const tb = b.timestamp ? new Date(b.timestamp).getTime() : 0;
        return ta - tb;
    });

    messages.forEach(msg => {
        this.renderChatMessage(msg, false);
    });

    this._scanForImageSegments(container);

    requestAnimationFrame(() => {
        // Scroll to top to show the older messages the user requested
        container.scrollTop = 0;
    });
},

storeMessageForTarget(messageData) {
    if (!this.storage) return;

    // Determine which target this message belongs to
    let key = null;
    if (messageData._targetKey) {
        key = messageData._targetKey;
    } else if (messageData.type === 'sent') {
        key = this.getMessageStorageKey();
    } else {
        if (messageData.isDM) {
            key = `messages_node_${messageData.from_node || messageData.from}`;
        } else {
            key = `messages_channel_${messageData.channel || 0}`;
        }
    }

    if (!key) return;

    // Store asynchronously in IndexedDB
    this.storage.addMessageAsync(key, messageData).catch(e => {
        console.error('Error storing message:', e);
    });
},

// Escape HTML to prevent XSS
escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
},

// Sync device method
async syncDevice() {
            this.showMessage('Refreshing device data...', 'info');

    try {
        const response = await fetch('/api/device/refresh', {
            method: 'POST',
            headers: {
                'X-Session-ID': this.sessionId
            }
        });

        if (response.ok) {
            const data = await response.json();
            if (data.success) {
                this.showMessage('Device sync completed', 'success');
                // Reset flag and reload data
                this._initialDataLoaded = false;
                this._initialChannelHistoryLoaded = false;
                this.loadInitialData();
            } else {
                this.showMessage('Device sync failed: ' + data.message, 'error');
            }
        } else {
            this.showMessage('Device sync failed: HTTP ' + response.status, 'error');
        }
    } catch (error) {
        console.error('Sync device error:', error);
        this.showMessage('Device sync error: ' + error.message, 'error');
    } finally {
        // Remove focus/highlight from the button
        if (document.activeElement) document.activeElement.blur();
    }
},

/** Reboot the connected Meshtastic device via the admin API. */
async rebootDevice() {
    if (!confirm('Are you sure you want to reboot the Meshtastic device? It will restart in 5 seconds.')) {
        return;
    }

    const btn = document.getElementById('rebootDeviceBtn');
    if (btn) {
        btn.disabled = true;
        btn.textContent = 'Rebooting...';
    }

    try {
        const response = await fetch('/api/device/reboot', {
            method: 'POST',
            headers: { 'X-Session-ID': this.sessionId }
        });

        const data = await response.json();
        if (data.success) {
            this.showMessage('Reboot command sent - device will restart in 5 seconds', 'success');
            this.closeSettingsModal();
        } else {
            this.showMessage('Reboot failed: ' + (data.message || 'Unknown error'), 'error');
        }
    } catch (error) {
        console.error('Reboot error:', error);
        this.showMessage('Reboot error: ' + error.message, 'error');
    } finally {
        if (btn) {
            btn.disabled = false;
            btn.textContent = 'Reboot Device';
        }
    }
},

// Alias for refreshChannels (for HTML onclick compatibility)
async refreshChannels() {

    this.showMessage('Reconnecting to refresh channel data...', 'info');
    this.addSystemMessage('Refreshing channel data - reopening connection...', 'info');
    this.showStatus('Reconnecting to refresh data...');

    try {
        // Trigger a fresh connection to get updated data
        const result = await this.loadChannels();

        this.showMessage('Channel data refreshed successfully', 'success');
        this.addSystemMessage('Channel data updated', 'success');
        this.showStatus('Data refreshed - Connection closed (will reconnect when needed)');

        return result;

    } catch (error) {
        console.error('Error refreshing channels:', error);
        this.showMessage('Failed to refresh channel data: ' + error.message, 'error');
        this.addSystemMessage('Failed to refresh channel data', 'error');
        throw error;
    } finally {
        if (document.activeElement) document.activeElement.blur();
    }
},

// Update statistics in the sidebar
updateStatistics() {
    try {
        // Get data from storage if available
        const nodes = this.storage ? this.storage.getNodes() : [];
        const channels = this.storage ? this.storage.getChannels() : [];
        const favorites = this.storage ? this.storage.getFavorites() : [];

        // Count "online" nodes (heard in last 1 hour)
        const oneHourAgo = Math.floor(Date.now() / 1000) - 3600;
        const onlineCount = nodes.filter(n => {
            const lastHeard = n.lastHeard || n.lastSeen;
            return lastHeard && lastHeard > oneHourAgo;
        }).length;

        // Count nodes with position
        const withPosition = nodes.filter(n => n.position && n.position.latitude !== undefined).length;

        // Update DOM elements
        const updateElement = (id, value) => {
            const element = document.getElementById(id);
            if (element) element.textContent = value;
        };

        updateElement('totalNodes', nodes.length);
        updateElement('onlineNodes', onlineCount);
        updateElement('totalChannels', channels.length);
        updateElement('favoriteNodes', favorites.length);
        updateElement('fragmentCount', withPosition);

        // Message count from IndexedDB (async)
        if (this.storage && this.storage.messageDB) {
            this.storage.messageDB.getMessageCount().then(count => {
                updateElement('messageCount', count);
            }).catch(() => {
                updateElement('messageCount', '?');
            });
        } else {
            updateElement('messageCount', 0);
        }

        _IMG_DEBUG && console.log('Statistics updated:', { 
            nodes: nodes.length, 
            online: onlineCount,
            channels: channels.length,
            favorites: favorites.length,
            withPosition: withPosition
        });
    } catch (error) {
        console.error('Error updating statistics:', error);
    }
}
});
