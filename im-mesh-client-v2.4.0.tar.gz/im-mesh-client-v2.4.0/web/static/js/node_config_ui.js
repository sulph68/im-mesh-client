/**
 * node_config_ui.js — Device Configuration Edit Modal
 * Version: 1
 *
 * IIFE module that manages the 6-tab Node Config modal:
 *   General | Position | LoRa | Channels | MQTT | Store & Forward
 *
 * Exposes: window.NodeConfigUI.open()
 */
(function () {
    'use strict';

    // ── Config constants ─────────────────────────────────────────────────────
    const CONFIG = {
        REBOOT_POLL_INTERVAL_MS:  3000,   // Reconnect polling interval after reboot
        REBOOT_SETTLE_DELAY_MS:   10000,  // Wait before polling starts (device settle time)
        GEOLOCATION_API_URL:      'https://ipapi.co/json/',
    };

    // ── State ────────────────────────────────────────────────────────────────
    let _baseline = null;       // snapshot from GET /api/node/device-config
    let _config   = null;       // live config from server
    let _map      = null;       // Leaflet map instance (lazy)
    let _marker   = null;       // Leaflet draggable marker
    let _mapReady = false;
    let _channelDirty = {};     // { index: {name, role, psk, uplinkEnabled, downlinkEnabled} | null }

    // ── DOM helpers ──────────────────────────────────────────────────────────
    const $  = id => document.getElementById(id);
    const el = id => $(id);

    // ── Field definitions for dirty tracking (excludes channels — handled separately) ──
    const SECTION_FIELDS = {
        owner:         ['ncLongName', 'ncShortName'],
        device:        ['ncDeviceRole', 'ncNodeInfoSecs'],
        lora:          ['ncLoraRegion', 'ncModemPreset', 'ncLoraUsePreset', 'ncHopLimit', 'ncTxPower', 'ncTxEnabled'],
        position:      ['ncFixedPosition', 'ncLat', 'ncLng', 'ncAlt'],
        mqtt:          ['ncMqttEnabled', 'ncMqttAddress', 'ncMqttUsername', 'ncMqttPassword',
                        'ncMqttRoot', 'ncMqttTls', 'ncMqttJson', 'ncMqttEncrypt', 'ncMqttProxy', 'ncMqttMapReport'],
        store_forward: ['ncSfEnabled', 'ncSfIsServer', 'ncSfHeartbeat', 'ncSfRecords', 'ncSfReturnMax', 'ncSfReturnWindow'],
    };

    // Map section → tab ID
    const SECTION_TAB = {
        owner:         'ncGeneral',
        device:        'ncGeneral',
        lora:          'ncLora',
        position:      'ncPosition',
        mqtt:          'ncMqtt',
        store_forward: 'ncStoreForward',
        channels:      'ncChannels',
    };

    // ── Populate helpers ─────────────────────────────────────────────────────

    function _val(id, v) {
        const e = el(id);
        if (!e) return;
        if (e.type === 'checkbox') { e.checked = !!v; }
        else { e.value = (v === null || v === undefined) ? '' : v; }
    }

    function _get(id) {
        const e = el(id);
        if (!e) return undefined;
        if (e.type === 'checkbox') return e.checked;
        if (e.type === 'number')   return e.value === '' ? null : Number(e.value);
        return e.value;
    }

    function _populate(cfg) {
        const o = cfg.owner || {};
        _val('ncLongName',  o.longName  || '');
        _val('ncShortName', o.shortName || '');

        const d = cfg.device || {};
        _val('ncDeviceRole',    d.role                    || 0);
        _val('ncNodeInfoSecs',  d.nodeInfoBroadcastSecs  || '');

        const lo = cfg.lora || {};
        _val('ncLoraRegion',    lo.region      || 0);
        _val('ncModemPreset',   lo.modemPreset || 0);
        _val('ncLoraUsePreset', lo.usePreset   || false);
        _val('ncHopLimit',      lo.hopLimit    != null ? lo.hopLimit : 3);
        _val('ncTxPower',       lo.txPower     != null ? lo.txPower  : 0);
        _val('ncTxEnabled',     lo.txEnabled !== false);

        const pos = cfg.position || {};
        _val('ncFixedPosition', !!pos.fixedPosition);
        _val('ncLat',  pos.lat != null ? pos.lat : '');
        _val('ncLng',  pos.lng != null ? pos.lng : '');
        _val('ncAlt',  pos.alt != null ? pos.alt : 0);

        const m = cfg.mqtt || {};
        _val('ncMqttEnabled',   m.enabled              || false);
        _val('ncMqttAddress',   m.address              || '');
        _val('ncMqttUsername',  m.username             || '');
        _val('ncMqttPassword',  m.password             || '');
        _val('ncMqttRoot',      m.root                 || '');
        _val('ncMqttTls',       m.tlsEnabled           || false);
        _val('ncMqttJson',      m.jsonEnabled          || false);
        _val('ncMqttEncrypt',   m.encryptionEnabled    || false);
        _val('ncMqttProxy',     m.proxyToClientEnabled || false);
        _val('ncMqttMapReport', m.mapReportingEnabled  || false);

        const sf = cfg.store_forward || {};
        _val('ncSfEnabled',      sf.enabled            || false);
        _val('ncSfIsServer',     sf.isServer           || false);
        _val('ncSfHeartbeat',    sf.heartbeat          || false);
        _val('ncSfRecords',      sf.records            || 0);
        _val('ncSfReturnMax',    sf.historyReturnMax   || 0);
        _val('ncSfReturnWindow', sf.historyReturnWindow || 0);

        _populateChannels(cfg.channels || []);
    }

    function _populateChannels(channels) {
        const sel = el('ncChannelSelect');
        if (!sel) return;
        sel.innerHTML = '';
        channels.forEach(ch => {
            const opt = document.createElement('option');
            opt.value = ch.index;
            const roleLabel = ['DISABLED','PRIMARY','SECONDARY'][ch.role] || ch.role;
            opt.textContent = `Ch ${ch.index} — ${ch.name || '(unnamed)'} [${roleLabel}]`;
            sel.appendChild(opt);
        });
        if (channels.length > 0) _loadChannelFields(channels[0]);
    }

    function _loadChannelFields(ch) {
        if (!ch) return;
        _val('ncChName',     ch.name             || '');
        _val('ncChRole',     ch.role             || 0);
        _val('ncChPsk',      ch.psk              || '');  // pre-fill from device
        _val('ncChUplink',   ch.uplinkEnabled    || false);
        _val('ncChDownlink', ch.downlinkEnabled  || false);
    }

    // ── Snapshot (baseline) ──────────────────────────────────────────────────

    function _snapshot() {
        const snap = {};
        for (const [sec, fields] of Object.entries(SECTION_FIELDS)) {
            snap[sec] = {};
            fields.forEach(id => { snap[sec][id] = _get(id); });
        }
        return snap;
    }

    // ── Dirty detection ──────────────────────────────────────────────────────

    function _isSectionDirty(section) {
        if (!_baseline) return false;
        if (section === 'channels') return Object.values(_channelDirty).some(Boolean);
        const base = _baseline[section] || {};
        const fields = SECTION_FIELDS[section] || [];
        return fields.some(id => String(_get(id)) !== String(base[id]));
    }

    function _updateDirtyUI() {
        // Tab dots
        const tabBar = el('nodeConfigTabBar');
        if (!tabBar) return;
        tabBar.querySelectorAll('.tab-btn').forEach(btn => {
            const tabId = btn.dataset.tab;
            const sections = Object.entries(SECTION_TAB)
                .filter(([, tid]) => tid === tabId)
                .map(([sec]) => sec);
            const dirty = sections.some(s => _isSectionDirty(s));
            // Show/hide dot indicator
            let dot = btn.querySelector('.nc-dirty-dot');
            if (dirty && !dot) {
                dot = document.createElement('span');
                dot.className = 'nc-dirty-dot';
                dot.style.cssText = 'display:inline-block;width:6px;height:6px;border-radius:50%;background:#e67e22;margin-left:5px;vertical-align:middle;';
                btn.appendChild(dot);
            } else if (!dirty && dot) {
                dot.remove();
            }
        });

        // Field amber borders
        for (const [sec, fields] of Object.entries(SECTION_FIELDS)) {
            const base = (_baseline || {})[sec] || {};
            fields.forEach(id => {
                const e = el(id);
                if (!e) return;
                const dirty = _baseline && String(_get(id)) !== String(base[id]);
                e.style.borderColor = dirty ? '#e67e22' : '';
            });
        }
    }

    function _attachChangeListeners() {
        for (const fields of Object.values(SECTION_FIELDS)) {
            fields.forEach(id => {
                const e = el(id);
                if (!e) return;
                e.addEventListener('input', _updateDirtyUI);
                e.addEventListener('change', _updateDirtyUI);
            });
        }
        // Channel fields
        ['ncChName','ncChRole','ncChPsk','ncChUplink','ncChDownlink'].forEach(id => {
            const e = el(id);
            if (!e) return;
            e.addEventListener('input',  _markChannelDirty);
            e.addEventListener('change', _markChannelDirty);
        });
    }

    function _snapshotChannelForm(idx) {
        // Capture current form values for the given channel index
        const originalPsk = _config?.channels?.find(c => c.index === idx)?.psk || '';
        const currentPsk  = _get('ncChPsk');
        return {
            index:          idx,
            name:           _get('ncChName'),
            role:           parseInt(_get('ncChRole')),
            psk:            currentPsk !== originalPsk ? (currentPsk || null) : null,
            uplinkEnabled:  _get('ncChUplink'),
            downlinkEnabled:_get('ncChDownlink'),
        };
    }

    function _markChannelDirty() {
        const idx = parseInt(el('ncChannelSelect')?.value ?? '-1');
        if (idx >= 0) _channelDirty[idx] = _snapshotChannelForm(idx);
        _updateDirtyUI();
    }

    // ── Tab switching ─────────────────────────────────────────────────────────

    function _switchTab(tabId) {
        document.querySelectorAll('.nc-tab-pane').forEach(p => p.style.display = 'none');
        document.querySelectorAll('#nodeConfigTabBar .tab-btn').forEach(b => b.classList.remove('active'));
        const pane = el(tabId);
        if (pane) pane.style.display = '';
        const btn = document.querySelector(`#nodeConfigTabBar [data-tab="${tabId}"]`);
        if (btn) btn.classList.add('active');

        if (tabId === 'ncPosition') _initMap();
    }

    // ── Map ──────────────────────────────────────────────────────────────────

    function _initMap() {
        if (_mapReady) {
            // Ensure map renders correctly when tab is shown
            if (_map) setTimeout(() => _map.invalidateSize(), 50);
            return;
        }
        if (typeof L === 'undefined') return;

        const lat = parseFloat(el('ncLat')?.value) || null;
        const lng = parseFloat(el('ncLng')?.value) || null;

        function _buildMap(startLat, startLng, zoom) {
            _map = L.map('ncMapContainer').setView([startLat, startLng], zoom);
            L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                attribution: '© OpenStreetMap contributors',
                maxZoom: 19,
            }).addTo(_map);

            _marker = L.marker([startLat, startLng], { draggable: true }).addTo(_map);
            _marker.on('dragend', () => {
                const p = _marker.getLatLng();
                _val('ncLat', p.lat.toFixed(6));
                _val('ncLng', p.lng.toFixed(6));
                _updateDirtyUI();
            });
            _map.on('click', e => {
                _marker.setLatLng(e.latlng);
                _val('ncLat', e.latlng.lat.toFixed(6));
                _val('ncLng', e.latlng.lng.toFixed(6));
                _updateDirtyUI();
            });

            // Sync inputs → marker
            ['ncLat','ncLng'].forEach(id => {
                el(id)?.addEventListener('input', () => {
                    const lt = parseFloat(el('ncLat')?.value);
                    const ln = parseFloat(el('ncLng')?.value);
                    if (!isNaN(lt) && !isNaN(ln)) {
                        _marker.setLatLng([lt, ln]);
                        _map.panTo([lt, ln]);
                    }
                });
            });

            _mapReady = true;
            setTimeout(() => _map.invalidateSize(), 100);
        }

        // Priority 1: existing fixed position from config
        if (lat && lng && (lat !== 0 || lng !== 0)) {
            _buildMap(lat, lng, 13);
            return;
        }

        // Priority 2: browser geolocation
        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(
                pos => _buildMap(pos.coords.latitude, pos.coords.longitude, 13),
                ()  => _tryIpGeolocation()
            );
        } else {
            _tryIpGeolocation();
        }
    }

    function _tryIpGeolocation() {
        // Priority 3: IP-based geolocation via ipapi.co
        fetch(CONFIG.GEOLOCATION_API_URL)
            .then(r => r.ok ? r.json() : null)
            .then(data => {
                if (data && data.latitude && data.longitude) {
                    _buildMap(data.latitude, data.longitude, 11);
                } else {
                    _buildMap(0, 0, 2);
                }
            })
            .catch(() => _buildMap(0, 0, 2));

        // local reference needed
        function _buildMap(lat, lng, zoom) {
            _map = L.map('ncMapContainer').setView([lat, lng], zoom);
            L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                attribution: '© OpenStreetMap contributors',
                maxZoom: 19,
            }).addTo(_map);
            _marker = L.marker([lat, lng], { draggable: true }).addTo(_map);
            _marker.on('dragend', () => {
                const p = _marker.getLatLng();
                _val('ncLat', p.lat.toFixed(6));
                _val('ncLng', p.lng.toFixed(6));
                _updateDirtyUI();
            });
            _map.on('click', e => {
                _marker.setLatLng(e.latlng);
                _val('ncLat', e.latlng.lat.toFixed(6));
                _val('ncLng', e.latlng.lng.toFixed(6));
                _updateDirtyUI();
            });
            ['ncLat','ncLng'].forEach(id => {
                el(id)?.addEventListener('input', () => {
                    const lt = parseFloat(el('ncLat')?.value);
                    const ln = parseFloat(el('ncLng')?.value);
                    if (!isNaN(lt) && !isNaN(ln)) {
                        _marker.setLatLng([lt, ln]);
                        _map.panTo([lt, ln]);
                    }
                });
            });
            _mapReady = true;
            setTimeout(() => _map.invalidateSize(), 100);
        }
    }

    // ── Collect dirty payload ─────────────────────────────────────────────────

    function _collectPayload() {
        const sections = [];
        const payload  = {};

        if (_isSectionDirty('owner') || _isSectionDirty('device')) {
            if (_isSectionDirty('owner')) {
                sections.push('owner');
                payload.owner = { longName: _get('ncLongName'), shortName: _get('ncShortName') };
            }
            if (_isSectionDirty('device')) {
                sections.push('device');
                payload.device = { role: _get('ncDeviceRole'), nodeInfoBroadcastSecs: _get('ncNodeInfoSecs') };
            }
        }

        if (_isSectionDirty('lora')) {
            sections.push('lora');
            payload.lora = {
                region:           _get('ncLoraRegion'),
                modemPreset:      _get('ncModemPreset'),
                usePreset:        _get('ncLoraUsePreset'),
                hopLimit:         _get('ncHopLimit'),
                txPower:          _get('ncTxPower'),
                txEnabled:        _get('ncTxEnabled'),
            };
        }

        if (_isSectionDirty('position')) {
            sections.push('position');
            payload.position = {
                fixedPosition: _get('ncFixedPosition'),
                lat:  parseFloat(el('ncLat')?.value) || 0,
                lng:  parseFloat(el('ncLng')?.value) || 0,
                alt:  parseInt(el('ncAlt')?.value)   || 0,
            };
        }

        if (_isSectionDirty('channels') && _config?.channels) {
            sections.push('channels');
            // Use the per-channel snapshot stored when each channel was dirtied
            // so we don't accidentally apply the currently-displayed channel's form
            // values to all dirty channels.
            payload.channels = Object.values(_channelDirty).filter(Boolean);

            // If the currently-displayed channel is dirty, refresh its snapshot now
            // (catches final edits made before clicking Save without switching away)
            const curIdx = parseInt(el('ncChannelSelect')?.value ?? '-1');
            if (curIdx >= 0 && _channelDirty[curIdx]) {
                payload.channels = payload.channels.filter(c => c.index !== curIdx);
                payload.channels.push(_snapshotChannelForm(curIdx));
            }
        }

        if (_isSectionDirty('mqtt')) {
            sections.push('mqtt');
            payload.mqtt = {
                enabled:              _get('ncMqttEnabled'),
                address:              _get('ncMqttAddress'),
                username:             _get('ncMqttUsername'),
                password:             _get('ncMqttPassword'),
                root:                 _get('ncMqttRoot'),
                tlsEnabled:           _get('ncMqttTls'),
                jsonEnabled:          _get('ncMqttJson'),
                encryptionEnabled:    _get('ncMqttEncrypt'),
                proxyToClientEnabled: _get('ncMqttProxy'),
                mapReportingEnabled:  _get('ncMqttMapReport'),
            };
        }

        if (_isSectionDirty('store_forward')) {
            sections.push('store_forward');
            payload.store_forward = {
                enabled:             _get('ncSfEnabled'),
                isServer:            _get('ncSfIsServer'),
                heartbeat:           _get('ncSfHeartbeat'),
                records:             _get('ncSfRecords'),
                historyReturnMax:    _get('ncSfReturnMax'),
                historyReturnWindow: _get('ncSfReturnWindow'),
            };
        }

        payload.sections = sections;
        return payload;
    }

    // ── Save ─────────────────────────────────────────────────────────────────

    // ── Reboot overlay ────────────────────────────────────────────────────────

    function _showRebootOverlay(writtenSections) {
        const overlay  = el('deviceRebootOverlay');
        const logEl    = el('rebootOverlayLog');
        const barEl    = el('rebootOverlayBar');
        const statusEl = el('rebootOverlayStatus');
        if (!overlay) return;

        // Populate initial log
        const ts = () => new Date().toLocaleTimeString();
        logEl.innerHTML = '';
        const _log = (msg, colour) => {
            const line = document.createElement('div');
            line.style.color = colour || '#d1fae5';
            line.textContent = `[${ts()}] ${msg}`;
            logEl.appendChild(line);
            logEl.scrollTop = logEl.scrollHeight;
        };

        _log(`Config sections saved: ${writtenSections.join(', ')}`);
        _log('Device rebooting in ~5 seconds…', '#fef08a');
        statusEl.textContent = 'Device rebooting… do not close this window';
        barEl.style.width = '15%';
        overlay.style.display = 'flex';

        // Expose log function so app_connection can append to it via DOM events
        let _overlayActive = true;
        let _pollTimer = null;

        const _onLog = e => _log(e.detail.message, e.detail.color);
        const _onDisconnected = e => {
            const attempt = e.detail?.attempt || 0;
            barEl.style.width = Math.min(15 + attempt * 10, 80) + '%';
            statusEl.textContent = `Waiting for device… (attempt ${attempt})`;
            _log(`WebSocket reconnect attempt ${attempt}`, '#fbbf24');
        };
        const _onDone = () => {
            if (!_overlayActive) return;
            _overlayActive = false;
            barEl.style.width = '100%';
            statusEl.textContent = 'Device reconnected — resuming';
            _log('✅ Device reconnected successfully', '#4ade80');
            clearTimeout(_pollTimer);
            _pollTimer = null;
            document.removeEventListener('reboot:log', _onLog);
            document.removeEventListener('reboot:disconnected', _onDisconnected);
            document.removeEventListener('reboot:done', _onDone);
            setTimeout(() => { overlay.style.display = 'none'; }, 1800);
        };

        document.addEventListener('reboot:log', _onLog);
        document.addEventListener('reboot:disconnected', _onDisconnected);
        document.addEventListener('reboot:done', _onDone);

        // After settle delay, start actively polling GET /api/connection every 3s.
        // Uses the lightweight connection-status endpoint which does NOT acquire
        // _operation_lock when disconnected, so it never hangs during reconnect.
        _pollTimer = setTimeout(function _startPolling() {
            if (!_overlayActive) return; // overlay already dismissed
            _log('Starting active reconnect polling…', '#93c5fd');
            statusEl.textContent = 'Waiting for device to come back online…';

            function _poll() {
                if (!_overlayActive) return; // dismissed while polling
                const sessionId = window.getCurrentSessionId ? window.getCurrentSessionId() : null;
                if (!sessionId) { setTimeout(_poll, CONFIG.REBOOT_POLL_INTERVAL_MS); return; }
                fetch('/api/connection', { headers: { 'X-Session-ID': sessionId } })
                    .then(r => r.ok ? r.json() : null)
                    .then(d => {
                        if (d && d.data && d.data.connected === true) {
                            _log('✅ Device reconnected — resuming', '#4ade80');
                            document.dispatchEvent(new CustomEvent('reboot:done'));
                        } else {
                            _log('Device not yet ready… retrying in 3s', '#fbbf24');
                            setTimeout(_poll, CONFIG.REBOOT_POLL_INTERVAL_MS);
                        }
                    })
                    .catch(() => {
                        _log('No response yet… retrying in 3s', '#fbbf24');
                        setTimeout(_poll, CONFIG.REBOOT_POLL_INTERVAL_MS);
                    });
            }
            _poll();
        }, CONFIG.REBOOT_SETTLE_DELAY_MS);
    }

    async function _save() {
        const payload = _collectPayload();
        if (!payload.sections.length) {
            alert('No changes detected. Edit fields before saving.');
            return;
        }

        const saveBtn = el('saveNodeConfigBtn');
        if (saveBtn) { saveBtn.disabled = true; saveBtn.textContent = 'Saving…'; }

        try {
            const sessionId = window.getCurrentSessionId ? window.getCurrentSessionId() : null;
            const headers   = { 'Content-Type': 'application/json' };
            if (sessionId) headers['X-Session-ID'] = sessionId;

            const resp = await fetch('/api/node/device-config', {
                method:  'POST',
                headers: headers,
                body:    JSON.stringify(payload),
            });
            const data = await resp.json();

            if (resp.ok && data.success) {
                // Close modal immediately, show blocking reboot overlay
                _closeModal();
                _showRebootOverlay(data.written || payload.sections);
                // Dispatch so app_connection refreshes Node Info on reconnect
                document.dispatchEvent(new CustomEvent('reboot:refresh-on-reconnect'));
                if (data.warnings?.length) {
                    data.warnings.forEach(w =>
                        document.dispatchEvent(new CustomEvent('reboot:log', {
                            detail: { message: `⚠ ${w}`, color: '#fca5a5' }
                        }))
                    );
                }
            } else {
                alert('Error saving config: ' + (data.detail || data.error || 'Unknown error'));
                if (saveBtn) { saveBtn.disabled = false; saveBtn.textContent = 'Save & Reboot'; }
            }
        } catch (e) {
            alert('Network error: ' + e.message);
            if (saveBtn) { saveBtn.disabled = false; saveBtn.textContent = 'Save & Reboot'; }
        }
    }

    // ── Open / Close ──────────────────────────────────────────────────────────

    function _closeModal() {
        const modal = el('nodeConfigModal');
        if (modal) modal.style.display = 'none';
        // Reset state
        _baseline = null;
        _config   = null;
        _channelDirty = {};
        _mapReady = false;
        if (_map) { _map.remove(); _map = null; _marker = null; }
        const saveBtn = el('saveNodeConfigBtn');
        if (saveBtn) { saveBtn.disabled = false; saveBtn.textContent = 'Save & Reboot'; }
        el('ncRebootWarning').style.display = 'none';
        // Switch back to first tab
        _switchTab('ncGeneral');
    }

    async function _open() {
        const modal = el('nodeConfigModal');
        if (!modal) return;

        // Show modal immediately with loading state
        modal.style.display = 'flex';
        _switchTab('ncGeneral');

        try {
            const sessionId = window.getCurrentSessionId ? window.getCurrentSessionId() : null;
            const headers   = {};
            if (sessionId) headers['X-Session-ID'] = sessionId;

            const resp = await fetch('/api/node/device-config', { headers });
            if (!resp.ok) {
                alert('Could not load device config: ' + resp.status);
                modal.style.display = 'none';
                return;
            }
            const body = await resp.json();
            _config = body.data;

            _populate(_config);
            _baseline = _snapshot();
            _channelDirty = {};
            _attachChangeListeners();
            _updateDirtyUI();

        } catch (e) {
            alert('Failed to load device config: ' + e.message);
            modal.style.display = 'none';
        }
    }

    // ── Init ─────────────────────────────────────────────────────────────────

    function _init() {
        // Edit button
        el('nodeConfigEditBtn')?.addEventListener('click', _open);

        // Tab bar
        el('nodeConfigTabBar')?.addEventListener('click', e => {
            const btn = e.target.closest('.tab-btn');
            if (btn) _switchTab(btn.dataset.tab);
        });

        // Channel select change
        el('ncChannelSelect')?.addEventListener('change', () => {
            const newIdx = parseInt(el('ncChannelSelect').value);
            // Save current channel's form state before switching away
            const prevIdx = el('ncChannelSelect')._prevIdx ?? -1;
            if (prevIdx >= 0 && _channelDirty[prevIdx]) {
                _channelDirty[prevIdx] = _snapshotChannelForm(prevIdx);
            }
            el('ncChannelSelect')._prevIdx = newIdx;
            const ch = _config?.channels?.find(c => c.index === newIdx);
            if (ch) _loadChannelFields(ch);
        });

        // Close buttons
        el('closeNodeConfigModal')?.addEventListener('click', _closeModal);
        el('cancelNodeConfigModal')?.addEventListener('click', _closeModal);

        // Save
        el('saveNodeConfigBtn')?.addEventListener('click', _save);

        // Backdrop close (respects data-no-backdrop-close)
        el('nodeConfigModal')?.addEventListener('click', e => {
            if (e.target === el('nodeConfigModal')) _closeModal();
        });
    }

    // ── Public API ────────────────────────────────────────────────────────────
    window.NodeConfigUI = { open: _open };

    // Listen for reconnect event triggered after save+reboot cycle
    document.addEventListener('reboot:refresh-on-reconnect', () => {
        if (typeof window.refreshNodeInfo === 'function') {
            window.refreshNodeInfo();
        }
    });

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', _init);
    } else {
        _init();
    }
})();
