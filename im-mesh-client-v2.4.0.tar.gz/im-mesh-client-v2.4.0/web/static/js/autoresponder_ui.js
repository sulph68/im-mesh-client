/**
 * autoresponder_ui.js — Auto Responder modal management for v2.4.X
 * v101: remove folder-hint from list; show config path in edit form
 * v100: preview button renamed Show/Hide Preview (no emojis); Test Trigger moved below Responder Engine; test passes current form engine config to backend
 */

(function () {
    'use strict';

    const modal = document.getElementById('autoResponderModal');
    const globalToggle = document.getElementById('arGlobalEnabled');
    const convList = document.getElementById('arConversationList');
    const responderForm = document.getElementById('arResponderForm');
    const formFooter = document.getElementById('arResponderFormFooter');

    let currentConvKey = null;
    let isNewConv = false;
    let allConvs = [];

    // ---- Comm log helper ----

    function commLog(direction, msg, type) {
        try {
            var c = window.meshtasticClient;
            if (c && typeof c.logCommunication === 'function') {
                c.logCommunication(direction, '[AutoResponder] ' + msg, type || 'info');
            }
        } catch (_) {}
    }

    // ---- Main modal ----

    function openModal() {
        modal.style.display = 'flex';
        loadGlobal();
        loadConversations();
        hideForm();
    }

    function closeModal() {
        modal.style.display = 'none';
        hideForm();
        currentConvKey = null;
    }

    async function loadGlobal() {
        try {
            const r = await fetch('/api/autoresponder/global');
            if (!r.ok) return;
            const d = await r.json();
            if (globalToggle) globalToggle.checked = !!(d.data && d.data.enabled);
        } catch (_) {}
    }

    async function loadConversations() {
        try {
            const r = await fetch('/api/autoresponder/conversations');
            if (!r.ok) return;
            const d = await r.json();
            allConvs = (d.data && d.data.conversations) || [];
            renderConversations(allConvs);
        } catch (_) {}
    }

    function renderConversations(convs) {
        if (convs.length === 0) {
            convList.innerHTML = '<p style="color:var(--text-muted); font-size:0.9em;">No auto responder conversations configured. Click + Add Responder to create one.</p>';
            return;
        }
        convList.innerHTML = convs.map((c, i) => {
            const displayName = c.label ? `${c.label}` : c.folder;
            const disabledTag = c.enabled ? '' : ' <span style="color:var(--text-muted)">[disabled]</span>';
            const engineLabels = { eliza: 'Eliza', script: 'Script', fixed: 'Fixed' };
            const engineName = engineLabels[c.responder_mode] || (c.responder_mode || 'Eliza');
            const engineTag = ` <span style="font-size:0.78em; color:var(--accent-color, #4488cc);">[${engineName}]</span>`;
            return `
            <div style="display:flex; align-items:center; gap:40px; padding:5px 4px;">
                <span style="flex:1; font-size:0.9em;">
                    <strong>${i + 1}) ${displayName}</strong>${disabledTag}${engineTag}
                </span>
                <button class="btn btn-small btn-outline" onclick="autoResponderUI.editConv('${c.folder}')">Edit</button>
            </div>`;
        }).join('');
    }

    // ---- Form open/close ----

    function openNewForm() {
        isNewConv = true;
        currentConvKey = null;

        document.getElementById('arResponderFormTitle').textContent = 'New Responder';
        document.getElementById('arFormFolderName').value = '';
        document.getElementById('arFormLabel').value = '';

        // Show monitor type group for new conversations
        const monitorGrp = document.getElementById('arFormMonitorGroup');
        if (monitorGrp) monitorGrp.style.display = '';

        // Default to channel; pre-select current chat context
        const client = window.meshtasticClient;
        let defaultChannel = 0;
        let defaultNode = '';

        if (client && client.sendTarget) {
            const st = client.sendTarget;
            if (st.type === 'node' && st.id) {
                document.getElementById('arFormTypeNode').checked = true;
                defaultNode = st.id;
                toggleFormType('node');
            } else {
                document.getElementById('arFormTypeChannel').checked = true;
                defaultChannel = st.id !== undefined ? st.id : (client.selectedChannelIndex || 0);
                toggleFormType('channel');
            }
        } else {
            document.getElementById('arFormTypeChannel').checked = true;
            toggleFormType('channel');
        }

        if (window.meshSelectors) {
            // Multiple rules per channel/node are now supported — no exclusions
            window.meshSelectors.loadChannelOptions(document.getElementById('arFormChannel'), defaultChannel, false, []);
            window.meshSelectors.loadNodeOptions(document.getElementById('arFormNode'), defaultNode, []);
        }

        // Reset trigger
        document.getElementById('arFormTriggerAny').checked = true;
        document.getElementById('arFormTriggerPattern').value = '';
        document.getElementById('arFormTriggerTestStr').value = '';
        document.getElementById('arFormTriggerTestResult').textContent = '';
        toggleFormTrigger('any');
        syncRegexHelpers('');

        // Responder mode: no script on new conv → force Eliza
        setResponderModeAvailability(false);
        const elizaRadio = document.getElementById('arFormModeEliza');
        if (elizaRadio) elizaRadio.checked = true;
        // Reset fixed response fields
        const fixedText = document.getElementById('arFormFixedText');
        if (fixedText) fixedText.value = '';
        const fixedCount = document.getElementById('arFormFixedCharCount');
        if (fixedCount) { fixedCount.textContent = '0 / 220'; fixedCount.style.color = ''; }
        const fixedPreview = document.getElementById('arFormFixedPreview');
        if (fixedPreview) { fixedPreview.style.display = 'none'; fixedPreview.textContent = ''; }
        const fixedBtn = document.getElementById('arFormFixedPreviewBtn');
        if (fixedBtn) fixedBtn.textContent = 'Show Preview';
        _updateFixedGroupVisibility();

        // Hide live test and log (new mode)
        const liveTestGrp = document.getElementById('arFormLiveTestGroup');
        if (liveTestGrp) liveTestGrp.style.display = 'none';
        const logSection = document.getElementById('arConvLogSection');
        if (logSection) logSection.style.display = 'none';

        // Enabled label
        document.getElementById('arFormEnabled').checked = true;
        document.getElementById('arFormEnabledLabel').textContent = 'Start enabled';

        // Footer: hide Delete for new
        showFormFooter(false);
        responderForm.style.display = 'block';
    }

    async function editConv(key) {
        isNewConv = false;
        currentConvKey = key;

        const conv = allConvs.find(c => c.folder === key);
        document.getElementById('arResponderFormTitle').textContent = 'Edit Responder';
        document.getElementById('arFormFolderName').value = key;

        // Show config path hint below the form title
        const pathDisplay = document.getElementById('arFormPathDisplay');
        if (pathDisplay) {
            pathDisplay.textContent = `Config folder: ${key}`;
            pathDisplay.style.display = '';
        }

        // Show monitor type group in edit mode too (allows changing channel/node)
        const monitorGrp = document.getElementById('arFormMonitorGroup');
        if (monitorGrp) monitorGrp.style.display = '';

        // Load config (label, trigger, pattern, monitor_type, responder_mode)
        try {
            const r = await fetch(`/api/autoresponder/conversations/${key}/config`);
            const d = r.ok ? await r.json() : null;
            const cfg = (d && d.data) || {};
            document.getElementById('arFormLabel').value = cfg.label || (conv && conv.label) || '';
            const trigger = cfg.trigger || 'any';
            const pattern = cfg.pattern || '';
            const anyRadio = document.getElementById('arFormTriggerAny');
            const regexRadio = document.getElementById('arFormTriggerRegex');
            if (anyRadio) anyRadio.checked = trigger === 'any';
            if (regexRadio) regexRadio.checked = trigger === 'regex';
            document.getElementById('arFormTriggerPattern').value = pattern;
            document.getElementById('arFormTriggerTestStr').value = '';
            document.getElementById('arFormTriggerTestResult').textContent = '';
            toggleFormTrigger(trigger);
            // Reset regex helpers to match loaded pattern
            syncRegexHelpers(pattern);

            // Load monitor type from config (prefer stored value; fall back to folder name inference)
            const storedType = cfg.monitor_type || (key.startsWith('ch') ? 'channel' : (key.startsWith('own_node') ? 'own_node' : 'node'));
            // Multiple rules per channel/node are now supported — no occupied exclusions.
            // Always show all channels/nodes; the UUID suffix distinguishes each rule.
            const occupiedChannels = [];
            const occupiedNodes = [];

            if (storedType === 'own_node') {
                document.getElementById('arFormTypeOwnNode').checked = true;
                toggleFormType('own_node');
                if (window.meshSelectors) {
                    window.meshSelectors.loadChannelOptions(document.getElementById('arFormChannel'), 0, false, occupiedChannels);
                    window.meshSelectors.loadNodeOptions(document.getElementById('arFormNode'), '', occupiedNodes);
                }
            } else if (storedType === 'channel') {
                document.getElementById('arFormTypeChannel').checked = true;
                toggleFormType('channel');
                const chIdx = cfg.channel_idx !== undefined ? cfg.channel_idx : (() => {
                    const m = key.match(/^ch(\d+)_/); return m ? parseInt(m[1], 10) : 0;
                })();
                if (window.meshSelectors) {
                    window.meshSelectors.loadChannelOptions(document.getElementById('arFormChannel'), chIdx, false, occupiedChannels);
                    window.meshSelectors.loadNodeOptions(document.getElementById('arFormNode'), '', occupiedNodes);
                } else {
                    document.getElementById('arFormChannel').value = chIdx;
                }
            } else {
                document.getElementById('arFormTypeNode').checked = true;
                toggleFormType('node');
                const nodeId = cfg.node_id || (key.startsWith('!') ? key : '!' + key);
                if (window.meshSelectors) {
                    window.meshSelectors.loadChannelOptions(document.getElementById('arFormChannel'), 0, false, occupiedChannels);
                    window.meshSelectors.loadNodeOptions(document.getElementById('arFormNode'), nodeId, occupiedNodes);
                } else {
                    document.getElementById('arFormNode').value = nodeId;
                }
            }

            // Responder mode
            const hasScript = !!(conv && conv.has_responder);
            setResponderModeAvailability(hasScript);
            const mode = cfg.responder_mode || 'eliza';
            const elizaRad = document.getElementById('arFormModeEliza');
            const scriptRad = document.getElementById('arFormModeScript');
            const fixedRad = document.getElementById('arFormModeFixed');
            if (mode === 'fixed') {
                if (fixedRad) fixedRad.checked = true;
            } else if (mode === 'script' && hasScript) {
                if (scriptRad) scriptRad.checked = true;
            } else {
                if (elizaRad) elizaRad.checked = true;
            }
            _updateFixedGroupVisibility();
            // Load fixed response text
            const fixedText = document.getElementById('arFormFixedText');
            const fixedCount = document.getElementById('arFormFixedCharCount');
            if (fixedText) {
                fixedText.value = cfg.fixed_response || '';
                const len = fixedText.value.length;
                if (fixedCount) fixedCount.textContent = `${len} / 220`;
                fixedCount && (fixedCount.style.color = len > 200 ? 'var(--warning, orange)' : '');
            }
            const fixedPreview = document.getElementById('arFormFixedPreview');
            if (fixedPreview) { fixedPreview.style.display = 'none'; fixedPreview.textContent = ''; }
            const fixedBtn = document.getElementById('arFormFixedPreviewBtn');
            if (fixedBtn) fixedBtn.textContent = 'Show Preview';
        } catch (_) {}

        // Enabled state
        const isEnabled = conv ? conv.enabled : true;
        document.getElementById('arFormEnabled').checked = isEnabled;
        document.getElementById('arFormEnabledLabel').textContent = 'Enabled';

        // Show live test section
        const liveTestGrp = document.getElementById('arFormLiveTestGroup');
        if (liveTestGrp) {
            liveTestGrp.style.display = '';
            document.getElementById('arFormTestMessage').value = '';
            document.getElementById('arFormTestResult').textContent = '';
            document.getElementById('arFormTestResult').style.cssText = '';
        }

        // Show and load log
        const logSection = document.getElementById('arConvLogSection');
        if (logSection) logSection.style.display = '';
        loadLog(key);

        // Footer: show Delete for existing
        showFormFooter(true);
        responderForm.style.display = 'block';
    }

    function hideForm() {
        if (responderForm) responderForm.style.display = 'none';
        if (formFooter) formFooter.style.display = 'none';
        const logSection = document.getElementById('arConvLogSection');
        if (logSection) logSection.style.display = 'none';
    }

    function showFormFooter(showDelete) {
        if (!formFooter) return;
        formFooter.style.display = 'flex';
        const delBtn = document.getElementById('arDeleteConvBtn');
        if (delBtn) delBtn.style.display = showDelete ? '' : 'none';
    }

    // ---- Form helpers ----

    function toggleFormType(type) {
        const chGrp = document.getElementById('arFormChannelGroup');
        const ndGrp = document.getElementById('arFormNodeGroup');
        const onGrp = document.getElementById('arFormOwnNodeGroup');
        if (chGrp) chGrp.style.display = type === 'channel' ? '' : 'none';
        if (ndGrp) ndGrp.style.display = type === 'node' ? '' : 'none';
        if (onGrp) onGrp.style.display = type === 'own_node' ? '' : 'none';
    }

    function toggleFormTrigger(trigger) {
        const grp = document.getElementById('arFormTriggerRegexGroup');
        if (grp) grp.style.display = trigger === 'regex' ? '' : 'none';
    }

    // ---- Responder mode helper ----

    /**
     * Enable/disable the script radio based on whether a responder script exists.
     * If no script, force Eliza and show a hint.
     */
    function setResponderModeAvailability(hasScript) {
        const scriptRad = document.getElementById('arFormModeScript');
        const scriptLabel = document.getElementById('arFormModeScriptLabel');
        const hint = document.getElementById('arFormResponderModeHint');
        if (!scriptRad) return;
        scriptRad.disabled = !hasScript;
        if (scriptLabel) scriptLabel.style.opacity = hasScript ? '' : '0.45';
        if (hint) {
            hint.textContent = hasScript
                ? 'Choose Eliza for the built-in chatbot, Script to run the "responder" executable, or Fixed Response to send a static message.'
                : 'No responder script found — upload a "responder" file to enable script mode.';
        }
        if (!hasScript && scriptRad.checked) {
            const elizaRad = document.getElementById('arFormModeEliza');
            if (elizaRad) elizaRad.checked = true;
        }
        _updateFixedGroupVisibility();
    }

    function _updateFixedGroupVisibility() {
        const modeEl = document.querySelector('input[name="arFormResponderMode"]:checked');
        const fixedGroup = document.getElementById('arFormFixedGroup');
        if (!fixedGroup) return;
        fixedGroup.style.display = (modeEl && modeEl.value === 'fixed') ? '' : 'none';
        if (modeEl && modeEl.value !== 'fixed') {
            const preview = document.getElementById('arFormFixedPreview');
            if (preview) preview.style.display = 'none';
        }
    }

    function toggleFixedPreview() {
        const text = (document.getElementById('arFormFixedText') || {}).value || '';
        const previewDiv = document.getElementById('arFormFixedPreview');
        const btn = document.getElementById('arFormFixedPreviewBtn');
        if (!previewDiv) return;
        if (previewDiv.style.display === 'none') {
            // Substitute {{VAR}} with example placeholders and {{S_VAR}} with own node examples
            const resolved = text
                .replace(/\{\{MESSAGE\}\}/g, '[incoming message text]')
                .replace(/\{\{S_LONG_NAME\}\}/g, '[own:LongName]')
                .replace(/\{\{S_SHORT_NAME\}\}/g, '[own:Short]')
                .replace(/\{\{S_ID\}\}/g, '[own:!00000000]')
                .replace(/\{\{S_SNR\}\}/g, '[own:SNR]')
                .replace(/\{\{S_RSSI\}\}/g, '[own:RSSI]')
                .replace(/\{\{S_BATTERY\}\}/g, '[own:Bat%]')
                .replace(/\{\{S_VOLTAGE\}\}/g, '[own:V]')
                .replace(/\{\{S_HOPS\}\}/g, '[own:Hops]')
                .replace(/\{\{S_ROLE\}\}/g, '[own:Role]')
                .replace(/\{\{S_HARDWARE\}\}/g, '[own:HW]')
                .replace(/\{\{S_LAT\}\}/g, '[own:Lat]')
                .replace(/\{\{S_LON\}\}/g, '[own:Lon]')
                .replace(/\{\{S_ALT\}\}/g, '[own:Alt]')
                .replace(/\{\{S_UPTIME\}\}/g, '[own:Uptime]')
                .replace(/\{\{S_CH_UTIL\}\}/g, '[own:ChUtil]')
                .replace(/\{\{S_AIR_TX\}\}/g, '[own:AirTx]')
                .replace(/\{\{LONG_NAME\}\}/g, '[node:LongName]')
                .replace(/\{\{SHORT_NAME\}\}/g, '[node:Short]')
                .replace(/\{\{ID\}\}/g, '[node:!abcdef12]')
                .replace(/\{\{SNR\}\}/g, '[node:SNR]')
                .replace(/\{\{RSSI\}\}/g, '[node:RSSI]')
                .replace(/\{\{BATTERY\}\}/g, '[node:Bat%]')
                .replace(/\{\{VOLTAGE\}\}/g, '[node:V]')
                .replace(/\{\{HOPS\}\}/g, '[node:Hops]')
                .replace(/\{\{ROLE\}\}/g, '[node:Role]')
                .replace(/\{\{HARDWARE\}\}/g, '[node:HW]')
                .replace(/\{\{LAT\}\}/g, '[node:Lat]')
                .replace(/\{\{LON\}\}/g, '[node:Lon]')
                .replace(/\{\{ALT\}\}/g, '[node:Alt]')
                .replace(/\{\{UPTIME\}\}/g, '[node:Uptime]')
                .replace(/\{\{CH_UTIL\}\}/g, '[node:ChUtil]')
                .replace(/\{\{AIR_TX\}\}/g, '[node:AirTx]');
            previewDiv.textContent = resolved || '(empty)';
            previewDiv.style.display = '';
            if (btn) btn.textContent = 'Hide Preview';
        } else {
            previewDiv.style.display = 'none';
            if (btn) btn.textContent = 'Show Preview';
        }
    }

    // ---- Regex helpers ----

    /**
     * Sync the helper checkboxes from a given pattern string.
     * Used when loading an existing pattern to pre-check appropriate helpers.
     */
    function syncRegexHelpers(pattern) {
        const el = id => document.getElementById(id);
        if (!el('arRegexCaseInsensitive')) return; // helpers not rendered yet
        // Case insensitive: backend always uses IGNORECASE, so always checked
        if (el('arRegexCaseInsensitive')) el('arRegexCaseInsensitive').checked = true;
        // Word boundary: pattern is wrapped in \b...\b
        if (el('arRegexWholeWord')) el('arRegexWholeWord').checked = /^\\b.*\\b$/.test(pattern);
        // Start anchor
        if (el('arRegexStartAnchor')) el('arRegexStartAnchor').checked = pattern.startsWith('^');
        // End anchor
        if (el('arRegexEndAnchor')) el('arRegexEndAnchor').checked = pattern.endsWith('$');
    }

    /** Apply helper checkboxes to the current pattern. Called on checkbox change. */
    function applyRegexHelpers() {
        const patEl = document.getElementById('arFormTriggerPattern');
        if (!patEl) return;
        let p = patEl.value;

        // Strip existing anchors/boundary wrappers so we can re-apply cleanly
        p = p.replace(/^\^/, '').replace(/\$$/, '');
        p = p.replace(/^\\b/, '').replace(/\\b$/, '');

        const wholeWord = document.getElementById('arRegexWholeWord');
        const startAnchor = document.getElementById('arRegexStartAnchor');
        const endAnchor = document.getElementById('arRegexEndAnchor');

        if (wholeWord && wholeWord.checked) {
            p = '\\b' + p + '\\b';
        } else {
            if (startAnchor && startAnchor.checked) p = '^' + p;
            if (endAnchor && endAnchor.checked) p = p + '$';
        }

        patEl.value = p;
        // Clear old test result
        const res = document.getElementById('arFormTriggerTestResult');
        if (res) { res.textContent = ''; res.style.cssText = ''; }
    }

    function testFormRegex() {
        const pattern = document.getElementById('arFormTriggerPattern').value || '';
        const testStr = document.getElementById('arFormTriggerTestStr').value || '';
        const resultEl = document.getElementById('arFormTriggerTestResult');
        // Clear result if no test string entered
        if (!testStr.trim()) {
            resultEl.textContent = '';
            resultEl.style.cssText = '';
            return;
        }
        if (!pattern) {
            resultEl.textContent = '⚠ Enter a pattern first.';
            resultEl.style.cssText = 'background:var(--surface-warning,#332200);color:var(--warning-color,#ffaa00);padding:4px 6px;border-radius:4px;font-size:0.82em;margin-top:4px;';
            return;
        }
        try {
            const matched = new RegExp(pattern, 'i').test(testStr);
            resultEl.textContent = matched ? '✓ Match!' : '✗ No match';
            resultEl.style.cssText = matched
                ? 'background:var(--surface-success,#003322);color:var(--success-color,#44dd88);padding:4px 6px;border-radius:4px;font-size:0.82em;margin-top:4px;'
                : 'background:var(--surface-error,#330011);color:var(--error-color,#ff6677);padding:4px 6px;border-radius:4px;font-size:0.82em;margin-top:4px;';
        } catch (e) {
            resultEl.textContent = '⚠ Invalid regex: ' + e.message;
            resultEl.style.cssText = 'background:var(--surface-warning,#332200);color:var(--warning-color,#ffaa00);padding:4px 6px;border-radius:4px;font-size:0.82em;margin-top:4px;';
        }
    }

    // ---- Live trigger test ----

    async function testLiveTrigger() {
        if (!currentConvKey) return;
        const msg = document.getElementById('arFormTestMessage').value.trim();
        const resultEl = document.getElementById('arFormTestResult');
        const baseStyle = 'padding:6px 8px;border-radius:4px;font-size:0.85em;margin-top:4px;';
        if (!msg) {
            resultEl.textContent = '⚠ Enter a test message first.';
            resultEl.style.cssText = baseStyle + 'background:var(--surface-warning,#332200);color:var(--warning-color,#ffaa00);';
            return;
        }
        // Collect current form state to send as overrides
        const modeEl = document.querySelector('input[name="arFormResponderMode"]:checked');
        const responderMode = modeEl ? modeEl.value : null;
        const fixedResponse = responderMode === 'fixed'
            ? ((document.getElementById('arFormFixedText') || {}).value || '')
            : null;
        const triggerEl = document.querySelector('input[name="arFormTrigger"]:checked');
        const trigger = triggerEl ? triggerEl.value : null;
        const pattern = trigger === 'regex'
            ? (document.getElementById('arFormTriggerPattern').value || '')
            : null;

        resultEl.textContent = 'Testing…';
        resultEl.style.cssText = baseStyle + 'background:var(--background-secondary);color:var(--text-muted);';
        try {
            const body = { message: msg };
            if (responderMode) body.responder_mode = responderMode;
            if (fixedResponse !== null) body.fixed_response = fixedResponse;
            if (trigger) body.trigger = trigger;
            if (pattern !== null) body.pattern = pattern;

            const r = await fetch(`/api/autoresponder/conversations/${currentConvKey}/test`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(body),
            });
            const d = await r.json();
            if (!r.ok) {
                resultEl.textContent = '⚠ ' + (d.detail || 'Test failed');
                resultEl.style.cssText = baseStyle + 'background:var(--surface-error,#330011);color:var(--error-color,#ff6677);';
                return;
            }
            const data = d.data || {};
            if (data.triggered && data.response) {
                resultEl.textContent = '✓ Triggered — Response: ' + data.response;
                resultEl.style.cssText = baseStyle + 'background:var(--surface-success,#003322);color:var(--success-color,#44dd88);';
                commLog('INFO', `Test triggered for "${currentConvKey}" — response: ${data.response}`, 'success');
            } else {
                const reason = data.reason ? ` (${data.reason})` : '';
                resultEl.textContent = `✗ Not triggered${reason}`;
                resultEl.style.cssText = baseStyle + 'background:var(--background-secondary);color:var(--text-secondary);';
            }
        } catch (e) {
            resultEl.textContent = '⚠ Error: ' + e.message;
            resultEl.style.cssText = baseStyle + 'background:var(--surface-error,#330011);color:var(--error-color,#ff6677);';
        }
    }

    // ---- Save ----

    async function saveForm() {
        const triggerEl = document.querySelector('input[name="arFormTrigger"]:checked');
        const trigger = triggerEl ? triggerEl.value : 'any';
        const pattern = document.getElementById('arFormTriggerPattern').value || '';
        const label = document.getElementById('arFormLabel').value || '';
        const enabled = document.getElementById('arFormEnabled').checked;
        const responderModeEl = document.querySelector('input[name="arFormResponderMode"]:checked');
        const responderMode = responderModeEl ? responderModeEl.value : 'eliza';
        const fixedResponse = (document.getElementById('arFormFixedText') || {}).value || '';

        // Validate regex
        if (trigger === 'regex' && pattern) {
            try { new RegExp(pattern); } catch (e) {
                alert('Invalid regex pattern: ' + e.message); return;
            }
        }

        // Collect monitor type fields
        const typeEl = document.querySelector('input[name="arFormType"]:checked');
        const type = typeEl ? typeEl.value : 'channel';
        let folderChannelIdx = 0;
        let folderNodeId = '';

        if (type === 'channel') {
            const chSel = document.getElementById('arFormChannel');
            folderChannelIdx = parseInt(chSel ? chSel.value : '0', 10) || 0;
        } else if (type === 'node') {
            const nodeSel = document.getElementById('arFormNode');
            folderNodeId = nodeSel ? (nodeSel.value || '') : '';
        }
        // own_node: folderChannelIdx/folderNodeId remain default (0/'')

        if (isNewConv) {
            // Determine base folder name from type + channel/node selection
            // The server will append a UUID suffix to make each rule unique.
            let folderName = '';

            if (type === 'channel') {
                const chSel = document.getElementById('arFormChannel');
                const chText = chSel && chSel.selectedOptions[0] ? chSel.selectedOptions[0].textContent : '';
                const namePart = chText.replace(/^Ch\s*\d+:\s*/i, '').trim().toLowerCase().replace(/[^a-z0-9]/g, '_') || 'primary';
                folderName = `ch${folderChannelIdx}_${namePart}`;
            } else if (type === 'node') {
                if (!folderNodeId) { alert('Please select a node.'); return; }
                folderName = folderNodeId.replace(/^!/, '');
            } else {
                // own_node catch-all
                folderName = 'own_node';
            }

            if (!folderName) { alert('Could not determine conversation key.'); return; }

            try {
                const r = await fetch('/api/autoresponder/conversations', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        folder_name: folderName, label, trigger, pattern, enabled,
                        monitor_type: type,
                        channel_idx: folderChannelIdx,
                        node_id: folderNodeId,
                        responder_mode: responderMode,
                        fixed_response: fixedResponse,
                    }),
                });
                if (!r.ok) { alert('Failed to create conversation'); return; }
                // Server returns the actual folder name (with UUID suffix)
                const resp = await r.json().catch(() => ({}));
                const createdFolder = (resp.data && resp.data.folder) || folderName;
                const triggerDesc = trigger === 'regex' ? `regex: ${pattern}` : 'any message';
                commLog('INFO', `Conversation "${createdFolder}" created (trigger: ${triggerDesc})`, 'success');
                hideForm();
                loadConversations();
            } catch (e) {
                alert('Error: ' + e.message);
            }
        } else {
            // Edit: compute new folder name, rename if changed, then save config
            const key = currentConvKey;
            const conv = allConvs.find(c => c.folder === key);

            // Compute new folder name from monitor type selection.
            // Preserve any 8-char UUID suffix from the current key (rule identity).
            let newFolderName = key;
            const _uuidSuffixMatch = key.match(/_([0-9a-f]{8})$/);
            const _uuidSuffix = _uuidSuffixMatch ? _uuidSuffixMatch[0] : '';

            if (type === 'channel') {
                const chSel = document.getElementById('arFormChannel');
                const chText = chSel && chSel.selectedOptions[0] ? chSel.selectedOptions[0].textContent : '';
                const namePart = chText.replace(/^Ch\s*\d+:\s*/i, '').trim().toLowerCase().replace(/[^a-z0-9]/g, '_') || 'primary';
                newFolderName = `ch${folderChannelIdx}_${namePart}${_uuidSuffix}`;
            } else if (type === 'node') {
                if (!folderNodeId) { alert('Please select a node.'); return; }
                newFolderName = folderNodeId.replace(/^!/, '') + _uuidSuffix;
            } else {
                // own_node — keep base as 'own_node', preserve uuid suffix
                newFolderName = 'own_node' + _uuidSuffix;
            }

            try {
                // Rename folder if target changed
                let effectiveKey = key;
                if (newFolderName !== key) {
                    const ren = await fetch(`/api/autoresponder/conversations/${key}/rename`, {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ new_name: newFolderName }),
                    });
                    if (!ren.ok) {
                        const err = await ren.json().catch(() => ({}));
                        alert('Failed to rename conversation: ' + (err.detail || 'unknown error'));
                        return;
                    }
                    effectiveKey = newFolderName;
                    currentConvKey = newFolderName;
                }

                // Save full config including monitor_type and responder_mode
                const r = await fetch(`/api/autoresponder/conversations/${effectiveKey}/config`, {
                    method: 'PUT',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        label, trigger, pattern,
                        monitor_type: type,
                        channel_idx: folderChannelIdx,
                        node_id: folderNodeId,
                        responder_mode: responderMode,
                        fixed_response: fixedResponse,
                    }),
                });
                if (!r.ok) { alert('Failed to save config'); return; }

                // Toggle enabled state if changed
                if (conv && conv.enabled !== enabled) {
                    const toggleUrl = enabled
                        ? `/api/autoresponder/conversations/${effectiveKey}/enable`
                        : `/api/autoresponder/conversations/${effectiveKey}/disable`;
                    await fetch(toggleUrl, { method: 'PUT' });
                }

                commLog('INFO', `Conversation "${effectiveKey}" saved`, 'success');
                hideForm();
                loadConversations();
            } catch (e) {
                alert('Error: ' + e.message);
            }
        }
    }

    // ---- Delete ----

    async function deleteConv() {
        if (!currentConvKey || !confirm(`Delete conversation "${currentConvKey}"? This cannot be undone.`)) return;
        try {
            const r = await fetch(`/api/autoresponder/conversations/${currentConvKey}`, { method: 'DELETE' });
            if (!r.ok) { alert('Failed to delete conversation'); return; }
            commLog('INFO', `Conversation "${currentConvKey}" deleted`, 'warning');
            hideForm();
            currentConvKey = null;
            loadConversations();
        } catch (e) {
            alert('Error: ' + e.message);
        }
    }

    // ---- Log ----

    async function loadLog(key) {
        const target = key || currentConvKey;
        if (!target) return;
        const logDiv = document.getElementById('arConvLog');
        try {
            const r = await fetch(`/api/autoresponder/conversations/${target}/log`);
            if (!r.ok) { logDiv.textContent = 'Error loading log'; return; }
            const d = await r.json();
            const content = (d.data && d.data.log) || '';
            logDiv.textContent = content || '(no log entries)';
        } catch (e) {
            logDiv.textContent = 'Error: ' + e.message;
        }
    }

    async function clearLog() {
        if (!currentConvKey || !confirm('Clear conversation history for "' + currentConvKey + '"?\nThis deletes conversation.txt and resets Eliza/script memory.')) return;
        const logDiv = document.getElementById('arConvLog');
        try {
            const r = await fetch(`/api/autoresponder/conversations/${currentConvKey}/log`, { method: 'DELETE' });
            if (r.ok) {
                logDiv.textContent = '(cleared)';
                commLog('INFO', `Conversation history cleared for "${currentConvKey}"`, 'warning');
            }
        } catch (_) {}
    }

    // ---- Wire buttons ----

    document.getElementById('closeAutoResponderModal').addEventListener('click', closeModal);

    if (globalToggle) {
        globalToggle.addEventListener('change', async function () {
            const enabled = this.checked;
            try {
                const r = await fetch('/api/autoresponder/global', {
                    method: 'PUT',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ enabled }),
                });
                if (!r.ok) { this.checked = !enabled; return; }
                commLog('INFO', `Auto Responder globally ${enabled ? 'enabled' : 'disabled'}`, enabled ? 'success' : 'warning');
            } catch (_) {
                this.checked = !enabled;
            }
        });
    }

    document.getElementById('addArConvBtn').addEventListener('click', openNewForm);
    document.getElementById('arSaveFormBtn').addEventListener('click', saveForm);
    document.getElementById('arCancelFormBtn').addEventListener('click', hideForm);
    document.getElementById('arDeleteConvBtn').addEventListener('click', deleteConv);
    document.getElementById('arFormTestBtn').addEventListener('click', testLiveTrigger);
    document.getElementById('arFormTriggerTestBtn').addEventListener('click', testFormRegex);

    // Regex helper checkboxes
    ['arRegexCaseInsensitive', 'arRegexWholeWord', 'arRegexStartAnchor', 'arRegexEndAnchor'].forEach(id => {
        const el = document.getElementById(id);
        if (el) el.addEventListener('change', applyRegexHelpers);
    });
    document.getElementById('arRefreshLogBtn').addEventListener('click', () => loadLog(currentConvKey));
    document.getElementById('arClearLogBtn').addEventListener('click', clearLog);

    // Responder mode radios → show/hide fixed group
    ['arFormModeEliza', 'arFormModeScript', 'arFormModeFixed'].forEach(id => {
        const el = document.getElementById(id);
        if (el) el.addEventListener('change', _updateFixedGroupVisibility);
    });

    // Fixed response char counter
    const fixedTextEl = document.getElementById('arFormFixedText');
    if (fixedTextEl) {
        fixedTextEl.addEventListener('input', function () {
            const len = this.value.length;
            const counter = document.getElementById('arFormFixedCharCount');
            if (counter) {
                counter.textContent = `${len} / 220`;
                counter.style.color = len > 200 ? 'var(--warning, orange)' : '';
            }
            // Hide preview when text changes
            const preview = document.getElementById('arFormFixedPreview');
            if (preview && preview.style.display !== 'none') {
                preview.style.display = 'none';
                const btn = document.getElementById('arFormFixedPreviewBtn');
                if (btn) btn.textContent = 'Show Preview';
            }
        });
    }

    // Monitor type radios
    ['arFormTypeChannel', 'arFormTypeNode', 'arFormTypeOwnNode'].forEach(id => {
        const el = document.getElementById(id);
        if (el) el.addEventListener('change', () => toggleFormType(el.value));
    });

    // Trigger type radios
    ['arFormTriggerAny', 'arFormTriggerRegex'].forEach(id => {
        const el = document.getElementById(id);
        if (el) el.addEventListener('change', () => toggleFormTrigger(el.value));
    });

    const arBtn = document.getElementById('openAutoResponderBtn');
    if (arBtn) arBtn.addEventListener('click', openModal);

    // Backdrop click intentionally disabled — use ✕ button to close

    // ---- checkApplicable ----

    async function checkApplicable() {
        if (!arBtn) return;
        try {
            const r = await fetch('/api/autoresponder/global');
            if (!r.ok) return;
            const d = await r.json();
            if (d.data && d.data.applicable === false) {
                arBtn.style.display = 'none';
                arBtn.disabled = false;
            } else {
                arBtn.style.display = '';
                const settingsEnabled = !!(d.data && d.data.settings_enabled);
                arBtn.disabled = !settingsEnabled;
                arBtn.title = settingsEnabled
                    ? 'Auto Responder'
                    : 'Auto Responder (disabled in settings.json)';
            }
        } catch (_) {}
    }
    window.checkAutoResponderApplicable = checkApplicable;
    setTimeout(checkApplicable, 1500);

    window.autoResponderUI = { openModal, closeModal, editConv, toggleFixedPreview };
})();
