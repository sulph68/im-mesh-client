/**
 * Meshtastic Web Client - Messages Module: Message routing, storage, history, chat management
 */

Object.assign(MeshtasticClient.prototype, {

// Add a chat message to the messages display area
addChatMessage(messageData) {
    // Store message asynchronously (IndexedDB)
    this.storeMessageForTarget(messageData);

    // Render in chat immediately (don't wait for storage)
    try {
        this.renderChatMessage(messageData, true);
    } catch (e) {
        console.error('Error rendering message:', e);
    }
},

// Handle incoming message from WebSocket
addMessage(messageData) {

    // CRITICAL: Skip binary_complete messages — the fragment_reassembler concatenates
    // ALL segment payloads into one giant string for these.  Individual segments are
    // already stored in IndexedDB as they arrive.  If we store the concatenated blob
    // here, _searchHistoryForChecksum will find it and use it as "segment 0" data,
    // producing garbled reassembly.
    // Allow image_complete through ONLY when a server-decoded image is attached;
    // without it the payload is still the concatenated blob and would corrupt storage.
    const msgType = messageData.type || messageData.message_type;
    if (msgType === 'binary_complete') {
        _MSG_DEBUG && console.log('addMessage: skipping binary_complete (concatenated payload, individual segments already stored)');
        return;
    }
    if (msgType === 'image_complete' && !messageData.image_data) {
        _MSG_DEBUG && console.log('addMessage: skipping image_complete without decoded image (concatenated payload)');
        return;
    }

    // Deduplicate: skip if we already have this message in storage.
    // Uses routed_at timestamp + from_node as a unique key to catch
    // buffered messages that arrive both via flush and live routing.
    if (messageData.routed_at && messageData.from_node && this.storage) {
        const dedupKey = `${messageData.routed_at}_${messageData.from_node}`;
        if (!this._seenMessageKeys) this._seenMessageKeys = new Set();
        if (this._seenMessageKeys.has(dedupKey)) {
            _MSG_DEBUG && console.log(`Dedup: skipping duplicate message ${dedupKey}`);
            return;
        }
        this._seenMessageKeys.add(dedupKey);
        // Keep set size bounded
        if (this._seenMessageKeys.size > DEDUP_SET_MAX) {
            const arr = Array.from(this._seenMessageKeys);
            this._seenMessageKeys = new Set(arr.slice(-DEDUP_SET_PRUNE_TO));
        }
    }

    // Deduplicate scheduled messages by sched_key (entry_id + fired_at + part_idx)
    if (messageData.sched_key) {
        if (!this._seenSchedKeys) this._seenSchedKeys = new Set();
        if (this._seenSchedKeys.has(messageData.sched_key)) {
            _MSG_DEBUG && console.log(`Dedup: skipping duplicate scheduled message ${messageData.sched_key}`);
            return;
        }
        this._seenSchedKeys.add(messageData.sched_key);
        if (this._seenSchedKeys.size > DEDUP_SET_MAX) {
            const arr = Array.from(this._seenSchedKeys);
            this._seenSchedKeys = new Set(arr.slice(-DEDUP_SET_PRUNE_TO));
        }
    }

    // Deduplicate AR response messages by ar_key
    if (messageData.ar_key) {
        if (!this._seenArKeys) this._seenArKeys = new Set();
        if (this._seenArKeys.has(messageData.ar_key)) {
            _MSG_DEBUG && console.log(`Dedup: skipping duplicate AR message ${messageData.ar_key}`);
            return;
        }
        this._seenArKeys.add(messageData.ar_key);
        if (this._seenArKeys.size > DEDUP_SET_MAX) {
            const arr = Array.from(this._seenArKeys);
            this._seenArKeys = new Set(arr.slice(-DEDUP_SET_PRUNE_TO));
        }
    }

    // Notify new message in browser tab title
    this._notifyNewMessageInTitle();

    // Resolve sender name
    const fromName = this._resolveSenderName(messageData);

    // Auto-refresh node list if we hear an unknown node
    this._checkForUnknownNode(messageData);

    // Determine routing key (channel vs DM)
    const { msgTargetKey, isDM } = this._resolveMessageTarget(messageData);

    _MSG_DEBUG && console.log(`Message routing: from=${messageData.from_node} to=${messageData.to_node} is_broadcast=${messageData.is_broadcast} isDM=${isDM} targetKey=${msgTargetKey}`);

    const currentTargetKey = this.getMessageStorageKey();
    const isCurrentView = (currentTargetKey === msgTargetKey);

    // Dispatch by message type
    if (messageData.type === 'image_complete' && messageData.image_data) {
        this._handleImageCompleteMessage(messageData, fromName, msgTargetKey, isCurrentView);
        return;
    }

    // Binary messages: check both wrapped (decoded.portnum) and unwrapped (portnum) forms
    const isBinaryMsg = (messageData.decoded && messageData.decoded.portnum === 288) ||
                        (messageData.portnum === 288 || messageData.portnum === 'CUSTOM_IMAGE_APP');
    if (isBinaryMsg) {
        // If the binary payload looks like an image segment text, treat it as
        // a text message so it renders the segment content and gets reassemble
        // buttons. Only show the generic "[Binary Message]" box if it's opaque data.
        // Check multiple locations where the payload string might be stored:
        // - decoded.payload: set by packet_processor (decoded UTF-8 string)
        // - decoded.binary_data: hex-encoded fallback from packet_processor
        // - payload: set by packet_handler path
        const binaryPayload = (messageData.decoded && messageData.decoded.payload) ||
                              messageData.payload || '';
        if (typeof binaryPayload === 'string' && this._isImageSegment(binaryPayload)) {
            // Render as text so image segment detection works
            const chatMsg = {
                from: fromName,
                text: binaryPayload,
                timestamp: messageData.rx_time || messageData.timestamp,
                type: 'received',
                portnum: 288,
                channel: messageData.channel,
                from_node: messageData.from_node,
                _targetKey: msgTargetKey
            };
            if (isCurrentView) {
                this.addChatMessage(chatMsg);
            } else {
                this._storeAndNotify(chatMsg, msgTargetKey, messageData.from_node || messageData.from);
            }
        } else {
            this._handleBinaryMessage(messageData, fromName, msgTargetKey, isCurrentView);
        }
        this.updateStatistics();
        return;
    }

    if (messageData.decoded_text || (messageData.decoded && messageData.decoded.text)) {
        this._handleTextMessage(messageData, fromName, msgTargetKey, isCurrentView);
    } else {
        this._handleFallbackMessage(messageData, fromName, msgTargetKey, isCurrentView);
    }

    this.updateStatistics();
},

/** Resolve sender display name from messageData or stored nodes. */
_resolveSenderName(messageData) {
    let fromName = messageData.from_name || messageData.from_node || messageData.from || 'Unknown';
    if (this.storage && (messageData.from_node || messageData.from)) {
        const nodeId = messageData.from_node || messageData.from;
        const nodes = this.storage.getNodes();
        const senderNode = nodes.find(n => (n.id || n.num) === nodeId);
        if (senderNode) {
            fromName = (senderNode.longName || '').trim() || (senderNode.shortName || '').trim() || (senderNode.name || '').trim() || fromName;
        }
    }
    return fromName;
},

/** Determine the storage key and whether this is a DM. */
_resolveMessageTarget(messageData) {
    const toNodeStr = String(messageData.to_node || '').toLowerCase().replace(/^!/, '');
    const isBroadcastAddr = !toNodeStr || toNodeStr === 'ffffffff' || toNodeStr === '4294967295';
    const isDM = messageData.to_node && messageData.is_broadcast === false && !isBroadcastAddr;
    let msgTargetKey;
    if (isDM) {
        // Scheduled and AR messages originate from the gateway — use to_node for conversation routing
        const dmTarget = (messageData.scheduled || messageData.ar_response) ? messageData.to_node : (messageData.from_node || messageData.from);
        msgTargetKey = `messages_node_${dmTarget}`;
    } else {
        msgTargetKey = `messages_channel_${messageData.channel || 0}`;
    }
    return { msgTargetKey, isDM };
},

/** Handle decoded image_complete messages. */
_handleImageCompleteMessage(messageData, fromName, msgTargetKey, isCurrentView) {
    const chatMsg = {
        from: fromName,
        text: 'Image received',
        timestamp: messageData.rx_time || messageData.timestamp,
        type: 'received',
        isImage: true,
        imageData: messageData.image_data,
        channel: messageData.channel,
        _targetKey: msgTargetKey
    };
    if (isCurrentView) {
        this.addChatMessage(chatMsg);
    } else {
        this._storeAndNotify(chatMsg, msgTargetKey, messageData.from_node || messageData.from);
    }
},

/** Handle CUSTOM_IMAGE_APP (portnum 288) binary messages. */
_handleBinaryMessage(messageData, fromName, msgTargetKey, isCurrentView) {
    const payload = messageData.decoded.payload || messageData.decoded.binary_data || '[binary data]';
    const chatMsg = {
        from: fromName,
        text: '[Binary Message]',
        timestamp: messageData.rx_time || messageData.timestamp,
        type: 'received',
        portnum: 288,
        isBinary: true,
        rawPayload: payload,
        payloadSize: typeof payload === 'string' ? payload.length : 0,
        channel: messageData.channel,
        _targetKey: msgTargetKey
    };
    if (isCurrentView) {
        this.addChatMessage(chatMsg);
    } else {
        this._storeAndNotify(chatMsg, msgTargetKey, messageData.from_node || messageData.from);
    }
},

/** Handle standard text messages. */
_handleTextMessage(messageData, fromName, msgTargetKey, isCurrentView) {
    const text = messageData.decoded_text || messageData.decoded.text;
    const chatMsg = {
        from: fromName,
        text: text,
        timestamp: messageData.rx_time || messageData.timestamp,
        type: 'received',
        channel: messageData.channel,
        from_node: messageData.from_node,
        source: messageData.source,
        _targetKey: msgTargetKey
    };
    if (isCurrentView) {
        this.addChatMessage(chatMsg);
    } else {
        this._storeAndNotify(chatMsg, msgTargetKey, messageData.from_node || messageData.from);
    }
},

/** Handle messages with no recognized payload format. */
_handleFallbackMessage(messageData, fromName, msgTargetKey, isCurrentView) {
    const fallbackText = messageData.payload || messageData.text || null;
    if (fallbackText) {
        // Automation messages (scheduler/AR) are outgoing — treat as 'sent' for correct alignment
        const isAutomation = messageData.source === 'scheduler' || messageData.source === 'ar';
        const chatMsg = {
            from: fromName,
            text: typeof fallbackText === 'string' ? fallbackText : '[message]',
            timestamp: messageData.rx_time || messageData.timestamp,
            type: isAutomation ? 'sent' : 'received',
            channel: messageData.channel,
            from_node: messageData.from_node,
            source: messageData.source,
            _targetKey: msgTargetKey
        };
        if (isCurrentView) {
            this.addChatMessage(chatMsg);
        } else {
            this._storeAndNotify(chatMsg, msgTargetKey, messageData.from_node || messageData.from);
        }
    } else {
        console.warn('addMessage: unhandled message format', messageData);
    }
},

/**
 * Store a message and show a notification badge (message is NOT for current view).
 */
_storeAndNotify(chatMsg, targetKey, fromNodeId) {
    // Store in IndexedDB (async, fire-and-forget with error logging)
    this.storeMessageForTarget(chatMsg);

    // Increment unread count
    this._unreadCounts[targetKey] = (this._unreadCounts[targetKey] || 0) + 1;

    // Track node with unread messages (for DMs)
    if (targetKey.startsWith('messages_node_') && fromNodeId) {
        this._nodesWithUnread.add(fromNodeId);
    }

    // Update badges on channels and nodes
    this._updateNotificationBadges();

    // Re-sort nodes if a DM arrived — use in-memory list to avoid stale IndexedDB overwrite
    if (targetKey.startsWith('messages_node_') && this._allNodes && this._allNodes.length > 0) {
        this.updateNodesList(this._allNodes);
    }
},

/**
 * Update notification badges on channel and node elements.
 */
_updateNotificationBadges() {
    // Update channel badges
    document.querySelectorAll('.channel-item').forEach(el => {
        const channelIdx = el.dataset.channelIndex;
        if (channelIdx === undefined) return;
        const key = `messages_channel_${channelIdx}`;
        const count = this._unreadCounts[key] || 0;

        // Remove existing badge
        let badge = el.querySelector('.unread-badge');
        if (count > 0) {
            if (!badge) {
                badge = document.createElement('span');
                badge.className = 'unread-badge';
                el.appendChild(badge);
            }
            badge.textContent = count > 99 ? '99+' : count;
        } else if (badge) {
            badge.remove();
        }
    });

    // Update node badges
    document.querySelectorAll('.node-item').forEach(el => {
        const detailsEl = el.querySelector('.node-details');
        if (!detailsEl) return;

        // Extract node ID from details text (e.g., "<uCon@!3d8309d0>")
        const detailsText = detailsEl.textContent || '';
        const idMatch = detailsText.match(/(![0-9a-f]{8})/i);
        if (!idMatch) return;

        const nodeId = idMatch[1];
        const key = `messages_node_${nodeId}`;
        const count = this._unreadCounts[key] || 0;

        // Remove existing badge
        let badge = el.querySelector('.unread-badge');
        if (count > 0) {
            if (!badge) {
                badge = document.createElement('span');
                badge.className = 'unread-badge';
                el.appendChild(badge);
            }
            badge.textContent = count > 99 ? '99+' : count;
        } else if (badge) {
            badge.remove();
        }
    });
},

// Handle node update from WebSocket

/**
 * Check if a message comes from a node not in our current node list.
 * If so, trigger a node list refresh from the server so the new/returning
 * node appears automatically without needing a manual "Refresh Nodes" click.
 * Debounced to avoid excessive API calls when many messages arrive at once.
 */
_checkForUnknownNode(messageData) {
    const fromNode = messageData.from_node || messageData.from;
    if (!fromNode || !this.storage) return;

    const nodes = this.storage.getNodes();
    const known = nodes.some(n => (n.id || n.num) === fromNode);
    if (known) return;

    // Unknown node detected - debounce the refresh (max once per 10 seconds)
    const now = Date.now();
    if (this._lastNodeRefreshTime && (now - this._lastNodeRefreshTime) < 10000) return;
    this._lastNodeRefreshTime = now;

    _MSG_DEBUG && console.log(`Unknown node detected: ${fromNode} - auto-refreshing node list`);
    this.loadNodes();
},

/**
 * Add (*) to document.title when a new message arrives (if tab is not focused).
 * The marker is cleared when the tab regains focus (see app_core.js).
 */
_notifyNewMessageInTitle() {
    if (document.hidden || !document.hasFocus()) {
        if (!document.title.startsWith('(*)')) {
            document.title = '(*) ' + document.title;
        }
    }
},

/**
 * Delete a single message from IndexedDB and remove its DOM element.
 * @param {HTMLElement} messageElement - The .message DOM element
 */
_deleteMessage(messageElement) {
    if (!this.storage) return;

    // Get the _dbId stored on the element's dataset
    const dbId = messageElement ? Number(messageElement.dataset.dbId) : NaN;
    if (dbId && !isNaN(dbId)) {
        this.storage.deleteMessageAsync(dbId).catch(e => {
            console.error('Error deleting message:', e);
        });
    }

    if (messageElement) {
        messageElement.remove();
    }
}

});
