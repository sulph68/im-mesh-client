/**
 * telegram_ui.js — Telegram forwarding modal management (v102)
 *
 * v102: host-gating — button hidden/disabled via checkApplicable() matching telegram.host
 * v101: list number included in <strong> tag
 * Opens via "Telegram Forwarder" button in Actions panel.
 * - Button always visible; disabled+tooltip when telegram is not enabled.
 * - Channel/Node radio + dropdown replaces free-text conv key.
 * - Regex pattern helpers: whole word, start (^), end ($) — same as AR.
 * - Edit button uses safe event delegation (no inline JSON.stringify).
 * - Backdrop close disabled via data-no-backdrop-close on the modal element.
 * - Label field for naming rules.
 * - Modal node picker for include/exclude nodes.
 * - Test message input.
 * - New rules default to current channel/node selection.
 */

(function () {
    'use strict';

    const modal = document.getElementById('telegramModal');
    const statusDiv = document.getElementById('telegramStatus');
    const convList = document.getElementById('telegramConvList');
    const convForm = document.getElementById('telegramConvForm');

    // Cached conversation array — used by Edit buttons via data-edit-idx
    let _convCache = [];

    // Cached node list for node picker
    let _nodeList = [];

    // Node picker state
    let _includeNodes = [];
    let _excludeNodes = [];
    let _pickerTarget = null;

    // ---- Modal open/close ----

    function openModal() {
        modal.style.display = 'flex';
        loadStatus();
        loadConversations();
        _populateDropdowns();
    }

    function closeModal() {
        modal.style.display = 'none';
        hideForm();
    }

    // ---- Status ----

    async function loadStatus() {
        try {
            const r = await fetch('/api/telegram/status');
            if (!r.ok) { statusDiv.textContent = 'Status unavailable'; return; }
            const d = await r.json();
            const enabled = d.data && d.data.enabled;
            const configured = d.data && d.data.bot_token_configured;
            if (!enabled) {
                statusDiv.textContent = '⚠️ Telegram forwarding is disabled — set "enabled": true in settings.json';
                statusDiv.style.color = 'var(--text-muted)';
            } else if (!configured) {
                statusDiv.textContent = '⚠️ No bot_token set in settings.json — forwarding disabled';
                statusDiv.style.color = 'var(--error-color, orange)';
            } else {
                statusDiv.textContent = '✅ Bot token configured and forwarding enabled';
                statusDiv.style.color = 'var(--success-color, green)';
            }
        } catch (_) {}
    }

    // ---- Conversation list ----

    async function loadConversations() {
        try {
            const r = await fetch('/api/telegram/conversations');
            if (!r.ok) return;
            const d = await r.json();
            _convCache = (d.data && d.data.conversations) || [];
            renderConversations(_convCache);
        } catch (_) {}
    }

    function _escHtml(s) {
        return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
    }

    function renderConversations(convs) {
        if (convs.length === 0) {
            convList.innerHTML = '<p style="color:var(--text-muted); font-size:0.9em;">No Telegram conversation configs. Click + Add Forwarding Rule.</p>';
            return;
        }
        convList.innerHTML = convs.map((c, i) => {
            const label = c.label ? _escHtml(c.label) : _escHtml(c.conversation_key);
            const disabledBadge = c.enabled ? '' : ' <span style="color:var(--text-muted); font-size:0.82em;">[disabled]</span>';
            return `
            <div style="display:flex; align-items:center; gap:40px; padding:5px 4px;">
                <span style="flex:1; font-size:0.9em;"><strong>${i + 1}) ${label}</strong>${disabledBadge}</span>
                <button class="btn btn-small btn-outline" data-edit-idx="${i}">Edit</button>
            </div>`;
        }).join('');
        convList.querySelectorAll('[data-edit-idx]').forEach(btn => {
            btn.addEventListener('click', () => editConv(_convCache[parseInt(btn.dataset.editIdx, 10)]));
        });
    }

    // ---- Dropdown population ----

    async function _populateDropdowns() {
        await Promise.all([_populateChannelDropdown(), _populateNodeDropdown()]);
    }

    async function _populateChannelDropdown() {
        const sel = document.getElementById('tgChannelSelect');
        if (!sel) return;
        try {
            const r = await fetch('/api/channels');
            if (!r.ok) return;
            const d = await r.json();
            const channels = (d.data && d.data.channels) || [];
            sel.innerHTML = channels.length === 0
                ? '<option value="">No channels found</option>'
                : channels.map(ch => {
                    const name = ch.name || `Channel ${ch.index}`;
                    const label = `Ch ${ch.index}: ${name}`;
                    const val = `ch${ch.index}_${name}`;
                    return `<option value="${_escHtml(val)}" data-ch-index="${ch.index}">${_escHtml(label)}</option>`;
                }).join('');
        } catch (_) {}
    }

    async function _populateNodeDropdown() {
        const sel = document.getElementById('tgNodeSelect');
        if (!sel) return;
        try {
            const r = await fetch('/api/nodes');
            if (!r.ok) return;
            const d = await r.json();
            const nodes = (d.data && d.data.nodes) || [];
            _nodeList = nodes;
            sel.innerHTML = nodes.length === 0
                ? '<option value="">No nodes found</option>'
                : nodes.map(n => {
                    const id = n.id || n.num || '';
                    const longN = n.long_name || n.longName || '';
                    const shortN = n.short_name || n.shortName || '';
                    const label = longN ? `${longN} <${shortN}@${id}>` : id;
                    return `<option value="${_escHtml(id)}">${_escHtml(label)}</option>`;
                }).join('');
        } catch (_) {}
    }

    function _updateTypeVisibility() {
        const isChannel = document.getElementById('tgConvTypeChannel').checked;
        const isOwnNode = document.getElementById('tgConvTypeOwnNode') && document.getElementById('tgConvTypeOwnNode').checked;
        document.getElementById('tgChannelSelectRow').style.display = isChannel ? '' : 'none';
        document.getElementById('tgNodeSelectRow').style.display = (!isChannel && !isOwnNode) ? '' : 'none';
        const includeSection = document.getElementById('tgIncludeSection');
        const excludeSection = document.getElementById('tgExcludeSection');
        if (includeSection) includeSection.style.display = (isChannel && !isOwnNode) ? '' : 'none';
        if (excludeSection) excludeSection.style.display = (isChannel && !isOwnNode) ? '' : 'none';
        const ownWarning = document.getElementById('tgOwnNodeWarning');
        if (ownWarning) ownWarning.style.display = isOwnNode ? '' : 'none';
    }

    // ---- Form show/hide ----

    function showForm(conv) {
        const c = conv || {};
        const existingKey = c.conversation_key || '';
        const isOwnNode = existingKey === '__own_node__';
        const isChannel = !isOwnNode && (!existingKey || existingKey.startsWith('ch'));

        document.getElementById('tgLabel').value = c.label || '';
        document.getElementById('tgConvTypeChannel').checked = isChannel;
        document.getElementById('tgConvTypeNode').checked = !isChannel && !isOwnNode;
        if (document.getElementById('tgConvTypeOwnNode')) {
            document.getElementById('tgConvTypeOwnNode').checked = isOwnNode;
        }
        _updateTypeVisibility();

        // Show conversation key display when editing
        const keyDisplay = document.getElementById('tgConvKeyDisplay');
        if (keyDisplay && existingKey) {
            keyDisplay.innerHTML = `Config: <code>${_escHtml(existingKey)}</code>`;
            keyDisplay.style.display = '';
        } else if (keyDisplay) {
            keyDisplay.style.display = 'none';
        }

        if (existingKey) {
            if (isChannel) {
                const sel = document.getElementById('tgChannelSelect');
                if (sel) {
                    for (const opt of sel.options) {
                        if (opt.value === existingKey) { sel.value = existingKey; break; }
                    }
                }
            } else {
                const sel = document.getElementById('tgNodeSelect');
                if (sel) sel.value = existingKey;
            }
        } else {
            // Default to current selection from main UI
            const mc = meshtasticClient;
            if (mc && mc.selectedNodeId) {
                document.getElementById('tgConvTypeNode').checked = true;
                document.getElementById('tgConvTypeChannel').checked = false;
                _updateTypeVisibility();
                const sel = document.getElementById('tgNodeSelect');
                if (sel) sel.value = mc.selectedNodeId;
            } else if (mc && mc.selectedChannelIndex !== undefined && mc.selectedChannelIndex !== null) {
                const sel = document.getElementById('tgChannelSelect');
                if (sel) {
                    for (const opt of sel.options) {
                        if (parseInt(opt.dataset.chIndex, 10) === mc.selectedChannelIndex) {
                            sel.value = opt.value;
                            break;
                        }
                    }
                }
            }
        }

        document.getElementById('tgConvKey').value = existingKey;
        document.getElementById('tgChatId').value = c.chat_id || '';
        document.getElementById('tgConvEnabled').checked = c.enabled !== false;
        document.getElementById('tgDirection').value = c.direction || 'all';
        document.getElementById('tgFilterType').value = c.filter_type || 'all';
        document.getElementById('tgFilterRegex').value = c.filter_regex || '';
        _updateFilterVisibility();
        _syncRegexHelpers(c.filter_regex || '');

        // Populate node picker state and set section checkboxes
        _includeNodes = (c.include_nodes || []).map(String);
        _excludeNodes = (c.exclude_nodes || []).map(String);
        const incCb = document.getElementById('tgIncludeEnabled');
        const excCb = document.getElementById('tgExcludeEnabled');
        if (incCb) incCb.checked = _includeNodes.length > 0;
        if (excCb) excCb.checked = _excludeNodes.length > 0;
        _updateNodeSummary('include');
        _updateNodeSummary('exclude');

        // Clear test message and status
        const tmEl = document.getElementById('tgTestMessage');
        if (tmEl) tmEl.value = '';
        const tsEl = document.getElementById('tgTestStatus');
        if (tsEl) { tsEl.textContent = ''; tsEl.style.color = ''; }

        // Show Delete button only when editing an existing config
        const delBtn = document.getElementById('deleteTelegramConv');
        if (delBtn) delBtn.style.display = existingKey ? '' : 'none';

        convForm.style.display = 'block';
    }

    function hideForm() {
        convForm.style.display = 'none';
    }

    function _updateFilterVisibility() {
        const ft = document.getElementById('tgFilterType').value;
        const regexRow = document.getElementById('tgFilterRegexRow');
        if (regexRow) regexRow.style.display = ft === 'regex' ? '' : 'none';
    }

    // ---- Node picker helpers ----

    function _nodeLabel(n) {
        const id = n.id || n.num || '';
        const longN = n.long_name || n.longName || '';
        const shortN = n.short_name || n.shortName || '';
        if (longN && shortN && id) return `${longN} <${shortN}@${id}>`;
        if (longN && id) return `${longN} <${id}>`;
        return id;
    }

    function _openNodePicker(target) {
        _pickerTarget = target;
        const modal = document.getElementById('tgNodePickerModal');
        if (!modal) return;
        const listDiv = document.getElementById('tgNodePickerList');
        const title = document.getElementById('tgNodePickerTitle');
        const currentIds = new Set((target === 'include' ? _includeNodes : _excludeNodes).map(s => String(s).toLowerCase()));

        title.textContent = target === 'include' ? 'Include Nodes — Forward only from these' : 'Exclude Nodes — Skip forwarding from these';
        listDiv.innerHTML = '';

        if (_nodeList.length === 0) {
            listDiv.innerHTML = '<p style="color:var(--text-muted); font-size:0.9em;">No nodes available.</p>';
        } else {
            for (const n of _nodeList) {
                const id = String(n.id || n.num || '');
                if (!id) continue;
                const label = _nodeLabel(n);
                const row = document.createElement('label');
                row.style.cssText = 'display:flex; align-items:center; gap:8px; padding:5px 4px; cursor:pointer; border-radius:4px;';
                const cb = document.createElement('input');
                cb.type = 'checkbox';
                cb.value = id;
                cb.checked = currentIds.has(id.toLowerCase());
                row.appendChild(cb);
                row.appendChild(document.createTextNode(label));
                listDiv.appendChild(row);
            }
        }

        modal.style.display = 'flex';
    }

    function _closeNodePicker(accept) {
        const modal = document.getElementById('tgNodePickerModal');
        if (modal) modal.style.display = 'none';

        if (accept) {
            const listDiv = document.getElementById('tgNodePickerList');
            const checked = listDiv
                ? Array.from(listDiv.querySelectorAll('input[type=checkbox]:checked')).map(cb => cb.value)
                : [];
            if (_pickerTarget === 'include') {
                _includeNodes = checked;
                const cbEl = document.getElementById('tgIncludeEnabled');
                if (cbEl) cbEl.checked = checked.length > 0;
            } else if (_pickerTarget === 'exclude') {
                _excludeNodes = checked;
                const cbEl = document.getElementById('tgExcludeEnabled');
                if (cbEl) cbEl.checked = checked.length > 0;
            }
        } else {
            if (_pickerTarget === 'include' && _includeNodes.length === 0) {
                const cbEl = document.getElementById('tgIncludeEnabled');
                if (cbEl) cbEl.checked = false;
            } else if (_pickerTarget === 'exclude' && _excludeNodes.length === 0) {
                const cbEl = document.getElementById('tgExcludeEnabled');
                if (cbEl) cbEl.checked = false;
            }
        }

        _updateNodeSummary('include');
        _updateNodeSummary('exclude');
        _pickerTarget = null;
    }

    function _updateNodeSummary(type) {
        const ids = type === 'include' ? _includeNodes : _excludeNodes;
        const sumDiv = document.getElementById(type === 'include' ? 'tgIncludeSummary' : 'tgExcludeSummary');
        const countEl = document.getElementById(type === 'include' ? 'tgIncludeCount' : 'tgExcludeCount');
        if (!sumDiv || !countEl) return;
        if (ids.length > 0) {
            const labels = ids.map(id => {
                const n = _nodeList.find(x => String(x.id || x.num || '').toLowerCase() === String(id).toLowerCase());
                return n ? _nodeLabel(n) : id;
            });
            countEl.textContent = `${ids.length} node(s): ${labels.join(', ')}`;
            sumDiv.style.display = '';
        } else {
            sumDiv.style.display = 'none';
        }
    }

    // ---- Regex helpers ----

    function _syncRegexHelpers(pattern) {
        const wb = document.getElementById('tgRegexWholeWord');
        const sa = document.getElementById('tgRegexStartAnchor');
        const ea = document.getElementById('tgRegexEndAnchor');
        if (!wb) return;
        wb.checked = /^\\b.*\\b$/.test(pattern);
        sa.checked = !wb.checked && pattern.startsWith('^');
        ea.checked = !wb.checked && pattern.endsWith('$');
    }

    function _applyRegexHelpers() {
        const patEl = document.getElementById('tgFilterRegex');
        if (!patEl) return;
        let p = patEl.value;
        p = p.replace(/^\^/, '').replace(/\$$/, '');
        p = p.replace(/^\\b/, '').replace(/\\b$/, '');
        const wb = document.getElementById('tgRegexWholeWord');
        const sa = document.getElementById('tgRegexStartAnchor');
        const ea = document.getElementById('tgRegexEndAnchor');
        if (wb && wb.checked) {
            p = '\\b' + p + '\\b';
        } else {
            if (sa && sa.checked) p = '^' + p;
            if (ea && ea.checked) p = p + '$';
        }
        patEl.value = p;
        const res = document.getElementById('tgFilterRegexResult');
        if (res) { res.textContent = ''; res.style.cssText = ''; }
    }

    function testRegex() {
        let pattern = document.getElementById('tgFilterRegex').value.trim();
        const testInput = document.getElementById('tgFilterRegexTest');
        const result = document.getElementById('tgFilterRegexResult');
        // Apply current helper flags to pattern for testing
        let p = pattern;
        p = p.replace(/^\^/, '').replace(/\$$/, '').replace(/^\\b/, '').replace(/\\b$/, '');
        const wb = document.getElementById('tgRegexWholeWord');
        const sa = document.getElementById('tgRegexStartAnchor');
        const ea = document.getElementById('tgRegexEndAnchor');
        if (wb && wb.checked) p = '\\b' + p + '\\b';
        else {
            if (sa && sa.checked) p = '^' + p;
            if (ea && ea.checked) p = p + '$';
        }
        if (!p) { result.textContent = 'Enter a regex pattern first'; result.style.color = 'var(--text-muted)'; return; }
        const testStr = testInput ? testInput.value : '';
        try {
            const re = new RegExp(p, 'i');
            const matched = re.test(testStr);
            result.textContent = testStr ? (matched ? '✅ Match' : '❌ No match') : 'Enter a test string above';
            result.style.color = matched ? 'var(--success-color, green)' : 'var(--error-color, orange)';
        } catch (e) {
            result.textContent = '⚠️ Invalid regex: ' + e.message;
            result.style.color = 'var(--error-color, orange)';
        }
    }

    // ---- Save / Delete / Test ----

    async function saveConv() {
        const isChannel = document.getElementById('tgConvTypeChannel').checked;
        const isOwnNode = document.getElementById('tgConvTypeOwnNode') && document.getElementById('tgConvTypeOwnNode').checked;
        let key;
        if (isOwnNode) {
            key = '__own_node__';
        } else if (isChannel) {
            const sel = document.getElementById('tgChannelSelect');
            key = sel ? sel.value : '';
        } else {
            const sel = document.getElementById('tgNodeSelect');
            key = sel ? sel.value : '';
        }
        if (!key) { alert('Please select a channel or node'); return; }

        _applyRegexHelpers();

        const label = document.getElementById('tgLabel').value.trim();
        const chatId = document.getElementById('tgChatId').value.trim();
        const enabled = document.getElementById('tgConvEnabled').checked;
        const direction = document.getElementById('tgDirection').value;
        const filterType = document.getElementById('tgFilterType').value;
        const filterRegex = document.getElementById('tgFilterRegex').value.trim();
        const tsEl = document.getElementById('tgTestStatus');
        function _setSaveStatus(msg, ok) {
            if (!tsEl) return;
            tsEl.textContent = msg;
            tsEl.style.color = ok ? 'var(--success-color, green)' : 'var(--error-color, red)';
        }
        if (!chatId) { _setSaveStatus('⚠️ Telegram Chat ID is required', false); return; }

        const incCb = document.getElementById('tgIncludeEnabled');
        const excCb = document.getElementById('tgExcludeEnabled');
        const includeNodes = (incCb && incCb.checked) ? _includeNodes : [];
        const excludeNodes = (excCb && excCb.checked) ? _excludeNodes : [];

        const body = { conversation_key: key, label, chat_id: chatId, enabled, direction, filter_type: filterType, filter_regex: filterRegex, include_nodes: includeNodes, exclude_nodes: excludeNodes };
        try {
            const r = await fetch('/api/telegram/conversations', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(body),
            });
            if (!r.ok) { _setSaveStatus('❌ Failed to save conversation', false); return; }
            hideForm();
            loadConversations();
        } catch (e) {
            _setSaveStatus('❌ Error: ' + e.message, false);
        }
    }

    async function testConv() {
        const chatId = document.getElementById('tgChatId').value.trim();
        const tsEl = document.getElementById('tgTestStatus');
        function _setStatus(msg, ok) {
            if (!tsEl) return;
            tsEl.textContent = msg;
            tsEl.style.color = ok ? 'var(--success-color, green)' : 'var(--error-color, red)';
        }
        if (!chatId) { _setStatus('⚠️ Enter a Chat ID first', false); return; }
        const msgEl = document.getElementById('tgTestMessage');
        const message = msgEl ? msgEl.value.trim() : '';
        try {
            _setStatus('Sending…', true);
            const r = await fetch('/api/telegram/test', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ chat_id: chatId, message }),
            });
            const d = await r.json();
            if (r.ok && d.success) {
                _setStatus('✅ Test message sent successfully!', true);
            } else {
                _setStatus('❌ Test failed: ' + (d.detail || d.message || 'Unknown error'), false);
            }
        } catch (e) {
            _setStatus('❌ Error: ' + e.message, false);
        }
    }

    async function deleteConv(key) {
        if (!confirm('Delete Telegram config for ' + key + '?')) return;
        try {
            const r = await fetch(`/api/telegram/conversations/${encodeURIComponent(key)}`, { method: 'DELETE' });
            if (!r.ok) {
                const tsEl = document.getElementById('tgTestStatus');
                if (tsEl) { tsEl.textContent = '❌ Failed to delete'; tsEl.style.color = 'var(--error-color, red)'; }
                return;
            }
            hideForm();
            loadConversations();
        } catch (e) {
            const tsEl = document.getElementById('tgTestStatus');
            if (tsEl) { tsEl.textContent = '❌ Error: ' + e.message; tsEl.style.color = 'var(--error-color, red)'; }
        }
    }

    function editConv(conv) {
        showForm(conv);
    }

    // ---- Wire buttons ----

    document.getElementById('closeTelegramModal').addEventListener('click', closeModal);
    document.getElementById('addTelegramConvBtn').addEventListener('click', () => {
        _populateDropdowns().then(() => showForm(null));
    });
    document.getElementById('saveTelegramConv').addEventListener('click', saveConv);
    document.getElementById('cancelTelegramConv').addEventListener('click', hideForm);
    document.getElementById('testTelegramConv').addEventListener('click', testConv);
    const delFormBtn = document.getElementById('deleteTelegramConv');
    if (delFormBtn) delFormBtn.addEventListener('click', () => {
        const key = document.getElementById('tgConvKey').value;
        if (key) deleteConv(key);
    });

    const filterTypeEl = document.getElementById('tgFilterType');
    if (filterTypeEl) filterTypeEl.addEventListener('change', _updateFilterVisibility);

    // Type radio buttons toggle channel/node visibility
    document.querySelectorAll('input[name="tgConvType"]').forEach(r => {
        r.addEventListener('change', _updateTypeVisibility);
    });

    // Regex helper checkboxes modify pattern live
    ['tgRegexWholeWord', 'tgRegexStartAnchor', 'tgRegexEndAnchor'].forEach(id => {
        const el = document.getElementById(id);
        if (el) el.addEventListener('change', _applyRegexHelpers);
    });

    // ---- Actions panel button ----
    const openBtn = document.getElementById('openTelegramBtn');
    if (openBtn) {
        openBtn.addEventListener('click', () => {
            if (!openBtn.disabled) openModal();
        });
    }

    // On load: fetch version to populate settings badge
    fetch('/api/version').then(r => r.json()).then(d => {
        if (d.data) {
            const badge = document.getElementById('settingsVersionBadge');
            if (badge) {
                const ch = d.data.channel ? ` (${d.data.channel})` : '';
                badge.textContent = `v${d.data.version}${ch}`;
            }
        }
    }).catch(() => {});

    // ---- checkApplicable — hide/disable button based on host match ----
    async function checkApplicable() {
        if (!openBtn) return;
        try {
            const r = await fetch('/api/telegram/global');
            if (!r.ok) return;
            const d = await r.json();
            if (d.data && d.data.applicable === false) {
                openBtn.style.display = 'none';
                openBtn.disabled = false;
            } else {
                openBtn.style.display = '';
                const settingsEnabled = !!(d.data && d.data.settings_enabled);
                openBtn.disabled = !settingsEnabled;
                openBtn.title = settingsEnabled
                    ? 'Telegram Forwarder'
                    : 'Telegram Forwarder (disabled in settings.json)';
            }
        } catch (_) {}
    }
    window.checkTelegramApplicable = checkApplicable;
    setTimeout(checkApplicable, 1500);

    // Wire include/exclude checkbox toggles and picker buttons
    const incCbEl = document.getElementById('tgIncludeEnabled');
    const excCbEl = document.getElementById('tgExcludeEnabled');
    if (incCbEl) incCbEl.addEventListener('change', () => {
        if (incCbEl.checked) { _populateNodeDropdown().then(() => _openNodePicker('include')); }
        else { _includeNodes = []; _updateNodeSummary('include'); }
    });
    if (excCbEl) excCbEl.addEventListener('change', () => {
        if (excCbEl.checked) { _populateNodeDropdown().then(() => _openNodePicker('exclude')); }
        else { _excludeNodes = []; _updateNodeSummary('exclude'); }
    });

    document.getElementById('closeTgNodePicker')?.addEventListener('click', () => _closeNodePicker(false));
    document.getElementById('cancelTgNodePicker')?.addEventListener('click', () => _closeNodePicker(false));
    document.getElementById('acceptTgNodePicker')?.addEventListener('click', () => _closeNodePicker(true));

    document.getElementById('tgIncludeEditBtn')?.addEventListener('click', () => { _populateNodeDropdown().then(() => _openNodePicker('include')); });
    document.getElementById('tgExcludeEditBtn')?.addEventListener('click', () => { _populateNodeDropdown().then(() => _openNodePicker('exclude')); });

    window.telegramUI = { openModal, closeModal, editConv, deleteConv, testRegex, openNodePicker: _openNodePicker };
})();
