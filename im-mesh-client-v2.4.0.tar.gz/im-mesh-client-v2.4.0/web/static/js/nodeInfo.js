// nodeInfo.js — Phase 1-B: Node Info Panel
// Fetches GET /api/node/self and populates #nodeInfoContainer fields.

(function () {
    'use strict';

    const REFRESH_INTERVAL_MS = 900000; // 15 minutes — node data changes rarely
    const RETRY_WHEN_DISCONNECTED_MS = 5000; // retry quickly when device not yet connected
    const SESSION_POLL_MS     = 2000;   // retry interval when session not ready yet

    let _timer = null;

    // ---- helpers ----

    function commLog(direction, msg, type) {
        try {
            var c = window.meshtasticClient;
            if (c && typeof c.logCommunication === 'function') {
                c.logCommunication(direction, '[NodeInfo] ' + msg, type || 'info');
            }
        } catch (_) {}
        console.debug('[NodeInfo]', direction, msg);
    }

    function setText(id, value) {
        var el = document.getElementById(id);
        if (el) el.textContent = (value !== null && value !== undefined && value !== '') ? value : '—';
    }

    // ---- main polling tick ----

    async function tick(force) {
        _timer = null;

        var core = window.meshtasticClient;
        var sessionId = core && core.sessionId;

        if (!sessionId) {
            commLog('INFO', 'Waiting for session…', 'info');
            _timer = setTimeout(tick, SESSION_POLL_MS);
            return;
        }

        try {
            var url = '/api/node/self' + (force ? '?force=true' : '');
            commLog('OUT', 'GET ' + url + ' (session=' + sessionId.substring(0, 8) + '…)', 'info');

            var response = await fetch(url, {
                headers: { 'X-Session-ID': sessionId }
            });

            commLog('IN', 'HTTP ' + response.status + ' from /api/node/self', response.ok ? 'info' : 'error');

            if (!response.ok) {
                // HTTP error — retry quickly in case device is still connecting
                _timer = setTimeout(tick, RETRY_WHEN_DISCONNECTED_MS);
                return;
            }

            var resp = await response.json();
            commLog('IN', 'Payload: ' + JSON.stringify(resp).substring(0, 200), 'info');

            // API wraps payload: { success, message, data: { node: { ... } } }
            var node = null;
            if (resp && resp.data && resp.data.node) {
                node = resp.data.node;
            } else if (resp && resp.data) {
                node = resp.data;
            } else {
                node = resp;
            }

            // If device is not yet connected to server, retry shortly rather than
            // waiting 15 minutes (common after a server restart).
            if (!node || node.connected === false) {
                commLog('INFO', 'Device not yet connected — retrying in 5s', 'warning');
                _timer = setTimeout(tick, RETRY_WHEN_DISCONNECTED_MS);
                return;
            }

            // If connected but node data not yet populated (device still initialising),
            // retry shortly so we don't lock in all-dash values for 15 minutes.
            var hasData = node.node_id && node.node_id !== 'unknown'
                          && node.long_name && node.long_name !== 'unknown';
            if (!hasData) {
                commLog('INFO', 'Connected but node data not ready — retrying in 5s', 'warning');
                _timer = setTimeout(tick, RETRY_WHEN_DISCONNECTED_MS);
                return;
            }

            commLog('INFO',
                'node_id=' + node.node_id + ' long_name=' + node.long_name +
                ' short_name=' + node.short_name + ' hw_model=' + node.hw_model,
                'info');

            // ---- Basic info (always visible) ----
            setText('nodeLongName', node.long_name);
            setText('nodeShortName', node.short_name);

            var nodeNum = node.node_id;
            var nodeIdStr = '—';
            if (nodeNum && nodeNum !== 'unknown') {
                var n = typeof nodeNum === 'string' ? parseInt(nodeNum, 10) : nodeNum;
                if (!isNaN(n)) nodeIdStr = '!' + (n >>> 0).toString(16).padStart(8, '0');
                else nodeIdStr = String(nodeNum);
            }
            setText('nodeID', nodeIdStr);
            setText('nodeHardware', node.hw_model);

            // ---- Radio & Power ----
            var bat = (node.battery_level !== null && node.battery_level !== undefined)
                ? node.battery_level + '%' : null;
            setText('nodeBattery', bat);
            var volts = (node.voltage !== null && node.voltage !== undefined)
                ? Number(node.voltage).toFixed(2) + 'V' : null;
            setText('nodeVoltage', volts);
            var chUtil = (node.channel_utilization !== null && node.channel_utilization !== undefined)
                ? Number(node.channel_utilization).toFixed(1) + '%' : null;
            setText('nodeChannelUtil', chUtil);
            var airTx = (node.air_util_tx !== null && node.air_util_tx !== undefined)
                ? Number(node.air_util_tx).toFixed(1) + '%' : null;
            setText('nodeAirTxUtil', airTx);
            setText('nodeOnlineLocal', node.online_local_nodes);

            // ---- Position & Role ----
            // Map numeric NodeRole enum (0=CLIENT is the protobuf default and often
            // omitted from serialised dicts — Python side now falls back to localConfig)
            var NODE_ROLE_LABELS = {
                0: 'CLIENT', 1: 'CLIENT_MUTE', 2: 'ROUTER',
                3: 'ROUTER_CLIENT', 4: 'REPEATER', 5: 'TRACKER',
                6: 'SENSOR', 7: 'TAK', 8: 'CLIENT_HIDDEN',
                9: 'LOST_AND_FOUND', 10: 'TAK_TRACKER'
            };
            var roleVal = node.role;
            var roleLabel = (roleVal !== null && roleVal !== undefined)
                ? (NODE_ROLE_LABELS[roleVal] || String(roleVal))
                : null;
            setText('nodeRole', roleLabel);
            var lat = (node.latitude !== null && node.latitude !== undefined)
                ? Number(node.latitude).toFixed(6) : null;
            setText('nodeLatitude', lat);
            var lng = (node.longitude !== null && node.longitude !== undefined)
                ? Number(node.longitude).toFixed(6) : null;
            setText('nodeLongitude', lng);
            var alt = (node.altitude !== null && node.altitude !== undefined)
                ? node.altitude + 'm' : null;
            setText('nodeAltitude', alt);
            if (node.last_heard) {
                var d = new Date(node.last_heard * 1000);
                setText('nodeLastPosition', d.toLocaleString());
            } else {
                setText('nodeLastPosition', null);
            }

            commLog('INFO', 'Node info panel updated OK', 'success');

        } catch (err) {
            commLog('ERR', 'refreshNodeInfo error: ' + err, 'error');
        }

        _timer = setTimeout(tick, REFRESH_INTERVAL_MS);
    }

    // ---- init ----

    function init() {
        commLog('INFO', 'nodeInfo.js init', 'info');

        var btn = document.getElementById('nodeInfoRefreshBtn');
        if (btn) {
            btn.addEventListener('click', function () {
                if (_timer) { clearTimeout(_timer); _timer = null; }
                tick(true); // force=true: re-fetch from device, not just in-memory cache
            });
        }

        tick();
    }

    // Expose for external callers
    window.refreshNodeInfo = function () {
        if (_timer) { clearTimeout(_timer); _timer = null; }
        tick(true); // force=true: re-fetch from device, not just cache
    };

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
})();
