"""
telegram/telegram_forwarder.py — Telegram forwarding module.

Forwards Meshtastic messages/images to configured Telegram chats.
One-way only: Meshtastic → Telegram.

Requires:
  - settings.json: telegram.enabled = true and telegram.bot_token (non-empty)
  - telegram/{conversation_key}.json: per-conversation config

Config fields per conversation:
  conversation_key: str        — channel name or node ID, used to match incoming messages
  chat_id: str                 — Telegram chat ID to forward to
  enabled: bool                — whether this rule is active
  direction: str               — 'all' | 'sent' | 'received'
  filter_type: str             — 'all' | 'regex'
  filter_regex: str            — regex pattern (only used when filter_type='regex')
  include_nodes: list[str]     — whitelist of node IDs; empty = include all
  exclude_nodes: list[str]     — blacklist of node IDs
"""

import json
import logging
import os
import re
from typing import Optional

logger = logging.getLogger(__name__)


# --- Config CRUD ---

def _configs_dir(telegram_dir: str) -> str:
    """Return the configs subdirectory path inside the main working directory."""
    return os.path.join(telegram_dir, 'configs')


def _conv_key_to_filename(conv_key: str) -> str:
    """Strip leading '!' from a conversation key to produce a safe filename stem."""
    return conv_key.lstrip('!')


def _safe_conv_path(telegram_dir: str, conv_key: str) -> str:
    """Return safe path to per-conversation JSON; raise ValueError on traversal."""
    fname = _conv_key_to_filename(conv_key)
    if not fname or '/' in fname or '\\' in fname or '..' in fname:
        raise ValueError(f"Invalid conversation key: {conv_key!r}")
    configs = _configs_dir(telegram_dir)
    path = os.path.realpath(os.path.join(configs, f"{fname}.json"))
    if not path.startswith(os.path.realpath(configs)):
        raise ValueError(f"Path traversal attempt: {path}")
    return path


def load_conversation_config(telegram_dir: str, conv_key: str) -> Optional[dict]:
    """Load per-conversation config. Returns None if not found."""
    try:
        path = _safe_conv_path(telegram_dir, conv_key)
        with open(path) as f:
            return json.load(f)
    except (FileNotFoundError, ValueError, json.JSONDecodeError):
        return None


def save_conversation_config(telegram_dir: str, config: dict) -> None:
    """Save per-conversation config. config must have 'conversation_key'."""
    configs = _configs_dir(telegram_dir)
    os.makedirs(configs, exist_ok=True)
    conv_key = config.get('conversation_key')
    if not conv_key:
        raise ValueError("config must have 'conversation_key'")
    path = _safe_conv_path(telegram_dir, conv_key)
    with open(path, 'w') as f:
        json.dump(config, f, indent=2)


def delete_conversation_config(telegram_dir: str, conv_key: str) -> bool:
    """Delete per-conversation config. Returns True if deleted, False if not found."""
    try:
        path = _safe_conv_path(telegram_dir, conv_key)
        if os.path.exists(path):
            os.remove(path)
            return True
        return False
    except ValueError:
        return False


def list_conversation_configs(telegram_dir: str) -> list:
    """List all per-conversation config files in the configs/ subdirectory."""
    configs_path = _configs_dir(telegram_dir)
    os.makedirs(configs_path, exist_ok=True)
    # Migrate any legacy filenames that start with '!' (e.g. '!e2e53670.json' → 'e2e53670.json').
    # The JSON content's 'conversation_key' field retains the '!' prefix for matching logic.
    for fname in os.listdir(configs_path):
        if fname.startswith('!') and fname.endswith('.json'):
            old_path = os.path.join(configs_path, fname)
            new_path = os.path.join(configs_path, fname.lstrip('!'))
            if not os.path.exists(new_path):
                try:
                    os.rename(old_path, new_path)
                except OSError:
                    pass
    configs = []
    for fname in os.listdir(configs_path):
        if not fname.endswith('.json'):
            continue
        fpath = os.path.join(configs_path, fname)
        try:
            with open(fpath) as f:
                configs.append(json.load(f))
        except (json.JSONDecodeError, OSError):
            pass
    return configs


# --- Message matching helpers ---

def _norm_node(node_id) -> str:
    """Normalise a node ID to bare 8-char lowercase hex (no '!' prefix).

    Handles: None, empty string, '!hex', bare 'hex', and decimal integers.
    """
    if not node_id:
        return ''
    s = str(node_id).strip()
    if s.startswith('!'):
        return s[1:].lower()
    try:
        return f"{int(s):08x}"
    except ValueError:
        return s.lower()


def _node_allowed(node_id, include_nodes: list, exclude_nodes: list) -> bool:
    """Return True if node_id passes include/exclude filters."""
    norm = _norm_node(node_id)
    if not norm:
        return True
    exc_norms = {_norm_node(x) for x in exclude_nodes if x}
    inc_norms = {_norm_node(x) for x in include_nodes if x}
    if exc_norms and norm in exc_norms:
        return False
    if inc_norms and norm not in inc_norms:
        return False
    return True


def _message_passes_filter(text: str, filter_type: str, filter_regex: str) -> bool:
    """Return True if text passes the configured message filter."""
    if filter_type == 'regex' and filter_regex:
        try:
            return bool(re.search(filter_regex, text))
        except re.error:
            logger.warning("TelegramForwarder: invalid regex %r — skipping filter", filter_regex)
            return True
    return True


_BROADCAST_NODE_IDS = {'!ffffffff', 'ffffffff', '4294967295'}

def _format_node(long_name: Optional[str], short_name: Optional[str], node_id: Optional[str]) -> str:
    """Format a node reference as 'Long Name <Short@!NodeID>' consistent with app UI."""
    if node_id and (str(node_id).lower() in _BROADCAST_NODE_IDS or str(node_id) == '4294967295'):
        return "All"
    if long_name and short_name and node_id:
        return f"{long_name} <{short_name}@{node_id}>"
    if long_name and node_id:
        return f"{long_name} <{node_id}>"
    if node_id:
        return node_id
    return "Unknown"


# --- Forwarding Engine ---

class TelegramForwarder:
    def __init__(self, bot_token: str, telegram_dir: str, host: str = '127.0.0.1') -> None:
        self._bot_token = bot_token
        self._telegram_dir = telegram_dir
        self._host = host
        self._bot = None
        self._enabled = bool(bot_token)

    @staticmethod
    def _find_telegram_in_system() -> bool:
        """
        When the current Python can't find python-telegram-bot, scan common
        system site-packages directories (bypassing any active virtualenv) for
        the 'telegram' package and add the first found directory to sys.path.

        This filesystem scan approach is used instead of subprocess probing
        because subprocess inherits the active venv environment, which means
        'python3' in the subprocess would be the venv Python — the same one
        that already lacks the package.

        Returns True if a usable path was found and added.
        """
        import glob
        import sys

        logger.info("TelegramForwarder: searching system site-packages for python-telegram-bot...")

        # Build a list of candidate site-packages directories to scan.
        # Sort version-numbered paths in reverse so newer Python versions are preferred.
        scan_patterns = [
            '/usr/local/lib/python3*/dist-packages',
            '/usr/local/lib/python3*/site-packages',
            '/usr/lib/python3*/dist-packages',
            '/usr/lib/python3*/site-packages',
            '/usr/lib/python3/dist-packages',
            '/usr/local/lib/python3/dist-packages',
        ]
        # Also add ~/.local user installs
        home = os.path.expanduser('~')
        scan_patterns += [
            f'{home}/.local/lib/python3*/site-packages',
        ]

        candidates = []
        for pat in scan_patterns:
            matches = sorted(glob.glob(pat), reverse=True)
            for d in matches:
                if d not in candidates:
                    candidates.append(d)

        logger.info("TelegramForwarder: scanning %d candidate path(s): %s",
                    len(candidates), candidates)

        for site_pkg in candidates:
            telegram_init = os.path.join(site_pkg, 'telegram', '__init__.py')
            if os.path.isfile(telegram_init):
                logger.info(
                    "TelegramForwarder: found python-telegram-bot at %s", site_pkg
                )
                if site_pkg not in sys.path:
                    sys.path.insert(0, site_pkg)
                # Clear any cached failed import so the next attempt is fresh
                for key in list(sys.modules.keys()):
                    if key == 'telegram' or key.startswith('telegram.'):
                        del sys.modules[key]
                return True
            else:
                logger.debug(
                    "TelegramForwarder: telegram not found in %s", site_pkg
                )

        logger.error(
            "TelegramForwarder: python-telegram-bot not found in any of: %s",
            candidates
        )
        return False

    def _get_bot(self) -> Optional[object]:
        """Lazy-initialize Telegram bot, searching system site-packages if needed."""
        if not self._bot and self._enabled:
            import sys
            logger.info(
                "TelegramForwarder: initializing bot (Python %s, sys.prefix=%s)",
                sys.version.split()[0], sys.prefix
            )
            try:
                from telegram import Bot
                logger.info("TelegramForwarder: python-telegram-bot imported successfully")
                self._bot = Bot(token=self._bot_token)
            except ImportError as e:
                logger.warning(
                    "TelegramForwarder: ImportError on 'from telegram import Bot': %s — "
                    "attempting system-wide search", e
                )
                if self._find_telegram_in_system():
                    try:
                        from telegram import Bot
                        logger.info("TelegramForwarder: python-telegram-bot imported after path fix")
                        self._bot = Bot(token=self._bot_token)
                    except ImportError as e2:
                        logger.error(
                            "TelegramForwarder: still cannot import after path fix: %s", e2
                        )
                        self._enabled = False
                else:
                    self._enabled = False
        return self._bot

    async def forward_message(
        self,
        conv_key: str,
        text: str,
        direction: str = 'received',
        from_long: Optional[str] = None,
        from_short: Optional[str] = None,
        from_node_id: Optional[str] = None,
        to_long: Optional[str] = None,
        to_short: Optional[str] = None,
        to_node_id: Optional[str] = None,
        channel_name: Optional[str] = None,
    ) -> bool:
        """Forward a text message according to conversation config rules.

        Returns True if sent, False if filtered/disabled/error.
        """
        if not self._enabled:
            return False
        config = load_conversation_config(self._telegram_dir, conv_key)
        if not config or not config.get('enabled') or not config.get('chat_id'):
            return False

        # Direction filter
        cfg_direction = config.get('direction', 'all')
        if cfg_direction == 'sent' and direction != 'sent':
            return False
        if cfg_direction == 'received' and direction != 'received':
            return False

        # Node filter
        active_node_id = from_node_id if direction == 'received' else to_node_id
        include_nodes = config.get('include_nodes', [])
        exclude_nodes = config.get('exclude_nodes', [])
        if not _node_allowed(active_node_id, include_nodes, exclude_nodes):
            return False

        # Message filter
        filter_type = config.get('filter_type', 'all')
        filter_regex = config.get('filter_regex', '')
        if not _message_passes_filter(text, filter_type, filter_regex):
            return False

        bot = self._get_bot()
        if not bot:
            return False

        # Build formatted message per spec:
        # [channel or "DM"] Sender -> Receiver
        # <blockquote>message</blockquote>
        import html as _html
        context = _html.escape(channel_name) if channel_name else "DM"
        sender = _html.escape(_format_node(from_long, from_short, from_node_id))
        # Channel broadcast with no specific recipient → "All"
        if channel_name and not to_node_id:
            receiver = "All"
        else:
            receiver = _html.escape(_format_node(to_long, to_short, to_node_id))
        safe_text = _html.escape(text)
        tg_html = f"[{context}] {sender} -&gt; {receiver}\n<blockquote>{safe_text}</blockquote>"

        try:
            await bot.send_message(chat_id=config['chat_id'], text=tg_html, parse_mode='HTML')
            self._log(f"[{direction}] Forwarded to {conv_key}: {text[:60]}")
            logger.info(
                "TelegramForwarder: forwarded %s message to %s (chat_id=%s)",
                direction, conv_key, config['chat_id']
            )
            return True
        except Exception as e:
            logger.error("Telegram send error: %s", e)
            self._log(f"ERROR forwarding to {conv_key}: {e}")
            return False

    async def forward_text(self, conv_key: str, text: str, source_info: str = '') -> bool:
        """Legacy single-arg forward. Calls forward_message with minimal context."""
        return await self.forward_message(
            conv_key=conv_key,
            text=text,
            direction='received',
            channel_name=source_info or None,
        )

    async def forward_image(self, conv_key: str, image_data: bytes,
                            caption: str = '') -> bool:
        """Forward a binary image to the configured Telegram chat as a photo.

        Returns True if sent successfully, False otherwise.
        """
        if not self._enabled:
            return False
        config = load_conversation_config(self._telegram_dir, conv_key)
        if not config or not config.get('enabled') or not config.get('chat_id'):
            return False

        bot = self._get_bot()
        if not bot:
            return False

        try:
            await bot.send_photo(
                chat_id=config['chat_id'],
                photo=image_data,
                caption=caption or None,
            )
            self._log(f"Forwarded image to {conv_key} ({len(image_data)} bytes)")
            logger.info(
                "TelegramForwarder: forwarded image to %s (%d bytes)", conv_key, len(image_data)
            )
            return True
        except Exception as e:
            logger.error("Telegram image send error: %s", e)
            self._log(f"ERROR forwarding image to {conv_key}: {e}")
            return False

    def _log(self, message: str) -> None:
        """Append to telegram.log."""
        log_path = os.path.join(self._telegram_dir, 'telegram.log')
        from datetime import datetime
        ts = datetime.now().isoformat(timespec='seconds')
        try:
            with open(log_path, 'a', encoding='utf-8') as f:
                f.write(f"[{ts}] {message}\n")
        except OSError as e:
            logger.warning("Could not write telegram.log: %s", e)
