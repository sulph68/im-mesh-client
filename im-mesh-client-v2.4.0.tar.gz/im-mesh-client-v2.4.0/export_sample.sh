#!/usr/bin/env bash
# export_sample.sh — Sample node-list export calls for im-mesh-client v2.4.0
#
# Usage:  ./export_sample.sh <device-ip> [port]
#
# All requests use the ?host= query param so no session header is required.
# The default TCP bridge port is 4403 if not supplied.
# Uses -k to accept self-signed TLS certificates.

HOST="${1:?Usage: $0 <device-ip> [port]}"
PORT="${2:-4403}"
BASE="https://localhost:8082"

echo "=== 1. Full export (all fields) ==="
curl -sk "${BASE}/api/nodes/export?host=${HOST}&port=${PORT}" | python3 -m json.tool

echo ""
echo "=== 2. Include-only: id, name, snr, lastSeen ==="
curl -sk "${BASE}/api/nodes/export?host=${HOST}&port=${PORT}&include=id,name,snr,lastSeen" | python3 -m json.tool

echo ""
echo "=== 3. Exclude position and battery ==="
curl -sk "${BASE}/api/nodes/export?host=${HOST}&port=${PORT}&exclude=position,battery" | python3 -m json.tool

echo ""
echo "=== 4. Combined: include core fields, then exclude rssi ==="
curl -sk "${BASE}/api/nodes/export?host=${HOST}&port=${PORT}&include=id,name,snr,rssi,hopsAway,lastSeen&exclude=rssi" | python3 -m json.tool
