#!/bin/bash
#
# restore_settings.sh — Restore user-configurable files for Im Mesh Client
#
# Extracts a backup created by backup_settings.sh into the project directory.
# Restores any combination of:
#   settings.json                — main configuration
#   cert.pem / key.pem           — TLS certificates
#   auto_responder/              — AR conversation folders
#   sched_messages/              — scheduled message command files
#   telegram_forwarder/configs/  — Telegram Forwarder conversation configs
#
# Usage:
#   ./restore_settings.sh backup_20260418_120000.tar.gz     # Interactive (asks before overwriting)
#   ./restore_settings.sh backup_20260418_120000.tar.gz -y  # Overwrite all without prompting

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
BLUE='\033[0;34m'
NC='\033[0m'

ARCHIVE=""
FORCE=false

# Parse arguments
for arg in "$@"; do
    case "$arg" in
        -y|--yes) FORCE=true ;;
        *)        ARCHIVE="$arg" ;;
    esac
done

if [ -z "$ARCHIVE" ]; then
    echo -e "${RED}Usage: $0 <backup_file.tar.gz> [-y]${NC}"
    echo ""
    echo "  -y   Overwrite existing files without prompting"
    echo ""
    echo "Available backups in current directory:"
    ls backup_*.tar.gz 2>/dev/null | sed 's/^/  /' || echo "  (none found)"
    exit 1
fi

if [ ! -f "$ARCHIVE" ]; then
    echo -e "${RED}Error: Backup file not found: $ARCHIVE${NC}"
    exit 1
fi

echo -e "${GREEN}Im Mesh Client — Restore${NC}"
echo "==============================="
echo "Backup file: $ARCHIVE"
echo ""

# Show contents of the archive
echo "Contents:"
tar -tzf "$ARCHIVE" | head -30 | sed 's/^/  /'
TOTAL=$(tar -tzf "$ARCHIVE" | wc -l)
[ "$TOTAL" -gt 30 ] && echo "  ... ($TOTAL items total)"
echo ""

# Confirm unless -y flag given
if [ "$FORCE" = false ]; then
    read -rp "Restore these files to $SCRIPT_DIR? This may overwrite existing files. [y/N] " confirm
    case "$confirm" in
        [yY]|[yY][eE][sS]) ;;
        *)
            echo -e "${YELLOW}Restore cancelled.${NC}"
            exit 0
            ;;
    esac
fi

# Extract
echo "Restoring..."
tar -xzf "$ARCHIVE" -C "$SCRIPT_DIR"

echo ""
echo -e "${GREEN}✓ Restore complete.${NC}"
echo ""
echo -e "${BLUE}Note: Restart the server to apply restored settings.${NC}"
echo "  ./stop_server.sh && ./start_server.sh"
