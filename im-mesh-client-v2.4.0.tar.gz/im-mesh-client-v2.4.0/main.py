#!/usr/bin/env python3
"""
Im Mesh Client - Multi-Tenant Main Entry Point

Updated main.py to use the simplified startup approach.
Supports HTTPS with self-signed certificates.
Supports both TCP and Serial connections to Meshtastic nodes.
"""

import logging
import signal
import sys
from contextlib import asynccontextmanager
from pathlib import Path

# Add project root to path for imports
sys.path.insert(0, str(Path(__file__).parent))

from config.settings import Settings, setup_logging, generate_self_signed_cert, resolve_ssl_paths
from core.session_manager import SessionManager
from api.rest_api_multitenant import create_rest_api, _load_raw_settings
from api.websocket_api_multitenant import WebSocketAPI
from core.scheduler import Scheduler
from core.auto_responder import AutoResponder
from core.path_utils import resolve_project_path

def main():
    """Main application entry point."""
    
    # Setup logging
    setup_logging()
    logger = logging.getLogger(__name__)
    
    try:
        # Load configuration
        settings = Settings.load()
        
        # Resolve SSL paths relative to this script's directory
        script_dir = str(Path(__file__).parent)
        certfile, keyfile = resolve_ssl_paths(settings, base_dir=script_dir)
        
        # Generate self-signed certificate if SSL enabled and certs missing
        ssl_kwargs = {}
        if certfile and keyfile:
            if generate_self_signed_cert(certfile, keyfile):
                ssl_kwargs['ssl_certfile'] = certfile
                ssl_kwargs['ssl_keyfile'] = keyfile
                protocol = "https"
            else:
                logger.warning("SSL certificate generation failed. Falling back to HTTP.")
                protocol = "http"
        else:
            protocol = "http"
        
        logger.info(f"Starting Im Mesh Client (Multi-Tenant) on port {settings.web.port}")
        
        # Initialize session manager
        session_manager = SessionManager(settings)
        session_manager.start()
        logger.info("Session manager initialized")

        # Load v2.4.X raw settings
        raw_settings = _load_raw_settings()
        sched_settings = raw_settings.get('sched_message', {})
        ar_settings = raw_settings.get('auto_responder', {})
        tg_settings = raw_settings.get('telegram', {})

        # Session getter: returns session for configured sched_message host, fallback to first
        # Parse host:port from sched_message.host (format: "host" or "host:port")
        _sched_host_raw = sched_settings.get('host', '127.0.0.1')
        if ':' in _sched_host_raw:
            _sched_host, _sched_port_str = _sched_host_raw.rsplit(':', 1)
            try:
                _sched_port = int(_sched_port_str)
            except ValueError:
                _sched_port = 4403
        else:
            _sched_host = _sched_host_raw
            _sched_port = raw_settings.get('meshtastic', {}).get('port', 4403)

        def get_sched_session():
            sid = session_manager.find_session_by_host_port(_sched_host, _sched_port)
            if sid:
                return session_manager.sessions.get(sid)
            # Fallback: return any active session
            sessions = list(session_manager.sessions.values())
            return sessions[0] if sessions else None

        # Initialize v2.4.X services
        scheduler = None
        if sched_settings.get('enabled', True):
            scheduler = Scheduler(get_sched_session, sched_settings)
            logger.info("Scheduler initialized")

        auto_responder = None
        if ar_settings.get('enabled', True):
            auto_responder = AutoResponder(ar_settings)
            logger.info("AutoResponder initialized")

        # Initialize TelegramForwarder if enabled and bot_token is configured
        telegram_forwarder = None
        tg_bot_token = tg_settings.get('bot_token', '')
        tg_enabled = tg_settings.get('enabled', False)
        if tg_enabled and tg_bot_token:
            from telegram_forwarder.telegram_forwarder import TelegramForwarder
            tg_dir = resolve_project_path(tg_settings.get('directory', './telegram_forwarder'))
            tg_host = tg_settings.get('host', '127.0.0.1')
            telegram_forwarder = TelegramForwarder(bot_token=tg_bot_token, telegram_dir=tg_dir, host=tg_host)
            logger.info("TelegramForwarder initialized")
        elif tg_enabled and not tg_bot_token:
            logger.warning("Telegram enabled in settings but no bot_token configured — Telegram forwarding disabled")
        
        # Initialize WebSocket API with session manager
        websocket_api = WebSocketAPI(session_manager, auto_responder=auto_responder,
                                     telegram_forwarder=telegram_forwarder,
                                     scheduler=scheduler)

        # Wire scheduler WebSocket callback so fired messages are pushed to browsers
        if scheduler:
            scheduler.ws_send_callback = websocket_api._send_to_session
            scheduler.is_connected_fn = websocket_api.is_session_connected
        
        # Create lifespan context manager for startup/shutdown
        @asynccontextmanager
        async def lifespan(app):
            # Startup
            if scheduler:
                await scheduler.start()
                logger.info("Scheduler started")
            if auto_responder:
                logger.info("AutoResponder ready")
            yield
            # Shutdown
            logger.info("Shutting down - cleaning up connections...")
            if scheduler:
                await scheduler.stop()
            try:
                await websocket_api.shutdown()
            except (ConnectionError, RuntimeError) as e:
                logger.warning(f"Error shutting down WebSocket API: {e}")
            try:
                await session_manager.shutdown()
            except (ConnectionError, RuntimeError) as e:
                logger.warning(f"Error shutting down session manager: {e}")
            logger.info("Cleanup complete")
        
        # Create FastAPI application with session manager and lifespan
        app = create_rest_api(session_manager, websocket_api, settings, lifespan=lifespan, scheduler=scheduler, auto_responder=auto_responder, telegram_forwarder=telegram_forwarder)
        
        # Install SIGINT handler to force exit after 5 seconds if graceful fails
        _shutdown_count = 0
        _original_sigint = signal.getsignal(signal.SIGINT)
        
        def _force_shutdown_handler(signum, frame):
            nonlocal _shutdown_count
            _shutdown_count += 1
            if _shutdown_count == 1:
                logger.info("Shutdown requested (Ctrl+C) - stopping server...")
                # Let uvicorn handle the first SIGINT
                if callable(_original_sigint) and _original_sigint is not signal.SIG_DFL:
                    _original_sigint(signum, frame)
                else:
                    raise KeyboardInterrupt
            else:
                logger.warning("Force shutdown (second Ctrl+C)")
                sys.exit(1)
        
        signal.signal(signal.SIGINT, _force_shutdown_handler)
        
        # Import uvicorn for running the server
        import uvicorn
        
        # Start web server
        logger.info(f"Web interface available at {protocol}://{settings.web.host}:{settings.web.port}")
        if ssl_kwargs:
            logger.info("HTTPS enabled with SSL certificate")
        else:
            logger.info("Running in HTTP mode (no SSL)")
        logger.info("Multi-tenant mode: Each browser can connect to different Meshtastic nodes")
        logger.info("Use Ctrl+C to shutdown")
        
        # Run the server with a graceful shutdown timeout
        uvicorn.run(
            app,
            host=settings.web.host,
            port=settings.web.port,
            log_level="info",
            timeout_graceful_shutdown=5,
            **ssl_kwargs
        )
        
    except KeyboardInterrupt:
        logger.info("Shutdown requested by user")
    except Exception as e:  # Top-level: catch-all for fatal startup errors
        logger.exception(f"Application error: {e}")
        raise
    finally:
        # Force exit after graceful shutdown to prevent daemon threads
        # (e.g. meshtastic TCP rxThread) from keeping the process alive.
        import os
        os._exit(0)

if __name__ == "__main__":
    main()
