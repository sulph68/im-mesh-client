/**
 * HTML5 Storage for Meshtastic Web Client.
 *
 * Uses localStorage for small/fast data (nodes, channels, favorites).
 * Delegates message storage to MessageDB (IndexedDB) for scalability.
 *
 * Migration from localStorage message arrays to IndexedDB happens
 * automatically on first use of a session (see initMessageDB).
 */

class MeshtasticStorage {
    constructor(sessionId) {
        this.sessionId = sessionId;
        this.storagePrefix = `meshtastic_${sessionId}_`;
        this.messageDB = null; // set by initMessageDB()
        this.init();
    }
    
    init() {
        if (!this.getItem('initialized')) {
            this.setItem('initialized', true);
            this.setItem('nodes', []);
            this.setItem('channels', []);
            this.setItem('favorites', []);
        }
    }

    /**
     * Initialize IndexedDB for message storage and run migration.
     * Must be awaited before using message methods.
     * @returns {Promise<MessageDB>}
     */
    async initMessageDB() {
        if (this.messageDB) return this.messageDB;
        this.messageDB = new MessageDB(this.sessionId);
        await this.messageDB.open();
        await this.messageDB.migrateFromLocalStorage(this);
        return this.messageDB;
    }
    
    // ── Generic localStorage methods ────────────────────────────────

    getItem(key) {
        const item = localStorage.getItem(this.storagePrefix + key);
        try {
            return item ? JSON.parse(item) : null;
        } catch (e) {
            console.error('Error parsing storage item:', key, e);
            return null;
        }
    }
    
    setItem(key, value) {
        try {
            localStorage.setItem(this.storagePrefix + key, JSON.stringify(value));
            return true;
        } catch (e) {
            console.error('Error saving to storage:', key, e);
            return false;
        }
    }
    
    removeItem(key) {
        localStorage.removeItem(this.storagePrefix + key);
    }
    
    clear(key) {
        if (key) {
            this.removeItem(key);
        } else {
            // Clear all keys for this session
            const keys = [];
            for (let i = 0; i < localStorage.length; i++) {
                const k = localStorage.key(i);
                if (k.startsWith(this.storagePrefix)) keys.push(k);
            }
            keys.forEach(k => localStorage.removeItem(k));
            if (this.messageDB) {
                this.messageDB.deleteDatabase().catch(e => {
                    console.error('Error deleting message database:', e);
                });
            }
        }
    }
    
    // ── Node management ──────────────────────────────────────────────

    getNodes() {
        return this.getItem('nodes') || [];
    }
    
    addOrUpdateNode(nodeData) {
        const nodes = this.getNodes();
        const nodeId = nodeData.id || nodeData.node_id;
        const existingIndex = nodes.findIndex(n => (n.id || n.node_id) === nodeId);
        if (existingIndex >= 0) {
            nodes[existingIndex] = { ...nodes[existingIndex], ...nodeData };
        } else {
            nodes.push(nodeData);
        }
        this.setItem('nodes', nodes);
        return nodeData;
    }
    
    // ── Channel management ───────────────────────────────────────────

    getChannels() {
        return this.getItem('channels') || [];
    }
    
    addOrUpdateChannel(channelData) {
        const channels = this.getChannels();
        const existingIndex = channels.findIndex(c => c.index === channelData.index);
        if (existingIndex >= 0) {
            channels[existingIndex] = { ...channels[existingIndex], ...channelData };
        } else {
            channels.push(channelData);
        }
        this.setItem('channels', channels);
        return channelData;
    }
    
    // ── Message management (delegates to IndexedDB) ──────────────────

    async getMessagesAsync(targetKey, limit = 200) {
        if (this.messageDB) {
            return this.messageDB.getMessages(targetKey, limit);
        }
        return this.getItem(targetKey) || [];
    }

    async addMessageAsync(targetKey, messageData) {
        if (this.messageDB) {
            await this.messageDB.addMessage(targetKey, messageData);
            return;
        }
        // Fallback to localStorage
        const messages = this.getItem(targetKey) || [];
        if (!messageData.timestamp) messageData.timestamp = new Date().toISOString();
        if (!messageData.id) messageData.id = Date.now() + '_' + Math.random().toString(36).substr(2, 9);
        const toStore = { ...messageData };
        delete toStore._targetKey;
        messages.push(toStore);
        if (messages.length > 200) messages.splice(0, messages.length - 200);
        this.setItem(targetKey, messages);
    }

    async deleteMessageAsync(dbId) {
        if (this.messageDB) {
            await this.messageDB.deleteMessage(dbId);
        }
    }

    async clearTargetAsync(targetKey) {
        if (this.messageDB) {
            return this.messageDB.clearTarget(targetKey);
        }
        this.removeItem(targetKey);
        return 0;
    }

    async clearTargetBeforeAsync(targetKey, cutoffMs) {
        if (this.messageDB) {
            return this.messageDB.clearTargetBefore(targetKey, cutoffMs);
        }
        return 0;
    }

    async updateAckStatusAsync(packetId, ackOk, errorReason, ackType, status) {
        if (this.messageDB) {
            return this.messageDB.updateAckStatus(packetId, ackOk, errorReason, ackType, status);
        }
        return false;
    }

    async getLatestTimestampAsync() {
        if (this.messageDB) {
            return this.messageDB.getLatestTimestamp();
        }
        return null;
    }

    async searchMessagesAsync(targetKey, query, limit = 100) {
        if (this.messageDB) {
            return this.messageDB.searchMessages(targetKey, query, limit);
        }
        return [];
    }

    // ── Favorites management ─────────────────────────────────────────

    getFavorites() {
        return this.getItem('favorites') || [];
    }

    // ── Data export/import ───────────────────────────────────────────

    async exportAllAsync() {
        const localData = {};
        for (let i = 0; i < localStorage.length; i++) {
            const key = localStorage.key(i);
            if (key.startsWith(this.storagePrefix)) {
                const shortKey = key.replace(this.storagePrefix, '');
                localData[shortKey] = this.getItem(shortKey);
            }
        }
        let messageExport = null;
        if (this.messageDB) {
            messageExport = await this.messageDB.exportAll();
        }
        return {
            localStorage: localData,
            messages: messageExport,
            exportedAt: new Date().toISOString(),
            sessionId: this.sessionId
        };
    }

    async importMessagesAsync(data) {
        if (!this.messageDB) {
            throw new Error('Message database not initialized');
        }
        const messageData = data.messages || data;
        return this.messageDB.importMessages(messageData);
    }

    /**
     * Storage usage estimate.
     */
    async estimate() {
        const result = { localStorage: 0, indexedDB: 0 };
        for (let i = 0; i < localStorage.length; i++) {
            const key = localStorage.key(i);
            if (key.startsWith(this.storagePrefix)) {
                result.localStorage += (localStorage.getItem(key) || '').length;
            }
        }
        if (this.messageDB) {
            result.indexedDB = await this.messageDB.getMessageCount();
        }
        return result;
    }
}

// Make available globally
window.MeshtasticStorage = MeshtasticStorage;
