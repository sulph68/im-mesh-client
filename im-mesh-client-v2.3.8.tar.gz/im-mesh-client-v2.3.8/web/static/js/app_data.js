/**
 * Meshtastic Web Client - Data Module: WS message handler, ACK, loadInitialData, loadNodes, loadChannels
 */

Object.assign(MeshtasticClient.prototype, {

handleWebSocketMessage(data) {
    switch (data.type) {
        case 'auth_success':
                            this.addSystemMessage('Authentication successful - Loading device data...', 'success');
            this.loadInitialData();
            break;

        case 'connected':
                            break;

        case 'message':
        case 'text':
        case 'binary':
            // 'message' is the primary path from subscription callbacks.
            // 'text' and 'binary' are fallback types from the broadcast path.
            this.addMessage(data.data);
            break;

        case 'node_update':
        case 'position_update':
            this.updateNode(data.data);
            break;

        case 'channel_update':
            this.updateChannels(data.data);
            this.addSystemMessage('Channel information updated', 'info');
            break;

        case 'connection_status':
            this.handleConnectionStatusUpdate(data.data);
            break;

        case 'binary_complete':
            // Fragment reassembly complete - binary message.
            // Individual fragments are already displayed as they arrive,
            // so only add this if the image_complete path didn't already
            // handle it (i.e., the reassembled payload is not an image).
            // The channel is preserved from fragment_reassembler.
            this.addMessage({
                ...data.data,
                decoded: { portnum: 288, payload: data.data.payload },
                channel: data.data.channel || 0,
                type: 'received'
            });
            break;

        case 'image_complete':
            // Decoded image from fragment reassembly
            this.addMessage({
                ...data.data,
                type: 'image_complete'
            });
            break;

        case 'ack':
            // Ack/Nak received for a sent message
            this._handleAckReceived(data.data);
            break;

        case 'pong':
            // Heartbeat response - update latency display
            this._handlePong(data);
            break;

        case 'fragment_progress':
            break;

        case 'error':
            console.error('Server error:', data.message || data.data);
            const errMsg = data.message || (data.data && data.data.error_message) || 'Unknown server error';
            this.showMessage(errMsg, 'error');
            // If session not found, stop reconnecting and show login screen
            if (errMsg.includes('Session not found')) {
                this._resetWsReconnect();
                this._wsSessionLost = true;  // Flag to prevent auto-reconnect in onclose
            }
            break;

        case 'system':
            if (data.data && data.data.message) {
                this.addSystemMessage(data.data.message, data.data.level || 'info');
            }
            break;

        default:
    }
},

handleConnectionStatusUpdate(statusData) {
    if (!statusData) return;

    if (statusData.connected) {
        this.updateConnectionStatus('connected', 'Connected');
        this.addSystemMessage('Connection to Meshtastic node established', 'success');

        // Cache own node ID immediately from the connection_info so it's
        // available before the first node list render (prevents showing
        // own node in favourites on page refresh / first load).
        const connInfo = statusData.connection_info || {};
        const rawNodeId = connInfo.node_id;
        if (rawNodeId && rawNodeId !== 'unknown') {
            this._myNodeId = _normalizeNodeId(rawNodeId);
            // Persist so it survives page refresh before loadNodes() fires
            try {
                localStorage.setItem('meshtastic_myNodeId_' + this.sessionId, this._myNodeId);
            } catch (e) { /* quota or private mode */ }
        }

        // Update browser tab title with node name
        this._updateConnectionTitle();

        // If this was a reconnect, data may have been refreshed
        if (statusData.reconnected) {
            this.addSystemMessage('Data refreshed after reconnection', 'info');
            // Reload data to get fresh info
            this._initialDataLoaded = false;
            this.loadInitialData();
        }
    } else {
        if (statusData.reconnecting) {
            this.updateConnectionStatus('connecting', 'Reconnecting...');
            this.addSystemMessage('Connection lost - reconnecting automatically...', 'warning');
        } else {
            this.updateConnectionStatus('disconnected', 'Disconnected');
            this.addConnectionLostMessage();
        }
    }
},

/**
 * Handle an ack/nak received from the mesh network.
 * Any successful ACK (node or destination) upgrades status to "delivered"
 * since "sent" is already set when the API call succeeds.
 *
 * Updates the tick-mark indicator in the DOM and persists to IndexedDB.
 */
_handleAckReceived(ackData) {
    if (!ackData || !ackData.request_id) return;

    const requestId = ackData.request_id;
    const ackOk = ackData.ack_received;
    const errorReason = ackData.error_reason || '';
    const ackType = ackData.ack_type || 'destination';  // 'node' or 'destination'

    console.log(`ACK received: requestId=${requestId} ack=${ackOk} type=${ackType} error=${errorReason}`);

    // Dispatch to image segment ACK handler if active
    if (this._imageSegmentAckHandler) {
        this._imageSegmentAckHandler(ackData);
    }

    // Any successful ACK -> delivered.  "Sent" is set at API-call time.
    const ackStatus = ackOk ? 'delivered' : 'failed';
    this._persistAckStatus(requestId, ackOk, errorReason, ackType, ackStatus);

    // Find the message element with this packet_id (may not be in DOM if on different panel)
    const container = document.getElementById('messagesContainer');
    if (!container) return;

    const msgEl = container.querySelector(`[data-packet-id="${requestId}"]`);
    if (!msgEl) {
        console.log(`No message element found for packetId=${requestId} (may be on different panel)`);
        return;
    }

    // Update tick-mark indicator (span.ack-ticks inside .message-header)
    const tickSpan = msgEl.querySelector('.ack-ticks');
    if (!tickSpan) return;

    if (ackOk) {
        // Upgrade to delivered (double tick, green)
        tickSpan.className = 'ack-ticks ack-delivered';
        tickSpan.textContent = '\u2713\u2713';
        tickSpan.title = 'Delivered';
        tickSpan.setAttribute('data-ack-status', 'delivered');
    } else {
        tickSpan.className = 'ack-ticks ack-failed';
        tickSpan.textContent = '\u2717';
        tickSpan.title = `Nak: ${errorReason}`;
        tickSpan.setAttribute('data-ack-status', 'failed');
    }
},

/**
 * Persist ack status into IndexedDB message history.
 * Uses the byPacketId index for efficient lookup.
 * Any successful ACK (node or destination) -> 'delivered'.
 */
_persistAckStatus(packetId, ackOk, errorReason, ackType, status) {
    if (!this.storage || !packetId) return;

    const finalStatus = status || (ackOk ? 'delivered' : 'failed');
    this.storage.updateAckStatusAsync(packetId, ackOk, errorReason, ackType, finalStatus).catch(e => {
        console.error('Error persisting ack status:', e);
    });
},

loadInitialData() {
    if (this._initialDataLoaded) {
        return;
    }
    this._initialDataLoaded = true;

    try {
        // Add a small delay to ensure WebSocket auth is complete
        setTimeout(async () => {

            // Update status to show loading
            this.showStatus('Loading nodes and channels...');
            this.addSystemMessage('Loading device data automatically...', 'info');

            try {
                // Load all data in parallel for efficiency
                await Promise.all([
                    this.loadNodes(),
                    this.loadChannels()
                ]);

                this.showStatus('Connected - Data loaded successfully');
                this.addSystemMessage('Device data loaded successfully', 'success');

                // Update title with connected node name
                this._updateConnectionTitle();

                // Re-apply notification badges - buffered messages that
                // arrived via WS flush before the DOM was ready may have
                // incremented _unreadCounts but couldn't update badges
                // because channel/node elements didn't exist yet.
                this._updateNotificationBadges();

            } catch (error) {
                console.error('Error loading initial data:', error);
                this.showMessage('Failed to load initial data: ' + error.message, 'error');
                this.addSystemMessage('Failed to load device data: ' + error.message, 'error');
            }

        }, INITIAL_DATA_DELAY_MS); // Delay for WebSocket stability

    } catch (error) {
        console.error('Error in loadInitialData:', error);
        this.showMessage('Error displaying main app: ' + error.message, 'error');
    }
},

/** Fetch session info and update page title with connected node name. */
async _updateConnectionTitle() {
    if (!this.sessionId) return;
    try {
        const response = await fetch(`/api/sessions/${this.sessionId}`, {
            headers: { 'X-Session-ID': this.sessionId }
        });
        if (!response.ok) return;
        const data = await response.json();
        const conn = data.data?.connection;
        if (!conn) return;

        const nodeName = conn.long_name || conn.short_name || null;
        if (nodeName && nodeName !== 'unknown') {
            document.title = `Im Mesh Client (${nodeName})`;
        } else if (!this._titleRetried) {
            // Node name not available yet - retry once after 10s
            this._titleRetried = true;
            setTimeout(() => this._updateConnectionTitle(), TITLE_UPDATE_DELAY_MS);
        }
    } catch (e) {
        console.error('Error updating connection title:', e);
    }
},

async loadNodes() {
    if (!this.sessionId) return;

    this.logCommunication('OUT', 'Loading nodes from device', 'info');

    try {
        const response = await fetch('/api/nodes', {
            headers: {
                'X-Session-ID': this.sessionId
            }
        });

        if (response.ok) {
            const data = await response.json();
            this.logCommunication('IN', `Nodes loaded: ${data.data?.count || 0} nodes`, 'success');

            if (data.success && data.data.nodes) {
                // Store our own node ID so we can filter it from the list
                if (data.data.my_node_id) {
                    this._myNodeId = _normalizeNodeId(data.data.my_node_id);
                    try {
                        localStorage.setItem('meshtastic_myNodeId_' + this.sessionId, this._myNodeId);
                    } catch (e) { /* quota */ }
                }
                this.updateNodesList(data.data.nodes);

                // If server returned no my_node_id (not ready yet) and we
                // don't have one cached, retry once after 2s when the server
                // should have received getMyNodeInfo() from the radio.
                if (!this._myNodeId && !data.data.my_node_id) {
                    setTimeout(() => this.loadNodes(), 2000);
                }
            }
        } else {
            const errorText = await response.text();
            console.error('Nodes load failed:', errorText);
            this.logCommunication('IN', `Nodes load failed: HTTP ${response.status}`, 'error');
        }
    } catch (error) {
        console.error('Load nodes error:', error);
        this.logCommunication('IN', `Nodes load error: ${error.message}`, 'error');
    } finally {
        if (document.activeElement) document.activeElement.blur();
    }
},

async loadChannels() {
    if (!this.sessionId) return;

    this.logCommunication('OUT', 'Loading channels from device', 'info');

    try {
        const response = await fetch('/api/channels', {
            headers: {
                'X-Session-ID': this.sessionId
            }
        });

        if (response.ok) {
            const data = await response.json();
            this.logCommunication('IN', `Channels loaded: ${data.data?.count || 0} channels`, 'success');

            if (data.success && data.data.channels) {
                this.updateChannelsList(data.data.channels);
            }
        } else {
            const errorText = await response.text();
            console.error('Channels load failed:', errorText);
            this.logCommunication('IN', `Channels load failed: HTTP ${response.status}`, 'error');
        }
    } catch (error) {
        console.error('Load channels error:', error);
        this.logCommunication('IN', `Channels load error: ${error.message}`, 'error');
    } finally {
        if (document.activeElement) document.activeElement.blur();
    }
}
});
