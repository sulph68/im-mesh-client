/**
 * MessageDB - IndexedDB storage for Meshtastic message history.
 *
 * Replaces localStorage arrays for message data. Provides:
 *  - Per-target message storage (channel or DM node)
 *  - Indexed by targetKey + timestamp for fast retrieval
 *  - Pagination-ready with cursor-based loading
 *  - Export/import for backup and restore
 *  - Schema versioning for future migrations
 *
 * All public methods return Promises (IndexedDB is async).
 */

const MESSAGE_DB_NAME = 'MeshtasticMessages';
const MESSAGE_DB_VERSION = 1;
const MESSAGE_STORE = 'messages';
const META_STORE = 'meta';

class MessageDB {
    constructor(sessionId) {
        this.sessionId = sessionId;
        this.db = null;
        this._ready = null; // resolved when DB is open
    }

    /**
     * Open the database. Called once during init.
     * Returns a promise that resolves when the DB is ready.
     */
    open() {
        if (this._ready) return this._ready;

        this._ready = new Promise((resolve, reject) => {
            const dbName = `${MESSAGE_DB_NAME}_${this.sessionId}`;
            const request = indexedDB.open(dbName, MESSAGE_DB_VERSION);

            request.onupgradeneeded = (event) => {
                const db = event.target.result;
                const oldVersion = event.oldVersion;

                // Version 0 -> 1: initial schema
                if (oldVersion < 1) {
                    // Main message store with auto-incrementing key
                    const store = db.createObjectStore(MESSAGE_STORE, {
                        keyPath: '_dbId',
                        autoIncrement: true
                    });
                    // Index for loading messages by target (channel or node)
                    store.createIndex('byTarget', 'targetKey', { unique: false });
                    // Index for finding messages by target + timestamp (for ordering)
                    store.createIndex('byTargetTime', ['targetKey', 'timestamp'], { unique: false });
                    // Index for finding messages by packet_id (for ACK updates)
                    store.createIndex('byPacketId', 'packet_id', { unique: false });
                    // Index for finding messages by unique dedup key
                    store.createIndex('byDedupKey', '_dedupKey', { unique: false });

                    // Meta store for migration state, schema version, etc.
                    db.createObjectStore(META_STORE, { keyPath: 'key' });
                }

                // Future migrations go here:
                // if (oldVersion < 2) { ... }
            };

            request.onsuccess = (event) => {
                this.db = event.target.result;

                // Handle version change (another tab upgraded)
                this.db.onversionchange = () => {
                    this.db.close();
                    this.db = null;
                    this._ready = null;
                    console.warn('MessageDB: database version changed, please reload');
                };

                resolve(this.db);
            };

            request.onerror = (event) => {
                console.error('MessageDB: failed to open', event.target.error);
                reject(event.target.error);
            };

            request.onblocked = () => {
                console.warn('MessageDB: open blocked (close other tabs?)');
            };
        });

        return this._ready;
    }

    /**
     * Ensure the DB is open before operations.
     */
    async _ensureOpen() {
        if (!this.db) {
            await this.open();
        }
        return this.db;
    }

    // ── Message CRUD ──────────────────────────────────────────────────

    /**
     * Add a message for a specific target.
     * @param {string} targetKey - e.g. "messages_channel_0" or "messages_node_!abc"
     * @param {object} messageData - the message object to store
     * @returns {Promise<number>} the auto-generated _dbId
     */
    async addMessage(targetKey, messageData) {
        const db = await this._ensureOpen();
        return new Promise((resolve, reject) => {
            try {
                const tx = db.transaction(MESSAGE_STORE, 'readwrite');
                const store = tx.objectStore(MESSAGE_STORE);

                // Attach targetKey for indexing
                const record = { ...messageData, targetKey };

                // Generate a dedup key (timestamp + from + text substring)
                if (!record._dedupKey) {
                    const ts = record.timestamp || '';
                    const from = record.from || record.from_node || '';
                    const text = (record.text || '').substring(0, 50);
                    record._dedupKey = `${targetKey}:${ts}:${from}:${text}`;
                }

                // Ensure timestamp exists
                if (!record.timestamp) {
                    record.timestamp = new Date().toISOString();
                }

                // Generate ID if not present
                if (!record.id) {
                    record.id = Date.now() + '_' + Math.random().toString(36).substr(2, 9);
                }

                // Remove internal _targetKey (was used for routing, not storage)
                delete record._targetKey;

                const request = store.add(record);
                request.onsuccess = () => resolve(request.result);

                tx.onerror = (event) => {
                    const error = event.target.error;
                    if (error && error.name === 'QuotaExceededError') {
                        this._handleQuotaExceeded();
                    }
                    reject(error);
                };
            } catch (e) {
                reject(e);
            }
        });
    }

    /**
     * Get all messages for a target, ordered by timestamp.
     * @param {string} targetKey
     * @param {number} limit - max messages to return (default 200)
     * @returns {Promise<Array>}
     */
    async getMessages(targetKey, limit = 200) {
        const db = await this._ensureOpen();
        return new Promise((resolve, reject) => {
            try {
                const tx = db.transaction(MESSAGE_STORE, 'readonly');
                const store = tx.objectStore(MESSAGE_STORE);
                const index = store.index('byTargetTime');

                // IDBKeyRange for this targetKey (all timestamps)
                const range = IDBKeyRange.bound(
                    [targetKey, ''],
                    [targetKey, '\uffff']
                );

                const results = [];
                const request = index.openCursor(range, 'prev'); // newest first

                request.onsuccess = (event) => {
                    const cursor = event.target.result;
                    if (cursor && results.length < limit) {
                        results.push(cursor.value);
                        cursor.continue();
                    } else {
                        // Reverse so oldest is first (chronological order)
                        resolve(results.reverse());
                    }
                };

                request.onerror = (event) => reject(event.target.error);
            } catch (e) {
                reject(e);
            }
        });
    }

    /**
     * Update a message by its _dbId, merging in new fields.
     * @param {number} dbId
     * @param {object} fields - fields to merge into the stored record
     * @returns {Promise<boolean>}
     */
    async updateMessage(dbId, fields) {
        const db = await this._ensureOpen();
        return new Promise((resolve, reject) => {
            try {
                const tx = db.transaction(MESSAGE_STORE, 'readwrite');
                const store = tx.objectStore(MESSAGE_STORE);
                const getReq = store.get(dbId);
                getReq.onsuccess = (event) => {
                    const record = event.target.result;
                    if (!record) { resolve(false); return; }
                    Object.assign(record, fields);
                    const putReq = store.put(record);
                    putReq.onsuccess = () => resolve(true);
                    putReq.onerror = (ev) => reject(ev.target.error);
                };
                getReq.onerror = (event) => reject(event.target.error);
            } catch (e) {
                reject(e);
            }
        });
    }

    /**
     * Delete a single message by its _dbId.
     * @param {number} dbId
     * @returns {Promise<void>}
     */
    async deleteMessage(dbId) {
        const db = await this._ensureOpen();
        return new Promise((resolve, reject) => {
            try {
                const tx = db.transaction(MESSAGE_STORE, 'readwrite');
                const store = tx.objectStore(MESSAGE_STORE);
                const request = store.delete(dbId);
                request.onsuccess = () => resolve();
                request.onerror = (event) => reject(event.target.error);
            } catch (e) {
                reject(e);
            }
        });
    }

    /**
     * Delete all messages for a target.
     * @param {string} targetKey
     * @returns {Promise<number>} count of deleted messages
     */
    async clearTarget(targetKey) {
        const db = await this._ensureOpen();
        return new Promise((resolve, reject) => {
            try {
                const tx = db.transaction(MESSAGE_STORE, 'readwrite');
                const store = tx.objectStore(MESSAGE_STORE);
                const index = store.index('byTarget');
                const range = IDBKeyRange.only(targetKey);
                let count = 0;

                const request = index.openCursor(range);
                request.onsuccess = (event) => {
                    const cursor = event.target.result;
                    if (cursor) {
                        cursor.delete();
                        count++;
                        cursor.continue();
                    } else {
                        resolve(count);
                    }
                };

                request.onerror = (event) => reject(event.target.error);
            } catch (e) {
                reject(e);
            }
        });
    }

    /**
     * Delete messages for a target older than a given cutoff time.
     * @param {string} targetKey
     * @param {number} cutoffMs - Unix timestamp in ms; messages older than this are deleted
     * @returns {Promise<number>} count of deleted messages
     */
    async clearTargetBefore(targetKey, cutoffMs) {
        const db = await this._ensureOpen();
        return new Promise((resolve, reject) => {
            try {
                const tx = db.transaction(MESSAGE_STORE, 'readwrite');
                const store = tx.objectStore(MESSAGE_STORE);
                const index = store.index('byTarget');
                const range = IDBKeyRange.only(targetKey);
                let count = 0;

                const request = index.openCursor(range);
                request.onsuccess = (event) => {
                    const cursor = event.target.result;
                    if (cursor) {
                        const record = cursor.value;
                        const ts = record.timestamp ? new Date(record.timestamp).getTime() : 0;
                        if (ts < cutoffMs) {
                            cursor.delete();
                            count++;
                        }
                        cursor.continue();
                    } else {
                        resolve(count);
                    }
                };

                request.onerror = (event) => reject(event.target.error);
            } catch (e) {
                reject(e);
            }
        });
    }

    /**
     * Update a message's ACK status by packet_id.
     * Scans the byPacketId index for a matching pending message.
     * @param {string} packetId
     * @param {boolean} ackOk
     * @param {string} [errorReason]
     * @returns {Promise<boolean>} whether a message was updated
     */
    async updateAckStatus(packetId, ackOk, errorReason, ackType, status) {
        if (!packetId) return false;
        const db = await this._ensureOpen();
        return new Promise((resolve, reject) => {
            try {
                const tx = db.transaction(MESSAGE_STORE, 'readwrite');
                const store = tx.objectStore(MESSAGE_STORE);
                const index = store.index('byPacketId');
                const range = IDBKeyRange.only(packetId);

                const request = index.openCursor(range);
                request.onsuccess = (event) => {
                    const cursor = event.target.result;
                    if (cursor) {
                        const record = cursor.value;
                        // ACK status: sent -> delivered.  "sent" is set at API-call time,
                        // "delivered" is set when any ACK arrives from the mesh.
                        // Only upgrade status, never downgrade.
                        const currentStatus = record.ack_status || 'sent';
                        const statusRank = { pending: 0, sent: 1, delivered: 2, received: 2, failed: -1 };
                        const newStatus = status || (ackOk ? 'delivered' : 'failed');
                        const currentRank = statusRank[currentStatus] ?? 0;
                        const newRank = statusRank[newStatus] ?? 0;

                        if (newRank > currentRank || newStatus === 'failed') {
                            record.ack_status = newStatus;
                            record.ack_type = ackType || 'destination';
                            if (!ackOk && errorReason) {
                                record.ack_error = errorReason;
                            }
                            cursor.update(record);
                            resolve(true);
                            return;
                        }
                        cursor.continue();
                    } else {
                        resolve(false);
                    }
                };

                request.onerror = (event) => reject(event.target.error);
            } catch (e) {
                reject(e);
            }
        });
    }

    /**
     * Update a specific field on a message found by matching text content.
     * Used for persisting decoded image data back to segment messages.
     * @param {string} targetKey
     * @param {string} matchText - text to match against message text field
     * @param {object} fields - fields to merge into the message
     * @returns {Promise<boolean>}
     */
    async updateMessageByText(targetKey, matchText, fields) {
        const db = await this._ensureOpen();
        return new Promise((resolve, reject) => {
            try {
                const tx = db.transaction(MESSAGE_STORE, 'readwrite');
                const store = tx.objectStore(MESSAGE_STORE);
                const index = store.index('byTarget');
                const range = IDBKeyRange.only(targetKey);

                const request = index.openCursor(range, 'prev');
                request.onsuccess = (event) => {
                    const cursor = event.target.result;
                    if (cursor) {
                        const record = cursor.value;
                        const msgText = (record.text || record.decoded_text || '').trim();
                        if (msgText === matchText.trim()) {
                            Object.assign(record, fields);
                            cursor.update(record);
                            resolve(true);
                            return;
                        }
                        cursor.continue();
                    } else {
                        resolve(false);
                    }
                };

                request.onerror = (event) => reject(event.target.error);
            } catch (e) {
                reject(e);
            }
        });
    }

    /**
     * Find the latest timestamp across all messages (for reconnect buffer).
     * @returns {Promise<string|null>}
     */
    async getLatestTimestamp() {
        const db = await this._ensureOpen();
        return new Promise((resolve, reject) => {
            try {
                const tx = db.transaction(MESSAGE_STORE, 'readonly');
                const store = tx.objectStore(MESSAGE_STORE);
                const index = store.index('byTargetTime');

                // Open a reverse cursor to get the latest entry
                const request = index.openCursor(null, 'prev');
                request.onsuccess = (event) => {
                    const cursor = event.target.result;
                    if (cursor) {
                        resolve(cursor.value.timestamp || null);
                    } else {
                        resolve(null);
                    }
                };

                request.onerror = (event) => reject(event.target.error);
            } catch (e) {
                reject(e);
            }
        });
    }

    /**
     * Check if a message already exists (dedup).
     * @param {string} dedupKey
     * @returns {Promise<boolean>}
     */
    async hasDedupKey(dedupKey) {
        if (!dedupKey) return false;
        const db = await this._ensureOpen();
        return new Promise((resolve, reject) => {
            try {
                const tx = db.transaction(MESSAGE_STORE, 'readonly');
                const store = tx.objectStore(MESSAGE_STORE);
                const index = store.index('byDedupKey');
                const request = index.count(IDBKeyRange.only(dedupKey));
                request.onsuccess = () => resolve(request.result > 0);
                request.onerror = (event) => reject(event.target.error);
            } catch (e) {
                reject(e);
            }
        });
    }

    // ── Migration ─────────────────────────────────────────────────────

    /**
     * Migrate messages from localStorage to IndexedDB.
     * Runs once per session. Idempotent (checks meta store).
     * @param {MeshtasticStorage} oldStorage - the localStorage-based storage instance
     * @returns {Promise<number>} number of messages migrated
     */
    async migrateFromLocalStorage(oldStorage) {
        const db = await this._ensureOpen();

        // Check if already migrated
        const migrated = await this._getMeta('migrated_from_localstorage');
        if (migrated) return 0;

        const prefix = `meshtastic_${this.sessionId}_messages_`;
        let totalMigrated = 0;

        try {
            // Find all localStorage keys for this session's messages
            const keysToMigrate = [];
            for (let i = 0; i < localStorage.length; i++) {
                const fullKey = localStorage.key(i);
                if (fullKey && fullKey.startsWith(prefix)) {
                    keysToMigrate.push(fullKey);
                }
            }

            for (const fullKey of keysToMigrate) {
                const shortKey = fullKey.replace(`meshtastic_${this.sessionId}_`, '');
                const raw = localStorage.getItem(fullKey);
                if (!raw) continue;

                let messages;
                try {
                    messages = JSON.parse(raw);
                } catch (_e) {
                    continue;
                }

                if (!Array.isArray(messages) || messages.length === 0) continue;

                // Bulk insert into IndexedDB
                const tx = db.transaction(MESSAGE_STORE, 'readwrite');
                const store = tx.objectStore(MESSAGE_STORE);

                for (const msg of messages) {
                    const record = { ...msg, targetKey: shortKey };
                    if (!record.timestamp) {
                        record.timestamp = new Date().toISOString();
                    }
                    if (!record.id) {
                        record.id = Date.now() + '_' + Math.random().toString(36).substr(2, 9);
                    }
                    const ts = record.timestamp || '';
                    const from = record.from || record.from_node || '';
                    const text = (record.text || '').substring(0, 50);
                    record._dedupKey = `${shortKey}:${ts}:${from}:${text}`;
                    delete record._targetKey;
                    store.add(record);
                    totalMigrated++;
                }

                await new Promise((resolve, reject) => {
                    tx.oncomplete = resolve;
                    tx.onerror = () => reject(tx.error);
                });

                // Remove the old localStorage key after successful migration
                localStorage.removeItem(fullKey);
            }

            // Also migrate the global 'messages' array
            const globalMessages = oldStorage.getItem('messages');
            if (Array.isArray(globalMessages) && globalMessages.length > 0) {
                // Global messages don't have a targetKey; store under '_global'
                const tx = db.transaction(MESSAGE_STORE, 'readwrite');
                const store = tx.objectStore(MESSAGE_STORE);
                for (const msg of globalMessages) {
                    const targetKey = msg._targetKey || '_global';
                    const record = { ...msg, targetKey };
                    if (!record.timestamp) record.timestamp = new Date().toISOString();
                    if (!record.id) record.id = Date.now() + '_' + Math.random().toString(36).substr(2, 9);
                    const ts = record.timestamp || '';
                    const from = record.from || record.from_node || '';
                    const text = (record.text || '').substring(0, 50);
                    record._dedupKey = `${targetKey}:${ts}:${from}:${text}`;
                    delete record._targetKey;
                    store.add(record);
                    totalMigrated++;
                }
                await new Promise((resolve, reject) => {
                    tx.oncomplete = resolve;
                    tx.onerror = () => reject(tx.error);
                });
                oldStorage.removeItem('messages');
            }

            // Mark migration complete
            await this._setMeta('migrated_from_localstorage', {
                migratedAt: new Date().toISOString(),
                messageCount: totalMigrated
            });

            console.log(`MessageDB: migrated ${totalMigrated} messages from localStorage`);
        } catch (e) {
            console.error('MessageDB: migration error', e);
        }

        return totalMigrated;
    }

    // ── Export / Import ───────────────────────────────────────────────

    /**
     * Export all messages as a JSON-serializable object.
     * @returns {Promise<object>}
     */
    async exportAll() {
        const db = await this._ensureOpen();
        return new Promise((resolve, reject) => {
            try {
                const tx = db.transaction(MESSAGE_STORE, 'readonly');
                const store = tx.objectStore(MESSAGE_STORE);
                const request = store.getAll();

                request.onsuccess = () => {
                    const messages = request.result || [];
                    // Strip internal _dbId for portability
                    const exported = messages.map(m => {
                        const copy = { ...m };
                        delete copy._dbId;
                        return copy;
                    });
                    resolve({
                        version: MESSAGE_DB_VERSION,
                        sessionId: this.sessionId,
                        exportedAt: new Date().toISOString(),
                        messageCount: exported.length,
                        messages: exported
                    });
                };

                request.onerror = (event) => reject(event.target.error);
            } catch (e) {
                reject(e);
            }
        });
    }

    /**
     * Import messages from an exported JSON object.
     * Deduplicates by _dedupKey to avoid duplicates.
     * @param {object} data - the exported data object
     * @returns {Promise<{imported: number, skipped: number}>}
     */
    async importMessages(data) {
        if (!data || !Array.isArray(data.messages)) {
            throw new Error('Invalid import data: missing messages array');
        }

        const db = await this._ensureOpen();
        let imported = 0;
        let skipped = 0;

        // Process in batches of 100
        const batchSize = 100;
        for (let i = 0; i < data.messages.length; i += batchSize) {
            const batch = data.messages.slice(i, i + batchSize);
            const tx = db.transaction(MESSAGE_STORE, 'readwrite');
            const store = tx.objectStore(MESSAGE_STORE);
            const dedupIndex = store.index('byDedupKey');

            for (const msg of batch) {
                // Check for duplicate
                if (msg._dedupKey) {
                    const exists = await new Promise((resolve) => {
                        const req = dedupIndex.count(IDBKeyRange.only(msg._dedupKey));
                        req.onsuccess = () => resolve(req.result > 0);
                        req.onerror = () => resolve(false);
                    });
                    if (exists) {
                        skipped++;
                        continue;
                    }
                }

                // Ensure required fields
                const record = { ...msg };
                delete record._dbId; // Let auto-increment assign new ID
                if (!record.timestamp) record.timestamp = new Date().toISOString();
                if (!record.id) record.id = Date.now() + '_' + Math.random().toString(36).substr(2, 9);
                if (!record._dedupKey) {
                    const ts = record.timestamp || '';
                    const from = record.from || record.from_node || '';
                    const text = (record.text || '').substring(0, 50);
                    record._dedupKey = `${record.targetKey || '_global'}:${ts}:${from}:${text}`;
                }

                store.add(record);
                imported++;
            }

            await new Promise((resolve, reject) => {
                tx.oncomplete = resolve;
                tx.onerror = () => {
                    const error = tx.error;
                    if (error && error.name === 'QuotaExceededError') {
                        this._handleQuotaExceeded();
                    }
                    reject(error);
                };
            });
        }

        return { imported, skipped };
    }

    // ── Meta store helpers ────────────────────────────────────────────

    async _getMeta(key) {
        const db = await this._ensureOpen();
        return new Promise((resolve, reject) => {
            try {
                const tx = db.transaction(META_STORE, 'readonly');
                const store = tx.objectStore(META_STORE);
                const request = store.get(key);
                request.onsuccess = () => resolve(request.result ? request.result.value : null);
                request.onerror = (event) => reject(event.target.error);
            } catch (e) {
                reject(e);
            }
        });
    }

    async _setMeta(key, value) {
        const db = await this._ensureOpen();
        return new Promise((resolve, reject) => {
            try {
                const tx = db.transaction(META_STORE, 'readwrite');
                const store = tx.objectStore(META_STORE);
                store.put({ key, value });
                tx.oncomplete = () => resolve();
                tx.onerror = (event) => reject(event.target.error);
            } catch (e) {
                reject(e);
            }
        });
    }

    // ── Quota handling ────────────────────────────────────────────────

    _handleQuotaExceeded() {
        console.error('MessageDB: storage quota exceeded');
        // Dispatch a custom event so the UI can show a modal
        window.dispatchEvent(new CustomEvent('messagedb-quota-exceeded', {
            detail: {
                sessionId: this.sessionId,
                message: 'Message storage is full. Please export and clear old messages, or increase your browser storage quota.'
            }
        }));
    }

    /**
     * Get approximate storage usage info.
     * @returns {Promise<{used: number, quota: number}|null>}
     */
    async getStorageEstimate() {
        if (navigator.storage && navigator.storage.estimate) {
            const est = await navigator.storage.estimate();
            return { used: est.usage || 0, quota: est.quota || 0 };
        }
        return null;
    }

    /**
     * Count total messages in the database.
     * @returns {Promise<number>}
     */
    async getMessageCount() {
        const db = await this._ensureOpen();
        return new Promise((resolve, reject) => {
            try {
                const tx = db.transaction(MESSAGE_STORE, 'readonly');
                const store = tx.objectStore(MESSAGE_STORE);
                const request = store.count();
                request.onsuccess = () => resolve(request.result);
                request.onerror = (event) => reject(event.target.error);
            } catch (e) {
                reject(e);
            }
        });
    }

    /**
     * Search messages by text content within a specific target.
     * Uses cursor scan with case-insensitive substring matching.
     * @param {string} targetKey - the target to search within
     * @param {string} query - search string (case-insensitive)
     * @param {number} limit - max results (default 100)
     * @returns {Promise<Array>} matching messages, newest first
     */
    async searchMessages(targetKey, query, limit = 100) {
        if (!query || !query.trim()) return [];
        const db = await this._ensureOpen();
        const needle = query.trim().toLowerCase();

        return new Promise((resolve, reject) => {
            try {
                const tx = db.transaction(MESSAGE_STORE, 'readonly');
                const store = tx.objectStore(MESSAGE_STORE);
                const index = store.index('byTargetTime');
                const range = IDBKeyRange.bound(
                    [targetKey, ''],
                    [targetKey, '\uffff']
                );

                const results = [];
                const request = index.openCursor(range, 'prev'); // newest first

                request.onsuccess = (event) => {
                    const cursor = event.target.result;
                    if (cursor && results.length < limit) {
                        const record = cursor.value;
                        const text = (record.text || record.decoded_text || '').toLowerCase();
                        const from = (record.from || '').toLowerCase();
                        if (text.includes(needle) || from.includes(needle)) {
                            results.push(record);
                        }
                        cursor.continue();
                    } else {
                        resolve(results);
                    }
                };

                request.onerror = (event) => reject(event.target.error);
            } catch (e) {
                reject(e);
            }
        });
    }

    /**
     * Search messages across ALL targets.
     * @param {string} query - search string (case-insensitive)
     * @param {number} limit - max results (default 100)
     * @returns {Promise<Array>} matching messages, newest first
     */
    async searchAllMessages(query, limit = 100) {
        if (!query || !query.trim()) return [];
        const db = await this._ensureOpen();
        const needle = query.trim().toLowerCase();

        return new Promise((resolve, reject) => {
            try {
                const tx = db.transaction(MESSAGE_STORE, 'readonly');
                const store = tx.objectStore(MESSAGE_STORE);
                const index = store.index('byTargetTime');

                const results = [];
                const request = index.openCursor(null, 'prev'); // newest first

                request.onsuccess = (event) => {
                    const cursor = event.target.result;
                    if (cursor && results.length < limit) {
                        const record = cursor.value;
                        const text = (record.text || record.decoded_text || '').toLowerCase();
                        const from = (record.from || '').toLowerCase();
                        if (text.includes(needle) || from.includes(needle)) {
                            results.push(record);
                        }
                        cursor.continue();
                    } else {
                        resolve(results);
                    }
                };

                request.onerror = (event) => reject(event.target.error);
            } catch (e) {
                reject(e);
            }
        });
    }

    /**
     * Close the database connection.
     */
    close() {
        if (this.db) {
            this.db.close();
            this.db = null;
            this._ready = null;
        }
    }

    /**
     * Delete the entire database for this session.
     * @returns {Promise<void>}
     */
    async deleteDatabase() {
        this.close();
        const dbName = `${MESSAGE_DB_NAME}_${this.sessionId}`;
        return new Promise((resolve, reject) => {
            const request = indexedDB.deleteDatabase(dbName);
            request.onsuccess = () => resolve();
            request.onerror = (event) => reject(event.target.error);
        });
    }
}

// Make available globally
window.MessageDB = MessageDB;
