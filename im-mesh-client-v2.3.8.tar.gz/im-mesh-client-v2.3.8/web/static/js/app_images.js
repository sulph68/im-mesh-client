/**
 * Meshtastic Web Client - Images Module: Encode, reassembly, segment send, settings, export, history, utils
 */

Object.assign(MeshtasticClient.prototype, {

updateNode(nodeData) {

    if (this.storage && nodeData) {
        this.storage.addOrUpdateNode(nodeData);

        // Refresh the nodes display
        const nodes = this.storage.getNodes();
        this.updateNodesList(nodes);
    }

    this.updateStatistics();
},

// ============================================
// IMAGE UPLOAD METHODS
// ============================================

openImageUploadModal() {
    const modal = document.getElementById('imageUploadModal');
    if (modal) {
        modal.style.display = 'flex';
        // Reset state
        const fileInput = document.getElementById('imageFileInput');
        if (fileInput) fileInput.value = '';
        document.getElementById('imagePreviewArea').style.display = 'none';
        document.getElementById('encodePreviewBtn').style.display = 'none';
        document.getElementById('confirmImageUpload').disabled = true;
        this._encodedSegments = null;

        // Load saved encoding settings
        this.loadEncodingSettingsToModal();
    }
},

closeImageUploadModal() {
    const modal = document.getElementById('imageUploadModal');
    if (modal) modal.style.display = 'none';
    this._encodedSegments = null;
},

handleImageSelected(event) {
    const file = event.target.files[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
        this.showMessage('Please select an image file', 'error');
        return;
    }

    // Show original preview and auto-select best image size
    const reader = new FileReader();
    reader.onload = (e) => {
        const originalPreview = document.getElementById('originalPreview');
        if (originalPreview) {
            originalPreview.src = e.target.result;
        }
        // Auto-select closest image size from source dimensions
        const tempImg = new Image();
        tempImg.onload = () => {
            this._autoSelectImageSize(tempImg.naturalWidth, tempImg.naturalHeight);
        };
        tempImg.src = e.target.result;

        document.getElementById('imagePreviewArea').style.display = 'block';
        document.getElementById('encodePreviewBtn').style.display = 'inline-flex';
        document.getElementById('encodedPreview').src = '';
        document.getElementById('encodingStats').innerHTML = '<em>Click "Encode Preview" to see encoding results</em>';
        this._selectedImageFile = file;
    };
    reader.readAsDataURL(file);
},

/**
 * Auto-select the closest image size option based on source image dimensions.
 * Maximum is 128x64. Picks the option whose aspect ratio best matches the source.
 */
_autoSelectImageSize(srcW, srcH) {
    const sizeSelect = document.getElementById('encImageSize');
    if (!sizeSelect) return;

    const srcAspect = srcW / srcH;
    const options = Array.from(sizeSelect.options).map(opt => {
        const [w, h] = opt.value.split('x').map(Number);
        return { value: opt.value, w, h, aspect: w / h, pixels: w * h };
    });

    // Score each option: prefer aspect ratio match, then larger size
    let bestOption = options[0];
    let bestScore = Infinity;
    for (const opt of options) {
        const aspectDiff = Math.abs(Math.log(opt.aspect / srcAspect));
        // Penalize smaller sizes slightly
        const sizePenalty = (srcW * srcH > opt.pixels) ? 0.1 : 0;
        const score = aspectDiff + sizePenalty;
        if (score < bestScore) {
            bestScore = score;
            bestOption = opt;
        }
    }

    sizeSelect.value = bestOption.value;
},

async encodeImagePreview() {
    if (!this._selectedImageFile || !this.sessionId) {
        this.showMessage('No image selected or no session', 'error');
        return;
    }

    const btn = document.getElementById('encodePreviewBtn');
    if (btn) btn.textContent = 'Encoding...';

    try {
        const formData = this._buildEncodeFormData();
        const response = await fetch('/api/encode-image', {
            method: 'POST',
            headers: { 'X-Session-ID': this.sessionId },
            body: formData
        });

        const data = await response.json();

        if (data.success) {
            this._encodedSegments = data.data.segments;

            // Use decoded_preview from backend (actual encoded result), 
            // fall back to preview_data (original resize)
            const bestPreview = data.data.decoded_preview || data.data.preview_data || null;
            this._encodedPreviewBase64 = bestPreview;

            // Show the decoded preview, or try frontend decode as fallback
            if (data.data.decoded_preview) {
                const encodedPreview = document.getElementById('encodedPreview');
                if (encodedPreview) {
                    encodedPreview.src = 'data:image/png;base64,' + data.data.decoded_preview;
                }
            } else {
                // Backend didn't provide decoded_preview, try decode via API
                await this._updateEncodedPreview(data.data);
            }

            // Show stats and segments
            this._renderEncodingStats(data.data.stats);
            this._renderSegmentList('encodingStats', this._encodedSegments);

            document.getElementById('confirmImageUpload').disabled = false;
            this.showMessage(`Image encoded: ${data.data.stats.segment_count} segments`, 'success');
        } else {
            this.showMessage('Encoding failed: ' + (data.message || 'Unknown error'), 'error');
        }
    } catch (error) {
        console.error('Encode preview error:', error);
        this.showMessage('Encoding failed: ' + error.message, 'error');
    } finally {
        if (btn) btn.textContent = 'Encode Preview';
    }
},

/** Build FormData with image file and encoding parameters. */
_buildEncodeFormData() {
    const formData = new FormData();
    formData.append('file', this._selectedImageFile);

    const sizeVal = (document.getElementById('encImageSize') || {}).value || '64x64';
    const [imgW, imgH] = sizeVal.split('x').map(Number);
    const gammaEl = document.getElementById('encGamma');
    const pixelCompressEl = document.getElementById('encPixelCompress');
    const params = {
        bit_depth: parseInt(document.getElementById('encBitDepth').value) || 1,
        image_width: imgW || 64,
        image_height: imgH || 64,
        mode: document.getElementById('encMode').value || 'best',
        segment_length: parseInt(document.getElementById('encSegmentLen').value) || 200,
        gamma: gammaEl ? parseFloat(gammaEl.value) : 1.0,
        pixel_compress: pixelCompressEl ? pixelCompressEl.checked : false
    };
    formData.append('encoding_params', JSON.stringify(params));
    return formData;
},

/** Decode encoded segments back to show the actual encoded image preview. */
async _updateEncodedPreview(encodeResult) {
    try {
        const decodeResp = await fetch('/api/decode-segments', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-Session-ID': this.sessionId
            },
            body: JSON.stringify({ segments: encodeResult.segments })
        });
        const decodeData = await decodeResp.json();
        if (decodeData.success && decodeData.data && decodeData.data.image_data) {
            this._encodedPreviewBase64 = decodeData.data.image_data;
            const encodedPreview = document.getElementById('encodedPreview');
            if (encodedPreview) {
                encodedPreview.src = 'data:image/png;base64,' + decodeData.data.image_data;
            }
        } else {
            this._setPreviewFallback(encodeResult.preview_data);
        }
    } catch (decErr) {
        console.warn('Could not decode segments for preview:', decErr);
        this._setPreviewFallback(encodeResult.preview_data);
    }
},

/** Set the encoded preview image to the fallback resized preview. */
_setPreviewFallback(previewData) {
    if (previewData) {
        const encodedPreview = document.getElementById('encodedPreview');
        if (encodedPreview) {
            encodedPreview.src = 'data:image/png;base64,' + previewData;
        }
    }
},

/** Render encoding statistics in the stats container. */
_renderEncodingStats(stats) {
    const statsEl = document.getElementById('encodingStats');
    if (statsEl) {
        let html = `
            <div class="stat-row"><span class="stat-label">Packets required:</span> <span class="stat-value">${stats.segment_count}</span></div>
            <div class="stat-row"><span class="stat-label">Payload size:</span> <span class="stat-value">${stats.total_bytes} bytes</span></div>
            <div class="stat-row"><span class="stat-label">Encoding:</span> <span class="stat-value">${stats.compression_method}</span></div>
            <div class="stat-row"><span class="stat-label">Dimensions:</span> <span class="stat-value">${stats.image_dimensions}</span></div>
            <div class="stat-row"><span class="stat-label">Bit depth:</span> <span class="stat-value">${stats.bit_depth}-bit</span></div>
        `;
        if (stats.gamma && stats.gamma !== 1.0) {
            html += `<div class="stat-row"><span class="stat-label">Gamma:</span> <span class="stat-value">${stats.gamma}</span></div>`;
        }
        if (stats.pixel_compress) {
            html += `<div class="stat-row"><span class="stat-label">2x2 compress:</span> <span class="stat-value">Yes</span></div>`;
        }
        statsEl.innerHTML = html;
    }
},

/**
 * Render a list of segments inside a disclosure triangle with per-segment
 * copy and resend buttons and a "Copy All" button. Appended to the given container.
 * @param {string} containerId - DOM id of the container element
 * @param {Array} segments - array of segment text strings
 * @param {number|null} [channel] - channel index for resend (optional)
 * @param {string|null} [toNode] - destination node for resend (optional)
 */
_renderSegmentList(containerId, segments, channel, toNode) {
    if (!segments || segments.length === 0) return;
    const container = document.getElementById(containerId);
    if (!container) return;

    const canResend = (channel !== undefined && channel !== null);

    // Build disclosure triangle (details/summary)
    const details = document.createElement('details');
    details.className = 'segment-disclosure';
    const summary = document.createElement('summary');
    summary.textContent = `Segments (${segments.length})`;
    details.appendChild(summary);

    // "Copy All Segments" button at top
    const copyAllBtn = document.createElement('button');
    copyAllBtn.className = 'btn btn-small btn-copy-all';
    copyAllBtn.textContent = 'Copy All Segments';
    copyAllBtn.addEventListener('click', () => {
        const allText = segments.join('\n');
        this._copyToClipboard(allText).then(() => {
            copyAllBtn.textContent = 'Copied!';
            setTimeout(() => { copyAllBtn.textContent = 'Copy All Segments'; }, COPY_FEEDBACK_MS);
        });
    });
    details.appendChild(copyAllBtn);

    // Each segment with its own copy + resend buttons
    segments.forEach((seg, idx) => {
        const row = document.createElement('div');
        row.className = 'segment-row';

        const label = document.createElement('span');
        label.className = 'segment-label';
        label.textContent = `Seg ${idx + 1}/${segments.length}:`;

        const value = document.createElement('code');
        value.className = 'segment-value';
        value.textContent = seg.length > 80 ? seg.substring(0, 77) + '...' : seg;
        value.title = seg;  // Full text on hover

        const copyBtn = document.createElement('button');
        copyBtn.className = 'btn btn-tiny btn-copy-seg';
        copyBtn.textContent = 'Copy';
        copyBtn.addEventListener('click', () => {
            this._copyToClipboard(seg).then(() => {
                copyBtn.textContent = 'OK';
                setTimeout(() => { copyBtn.textContent = 'Copy'; }, COPY_FEEDBACK_MS);
            });
        });

        row.appendChild(label);
        row.appendChild(value);
        row.appendChild(copyBtn);

        // Per-segment Resend button (only for sent segments with channel info)
        if (canResend) {
            const resendBtn = document.createElement('button');
            resendBtn.className = 'btn btn-tiny btn-resend-seg';
            resendBtn.textContent = 'Resend';
            resendBtn.addEventListener('click', async () => {
                resendBtn.disabled = true;
                resendBtn.textContent = 'Sending...';
                try {
                    // Send via binary portnum 288 by default for image segments
                    const payload = { data: seg, channel: channel, want_ack: true };
                    if (toNode) payload.to_node = toNode;
                    const response = await fetch('/api/messages/send-binary', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                            'X-Session-ID': this.sessionId
                        },
                        body: JSON.stringify(payload)
                    });
                    const data = await response.json();
                    if (data.success) {
                        resendBtn.textContent = 'Sent';
                        this.logCommunication('OUT', `Resent seg ${idx + 1}/${segments.length} [bin]`, 'success');
                        this.showMessage(`Segment ${idx + 1}/${segments.length} resent`, 'success');
                    } else {
                        resendBtn.textContent = 'Failed';
                        this.showMessage('Resend failed: ' + (data.message || 'Unknown'), 'error');
                    }
                } catch (e) {
                    resendBtn.textContent = 'Error';
                    this.showMessage('Resend error: ' + e.message, 'error');
                }
                setTimeout(() => {
                    resendBtn.disabled = false;
                    resendBtn.textContent = 'Resend';
                }, 2000);
            });
            row.appendChild(resendBtn);
        }

        details.appendChild(row);
    });

    container.appendChild(details);
},

/**
 * Copy text to clipboard. Works on both HTTPS and plain HTTP.
 * Uses navigator.clipboard when available, falls back to execCommand.
 * Returns a Promise that resolves when copy is done.
 */
_copyToClipboard(text) {
    return new Promise((resolve, reject) => {
        // navigator.clipboard is only available in secure contexts (HTTPS / localhost)
        if (navigator.clipboard && typeof navigator.clipboard.writeText === 'function') {
            navigator.clipboard.writeText(text).then(resolve).catch(() => {
                // Fallback if clipboard API rejects (e.g. permissions)
                this._fallbackCopy(text);
                resolve();
            });
        } else {
            this._fallbackCopy(text);
            resolve();
        }
    });
},

/**
 * Fallback copy using a temporary textarea (for non-HTTPS contexts).
 */
_fallbackCopy(text) {
    const textarea = document.createElement('textarea');
    textarea.value = text;
    textarea.style.position = 'fixed';
    textarea.style.left = '-9999px';
    textarea.style.opacity = '0';
    document.body.appendChild(textarea);
    textarea.focus();
    textarea.select();
    try { document.execCommand('copy'); } catch (e) { /* ignore */ }
    document.body.removeChild(textarea);
},

/**
 * Check if a text message is an image segment.
 * Format: IMG{w}x{h}:{method}{bitdepth}:{checksum}:{seg}[/{total}]:{data}
 * Checksum is required (8 hex chars).
 */
_isImageSegment(text) {
    if (!text || typeof text !== 'string') return false;
    const t = text.trim();
    return /^IMG\d+x\d+:[TRXVtrxv]\d+:[0-9a-fA-F]{8}:\d+(?:\/\d+)?:.+$/s.test(t);
},

/**
 * Parse an image segment header to extract metadata.
 * Returns null if not a valid segment.
 * Format: IMG{w}x{h}:{method}{depth}:{checksum}:{seg}[/{total}]:{data}
 * Checksum is required (8 hex chars).
 * 
 * NOTE: Field names must match what app_messages.js expects:
 *   segNum, totalSegments, fullSegment, compressionMethod, useHeatshrink, checksum
 */
_parseImageSegment(text) {
    if (!text) return null;
    const trimmed = text.trim();
    const methodNames = { T: 'tile_rle', R: 'rle_nibble', X: 'rle_nibble_xor', V: 'xor_vlq_rle' };

    const match = trimmed.match(/^IMG(\d+)x(\d+):([TRXVtrxv])(\d+):([0-9a-fA-F]{8}):(\d+)(?:\/(\d+))?:(.+)$/s);
    if (!match) return null;

    const methodCode = match[3].toUpperCase();
    return {
        width: parseInt(match[1], 10),
        height: parseInt(match[2], 10),
        method: match[3],
        methodCode: match[3],
        compressionMethod: methodNames[methodCode] || 'unknown',
        useHeatshrink: match[3] === match[3].toLowerCase(),
        bitDepth: parseInt(match[4], 10),
        checksum: match[5].toLowerCase(),
        segIndex: parseInt(match[6], 10),
        segNum: parseInt(match[6], 10),
        totalSegs: match[7] ? parseInt(match[7], 10) : 1,
        totalSegments: match[7] ? parseInt(match[7], 10) : 1,
        data: match[8],
        payload: match[8],
        raw: trimmed,
        fullSegment: trimmed
    };
},

/**
 * Post-render scan: walk all rendered received messages in the container
 * and create grouped message boxes for image segments sharing the same checksum.
 * Each group box contains all segment disclosures in one message bubble.
 */
_scanForImageSegments(container) {
    if (!container) return;
    const allMessages = Array.from(container.querySelectorAll('.message.received, .message.binary-msg'));

    // First pass: parse all image segments and collect metadata
    const segmentInfos = []; // {index, element, parsed, sender, time}
    for (let i = 0; i < allMessages.length; i++) {
        const el = allMessages[i];

        // Skip elements that are already part of a group box
        if (el.classList.contains('segment-group-box')) continue;

        let parsed = null;
        if (el.dataset.imageSegment === 'true' && el.dataset.segPayload) {
            parsed = this._parseImageSegment(el.dataset.segPayload);
        } else {
            const contentEl = el.querySelector('.message-content');
            if (!contentEl) continue;
            const text = contentEl.textContent || '';
            if (!this._isImageSegment(text)) continue;
            parsed = this._parseImageSegment(text);
        }
        if (!parsed) continue;

        // Tag element
        el.dataset.imageSegment = 'true';
        el.dataset.segNum = parsed.segNum;
        el.dataset.segPayload = parsed.fullSegment;
        if (parsed.checksum) el.dataset.checksum = parsed.checksum;

        // Extract sender and time from the original message
        const fromEl = el.querySelector('.message-from');
        const sender = fromEl ? fromEl.textContent.trim() : 'Unknown';
        const timeEl = el.querySelector('.message-time');
        const time = timeEl ? timeEl.textContent.trim() : '';

        segmentInfos.push({ index: i, element: el, parsed, sender, time });
    }

    // Group segments by checksum
    const checksumGroups = new Map();

    for (const info of segmentInfos) {
        const key = info.parsed.checksum;
        if (!key) continue; // Skip segments without checksum (shouldn't happen)
        if (!checksumGroups.has(key)) checksumGroups.set(key, []);
        checksumGroups.get(key).push(info);
    }

    // Process checksum-based groups - create grouped message boxes
    for (const [checksum, group] of checksumGroups) {
        // Check if a group box already exists for this checksum
        const existingBox = container.querySelector(`.segment-group-box[data-checksum="${checksum}"]`);
        if (existingBox) {
            // Check if it already has a decoded image
            if (existingBox.querySelector('.reassemble-result img')) continue;
        }

        // Deduplicate by segment index (keep last occurrence)
        const segMap = new Map();
        for (const info of group) {
            segMap.set(info.parsed.segIndex, info);
        }
        const deduped = Array.from(segMap.values()).sort((a, b) => a.parsed.segIndex - b.parsed.segIndex);

        // Hide all individual segment messages
        for (const info of group) {
            info.element.classList.add('segment-grouped');
            info.element.style.display = 'none';
        }

        // Remove old group box if rebuilding
        if (existingBox) existingBox.remove();

        // Find insertion point: after the last segment element in DOM order
        const lastSegEl = group[group.length - 1].element;

        // Build the grouped message box
        const groupBox = this._buildSegmentGroupBox(deduped, checksum);
        lastSegEl.insertAdjacentElement('afterend', groupBox);
    }
},

/**
 * Build a single grouped message box element containing all segments
 * for the same image. Hides individual segment messages and replaces
 * them with one consolidated message bubble.
 *
 * @param {Array} segInfos - [{element, parsed, sender, time}, ...]
 * @param {string} checksum - shared checksum for this image
 * @returns {HTMLElement} the group box element
 */
_buildSegmentGroupBox(segInfos, checksum) {
    const segments = segInfos.map(info => ({ parsed: info.parsed, element: info.element }));

    // Collect unique senders and time range
    const senders = new Set();
    const times = [];
    for (const info of segInfos) {
        senders.add(info.sender);
        if (info.time) times.push(info.time);
    }
    const isMultiSender = senders.size > 1;
    const senderList = Array.from(senders).join(', ');
    const timeRange = times.length > 1 ? `${times[0]} - ${times[times.length - 1]}` : (times[0] || '');

    const totalExpected = segments.reduce((max, s) => Math.max(max, s.parsed.totalSegs || s.parsed.segIndex + 1), 1);
    const segIndices = new Set(segments.map(s => s.parsed.segIndex));
    const uniqueCount = segIndices.size;
    const isComplete = uniqueCount >= totalExpected;

    // Create the group box
    const box = document.createElement('div');
    box.className = 'message received segment-group-box';
    if (checksum) box.dataset.checksum = checksum;

    // Header: sender(s), time range, and delete button
    const header = document.createElement('div');
    header.className = 'message-header';
    header.innerHTML = `
        <span class="message-from">${this.escapeHtml(senderList)}</span>
        <span class="message-time">${this.escapeHtml(timeRange)}</span>
    `;

    box.appendChild(header);

    // Delete button for the entire segment group (direct child of box for absolute positioning)
    const deleteBtn = document.createElement('button');
    deleteBtn.className = 'btn-delete-msg';
    deleteBtn.textContent = '\u00D7';
    deleteBtn.title = 'Delete all segments in this group';
    deleteBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        this._deleteSegmentGroup(checksum, box);
    });
    box.appendChild(deleteBtn);

    // Segment disclosures - one per unique segment
    for (const info of segInfos) {
        const p = info.parsed;
        const isBinary = info.element.classList.contains('binary-msg');

        // Build label: prefix with sender name if multi-sender
        let labelText = '';
        if (isMultiSender) labelText += `${info.sender}: `;
        labelText += `Image segment ${p.segNum}/${p.totalSegments}`;

        const details = document.createElement('details');
        details.className = 'segment-disclosure';
        const summary = document.createElement('summary');
        summary.className = 'image-segment-info';
        summary.innerHTML = `<span class="image-segment-label ${isBinary ? 'binary' : 'text'}">${this.escapeHtml(labelText)}</span>`;
        details.appendChild(summary);

        // Segment data content (collapsed by default)
        const dataDiv = document.createElement('div');
        dataDiv.className = 'segment-data';
        dataDiv.textContent = p.fullSegment;
        details.appendChild(dataDiv);

        // Copy Payload button
        const segText = p.fullSegment;
        const copyBtn = document.createElement('button');
        copyBtn.className = 'copy-payload-btn';
        copyBtn.textContent = 'Copy Payload';
        copyBtn.addEventListener('click', () => {
            this._copyToClipboard(segText).then(() => {
                this.showMessage('Payload copied', 'success');
            });
        });
        details.appendChild(copyBtn);

        // Forward button
        const fwdBtn = document.createElement('button');
        fwdBtn.className = 'copy-payload-btn btn-forward-seg';
        fwdBtn.textContent = 'Forward to Channel';
        fwdBtn.addEventListener('click', () => {
            this._forwardSegmentToChannel(segText);
        });
        details.appendChild(fwdBtn);

        box.appendChild(details);
    }

    // Add reassemble/status area
    this._addReassembleButton(segments, totalExpected, uniqueCount, isComplete, box);

    return box;
},

/**
 * Delete an entire segment group: remove all individual segment messages
 * (from DOM and IndexedDB) that share the given checksum, then remove
 * the group box itself.
 */
_deleteSegmentGroup(checksum, groupBoxEl) {
    if (!checksum) return;

    const container = document.getElementById('messagesContainer');
    if (!container) return;

    // Find all hidden individual segment messages with this checksum
    const segEls = container.querySelectorAll(`.message[data-checksum="${checksum}"]`);
    for (const el of segEls) {
        // Delete from IndexedDB
        const dbId = el.dataset.dbId ? Number(el.dataset.dbId) : NaN;
        if (dbId && !isNaN(dbId) && this.storage) {
            this.storage.deleteMessageAsync(dbId).catch(e => {
                console.error('Error deleting segment from DB:', e);
            });
        }
        el.remove();
    }

    // Remove the group box from DOM
    if (groupBoxEl) {
        groupBoxEl.remove();
    }

    this.showMessage('Image segments deleted', 'success');
},

/**
 * After rendering a received message, check if it is an image segment.
 * Finds or creates a grouped message box for all segments sharing the
 * same checksum. Checksum is required for all image segments.
 */
_checkForImageSegments(messageElement, messageData) {
    const text = (messageData.text || messageData.decoded_text || messageData.payload || '').trim();
    if (!this._isImageSegment(text)) return;

    const currentParsed = this._parseImageSegment(text);
    if (!currentParsed || !currentParsed.checksum) return;

    const container = document.getElementById('messagesContainer');
    if (!container) return;

    // Tag element with segment data attributes
    messageElement.dataset.imageSegment = 'true';
    messageElement.dataset.segNum = currentParsed.segNum;
    messageElement.dataset.segPayload = currentParsed.fullSegment;
    messageElement.dataset.checksum = currentParsed.checksum;

    // Collect all segment messages with this checksum
    const allMessages = Array.from(container.querySelectorAll('.message.received, .message.binary-msg'));
    const group = [];
    for (const el of allMessages) {
        if (el.classList.contains('segment-group-box')) continue;
        if (el.dataset.checksum !== currentParsed.checksum && el !== messageElement) {
            // Check content
            const contentEl = el.querySelector('.message-content');
            if (!contentEl) continue;
            const msgText = contentEl.textContent || '';
            const parsed = this._parseImageSegment(msgText);
            if (!parsed || parsed.checksum !== currentParsed.checksum) continue;
            el.dataset.imageSegment = 'true';
            el.dataset.segPayload = parsed.fullSegment;
            el.dataset.checksum = parsed.checksum;
            const sEl = el.querySelector('.message-from');
            const tEl = el.querySelector('.message-time');
            group.push({ element: el, parsed, sender: sEl ? sEl.textContent.trim() : 'Unknown', time: tEl ? tEl.textContent.trim() : '' });
        } else if (el.dataset.checksum === currentParsed.checksum || el === messageElement) {
            const p = el.dataset.segPayload ? this._parseImageSegment(el.dataset.segPayload) : null;
            if (!p) continue;
            const sEl = el.querySelector('.message-from');
            const tEl = el.querySelector('.message-time');
            group.push({ element: el, parsed: p, sender: sEl ? sEl.textContent.trim() : 'Unknown', time: tEl ? tEl.textContent.trim() : '' });
        }
    }

    if (group.length < 1) return;

    // Deduplicate by segment index (keep last)
    const segMap = new Map();
    for (const info of group) {
        segMap.set(info.parsed.segIndex, info);
    }
    const deduped = Array.from(segMap.values()).sort((a, b) => a.parsed.segIndex - b.parsed.segIndex);

    // Hide all individual segment messages
    for (const info of group) {
        info.element.classList.add('segment-grouped');
        info.element.style.display = 'none';
    }

    // Remove existing group box for this checksum
    const existingBox = container.querySelector(`.segment-group-box[data-checksum="${currentParsed.checksum}"]`);
    if (existingBox) existingBox.remove();

    // Insert new group box after the last segment element
    const lastSegEl = group[group.length - 1].element;
    const groupBox = this._buildSegmentGroupBox(deduped, currentParsed.checksum);
    lastSegEl.insertAdjacentElement('afterend', groupBox);
},

/**
 * Add reassemble/status controls to a target element (group box or last segment).
 * @param {Array} segments - [{parsed, element}, ...]
 * @param {number} totalExpected
 * @param {number} uniqueCount
 * @param {boolean} isComplete
 * @param {HTMLElement} [targetEl] - element to append controls to (defaults to last segment)
 */
_addReassembleButton(segments, totalExpected, uniqueCount, isComplete, targetEl) {
    const appendTo = targetEl || segments[segments.length - 1].element;
    const checksum = segments[0].parsed.checksum || null;

    // Collect unique segments for immediate use
    const getUniqueSegments = (segs) => {
        const seen = new Set();
        const unique = [];
        for (const s of segs) {
            if (!seen.has(s.parsed.segIndex)) {
                seen.add(s.parsed.segIndex);
                unique.push(s.parsed.raw);
            }
        }
        unique.sort((a, b) => {
            const pA = this._parseImageSegment(a);
            const pB = this._parseImageSegment(b);
            return (pA ? pA.segIndex : 0) - (pB ? pB.segIndex : 0);
        });
        return unique;
    };

    // Build the button container
    const btnContainer = document.createElement('div');
    btnContainer.className = 'reassemble-btn-container';

    let statusText = isComplete
        ? `Image complete (${uniqueCount}/${totalExpected} segments)`
        : `Incomplete (${uniqueCount}/${totalExpected} segments received)`;
    if (checksum) statusText += ` [${checksum}]`;

    const statusSpan = document.createElement('span');
    statusSpan.className = 'reassemble-status';
    statusSpan.textContent = statusText;
    btnContainer.appendChild(statusSpan);

    // "Copy All Segments" button
    const copyAllBtn = document.createElement('button');
    copyAllBtn.className = 'btn btn-small btn-reassemble';
    copyAllBtn.textContent = 'Copy All Segments';
    copyAllBtn.style.marginRight = '0.5rem';
    copyAllBtn.addEventListener('click', () => {
        const allText = getUniqueSegments(segments).join('\n');
        this._copyToClipboard(allText).then(() => {
            this.showMessage(`${getUniqueSegments(segments).length} segment(s) copied`, 'success');
        });
    });
    btnContainer.appendChild(copyAllBtn);

    if (isComplete) {
        const btn = document.createElement('button');
        btn.className = 'btn btn-small btn-reassemble';
        btn.textContent = 'Show Image';
        btn.addEventListener('click', () => {
            this._reassembleWithHistoryScan(segments, checksum, totalExpected, appendTo);
        });
        btnContainer.appendChild(btn);
    } else {
        const btn = document.createElement('button');
        btn.className = 'btn btn-small btn-reassemble';
        btn.textContent = 'Try Reassemble';
        btn.addEventListener('click', () => {
            this._reassembleWithHistoryScan(segments, checksum, totalExpected, appendTo);
        });
        btnContainer.appendChild(btn);

        if (checksum) {
            const scanBtn = document.createElement('button');
            scanBtn.className = 'btn btn-small btn-reassemble btn-scan-history';
            scanBtn.textContent = 'Scan History';
            scanBtn.addEventListener('click', () => {
                this._reassembleWithHistoryScan(segments, checksum, totalExpected, appendTo);
            });
            btnContainer.appendChild(scanBtn);
        }
    }

    appendTo.appendChild(btnContainer);

    // Auto-reassemble if all segments are present
    if (isComplete) {
        const uniqueSegments = getUniqueSegments(segments);
        setTimeout(() => this._reassembleImage(uniqueSegments, appendTo, true), 100);
    }
},

/**
 * Fix 3: Reassemble with history scan - search IndexedDB for additional segments
 * matching the checksum from any sender/channel, then reassemble using the best
 * (latest) segments available.
 */
async _reassembleWithHistoryScan(domSegments, checksum, totalExpected, lastEl) {
    // Start with DOM-visible segments
    const segMap = new Map(); // segIndex -> raw segment text
    for (const s of domSegments) {
        segMap.set(s.parsed.segIndex, s.parsed.raw);
    }

    // If we have a checksum and are missing segments, scan IndexedDB
    if (checksum && segMap.size < totalExpected && this.storage && this.storage.messageDB) {
        try {
            const historySegments = await this._searchHistoryForChecksum(checksum);
            for (const raw of historySegments) {
                const parsed = this._parseImageSegment(raw);
                if (parsed && parsed.checksum === checksum) {
                    // Only use if we don't already have this segment index
                    // or replace with the latest one
                    segMap.set(parsed.segIndex, raw);
                }
            }
        } catch (e) {
            console.warn('History scan failed:', e);
        }
    }

    // Build sorted unique segments array
    const allSegments = Array.from(segMap.entries())
        .sort((a, b) => a[0] - b[0])
        .map(([_, raw]) => raw);

    this._reassembleImage(allSegments, lastEl);
},

/**
 * Search IndexedDB message history for segments matching a checksum.
 * Scoped to the current channel/node conversation thread only.
 * Returns array of raw segment text strings.
 */
async _searchHistoryForChecksum(checksum) {
    if (!this.storage || !this.storage.messageDB || !checksum) return [];

    const results = [];
    try {
        // Search only the current target's history (scoped to this thread)
        const key = this.getMessageStorageKey();
        if (key) {
            const messages = await this.storage.getMessagesAsync(key);
            for (const msg of messages) {
                const text = (msg.text || msg.decoded_text || msg.rawPayload || '').trim();
                if (this._isImageSegment(text)) {
                    const parsed = this._parseImageSegment(text);
                    if (parsed && parsed.checksum === checksum) {
                        results.push(text);
                    }
                }
            }
        }
    } catch (e) {
        console.warn('Error searching history for checksum:', e);
    }

    return results;
},

/**
 * Fix 2: Forward a received image segment into the current channel/target.
 * Sends the segment text as a new message via the send API.
 */
async _forwardSegmentToChannel(segmentText) {
    if (!this.sessionId) {
        this.showMessage('No active session', 'error');
        return;
    }
    if (!this.sendTarget) {
        this.showMessage('No channel or node selected', 'error');
        return;
    }

    const channel = this.sendTarget.type === 'channel' ? this.sendTarget.id : (this.selectedChannelIndex || 0);
    const toNode = (this.sendTarget.type === 'node' && this.sendTarget.id) ? this.sendTarget.id : null;

    // Forward using binary portnum 288 (CUSTOM_IMAGE_APP) to preserve
    // the same portnum the segment was originally sent with.
    const payload = {
        data: segmentText,
        channel: channel,
        want_ack: true
    };
    if (toNode) payload.to_node = toNode;

    try {
        const response = await fetch('/api/messages/send-binary', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-Session-ID': this.sessionId
            },
            body: JSON.stringify(payload)
        });
        const data = await response.json();
        if (data.success) {
            const parsed = this._parseImageSegment(segmentText);
            const label = parsed ? `Seg ${parsed.segNum}/${parsed.totalSegments}` : 'Segment';
            this.showMessage(`${label} forwarded to ${this.sendTarget.name}`, 'success');
            this.logCommunication('OUT', `Forwarded ${label} [bin] to ${this.sendTarget.name}`, 'success');

            // Add to chat display
            this.addChatMessage({
                from: 'You',
                text: segmentText,
                timestamp: new Date().toISOString(),
                type: 'sent',
                to: this.sendTarget.name,
                channel: channel,
                packet_id: data.data ? data.data.packet_id : null,
                want_ack: true,
                ack_status: 'sent',
                _targetKey: this.getMessageStorageKey()
            });
        } else {
            this.showMessage('Forward failed: ' + (data.message || 'Unknown error'), 'error');
        }
    } catch (error) {
        console.error('Forward segment error:', error);
        this.showMessage('Forward failed: ' + error.message, 'error');
    }
},

/**
 * Send segments to the server for decoding and display the resulting image.
 * @param {boolean} silent - If true, suppress toast notifications (used by auto-reassemble)
 */
async _reassembleImage(segments, afterElement, silent) {
    if (!this.sessionId) {
        this.showMessage('No active session', 'error');
        return;
    }

    // Find or create result container
    let resultContainer = afterElement.querySelector('.reassemble-result');
    if (!resultContainer) {
        resultContainer = document.createElement('div');
        resultContainer.className = 'reassemble-result';
        afterElement.appendChild(resultContainer);
    }
    resultContainer.innerHTML = '<span class="reassemble-loading">Decoding image...</span>';

    try {
        const response = await fetch('/api/decode-segments', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-Session-ID': this.sessionId
            },
            body: JSON.stringify({ segments: segments })
        });

        const data = await response.json();

        if (data.success && data.data && data.data.image_data) {
            const stats = data.data.stats || {};
            resultContainer.innerHTML = `
                <div class="reassembled-image-info">
                    Decoded: ${stats.width || '?'}x${stats.height || '?'}, 
                    ${stats.compression_method || 'unknown'}, 
                    ${stats.segments_received || segments.length} segments
                </div>
                <img src="data:image/png;base64,${data.data.image_data}" 
                     alt="Reassembled Image" 
                     class="reassembled-image">
            `;
            if (!silent) this.showMessage('Image reassembled successfully', 'success');

            // Persist the decoded image into localStorage so it survives panel switches
            this._persistDecodedImage(segments, data.data.image_data, stats);
        } else {
            resultContainer.innerHTML = `<span class="reassemble-error">Decode failed: ${this.escapeHtml(data.message || 'Unknown error')}</span>`;
            if (!silent) this.showMessage('Image decode failed: ' + (data.message || 'Unknown error'), 'error');
        }
    } catch (error) {
        console.error('Reassemble error:', error);
        resultContainer.innerHTML = `<span class="reassemble-error">Error: ${this.escapeHtml(error.message)}</span>`;
        if (!silent) this.showMessage('Reassemble failed: ' + error.message, 'error');
    }
},

/**
 * Persist decoded image data into IndexedDB messages.
 * Finds the last segment message in storage and attaches the decoded image
 * so it can be rendered on next history load without re-decoding.
 */
async _persistDecodedImage(segmentTexts, imageBase64, stats) {
    if (!this.storage || !this.storage.messageDB || !segmentTexts || segmentTexts.length === 0) return;
    try {
        const key = this.getMessageStorageKey();
        if (!key) return;
        const lastSeg = segmentTexts[segmentTexts.length - 1];
        await this.storage.messageDB.updateMessageByText(key, lastSeg, {
            _decodedImage: imageBase64,
            _decodedStats: stats
        });
    } catch (e) {
        console.error('Error persisting decoded image:', e);
    }
},

async sendImageSegments() {
    if (!this._encodedSegments || this._encodedSegments.length === 0) {
        this.showMessage('No encoded image to send. Click "Encode Preview" first.', 'warning');
        return;
    }

    if (!this.sessionId) {
        this.showMessage('No active session', 'error');
        return;
    }

    const confirmBtn = document.getElementById('confirmImageUpload');
    if (confirmBtn) {
        confirmBtn.disabled = true;
        confirmBtn.textContent = 'Sending...';
    }

    const segments = [...this._encodedSegments];
    const totalSegments = segments.length;
    const channel = this.sendTarget.type === 'channel' ? this.sendTarget.id : (this.selectedChannelIndex || 0);
    const toNode = (this.sendTarget.type === 'node' && this.sendTarget.id) ? this.sendTarget.id : null;
    const previewBase64 = this._encodedPreviewBase64 || null;

    this.closeImageUploadModal();

    // Build the message UI
    const msgUid = 'img-send-' + Date.now();
    const { messageElement, statusContainer } = this._buildImageSendUI(msgUid, totalSegments, previewBase64);

    // Per-segment tracking state
    const segState = {
        ackState: new Array(totalSegments).fill(null),
        packetIds: new Array(totalSegments).fill(null),
        _segments: segments,
        _channel: channel,
        _toNode: toNode
    };

    // Create abort button
    this._imageSendAborted = false;
    this._addImageAbortButton(msgUid, statusContainer);

    // Create bound helpers for send/retry/ack
    const sendOne = (idx) => this._sendOneImageSegment(idx, segments, channel, toNode, msgUid, segState);
    const addRetry = (idx) => this._addSegmentRetryButton(idx, msgUid, segState, sendOne);
    const startAckTimeout = (idx) => this._startSegmentAckTimeout(idx, msgUid, segState, addRetry);

    // Set up ACK handler for image segments
    this._imageSegmentAckHandler = (ackData) => {
        this._handleImageSegmentAck(ackData, msgUid, totalSegments, segState);
    };

    // Send segments sequentially with 15s delay
    const { allOk, aborted } = await this._sendSegmentsSequentially(
        totalSegments, sendOne, addRetry, startAckTimeout, msgUid, segState
    );

    // Clean up and finalize
    this._finalizeImageSend(msgUid, messageElement, segments, segState, totalSegments, allOk, aborted);

    if (confirmBtn) {
        confirmBtn.disabled = false;
        confirmBtn.textContent = 'Send Image';
    }
},

/** Build the image send message element with per-segment status rows. */
_buildImageSendUI(msgUid, totalSegments, previewBase64) {
    const messagesContainer = document.getElementById('messagesContainer');
    const messageElement = document.createElement('div');
    messageElement.className = 'message sent';
    messageElement.id = msgUid;

    let previewHtml = '';
    if (previewBase64) {
        previewHtml = `<img src="data:image/png;base64,${previewBase64}" alt="Sent Image Preview" class="sent-image-preview">`;
    }

    messageElement.innerHTML = `
        <div class="message-header">
            <span class="message-from sent-name">You</span>
            <span class="message-time">${new Date().toLocaleTimeString()}</span>
        </div>
        <div class="message-content">[Image] Sending ${totalSegments} segment${totalSegments > 1 ? 's' : ''}...</div>
        ${previewHtml}
        <div class="segment-send-status" id="${msgUid}-status"></div>
    `;
    messagesContainer.appendChild(messageElement);
    messagesContainer.scrollTop = messagesContainer.scrollHeight;

    // Build per-segment status rows
    const statusContainer = document.getElementById(`${msgUid}-status`);
    for (let i = 0; i < totalSegments; i++) {
        const row = document.createElement('div');
        row.className = 'segment-row';
        row.id = `${msgUid}-seg-${i}`;
        row.innerHTML = `
            <span class="seg-label">Seg ${i + 1}/${totalSegments}</span>
            <span class="seg-state seg-waiting" id="${msgUid}-seg-${i}-state">Waiting</span>
        `;
        statusContainer.appendChild(row);
    }

    return { messageElement, statusContainer };
},

/** Add abort button to segment status container. */
_addImageAbortButton(msgUid, statusContainer) {
    const abortBtn = document.createElement('button');
    abortBtn.className = 'btn btn-small btn-abort-send';
    abortBtn.id = `${msgUid}-abort`;
    abortBtn.textContent = 'Abort Send';
    abortBtn.addEventListener('click', () => {
        this._imageSendAborted = true;
        abortBtn.disabled = true;
        abortBtn.textContent = 'Aborting...';
    });
    statusContainer.appendChild(abortBtn);
},

/** Send one image segment via API. Updates segState in-place. */
async _sendOneImageSegment(idx, segments, channel, toNode, msgUid, segState) {
    const totalSegments = segments.length;
    const stateEl = document.getElementById(`${msgUid}-seg-${idx}-state`);
    if (stateEl) {
        stateEl.className = 'seg-state seg-sending';
        stateEl.textContent = 'Sending...';
    }

    try {
        // Send image segments via binary portnum 288 (CUSTOM_IMAGE_APP) by default.
        // Use segState._sendMethod to allow per-instance override (e.g. 'text').
        const useBinary = (segState._sendMethod || 'binary') === 'binary';
        const endpoint = useBinary ? '/api/messages/send-binary' : '/api/messages/send';
        const payload = useBinary
            ? { data: segments[idx], channel: channel, want_ack: true }
            : { text: segments[idx], channel: channel, want_ack: true };
        if (toNode) payload.to_node = toNode;

        const response = await fetch(endpoint, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-Session-ID': this.sessionId
            },
            body: JSON.stringify(payload)
        });

        const data = await response.json();

        if (data.success) {
            const packetId = data.data ? data.data.packet_id : null;
            segState.packetIds[idx] = packetId;
            segState.ackState[idx] = 'pending';

            if (stateEl) {
                stateEl.className = 'seg-state seg-awaiting-ack';
                stateEl.textContent = 'Awaiting ack...';
            }

            const method = useBinary ? 'bin' : 'txt';
            this.logCommunication('OUT', `Seg ${idx + 1}/${totalSegments} sent [${method}] (id=${packetId})`, 'success');
            return true;
        } else {
            segState.ackState[idx] = 'failed';
            if (stateEl) {
                stateEl.className = 'seg-state seg-failed';
                stateEl.textContent = 'Send failed';
            }
            this.logCommunication('OUT', `Seg ${idx + 1}/${totalSegments} send failed`, 'error');
            return false;
        }
    } catch (error) {
        segState.ackState[idx] = 'failed';
        if (stateEl) {
            stateEl.className = 'seg-state seg-failed';
            stateEl.textContent = 'Error';
        }
        console.error(`Segment ${idx + 1} send error:`, error);
        return false;
    }
},

/** Add a retry button to a segment row. */
_addSegmentRetryButton(idx, msgUid, segState, sendOneFn) {
    const row = document.getElementById(`${msgUid}-seg-${idx}`);
    if (!row || row.querySelector('.btn-retry-seg')) return;
    const btn = document.createElement('button');
    btn.className = 'btn btn-small btn-retry-seg';
    btn.textContent = 'Retry';
    btn.addEventListener('click', async () => {
        btn.disabled = true;
        btn.textContent = 'Retrying...';
        const ok = await sendOneFn(idx);
        if (ok) {
            btn.remove();
            this._startSegmentAckTimeout(idx, msgUid, segState,
                (i) => this._addSegmentRetryButton(i, msgUid, segState, sendOneFn));
        } else {
            btn.disabled = false;
            btn.textContent = 'Retry';
        }
    });
    row.appendChild(btn);
},

/** Start ACK timeout for a segment; adds retry button on timeout. Uses ACK_TIMEOUT_IMAGE_MS (30s). */
_startSegmentAckTimeout(idx, msgUid, segState, addRetryFn) {
    setTimeout(() => {
        if (segState.ackState[idx] === 'pending') {
            segState.ackState[idx] = 'retry';
            const stateEl = document.getElementById(`${msgUid}-seg-${idx}-state`);
            if (stateEl) {
                stateEl.className = 'seg-state seg-timeout';
                stateEl.textContent = `No ack (${ACK_TIMEOUT_IMAGE_MS / 1000}s)`;
            }
            addRetryFn(idx);
        }
    }, ACK_TIMEOUT_IMAGE_MS);
},

/** Handle ACK for image segment packet IDs. */
_handleImageSegmentAck(ackData, msgUid, totalSegments, segState) {
    if (!ackData || !ackData.request_id) return;
    const rid = String(ackData.request_id);
    for (let i = 0; i < totalSegments; i++) {
        if (String(segState.packetIds[i]) === rid) {
            const ackOk = ackData.ack_received;
            const stateEl = document.getElementById(`${msgUid}-seg-${i}-state`);
            if (ackOk) {
                segState.ackState[i] = 'ack';
                if (stateEl) {
                    stateEl.className = 'seg-state seg-ack-ok';
                    stateEl.textContent = 'Ack received';
                }
                const row = document.getElementById(`${msgUid}-seg-${i}`);
                const retryBtn = row ? row.querySelector('.btn-retry-seg') : null;
                if (retryBtn) retryBtn.remove();
            } else {
                segState.ackState[i] = 'failed';
                if (stateEl) {
                    stateEl.className = 'seg-state seg-failed';
                    stateEl.textContent = `Nak: ${ackData.error_reason || 'unknown'}`;
                }
                // Use segState._segments/_channel/_toNode captured at send time
                this._addSegmentRetryButton(i, msgUid, segState,
                    (idx) => this._sendOneImageSegment(idx, segState._segments, segState._channel, segState._toNode, msgUid, segState));
            }
            break;
        }
    }
},

/** Send segments sequentially with 15s delay and abort support. */
async _sendSegmentsSequentially(totalSegments, sendOneFn, addRetryFn, startAckTimeoutFn, msgUid, segState) {
    let allOk = true;
    let aborted = false;
    for (let i = 0; i < totalSegments; i++) {
        if (this._imageSendAborted) {
            aborted = true;
            for (let j = i; j < totalSegments; j++) {
                segState.ackState[j] = 'aborted';
                const stateEl = document.getElementById(`${msgUid}-seg-${j}-state`);
                if (stateEl) {
                    stateEl.className = 'seg-state seg-aborted';
                    stateEl.textContent = 'Aborted';
                }
            }
            break;
        }

        const ok = await sendOneFn(i);
        if (ok) {
            startAckTimeoutFn(i);
        } else {
            allOk = false;
            addRetryFn(i);
        }

        if (i < totalSegments - 1) {
            const stateElNext = document.getElementById(`${msgUid}-seg-${i + 1}-state`);
            if (stateElNext) {
                stateElNext.className = 'seg-state seg-waiting';
                stateElNext.textContent = 'Waiting (15s)...';
            }
            for (let t = 0; t < SEGMENT_WAIT_TICKS; t++) {
                if (this._imageSendAborted) break;
                await new Promise(resolve => setTimeout(resolve, SEGMENT_WAIT_TICK_MS));
            }
        }
    }
    return { allOk, aborted };
},

/** Finalize image send: remove abort button, update status text, add segment disclosure, persist to DB. */
_finalizeImageSend(msgUid, messageElement, segments, segState, totalSegments, allOk, aborted) {
    const abortEl = document.getElementById(`${msgUid}-abort`);
    if (abortEl) abortEl.remove();

    const sentCount = segState.ackState.filter(s => s !== null && s !== 'failed' && s !== 'aborted').length;
    let statusText;
    if (aborted) {
        statusText = `[Image] Aborted - ${sentCount}/${totalSegments} segments sent`;
    } else {
        statusText = `[Image] ${sentCount}/${totalSegments} segments sent`;
    }

    const contentEl = messageElement.querySelector('.message-content');
    if (contentEl) {
        contentEl.textContent = statusText;
    }

    if (segments.length > 0) {
        const disclosureContainer = document.createElement('div');
        disclosureContainer.className = 'sent-segments-disclosure';
        const discId = 'seg-disc-' + Date.now();
        disclosureContainer.id = discId;
        messageElement.appendChild(disclosureContainer);
        setTimeout(() => this._renderSegmentList(discId, segments, segState._channel, segState._toNode), 0);
    }

    // Fix 1: Add "Resend All Segments" button after send completes
    this._addResendAllButton(messageElement, segments, segState._channel, segState._toNode);

    // Persist the sent image message to IndexedDB so it survives channel switches
    const imagePreview = this._encodedPreviewBase64 || null;
    const chatMsg = {
        from: 'You',
        text: statusText,
        timestamp: new Date().toISOString(),
        type: 'sent',
        isImage: true,
        to: this.sendTarget ? this.sendTarget.name : '',
        channel: segState._channel,
        segments: segments,
        imagePreviewBase64: imagePreview,
        ack_status: allOk ? 'delivered' : (aborted ? 'failed' : 'sent'),
        _targetKey: this.getMessageStorageKey()
    };
    this.storeMessageForTarget(chatMsg);

    if (aborted) {
        this.showMessage('Image send aborted', 'warning');
    } else {
        this.showMessage(allOk ? `Image: ${totalSegments} segments sent` : 'Some segments failed - use Retry buttons', allOk ? 'success' : 'warning');
    }
},

/**
 * Fix 1: Add "Resend All Segments" button to a sent image message.
 * Allows re-sending all segments even after they were acknowledged.
 */
_addResendAllButton(messageElement, segments, channel, toNode) {
    if (!segments || segments.length === 0) return;

    const container = document.createElement('div');
    container.className = 'resend-all-container';

    const resendAllBtn = document.createElement('button');
    resendAllBtn.className = 'btn btn-small btn-resend-all';
    resendAllBtn.textContent = `Resend All (${segments.length} segments)`;
    resendAllBtn.addEventListener('click', async () => {
        resendAllBtn.disabled = true;
        resendAllBtn.textContent = 'Resending...';

        let sentCount = 0;
        for (let i = 0; i < segments.length; i++) {
            try {
                // Send via binary portnum 288 by default for image segments
                const payload = {
                    data: segments[i],
                    channel: channel,
                    want_ack: true
                };
                if (toNode) payload.to_node = toNode;

                const response = await fetch('/api/messages/send-binary', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-Session-ID': this.sessionId
                    },
                    body: JSON.stringify(payload)
                });
                const data = await response.json();
                if (data.success) {
                    sentCount++;
                    this.logCommunication('OUT', `Resent seg ${i + 1}/${segments.length} [bin]`, 'success');
                }
            } catch (e) {
                console.error(`Resend seg ${i + 1} error:`, e);
            }

            // 15s delay between segments
            if (i < segments.length - 1) {
                resendAllBtn.textContent = `Resending ${i + 2}/${segments.length}...`;
                await new Promise(r => setTimeout(r, SEGMENT_INTER_DELAY_MS));
            }
        }

        resendAllBtn.disabled = false;
        resendAllBtn.textContent = `Resend All (${segments.length} segments)`;
        this.showMessage(`Resent ${sentCount}/${segments.length} segments`, sentCount === segments.length ? 'success' : 'warning');
    });
    container.appendChild(resendAllBtn);
    messageElement.appendChild(container);
},

loadEncodingSettingsToModal() {
    // Load saved encoding settings from localStorage
    const defaults = this.getEncodingSettings();
    const setVal = (id, val) => {
        const el = document.getElementById(id);
        if (el) el.value = val;
    };
    setVal('encMode', defaults.mode);
    setVal('encBitDepth', defaults.bit_depth);
    setVal('encImageSize', `${defaults.image_width}x${defaults.image_height}`);
    setVal('encSegmentLen', defaults.segment_length);

    // Gamma slider
    const gammaEl = document.getElementById('encGamma');
    const gammaValEl = document.getElementById('encGammaValue');
    if (gammaEl) {
        gammaEl.value = defaults.gamma || 1.0;
        if (gammaValEl) gammaValEl.textContent = gammaEl.value;
        // Live gamma label update
        gammaEl.oninput = () => {
            if (gammaValEl) gammaValEl.textContent = parseFloat(gammaEl.value).toFixed(1);
            this._liveReencode();
        };
    }

    // Pixel compress checkbox
    const pcEl = document.getElementById('encPixelCompress');
    if (pcEl) {
        pcEl.checked = !!defaults.pixel_compress;
        pcEl.onchange = () => this._liveReencode();
    }

    // Live re-encode listeners on setting changes
    const liveIds = ['encMode', 'encBitDepth', 'encImageSize'];
    for (const id of liveIds) {
        const el = document.getElementById(id);
        if (el) el.onchange = () => this._liveReencode();
    }
},

/** Live re-encode: triggered when encoding settings change while an image is selected. */
_liveReencode() {
    if (this._selectedImageFile && this.sessionId) {
        // Debounce: cancel previous timer
        if (this._liveEncodeTimer) clearTimeout(this._liveEncodeTimer);
        this._liveEncodeTimer = setTimeout(() => this.encodeImagePreview(), 300);
    }
},

getEncodingSettings() {
    const saved = localStorage.getItem('meshtastic_encoding_settings');
    if (saved) {
        try { return JSON.parse(saved); } catch (e) {}
    }
    return {
        mode: 'best',
        bit_depth: 1,
        image_width: 128,
        image_height: 64,
        segment_length: 200,
        gamma: 1.0,
        pixel_compress: false
    };
},

// ============================================
// SETTINGS MODAL METHODS
// ============================================

openSettingsModal() {
    const modal = document.getElementById('settingsModal');
    if (modal) {
        modal.style.display = 'flex';
        const defaults = this.getEncodingSettings();
        const setVal = (id, val) => {
            const el = document.getElementById(id);
            if (el) el.value = val;
        };
        setVal('settingsEncMode', defaults.mode);
        setVal('settingsBitDepth', defaults.bit_depth);
        setVal('settingsImageSize', `${defaults.image_width}x${defaults.image_height}`);
        setVal('settingsSegmentLen', defaults.segment_length);

        // Load node refresh interval from server
        this._loadNodeRefreshSetting();
    }
},

/** Fetch current node refresh interval from server and populate the dropdown. */
async _loadNodeRefreshSetting() {
    try {
        const resp = await fetch('/api/app/settings', {
            headers: { 'X-Session-ID': this.sessionId }
        });
        if (resp.ok) {
            const data = await resp.json();
            const interval = data.data?.node_refresh_interval || 15;
            const el = document.getElementById('settingsNodeRefresh');
            if (el) el.value = String(interval);
        }
    } catch (e) {
        console.warn('Could not load node refresh setting:', e);
    }
},

closeSettingsModal() {
    const modal = document.getElementById('settingsModal');
    if (modal) modal.style.display = 'none';
},

saveSettings() {
    const sizeVal = (document.getElementById('settingsImageSize') || {}).value || '128x64';
    const [sW, sH] = sizeVal.split('x').map(Number);
    const settings = {
        mode: document.getElementById('settingsEncMode').value,
        bit_depth: parseInt(document.getElementById('settingsBitDepth').value),
        image_width: sW || 128,
        image_height: sH || 64,
        segment_length: parseInt(document.getElementById('settingsSegmentLen').value),
        gamma: 1.0,
        pixel_compress: false
    };
    localStorage.setItem('meshtastic_encoding_settings', JSON.stringify(settings));

    // Save node refresh interval to server
    const refreshEl = document.getElementById('settingsNodeRefresh');
    if (refreshEl && this.sessionId) {
        const interval = parseInt(refreshEl.value) || 15;
        fetch('/api/app/settings', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-Session-ID': this.sessionId
            },
            body: JSON.stringify({ node_refresh_interval: interval })
        }).catch(e => console.warn('Failed to save node refresh setting:', e));
    }

    this.showMessage('Settings saved', 'success');
    this.closeSettingsModal();
},

/**
 * Export all stored messages as a downloadable JSON file.
 * Includes both localStorage data and IndexedDB messages.
 */
async exportMessages() {
    if (!this.storage) {
        this.showMessage('No active session to export from', 'error');
        return;
    }

    this.showMessage('Exporting messages...', 'info');

    try {
        const exportPayload = await this.storage.exportAllAsync();
        exportPayload.host = this.host || 'unknown';
        exportPayload.port = this.port || 'unknown';

        const blob = new Blob([JSON.stringify(exportPayload, null, 2)], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `meshtastic-export-${new Date().toISOString().slice(0, 10)}.json`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);

        const count = exportPayload.messages ? exportPayload.messages.messageCount : 0;
        this.showMessage(`Exported ${count} messages`, 'success');
    } catch (e) {
        console.error('Export error:', e);
        this.showMessage('Export failed: ' + e.message, 'error');
    }
},

/**
 * Import messages from a previously exported JSON file.
 */
async importMessages() {
    if (!this.storage || !this.storage.messageDB) {
        this.showMessage('No active session or database not ready', 'error');
        return;
    }

    // Create a file input to select the JSON file
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = '.json';
    input.addEventListener('change', async (e) => {
        const file = e.target.files[0];
        if (!file) return;

        this.showMessage('Importing messages...', 'info');

        try {
            const text = await file.text();
            const data = JSON.parse(text);

            const result = await this.storage.importMessagesAsync(data);
            this.showMessage(
                `Import complete: ${result.imported} imported, ${result.skipped} skipped (duplicates)`,
                'success'
            );

            // Reload current view to show imported messages
            if (this.sendTarget) {
                this.loadMessageHistory();
            }
        } catch (e) {
            console.error('Import error:', e);
            this.showMessage('Import failed: ' + e.message, 'error');
        }
    });
    input.click();
},

// ============================================
// MESSAGE HISTORY PER CHANNEL/NODE
// ============================================

getMessageStorageKey() {
    if (!this.sendTarget) return null;
    if (this.sendTarget.type === 'node') {
        return `messages_node_${this.sendTarget.id}`;
    }
    return `messages_channel_${this.sendTarget.id}`;
},

async loadMessageHistory() {
    // Load stored messages for the current target from IndexedDB
    const messagesContainer = document.getElementById('messagesContainer');
    if (!messagesContainer || !this.storage) return;

    // Clear current messages
    messagesContainer.innerHTML = '';

    const key = this.getMessageStorageKey();
    if (!key) return;

    let messages;
    try {
        messages = await this.storage.getMessagesAsync(key);
    } catch (e) {
        console.error('Error loading messages:', e);
        messages = [];
    }

    if (!messages || messages.length === 0) {
        messagesContainer.innerHTML = `<div class="empty-history-hint">No message history for ${this.escapeHtml(this.sendTarget.name)}</div>`;
        return;
    }

    // Sort messages by timestamp (oldest first) to ensure correct order
    messages.sort((a, b) => {
        const ta = a.timestamp ? new Date(a.timestamp).getTime() : 0;
        const tb = b.timestamp ? new Date(b.timestamp).getTime() : 0;
        return ta - tb;
    });

    // Split messages into recent (last 12 hours) and older
    const twelveHoursAgo = Date.now() - (12 * 60 * 60 * 1000);
    const recentMessages = [];
    const olderMessages = [];
    for (const msg of messages) {
        const ts = msg.timestamp ? new Date(msg.timestamp).getTime() : 0;
        if (ts >= twelveHoursAgo || ts === 0) {
            recentMessages.push(msg);
        } else {
            olderMessages.push(msg);
        }
    }

    // Store older messages for lazy loading
    this._olderMessages = olderMessages;
    this._currentStorageKey = key;

    // Add "load older messages" label if there are older messages
    if (olderMessages.length > 0) {
        const loadOlderDiv = document.createElement('div');
        loadOlderDiv.className = 'load-older-messages';
        loadOlderDiv.textContent = `Load older messages (${olderMessages.length})`;
        loadOlderDiv.addEventListener('click', () => {
            this._loadOlderMessages(messagesContainer, loadOlderDiv);
        });
        messagesContainer.appendChild(loadOlderDiv);
    }

    // Render recent messages (or all if none are recent)
    const toRender = recentMessages.length > 0 ? recentMessages : messages;
    if (recentMessages.length === 0 && olderMessages.length > 0) {
        // All messages are older than 12h, show them all
        this._olderMessages = [];
    }
    toRender.forEach(msg => {
        this.renderChatMessage(msg, false);
    });

    // Post-render pass: attach reassemble buttons to image segments in history
    this._scanForImageSegments(messagesContainer);

    // Scroll to bottom immediately - no animation.
    this._scrollToBottom(messagesContainer);
},

/**
 * Scroll a container to the very bottom instantly (no animation).
 * The bottom of the last message aligns to the base of the pane.
 *
 * Handles async image decoding: attaches onload listeners to all <img>
 * elements and re-scrolls when they finish loading. Also polls for
 * scroll-height changes over 1s to catch any remaining layout shifts.
 */
_scrollToBottom(container) {
    if (!container) return;

    const snap = () => {
        container.scrollTop = container.scrollHeight;
    };

    // First attempt after DOM settles
    requestAnimationFrame(snap);

    // Re-scroll when any image finishes decoding (changes scrollHeight)
    const images = container.querySelectorAll('img');
    images.forEach(img => {
        if (!img.complete) {
            img.addEventListener('load', snap, { once: true });
        }
    });

    // Poll for scrollHeight changes over 1s (5 checks at 200ms intervals)
    // to catch layout shifts from CSS, fonts, or late image decode.
    let prevHeight = container.scrollHeight;
    let checks = 0;
    const poll = setInterval(() => {
        checks++;
        const curHeight = container.scrollHeight;
        if (curHeight !== prevHeight) {
            prevHeight = curHeight;
            snap();
        }
        if (checks >= 5) clearInterval(poll);
    }, 200);
},

/**
 * Load older messages (>12h) when the user clicks "Load older messages".
 * Inserts them above the recent messages in chronological order.
 */
_loadOlderMessages(container, labelElement) {
    if (!this._olderMessages || this._olderMessages.length === 0) return;

    // Remove the "load older" label
    labelElement.remove();

    // Remember current scroll height to preserve scroll position
    const prevScrollHeight = container.scrollHeight;

    // Create a document fragment with older messages
    const fragment = document.createDocumentFragment();
    const tempContainer = document.createElement('div');

    this._olderMessages.forEach(msg => {
        const msgEl = document.createElement('div');
        tempContainer.appendChild(msgEl);
    });

    // Insert older messages at the top (after any existing load-older label)
    const firstMessage = container.querySelector('.message');
    this._olderMessages.forEach(msg => {
        // Use renderChatMessage which appends to messagesContainer
        // We need to render then move, so temporarily render
        this.renderChatMessage(msg, false);
    });

    // The messages were appended at the end - move them before the first recent message
    // Actually, renderChatMessage appends to container. We need to re-order.
    // Simpler approach: re-render everything in order
    container.innerHTML = '';
    const allMessages = [...this._olderMessages, ...this._recentMessagesCache || []];

    // Re-sort and re-render isn't ideal. Better approach: prepend before first message.
    // Let's clear and re-render properly.
    this._olderMessages = [];

    // Reload full history without the 12h filter
    this._loadFullHistory(container);
},

/**
 * Reload full message history without the 12-hour filter.
 */
async _loadFullHistory(container) {
    const key = this._currentStorageKey || this.getMessageStorageKey();
    if (!key) return;

    container.innerHTML = '';

    let messages;
    try {
        messages = await this.storage.getMessagesAsync(key);
    } catch (e) {
        console.error('Error loading messages:', e);
        messages = [];
    }

    if (!messages || messages.length === 0) return;

    messages.sort((a, b) => {
        const ta = a.timestamp ? new Date(a.timestamp).getTime() : 0;
        const tb = b.timestamp ? new Date(b.timestamp).getTime() : 0;
        return ta - tb;
    });

    messages.forEach(msg => {
        this.renderChatMessage(msg, false);
    });

    this._scanForImageSegments(container);

    requestAnimationFrame(() => {
        // Scroll to top to show the older messages the user requested
        container.scrollTop = 0;
    });
},

storeMessageForTarget(messageData) {
    if (!this.storage) return;

    // Determine which target this message belongs to
    let key = null;
    if (messageData._targetKey) {
        key = messageData._targetKey;
    } else if (messageData.type === 'sent') {
        key = this.getMessageStorageKey();
    } else {
        if (messageData.isDM) {
            key = `messages_node_${messageData.from_node || messageData.from}`;
        } else {
            key = `messages_channel_${messageData.channel || 0}`;
        }
    }

    if (!key) return;

    // Store asynchronously in IndexedDB
    this.storage.addMessageAsync(key, messageData).catch(e => {
        console.error('Error storing message:', e);
    });
},

// Escape HTML to prevent XSS
escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
},

// Sync device method
async syncDevice() {
            this.showMessage('Refreshing device data...', 'info');

    try {
        const response = await fetch('/api/device/refresh', {
            method: 'POST',
            headers: {
                'X-Session-ID': this.sessionId
            }
        });

        if (response.ok) {
            const data = await response.json();
            if (data.success) {
                this.showMessage('Device sync completed', 'success');
                // Reset flag and reload data
                this._initialDataLoaded = false;
                this.loadInitialData();
            } else {
                this.showMessage('Device sync failed: ' + data.message, 'error');
            }
        } else {
            this.showMessage('Device sync failed: HTTP ' + response.status, 'error');
        }
    } catch (error) {
        console.error('Sync device error:', error);
        this.showMessage('Device sync error: ' + error.message, 'error');
    } finally {
        // Remove focus/highlight from the button
        if (document.activeElement) document.activeElement.blur();
    }
},

/** Reboot the connected Meshtastic device via the admin API. */
async rebootDevice() {
    if (!confirm('Are you sure you want to reboot the Meshtastic device? It will restart in 5 seconds.')) {
        return;
    }

    const btn = document.getElementById('rebootDeviceBtn');
    if (btn) {
        btn.disabled = true;
        btn.textContent = 'Rebooting...';
    }

    try {
        const response = await fetch('/api/device/reboot', {
            method: 'POST',
            headers: { 'X-Session-ID': this.sessionId }
        });

        const data = await response.json();
        if (data.success) {
            this.showMessage('Reboot command sent - device will restart in 5 seconds', 'success');
            this.closeSettingsModal();
        } else {
            this.showMessage('Reboot failed: ' + (data.message || 'Unknown error'), 'error');
        }
    } catch (error) {
        console.error('Reboot error:', error);
        this.showMessage('Reboot error: ' + error.message, 'error');
    } finally {
        if (btn) {
            btn.disabled = false;
            btn.textContent = 'Reboot Device';
        }
    }
},

// Alias for refreshChannels (for HTML onclick compatibility)
async refreshChannels() {

    this.showMessage('Reconnecting to refresh channel data...', 'info');
    this.addSystemMessage('Refreshing channel data - reopening connection...', 'info');
    this.showStatus('Reconnecting to refresh data...');

    try {
        // Trigger a fresh connection to get updated data
        const result = await this.loadChannels();

        this.showMessage('Channel data refreshed successfully', 'success');
        this.addSystemMessage('Channel data updated', 'success');
        this.showStatus('Data refreshed - Connection closed (will reconnect when needed)');

        return result;

    } catch (error) {
        console.error('Error refreshing channels:', error);
        this.showMessage('Failed to refresh channel data: ' + error.message, 'error');
        this.addSystemMessage('Failed to refresh channel data', 'error');
        throw error;
    } finally {
        if (document.activeElement) document.activeElement.blur();
    }
},

// Update statistics in the sidebar
updateStatistics() {
    try {
        // Get data from storage if available
        const nodes = this.storage ? this.storage.getNodes() : [];
        const channels = this.storage ? this.storage.getChannels() : [];
        const favorites = this.storage ? this.storage.getFavorites() : [];

        // Count "online" nodes (heard in last 1 hour)
        const oneHourAgo = Math.floor(Date.now() / 1000) - 3600;
        const onlineCount = nodes.filter(n => {
            const lastHeard = n.lastHeard || n.lastSeen;
            return lastHeard && lastHeard > oneHourAgo;
        }).length;

        // Count nodes with position
        const withPosition = nodes.filter(n => n.position && n.position.latitude !== undefined).length;

        // Update DOM elements
        const updateElement = (id, value) => {
            const element = document.getElementById(id);
            if (element) element.textContent = value;
        };

        updateElement('totalNodes', nodes.length);
        updateElement('onlineNodes', onlineCount);
        updateElement('totalChannels', channels.length);
        updateElement('favoriteNodes', favorites.length);
        updateElement('fragmentCount', withPosition);

        // Message count from IndexedDB (async)
        if (this.storage && this.storage.messageDB) {
            this.storage.messageDB.getMessageCount().then(count => {
                updateElement('messageCount', count);
            }).catch(() => {
                updateElement('messageCount', '?');
            });
        } else {
            updateElement('messageCount', 0);
        }

        console.log('Statistics updated:', { 
            nodes: nodes.length, 
            online: onlineCount,
            channels: channels.length,
            favorites: favorites.length,
            withPosition: withPosition
        });
    } catch (error) {
        console.error('Error updating statistics:', error);
    }
}
});
