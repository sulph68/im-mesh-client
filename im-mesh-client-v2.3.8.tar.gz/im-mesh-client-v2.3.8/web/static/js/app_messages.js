/**
 * Meshtastic Web Client - Messages Module: Send, queue, ACK timeout, chat rendering, message routing
 */

Object.assign(MeshtasticClient.prototype, {

async sendMessage() {
    const messageInput = document.getElementById('messageInput');
    if (!messageInput) return;

    const text = messageInput.value.trim();
    if (!text) {
        this.showMessage('Please enter a message', 'warning');
        return;
    }

    if (!this.sessionId) {
        this.showMessage('No active session', 'error');
        return;
    }

    const payload = {
        text: text,
        channel: this.sendTarget.type === 'channel' ? this.sendTarget.id : (this.selectedChannelIndex || 0),
        want_ack: true
    };

    // If sending to a specific node (DM), set to_node
    if (this.sendTarget.type === 'node' && this.sendTarget.id) {
        payload.to_node = this.sendTarget.id;
    }

    // Clear input immediately for good UX
    messageInput.value = '';

    // Queue the message (with metadata for display after send)
    this._messageQueue.push({
        payload: payload,
        displayText: text,
        targetName: this.sendTarget.name,
        targetKey: this.getMessageStorageKey(),
        channel: payload.channel
    });

    console.log(`Message queued: "${text}" (queue size: ${this._messageQueue.length})`);

    if (this._messageQueue.length > 1) {
        this.showMessage(`Message queued (${this._messageQueue.length} in queue)`, 'info');
    }

    // Start processing if not already running
    this._processMessageQueue();
},

/**
 * Process the message queue, sending one message at a time with 3-second
 * spacing between each message to avoid overwhelming the mesh radio.
 */
async _processMessageQueue() {
    if (this._messageQueueProcessing) return;  // Already running
    this._messageQueueProcessing = true;

    try {
        while (this._messageQueue.length > 0) {
            const msg = this._messageQueue.shift();

            try {
                console.log(`Sending queued message: "${msg.displayText}" to ${msg.targetName}`);

                const response = await fetch('/api/messages/send', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-Session-ID': this.sessionId
                    },
                    body: JSON.stringify(msg.payload)
                });

                const data = await response.json();

                if (data.success) {
                    // Extract packet_id for ack tracking
                    const packetId = data.data ? data.data.packet_id : null;
                    const wantAck = msg.payload.want_ack || false;

                    // Add sent message to chat display with ack tracking info
                    // "Sent" = API call succeeded (immediate). "Delivered" = ACK from mesh.
                    this.addChatMessage({
                        from: 'You',
                        text: msg.displayText,
                        timestamp: new Date().toISOString(),
                        type: 'sent',
                        to: msg.targetName,
                        channel: msg.channel,
                        _targetKey: msg.targetKey,
                        packet_id: packetId,
                        want_ack: wantAck,
                        ack_status: wantAck ? 'sent' : null
                    });

                    this.logCommunication('OUT', `Sent: "${msg.displayText}" to ${msg.targetName} (id=${packetId})`, 'success');
                    console.log(`Message sent successfully (packetId=${packetId})`);

                    // Start 60-second ACK timeout with retry button
                    if (wantAck && packetId) {
                        this._startAckTimeout(packetId, msg);
                    }
                } else {
                    // Send failed - show failed message with retry button
                    this._addFailedMessage(msg, data.message || 'Unknown error');
                    this.logCommunication('OUT', `Send failed: ${data.message}`, 'error');

                    // If connection lost, try to indicate reconnection
                    if (data.message && data.message.includes('not connected')) {
                        this.addConnectionLostMessage();
                    }
                }
            } catch (error) {
                console.error('Send message error:', error);
                // Show failed message with retry button
                this._addFailedMessage(msg, error.message);
                this.logCommunication('OUT', `Send error: ${error.message}`, 'error');
            }

            // Wait 3 seconds before sending the next message (if any remain)
            if (this._messageQueue.length > 0) {
                console.log(`Waiting ${this._messageQueueDelay}ms before next message (${this._messageQueue.length} remaining)`);
                await new Promise(resolve => setTimeout(resolve, this._messageQueueDelay));
            }
        }
    } finally {
        // ALWAYS reset the processing flag so future messages can be sent
        this._messageQueueProcessing = false;
    }
},

/**
 * Start a 60-second ACK timeout for a sent message.
 * If no ACK arrives, shows a timeout indicator with a Retry button.
 * "Sent" is already shown (single tick). If no ACK upgrades to "Delivered",
 * the tick gets a timeout style and a Retry button appears.
 */
_startAckTimeout(packetId, originalMsg) {
    setTimeout(() => {
        const container = document.getElementById('messagesContainer');
        if (!container) return;
        const msgEl = container.querySelector(`[data-packet-id="${packetId}"]`);
        if (!msgEl) return;
        const tickSpan = msgEl.querySelector('.ack-ticks');
        if (!tickSpan) return;

        const currentStatus = tickSpan.getAttribute('data-ack-status') || 'sent';
        // Only show timeout if not yet delivered
        if (currentStatus === 'delivered') return;

        tickSpan.className = 'ack-ticks ack-timeout';
        tickSpan.textContent = '\u2713';
        tickSpan.title = 'No delivery ack received';
        tickSpan.setAttribute('data-ack-status', 'timeout');

        // Add retry button after the message content
        let retryContainer = msgEl.querySelector('.ack-retry-container');
        if (!retryContainer) {
            retryContainer = document.createElement('div');
            retryContainer.className = 'ack-retry-container';
            msgEl.appendChild(retryContainer);
        }
        retryContainer.innerHTML = '<span class="ack-timeout-label">No ack received </span>';

        const retryBtn = document.createElement('button');
        retryBtn.className = 'btn-retry-seg';
        retryBtn.textContent = 'Retry';
        retryBtn.addEventListener('click', () => {
            retryBtn.disabled = true;
            retryBtn.textContent = 'Retrying...';
            // Mark old message as failed
            tickSpan.className = 'ack-ticks ack-failed';
            tickSpan.textContent = '\u2717';
            tickSpan.title = 'No ack - retried';
            tickSpan.setAttribute('data-ack-status', 'failed');
            retryContainer.remove();
            // Re-queue as a new message (will create a new DOM entry with new packet_id)
            this._messageQueue.push({
                payload: originalMsg.payload,
                displayText: originalMsg.displayText,
                targetName: originalMsg.targetName,
                targetKey: originalMsg.targetKey,
                channel: originalMsg.channel
            });
            this._processMessageQueue();
        });
        retryContainer.appendChild(retryBtn);
    }, ACK_TIMEOUT_MS);
},

/**
 * Add a failed message to chat with a Retry button.
 */
_addFailedMessage(msg, errorText) {
    const messagesContainer = document.getElementById('messagesContainer');
    if (!messagesContainer) return;

    const messageElement = document.createElement('div');
    messageElement.className = 'message sent';

    const time = new Date().toLocaleTimeString();
    messageElement.innerHTML = `
        <div class="message-header">
            <span class="message-from sent-name">You</span>
            <span class="ack-ticks ack-failed" title="Send failed">\u2717</span>
            <span class="message-time">${time}</span>
        </div>
        <div class="message-content">${this.escapeHtml(msg.displayText)}</div>
        <div class="ack-retry-container"><span class="ack-timeout-label">Send failed: ${this.escapeHtml(errorText)} </span></div>
    `;

    const retryContainer = messageElement.querySelector('.ack-retry-container');
    const retryBtn = document.createElement('button');
    retryBtn.className = 'btn-retry-seg';
    retryBtn.textContent = 'Retry';
    retryBtn.addEventListener('click', () => {
        retryBtn.disabled = true;
        retryBtn.textContent = 'Retrying...';
        // Update the label and tick mark
        const tickSpan = messageElement.querySelector('.ack-ticks');
        if (tickSpan) { tickSpan.textContent = '\u2717'; tickSpan.title = 'Failed - retried'; }
        const label = retryContainer ? retryContainer.querySelector('.ack-timeout-label') : null;
        if (label) label.textContent = 'Send failed - retried ';
        retryBtn.remove();
        // Re-queue as a new message (will create a new DOM entry with new packet_id)
        this._messageQueue.push({
            payload: msg.payload,
            displayText: msg.displayText,
            targetName: msg.targetName,
            targetKey: msg.targetKey,
            channel: msg.channel
        });
        this._processMessageQueue();
    });
    if (retryContainer) {
        retryContainer.appendChild(retryBtn);
    } else {
        messageElement.appendChild(retryBtn);
    }

    messagesContainer.appendChild(messageElement);
    messagesContainer.scrollTop = messagesContainer.scrollHeight;
},

// Add a chat message to the messages display area
addChatMessage(messageData) {
    // Store message asynchronously (IndexedDB)
    this.storeMessageForTarget(messageData);

    // Render in chat immediately (don't wait for storage)
    try {
        this.renderChatMessage(messageData, true);
    } catch (e) {
        console.error('Error rendering message:', e);
    }
},

// Render a message element in the chat container
renderChatMessage(messageData, scrollToBottom) {
    const messagesContainer = document.getElementById('messagesContainer');
    if (!messagesContainer) return;

    const messageElement = document.createElement('div');
    const isSent = messageData.type === 'sent';
    const isSystem = messageData.type === 'system';
    const isBinary = messageData.portnum === 288 || messageData.isBinary;
    const isImage = messageData.isImage;

    let className = 'message';
    if (isSent) className += ' sent';
    else if (isSystem) className += ' system';
    else className += ' received';
    if (isBinary) className += ' binary-msg';
    if (isImage) className += ' image-msg';
    messageElement.className = className;

    const time = messageData.timestamp ? new Date(messageData.timestamp).toLocaleTimeString() : new Date().toLocaleTimeString();
    const fromName = this.escapeHtml(messageData.from || 'Unknown');
    const text = messageData.text || messageData.decoded_text || messageData.payload || '';

    // Render content by message type
    // Binary messages that contain image segments should render like text
    // image segments, just with a purple label. Check for image segment content.
    const binaryPayloadText = isBinary ? (messageData.rawPayload || messageData.text || '') : '';
    const isBinaryImageSegment = isBinary && !isSent && typeof binaryPayloadText === 'string' && this._isImageSegment(binaryPayloadText);

    if (isBinary && !isSent && !isBinaryImageSegment) {
        this._renderBinaryMessageContent(messageElement, messageData, fromName, time);
    } else if (isBinaryImageSegment) {
        // Render binary image segment like a text message but with purple label
        this._renderBinaryImageSegmentContent(messageElement, messageData, fromName, time, binaryPayloadText);
    } else if (isImage && messageData.imageData) {
        this._renderReceivedImageContent(messageElement, fromName, time, text, messageData.imageData);
    } else if (isImage && isSent) {
        this._renderSentImageContent(messageElement, messageData, fromName, time, text);
    } else {
        this._renderTextMessageContent(messageElement, messageData, fromName, time, text, isSent);
    }

    // ACK indicator for sent messages - tick marks right of username
    // "Sent" (single tick) = API send succeeded, "Delivered" (double tick) = ACK from mesh
    if (isSent && messageData.want_ack) {
        const packetId = messageData.packet_id;
        if (packetId) messageElement.setAttribute('data-packet-id', packetId);

        const storedStatus = messageData.ack_status || 'sent';
        // Inject tick marks into the message-header, right after the username
        const headerEl = messageElement.querySelector('.message-header');
        const fromEl = headerEl ? headerEl.querySelector('.message-from') : null;
        if (fromEl) {
            const tickSpan = document.createElement('span');
            tickSpan.className = 'ack-ticks';
            if (storedStatus === 'delivered' || storedStatus === 'received') {
                tickSpan.className += ' ack-delivered';
                tickSpan.textContent = '\u2713\u2713';
                tickSpan.title = 'Delivered';
            } else if (storedStatus === 'sent') {
                tickSpan.className += ' ack-sent';
                tickSpan.textContent = '\u2713';
                tickSpan.title = 'Sent';
            } else if (storedStatus === 'failed') {
                tickSpan.className += ' ack-failed';
                tickSpan.textContent = '\u2717';
                tickSpan.title = messageData.ack_error ? `Nak: ${messageData.ack_error}` : 'Send failed';
            } else {
                // pending (legacy fallback)
                tickSpan.className += ' ack-pending';
                tickSpan.textContent = '\u2713';
                tickSpan.title = 'Sending...';
            }
            tickSpan.setAttribute('data-ack-status', storedStatus);
            // Insert tick marks right after the username span
            fromEl.after(tickSpan);
        }
    }

    // Add per-message delete button (visible on hover)
    const deleteBtn = document.createElement('button');
    deleteBtn.className = 'btn-delete-msg';
    deleteBtn.textContent = '\u00d7';
    deleteBtn.title = 'Delete this message';
    deleteBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        this._deleteMessage(messageElement);
    });
    messageElement.appendChild(deleteBtn);

    // Store _dbId on the element for deletion (set after async storage)
    if (messageData._dbId) {
        messageElement.dataset.dbId = messageData._dbId;
    }

    messagesContainer.appendChild(messageElement);

    // Check for image segment reassembly on received text AND binary image segments
    if (!isSent && !isSystem && !isImage) {
        this._checkForImageSegments(messageElement, messageData);
    }

    // Render previously-decoded image if persisted in localStorage
    if (messageData._decodedImage) {
        let resultContainer = messageElement.querySelector('.reassemble-result');
        if (!resultContainer) {
            resultContainer = document.createElement('div');
            resultContainer.className = 'reassemble-result';
            messageElement.appendChild(resultContainer);
        }
        const stats = messageData._decodedStats || {};
        resultContainer.innerHTML = `
            <div class="reassembled-image-info">
                Decoded: ${stats.width || '?'}x${stats.height || '?'}, 
                ${stats.compression_method || 'unknown'}, 
                ${stats.segments_received || '?'} segments
            </div>
            <img src="data:image/png;base64,${messageData._decodedImage}" 
                 alt="Reassembled Image" 
                 class="reassembled-image">
        `;
    }

    if (scrollToBottom) {
        messagesContainer.scrollTop = messagesContainer.scrollHeight;
    }
},

/** Render binary/custom app message content. */
_renderBinaryMessageContent(el, messageData, fromName, time) {
    const payload = messageData.rawPayload || messageData.text || '';
    const displayPayload = typeof payload === 'string' && payload.length > 0
        ? payload
        : '[Binary Data]';
    const sizeInfo = messageData.payloadSize ? `Size: ${messageData.payloadSize} bytes` : '';
    el.innerHTML = `
        <div class="message-header">
            <span class="message-from">${fromName}</span>
            <span class="message-time">${time}</span>
        </div>
        <div class="message-content">${this.escapeHtml(displayPayload)}</div>
        <div class="binary-meta">
            ${sizeInfo ? `<span>${sizeInfo}</span>` : ''}
        </div>
    `;

    // Use event listener instead of inline onclick to avoid issues with
    // special characters in payload breaking the string literal
    const copyBtn = document.createElement('button');
    copyBtn.className = 'copy-payload-btn';
    copyBtn.textContent = 'Copy Payload';
    copyBtn.addEventListener('click', () => {
        this._copyToClipboard(String(payload)).then(() => {
            this.showMessage('Payload copied', 'success');
        });
    });
    el.appendChild(copyBtn);
},

/** Render received decoded image content. */
_renderReceivedImageContent(el, fromName, time, text, imageData) {
    el.innerHTML = `
        <div class="message-header">
            <span class="message-from">${fromName}</span>
            <span class="message-time">${time}</span>
        </div>
        <div class="message-content">${this.escapeHtml(text)}</div>
        <img src="data:image/png;base64,${imageData}" alt="Image" style="max-width: 200px; max-height: 200px; border-radius: 4px; border: 1px solid var(--border); margin-top: 0.5rem;">
    `;
},

/** Render sent image with preview and segment disclosure. */
_renderSentImageContent(el, messageData, fromName, time, text) {
    let previewHtml = '';
    if (messageData.imagePreviewBase64) {
        previewHtml = `<img src="data:image/png;base64,${messageData.imagePreviewBase64}" alt="Sent Image Preview" class="sent-image-preview">`;
    }
    el.innerHTML = `
        <div class="message-header">
            <span class="message-from sent-name">${fromName}</span>
            <span class="message-time">${time}</span>
        </div>
        <div class="message-content">${this.escapeHtml(text)}</div>
        ${previewHtml}
    `;
    if (messageData.segments && messageData.segments.length > 0) {
        const channel = messageData.channel || 0;
        const toNode = messageData.to_node || null;
        const disclosureContainer = document.createElement('div');
        disclosureContainer.className = 'sent-segments-disclosure';
        el.appendChild(disclosureContainer);
        const uid = 'seg-chat-' + Date.now();
        disclosureContainer.id = uid;
        setTimeout(() => this._renderSegmentList(uid, messageData.segments, channel, toNode), 0);

        // Add "Resend All Segments" button for sent images from history
        setTimeout(() => this._addResendAllButton(el, messageData.segments, channel, toNode), 0);
    }
},

/** Render standard text message content. */
_renderTextMessageContent(el, messageData, fromName, time, text, isSent) {
    el.innerHTML = `
        <div class="message-header">
            <span class="message-from${isSent ? ' sent-name' : ''}">${fromName}</span>
            <span class="message-time">${time}</span>
        </div>
        <div class="message-content">${this.escapeHtml(text)}</div>
    `;
},

// Handle incoming message from WebSocket
addMessage(messageData) {

    // Deduplicate: skip if we already have this message in storage.
    // Uses routed_at timestamp + from_node as a unique key to catch
    // buffered messages that arrive both via flush and live routing.
    if (messageData.routed_at && messageData.from_node && this.storage) {
        const dedupKey = `${messageData.routed_at}_${messageData.from_node}`;
        if (!this._seenMessageKeys) this._seenMessageKeys = new Set();
        if (this._seenMessageKeys.has(dedupKey)) {
            console.log(`Dedup: skipping duplicate message ${dedupKey}`);
            return;
        }
        this._seenMessageKeys.add(dedupKey);
        // Keep set size bounded
        if (this._seenMessageKeys.size > DEDUP_SET_MAX) {
            const arr = Array.from(this._seenMessageKeys);
            this._seenMessageKeys = new Set(arr.slice(-DEDUP_SET_PRUNE_TO));
        }
    }

    // Notify new message in browser tab title
    this._notifyNewMessageInTitle();

    // Resolve sender name
    const fromName = this._resolveSenderName(messageData);

    // Auto-refresh node list if we hear an unknown node
    this._checkForUnknownNode(messageData);

    // Determine routing key (channel vs DM)
    const { msgTargetKey, isDM } = this._resolveMessageTarget(messageData);

    console.log(`Message routing: from=${messageData.from_node} to=${messageData.to_node} is_broadcast=${messageData.is_broadcast} isDM=${isDM} targetKey=${msgTargetKey}`);

    const currentTargetKey = this.getMessageStorageKey();
    const isCurrentView = (currentTargetKey === msgTargetKey);

    // Dispatch by message type
    if (messageData.type === 'image_complete' && messageData.image_data) {
        this._handleImageCompleteMessage(messageData, fromName, msgTargetKey, isCurrentView);
        return;
    }

    // Binary messages: check both wrapped (decoded.portnum) and unwrapped (portnum) forms
    const isBinaryMsg = (messageData.decoded && messageData.decoded.portnum === 288) ||
                        (messageData.portnum === 288 || messageData.portnum === 'CUSTOM_IMAGE_APP');
    if (isBinaryMsg) {
        // If the binary payload looks like an image segment text, treat it as
        // a text message so it renders the segment content and gets reassemble
        // buttons. Only show the generic "[Binary Message]" box if it's opaque data.
        // Check multiple locations where the payload string might be stored:
        // - decoded.payload: set by packet_processor (decoded UTF-8 string)
        // - decoded.binary_data: hex-encoded fallback from packet_processor
        // - payload: set by packet_handler path
        const binaryPayload = (messageData.decoded && messageData.decoded.payload) ||
                              messageData.payload || '';
        if (typeof binaryPayload === 'string' && this._isImageSegment(binaryPayload)) {
            // Render as text so image segment detection works
            const chatMsg = {
                from: fromName,
                text: binaryPayload,
                timestamp: messageData.rx_time || messageData.timestamp,
                type: 'received',
                portnum: 288,
                channel: messageData.channel,
                from_node: messageData.from_node,
                _targetKey: msgTargetKey
            };
            if (isCurrentView) {
                this.addChatMessage(chatMsg);
            } else {
                this._storeAndNotify(chatMsg, msgTargetKey, messageData.from_node || messageData.from);
            }
        } else {
            this._handleBinaryMessage(messageData, fromName, msgTargetKey, isCurrentView);
        }
        this.updateStatistics();
        return;
    }

    if (messageData.decoded_text || (messageData.decoded && messageData.decoded.text)) {
        this._handleTextMessage(messageData, fromName, msgTargetKey, isCurrentView);
    } else {
        this._handleFallbackMessage(messageData, fromName, msgTargetKey, isCurrentView);
    }

    this.updateStatistics();
},

/** Resolve sender display name from messageData or stored nodes. */
_resolveSenderName(messageData) {
    let fromName = messageData.from_name || messageData.from_node || messageData.from || 'Unknown';
    if (this.storage && (messageData.from_node || messageData.from)) {
        const nodeId = messageData.from_node || messageData.from;
        const nodes = this.storage.getNodes();
        const senderNode = nodes.find(n => (n.id || n.num) === nodeId);
        if (senderNode) {
            fromName = senderNode.longName || senderNode.shortName || senderNode.name || fromName;
        }
    }
    return fromName;
},

/** Determine the storage key and whether this is a DM. */
_resolveMessageTarget(messageData) {
    const toNodeStr = String(messageData.to_node || '').toLowerCase().replace(/^!/, '');
    const isBroadcastAddr = !toNodeStr || toNodeStr === 'ffffffff' || toNodeStr === '4294967295';
    const isDM = messageData.to_node && messageData.is_broadcast === false && !isBroadcastAddr;
    let msgTargetKey;
    if (isDM) {
        msgTargetKey = `messages_node_${messageData.from_node || messageData.from}`;
    } else {
        msgTargetKey = `messages_channel_${messageData.channel || 0}`;
    }
    return { msgTargetKey, isDM };
},

/** Handle decoded image_complete messages. */
_handleImageCompleteMessage(messageData, fromName, msgTargetKey, isCurrentView) {
    const chatMsg = {
        from: fromName,
        text: 'Image received',
        timestamp: messageData.rx_time || messageData.timestamp,
        type: 'received',
        isImage: true,
        imageData: messageData.image_data,
        channel: messageData.channel,
        _targetKey: msgTargetKey
    };
    if (isCurrentView) {
        this.addChatMessage(chatMsg);
    } else {
        this._storeAndNotify(chatMsg, msgTargetKey, messageData.from_node || messageData.from);
    }
},

/** Handle CUSTOM_IMAGE_APP (portnum 288) binary messages. */
_handleBinaryMessage(messageData, fromName, msgTargetKey, isCurrentView) {
    const payload = messageData.decoded.payload || messageData.decoded.binary_data || '[binary data]';
    const chatMsg = {
        from: fromName,
        text: '[Binary Message]',
        timestamp: messageData.rx_time || messageData.timestamp,
        type: 'received',
        portnum: 288,
        isBinary: true,
        rawPayload: payload,
        payloadSize: typeof payload === 'string' ? payload.length : 0,
        channel: messageData.channel,
        _targetKey: msgTargetKey
    };
    if (isCurrentView) {
        this.addChatMessage(chatMsg);
    } else {
        this._storeAndNotify(chatMsg, msgTargetKey, messageData.from_node || messageData.from);
    }
},

/** Handle standard text messages. */
_handleTextMessage(messageData, fromName, msgTargetKey, isCurrentView) {
    const text = messageData.decoded_text || messageData.decoded.text;
    const chatMsg = {
        from: fromName,
        text: text,
        timestamp: messageData.rx_time || messageData.timestamp,
        type: 'received',
        channel: messageData.channel,
        from_node: messageData.from_node,
        _targetKey: msgTargetKey
    };
    if (isCurrentView) {
        this.addChatMessage(chatMsg);
    } else {
        this._storeAndNotify(chatMsg, msgTargetKey, messageData.from_node || messageData.from);
    }
},

/** Handle messages with no recognized payload format. */
_handleFallbackMessage(messageData, fromName, msgTargetKey, isCurrentView) {
    const fallbackText = messageData.payload || messageData.text || null;
    if (fallbackText) {
        const chatMsg = {
            from: fromName,
            text: typeof fallbackText === 'string' ? fallbackText : '[message]',
            timestamp: messageData.rx_time || messageData.timestamp,
            type: 'received',
            channel: messageData.channel,
            from_node: messageData.from_node,
            _targetKey: msgTargetKey
        };
        if (isCurrentView) {
            this.addChatMessage(chatMsg);
        } else {
            this._storeAndNotify(chatMsg, msgTargetKey, messageData.from_node || messageData.from);
        }
    } else {
        console.warn('addMessage: unhandled message format', messageData);
    }
},

/**
 * Store a message and show a notification badge (message is NOT for current view).
 */
_storeAndNotify(chatMsg, targetKey, fromNodeId) {
    // Store in IndexedDB (async, fire-and-forget with error logging)
    this.storeMessageForTarget(chatMsg);

    // Increment unread count
    this._unreadCounts[targetKey] = (this._unreadCounts[targetKey] || 0) + 1;

    // Track node with unread messages (for DMs)
    if (targetKey.startsWith('messages_node_') && fromNodeId) {
        this._nodesWithUnread.add(fromNodeId);
    }

    // Update badges on channels and nodes
    this._updateNotificationBadges();

    // Re-sort nodes if a DM arrived
    if (targetKey.startsWith('messages_node_') && this.storage) {
        const nodes = this.storage.getNodes();
        this.updateNodesList(nodes);
    }
},

/**
 * Update notification badges on channel and node elements.
 */
_updateNotificationBadges() {
    // Update channel badges
    document.querySelectorAll('.channel-item').forEach(el => {
        const channelIdx = el.dataset.channelIndex;
        if (channelIdx === undefined) return;
        const key = `messages_channel_${channelIdx}`;
        const count = this._unreadCounts[key] || 0;

        // Remove existing badge
        let badge = el.querySelector('.unread-badge');
        if (count > 0) {
            if (!badge) {
                badge = document.createElement('span');
                badge.className = 'unread-badge';
                el.appendChild(badge);
            }
            badge.textContent = count > 99 ? '99+' : count;
        } else if (badge) {
            badge.remove();
        }
    });

    // Update node badges
    document.querySelectorAll('.node-item').forEach(el => {
        const detailsEl = el.querySelector('.node-details');
        if (!detailsEl) return;

        // Extract node ID from details text (e.g., "<uCon@!3d8309d0>")
        const detailsText = detailsEl.textContent || '';
        const idMatch = detailsText.match(/(![0-9a-f]{8})/i);
        if (!idMatch) return;

        const nodeId = idMatch[1];
        const key = `messages_node_${nodeId}`;
        const count = this._unreadCounts[key] || 0;

        // Remove existing badge
        let badge = el.querySelector('.unread-badge');
        if (count > 0) {
            if (!badge) {
                badge = document.createElement('span');
                badge.className = 'unread-badge';
                el.appendChild(badge);
            }
            badge.textContent = count > 99 ? '99+' : count;
        } else if (badge) {
            badge.remove();
        }
    });
},

// Handle node update from WebSocket

/**
 * Check if a message comes from a node not in our current node list.
 * If so, trigger a node list refresh from the server so the new/returning
 * node appears automatically without needing a manual "Refresh Nodes" click.
 * Debounced to avoid excessive API calls when many messages arrive at once.
 */
_checkForUnknownNode(messageData) {
    const fromNode = messageData.from_node || messageData.from;
    if (!fromNode || !this.storage) return;

    const nodes = this.storage.getNodes();
    const known = nodes.some(n => (n.id || n.num) === fromNode);
    if (known) return;

    // Unknown node detected - debounce the refresh (max once per 10 seconds)
    const now = Date.now();
    if (this._lastNodeRefreshTime && (now - this._lastNodeRefreshTime) < 10000) return;
    this._lastNodeRefreshTime = now;

    console.log(`Unknown node detected: ${fromNode} - auto-refreshing node list`);
    this.loadNodes();
},

/**
 * Add (*) to document.title when a new message arrives (if tab is not focused).
 * The marker is cleared when the tab regains focus (see app_core.js).
 */
_notifyNewMessageInTitle() {
    if (document.hidden || !document.hasFocus()) {
        if (!document.title.startsWith('(*)')) {
            document.title = '(*) ' + document.title;
        }
    }
},

/**
 * Show a dropdown menu for clearing chat history with granular time options.
 */
clearCurrentChat() {
    if (!this.storage) return;
    const key = this.getMessageStorageKey();
    if (!key) return;

    // Remove any existing dropdown
    const existing = document.querySelector('.clear-chat-dropdown');
    if (existing) { existing.remove(); return; }

    const targetName = this.sendTarget ? this.sendTarget.name : 'this target';

    const dropdown = document.createElement('div');
    dropdown.className = 'clear-chat-dropdown';

    const options = [
        { label: 'Last 1 hour', hours: 1 },
        { label: 'Last 3 hours', hours: 3 },
        { label: 'Last 6 hours', hours: 6 },
        { label: 'Last 12 hours', hours: 12 },
        { label: 'Last 1 day', hours: 24 },
        { label: 'Last 3 days', hours: 72 },
        { label: 'Last 1 week', hours: 168 },
        { label: 'Last 2 weeks', hours: 336 },
        { label: 'All messages', hours: 0 }
    ];

    options.forEach(opt => {
        const item = document.createElement('div');
        item.className = 'clear-chat-option';
        item.textContent = opt.label;
        item.addEventListener('click', () => {
            dropdown.remove();
            this._clearChatByTime(key, targetName, opt.hours);
        });
        dropdown.appendChild(item);
    });

    // Position relative to the clear chat button
    const clearBtn = document.getElementById('clearChatBtn');
    if (clearBtn) {
        clearBtn.parentElement.style.position = 'relative';
        clearBtn.parentElement.appendChild(dropdown);
    }

    // Close dropdown on outside click
    const closeHandler = (e) => {
        if (!dropdown.contains(e.target) && e.target !== clearBtn) {
            dropdown.remove();
            document.removeEventListener('click', closeHandler);
        }
    };
    setTimeout(() => document.addEventListener('click', closeHandler), 0);
},

/**
 * Clear chat messages by time range.
 * @param {string} key - Storage key for the target
 * @param {string} targetName - Display name
 * @param {number} hours - Hours to clear (0 = all)
 */
_clearChatByTime(key, targetName, hours) {
    const label = hours === 0 ? 'all' : `last ${hours}h of`;
    if (!confirm(`Clear ${label} message history for "${targetName}"?\n\nThis cannot be undone.`)) {
        return;
    }

    if (hours === 0) {
        // Clear all
        this.storage.clearTargetAsync(key).then(count => {
            console.log(`Cleared ${count} messages for ${key}`);
        }).catch(e => {
            console.error('Error clearing messages:', e);
        });
    } else {
        // Clear messages within the last N hours
        const cutoffMs = Date.now() - (hours * 60 * 60 * 1000);
        this.storage.clearTargetBeforeAsync(key, cutoffMs).then(count => {
            console.log(`Cleared ${count} messages older than ${hours}h for ${key}`);
        }).catch(e => {
            console.error('Error clearing messages:', e);
        });
    }

    // Reload message history to reflect changes
    setTimeout(() => this.loadMessageHistory(), HISTORY_RELOAD_DELAY_MS);
    this.showMessage(`Chat history cleared (${hours === 0 ? 'all' : 'last ' + hours + 'h'})`, 'success');
},

/**
 * Delete a single message from IndexedDB and remove its DOM element.
 * @param {HTMLElement} messageElement - The .message DOM element
 */
_deleteMessage(messageElement) {
    if (!this.storage) return;

    // Get the _dbId stored on the element's dataset
    const dbId = messageElement ? Number(messageElement.dataset.dbId) : NaN;
    if (dbId && !isNaN(dbId)) {
        this.storage.deleteMessageAsync(dbId).catch(e => {
            console.error('Error deleting message:', e);
        });
    }

    if (messageElement) {
        messageElement.remove();
    }
},

// ── Message Search ─────────────────────────────────────────────────

/**
 * Toggle the message search input visibility.
 */
_toggleMessageSearch() {
    const input = document.getElementById('msgSearchInput');
    const btn = document.getElementById('msgSearchBtn');
    if (!input) return;

    const isExpanded = input.classList.contains('expanded');
    if (isExpanded) {
        this._closeMessageSearch();
    } else {
        input.style.display = 'block';
        // Force reflow before adding class for transition
        input.offsetWidth;
        input.classList.add('expanded');
        btn.classList.add('active');
        input.focus();
    }
},

/**
 * Close the message search and restore normal chat view.
 */
_closeMessageSearch() {
    const input = document.getElementById('msgSearchInput');
    const btn = document.getElementById('msgSearchBtn');
    if (input) {
        input.classList.remove('expanded');
        btn && btn.classList.remove('active');
        input.value = '';
        // After transition, hide
        setTimeout(() => {
            if (!input.classList.contains('expanded')) {
                input.style.display = 'none';
            }
        }, 300);
    }
    // Remove results bar
    const resultsBar = document.querySelector('.msg-search-results-bar');
    if (resultsBar) resultsBar.remove();

    // Reload normal message history
    if (this._searchActive) {
        this._searchActive = false;
        this.loadMessageHistory();
    }
},

/**
 * Execute a message search using IndexedDB.
 */
async _executeMessageSearch() {
    const input = document.getElementById('msgSearchInput');
    if (!input || !this.storage) return;

    const query = input.value.trim();
    if (!query) {
        // Empty query - restore normal view
        if (this._searchActive) {
            this._searchActive = false;
            const resultsBar = document.querySelector('.msg-search-results-bar');
            if (resultsBar) resultsBar.remove();
            this.loadMessageHistory();
        }
        return;
    }

    this._searchActive = true;
    const targetKey = this.getMessageStorageKey();
    if (!targetKey) return;

    try {
        const results = await this.storage.searchMessagesAsync(targetKey, query, 100);
        this._renderSearchResults(results, query);
    } catch (e) {
        console.error('Message search error:', e);
    }
},

/**
 * Render search results in the messages container.
 * @param {Array} results - matching messages
 * @param {string} query - the search query for highlighting
 */
_renderSearchResults(results, query) {
    const messagesContainer = document.getElementById('messagesContainer');
    if (!messagesContainer) return;

    // Clear current messages
    messagesContainer.innerHTML = '';

    // Add/update results bar
    let resultsBar = document.querySelector('.msg-search-results-bar');
    if (!resultsBar) {
        resultsBar = document.createElement('div');
        resultsBar.className = 'msg-search-results-bar';
        messagesContainer.parentNode.insertBefore(resultsBar, messagesContainer);
    }
    resultsBar.innerHTML = `
        <span><span class="search-count">${results.length}</span> result${results.length !== 1 ? 's' : ''} for "${this.escapeHtml(query)}"</span>
        <span class="search-close" title="Close search">&times;</span>
    `;
    resultsBar.querySelector('.search-close').addEventListener('click', () => this._closeMessageSearch());

    if (results.length === 0) {
        messagesContainer.innerHTML = '<div class="empty-history-hint">No messages found matching your search.</div>';
        return;
    }

    // Render each result (newest first from search, reverse for chronological)
    const chronological = results.reverse();
    for (const msg of chronological) {
        // Highlight matching text
        const highlighted = { ...msg };
        if (highlighted.text) {
            highlighted.text = this._highlightSearchMatch(highlighted.text, query);
        }
        this.renderChatMessage(msg, false);
    }

    // After rendering, highlight the text in rendered elements
    const needle = query.toLowerCase();
    messagesContainer.querySelectorAll('.message-content').forEach(el => {
        const html = el.innerHTML;
        const text = el.textContent;
        if (text.toLowerCase().includes(needle)) {
            el.innerHTML = this._highlightSearchMatch(html, query);
        }
    });

    messagesContainer.scrollTop = messagesContainer.scrollHeight;
},

/**
 * Highlight search matches in text (case-insensitive).
 * @param {string} text - original text/html
 * @param {string} query - search query
 * @returns {string} text with <span class="search-highlight"> wrapping matches
 */
_highlightSearchMatch(text, query) {
    if (!query) return text;
    // Escape regex special chars in query
    const escaped = query.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    const regex = new RegExp(`(${escaped})`, 'gi');
    return text.replace(regex, '<span class="search-highlight">$1</span>');
},

// ── Image Segment Rendering ─────────────────────────────────────
// Image segment detection, parsing, grouping, and reassembly are
// handled by app_images.js (loaded after this file). This file only
// provides the binary image segment renderer used during message
// rendering.

/**
 * Render a binary message that contains image segment data.
 * Similar to text segment rendering but with a purple label.
 */
_renderBinaryImageSegmentContent(el, messageData, fromName, time, payloadText) {
    const parsed = this._parseImageSegment(payloadText);
    let segLabel = parsed
        ? `Image segment ${parsed.segNum}/${parsed.totalSegments}`
        : 'Image Segment';
    if (parsed && parsed.checksum) {
        segLabel += ` [${parsed.checksum}]`;
    }
    el.innerHTML = `
        <div class="message-header">
            <span class="message-from">${fromName}</span>
            <span class="message-time">${time}</span>
        </div>
        <details class="segment-disclosure">
            <summary class="image-segment-info">
                <span class="image-segment-label binary">${segLabel}</span>
            </summary>
            <div class="message-content segment-data">${this.escapeHtml(payloadText)}</div>
        </details>
    `;

    // Copy Payload button inside the disclosure
    const segmentText = parsed ? parsed.fullSegment : payloadText;
    const disclosure = el.querySelector('.segment-disclosure');
    const copyBtn = document.createElement('button');
    copyBtn.className = 'copy-payload-btn';
    copyBtn.textContent = 'Copy Payload';
    copyBtn.addEventListener('click', () => {
        this._copyToClipboard(segmentText).then(() => {
            this.showMessage('Payload copied', 'success');
        });
    });
    disclosure.appendChild(copyBtn);

    // Forward button to re-send received segment into channel
    const fwdBtn = document.createElement('button');
    fwdBtn.className = 'copy-payload-btn btn-forward-seg';
    fwdBtn.textContent = 'Forward to Channel';
    fwdBtn.addEventListener('click', () => {
        this._forwardSegmentToChannel(segmentText);
    });
    disclosure.appendChild(fwdBtn);

    // Store segment data on the element for reassembly
    if (parsed) {
        el.dataset.imageSegment = 'true';
        el.dataset.segNum = parsed.segNum;
        el.dataset.segPayload = parsed.fullSegment;
        if (parsed.checksum) el.dataset.checksum = parsed.checksum;
    }
}

});
