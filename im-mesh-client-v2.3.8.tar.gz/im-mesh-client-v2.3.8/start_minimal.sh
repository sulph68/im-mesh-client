#!/bin/bash
echo "🚀 Starting Meshtastic Web Client (Minimal Version)"
echo "====================================================="

# Check Python
if ! python3 --version; then
    echo "❌ Python 3 not found"
    exit 1
fi

# Install dependencies without venv
echo "📦 Installing dependencies..."
pip3 install -r requirements.txt >/dev/null 2>&1 || pip install -r requirements.txt >/dev/null 2>&1

# Set environment variables
export WEB_HOST=${WEB_HOST:-0.0.0.0}
export WEB_PORT=${WEB_PORT:-8082}

# Kill any existing server
pkill -f "python3 main.py" 2>/dev/null || true
sleep 1

echo "🌐 Starting server on http://localhost:$WEB_PORT"
echo "💡 Use Ctrl+C to stop"
echo ""

# Start the application
python3 main.py

