"""
XOR Horizontal -> XOR Vertical -> Bit-wise VLQ RLE -> Heatshrink2 compression module.

Implements the algorithm from new_algo.txt:
  Stage 1: Horizontal XOR (row-wise delta encoding)
  Stage 2: Vertical XOR (column-wise delta encoding)
  Stage 3: Flatten to 1D stream (row-major)
  Stage 4: Bit-based Variable-Length RLE with VLQ run lengths
  Stage 5: Heatshrink2 compression (handled externally)

Supports 1-bit, 2-bit, and 4-bit pixel depths.
"""

from typing import List, Tuple
import struct


# ---------------------------------------------------------------------------
# BitWriter / BitReader helpers
# ---------------------------------------------------------------------------

class BitWriter:
    """Write individual bits into a byte buffer."""

    def __init__(self):
        self.buffer: List[int] = []
        self.current_byte: int = 0
        self.bit_pos: int = 0  # 0-7, number of bits written into current_byte

    def write_bits(self, value: int, nbits: int) -> None:
        """Write *nbits* from *value* (MSB first)."""
        for i in range(nbits - 1, -1, -1):
            bit = (value >> i) & 1
            self.current_byte = (self.current_byte << 1) | bit
            self.bit_pos += 1
            if self.bit_pos == 8:
                self.buffer.append(self.current_byte)
                self.current_byte = 0
                self.bit_pos = 0

    def flush(self) -> bytes:
        """Flush remaining bits (left-aligned pad) and return bytes."""
        if self.bit_pos > 0:
            self.current_byte <<= (8 - self.bit_pos)
            self.buffer.append(self.current_byte)
            self.current_byte = 0
            self.bit_pos = 0
        return bytes(self.buffer)

    def size_bytes(self) -> int:
        """Current size including partial byte."""
        return len(self.buffer) + (1 if self.bit_pos > 0 else 0)


class BitReader:
    """Read individual bits from a byte buffer."""

    def __init__(self, data: bytes):
        self.data = data
        self.byte_pos: int = 0
        self.bit_pos: int = 0  # 0-7, next bit to read within current byte

    def read_bits(self, nbits: int) -> int:
        """Read *nbits* and return as integer (MSB first)."""
        value = 0
        for _ in range(nbits):
            if self.byte_pos >= len(self.data):
                # Ran out of data – return what we have (zero-padded)
                value <<= 1
                continue
            byte_val = self.data[self.byte_pos]
            bit = (byte_val >> (7 - self.bit_pos)) & 1
            value = (value << 1) | bit
            self.bit_pos += 1
            if self.bit_pos == 8:
                self.bit_pos = 0
                self.byte_pos += 1
        return value

    def bits_remaining(self) -> int:
        """Approximate bits remaining."""
        return (len(self.data) - self.byte_pos) * 8 - self.bit_pos


# ---------------------------------------------------------------------------
# VLQ helpers
# ---------------------------------------------------------------------------

def write_vlq(bw: BitWriter, value: int) -> None:
    """Write a variable-length quantity (7-bit chunks, MSB continuation)."""
    chunks: List[int] = []
    while True:
        chunk = value & 0x7F
        value >>= 7
        if value != 0:
            chunk |= 0x80  # continuation bit
        chunks.append(chunk)
        if value == 0:
            break
    # Write chunks in order (LSB-first encoding)
    for ch in chunks:
        bw.write_bits(ch, 8)


def read_vlq(br: BitReader) -> int:
    """Read a VLQ-encoded integer."""
    value = 0
    shift = 0
    while True:
        if br.bits_remaining() < 8:
            # Not enough data – return what we have
            byte_val = br.read_bits(8)
            value |= (byte_val & 0x7F) << shift
            break
        byte_val = br.read_bits(8)
        value |= (byte_val & 0x7F) << shift
        shift += 7
        if not (byte_val & 0x80):
            break
    return value


# ---------------------------------------------------------------------------
# XOR stages
# ---------------------------------------------------------------------------

def xor_horizontal(pixels: List[List[int]]) -> List[List[int]]:
    """
    Stage 1 – Horizontal XOR.
    For each row, replace pixel[x] with pixel[x] XOR pixel[x-1].
    First pixel in each row is XOR with 0.
    Operates in-place on a copy.
    """
    h = len(pixels)
    w = len(pixels[0]) if h > 0 else 0
    out = [row[:] for row in pixels]
    for y in range(h):
        prev = 0
        for x in range(w):
            curr = out[y][x]
            out[y][x] = curr ^ prev
            prev = curr
    return out


def xor_vertical(pixels: List[List[int]]) -> List[List[int]]:
    """
    Stage 2 – Vertical XOR.
    For each column, replace pixel[y][x] with pixel[y][x] XOR pixel[y-1][x].
    First row of each column is XOR with 0.
    Operates in-place on a copy.
    """
    h = len(pixels)
    w = len(pixels[0]) if h > 0 else 0
    out = [row[:] for row in pixels]
    for x in range(w):
        prev = 0
        for y in range(h):
            curr = out[y][x]
            out[y][x] = curr ^ prev
            prev = curr
    return out


def inverse_xor_vertical(pixels: List[List[int]]) -> List[List[int]]:
    """Inverse of xor_vertical – reconstruct original from vertical XOR."""
    h = len(pixels)
    w = len(pixels[0]) if h > 0 else 0
    out = [row[:] for row in pixels]
    for x in range(w):
        prev = 0
        for y in range(h):
            curr = out[y][x] ^ prev
            out[y][x] = curr
            prev = curr
    return out


def inverse_xor_horizontal(pixels: List[List[int]]) -> List[List[int]]:
    """Inverse of xor_horizontal – reconstruct original from horizontal XOR."""
    h = len(pixels)
    w = len(pixels[0]) if h > 0 else 0
    out = [row[:] for row in pixels]
    for y in range(h):
        prev = 0
        for x in range(w):
            curr = out[y][x] ^ prev
            out[y][x] = curr
            prev = curr
    return out


# ---------------------------------------------------------------------------
# Flatten / unflatten
# ---------------------------------------------------------------------------

def flatten_row_major(pixels_2d: List[List[int]]) -> List[int]:
    """Stage 3 – Flatten 2D pixel array to 1D stream (row-major)."""
    stream = []
    for row in pixels_2d:
        stream.extend(row)
    return stream


def unflatten_row_major(stream: List[int], width: int, height: int) -> List[List[int]]:
    """Reverse of flatten_row_major."""
    pixels_2d = []
    for y in range(height):
        start = y * width
        pixels_2d.append(stream[start:start + width])
    return pixels_2d


# ---------------------------------------------------------------------------
# RLE encode / decode (bit-level with VLQ run lengths)
# ---------------------------------------------------------------------------

def rle_vlq_encode(stream: List[int], bit_depth: int) -> bytes:
    """
    Stage 4 – Bit-based Variable-Length RLE.
    Each run: [VALUE (bit_depth bits)] + [RUN LENGTH (VLQ)]
    Returns byte array from BitWriter.
    """
    if not stream:
        return b''

    bw = BitWriter()
    i = 0
    n = len(stream)

    while i < n:
        value = stream[i]
        run = 1
        while i + run < n and stream[i + run] == value:
            run += 1

        # Write VALUE (bit_depth bits)
        bw.write_bits(value, bit_depth)
        # Write RUN LENGTH (VLQ)
        write_vlq(bw, run)

        i += run

    return bw.flush()


def rle_vlq_decode(data: bytes, bit_depth: int, expected_pixels: int) -> List[int]:
    """
    Decode bit-based VLQ RLE data.
    Returns pixel stream.
    """
    if not data:
        return []

    br = BitReader(data)
    pixels = []

    while len(pixels) < expected_pixels and br.bits_remaining() >= bit_depth:
        value = br.read_bits(bit_depth)
        if br.bits_remaining() < 8:
            # May have a partial VLQ at end – try reading
            run = read_vlq(br)
            if run == 0:
                run = 1
        else:
            run = read_vlq(br)
            if run == 0:
                run = 1

        # Clamp to not exceed expected
        remaining = expected_pixels - len(pixels)
        actual_run = min(run, remaining)
        pixels.extend([value] * actual_run)

    return pixels[:expected_pixels]


# ---------------------------------------------------------------------------
# Full encode / decode pipeline
# ---------------------------------------------------------------------------

# Direction flags stored in packet header
DIR_H_THEN_V = 0  # horizontal XOR first, then vertical
DIR_V_THEN_H = 1  # vertical XOR first, then horizontal

# Packet header format:
#   Magic:     3 bytes "XVR"
#   Version:   1 byte  (2)
#   Width:     2 bytes (uint16 LE) – supports any width
#   Height:    2 bytes (uint16 LE) – supports any height
#   Bit depth: 1 byte
#   Flags:     1 byte  (bit 0 = direction: 0=H-then-V, 1=V-then-H)
#   Total: 10 bytes

HEADER_MAGIC = b'XVR'
HEADER_VERSION = 2
HEADER_SIZE = 10
HEADER_FORMAT = '<3sBHHBB'  # little-endian: 3s B H H B B


def _encode_direction(flat_pixels: List[int], width: int, height: int,
                      bit_depth: int, direction: int) -> bytes:
    """Encode with a specific XOR direction. Returns RLE-compressed bytes (no header)."""
    # Convert flat to 2D
    pixels_2d = unflatten_row_major(flat_pixels, width, height)

    if direction == DIR_H_THEN_V:
        xored = xor_horizontal(pixels_2d)
        xored = xor_vertical(xored)
    else:
        xored = xor_vertical(pixels_2d)
        xored = xor_horizontal(xored)

    stream = flatten_row_major(xored)
    return rle_vlq_encode(stream, bit_depth)


def encode_xor_vlq(pixels: List[int], width: int, height: int,
                   bit_depth: int) -> bytes:
    """
    Full encode pipeline: XOR H->V (or V->H, picks best) -> VLQ RLE -> packet.
    Does NOT apply heatshrink (caller handles that).

    Args:
        pixels: Flat pixel array with values 0 to (2^bit_depth - 1)
        width: Image width
        height: Image height
        bit_depth: 1, 2, or 4

    Returns:
        Complete packet bytes (header + compressed data)
    """
    if len(pixels) != width * height:
        raise ValueError(f"Pixel count {len(pixels)} != {width}x{height}={width*height}")

    # Try both directions, pick smaller
    data_hv = _encode_direction(pixels, width, height, bit_depth, DIR_H_THEN_V)
    data_vh = _encode_direction(pixels, width, height, bit_depth, DIR_V_THEN_H)

    if len(data_vh) < len(data_hv):
        direction = DIR_V_THEN_H
        compressed_data = data_vh
    else:
        direction = DIR_H_THEN_V
        compressed_data = data_hv

    # Raw fallback: if compressed is larger than raw packed pixels, use raw
    raw_size = (width * height * bit_depth + 7) // 8
    use_raw = len(compressed_data) >= raw_size
    if use_raw:
        # Pack raw pixels
        bw = BitWriter()
        for px in pixels:
            bw.write_bits(px, bit_depth)
        compressed_data = bw.flush()
        direction = DIR_H_THEN_V  # doesn't matter for raw
        flags = 0x02  # bit 1 = raw flag
    else:
        flags = direction & 0x01

    # Build header
    header = struct.pack(HEADER_FORMAT, HEADER_MAGIC, HEADER_VERSION,
                         width, height, bit_depth, flags)

    return header + compressed_data


def decode_xor_vlq(packet: bytes) -> Tuple[List[int], int, int, int, dict]:
    """
    Full decode pipeline.

    Args:
        packet: Complete packet bytes (header + compressed data)

    Returns:
        Tuple of (pixels, width, height, bit_depth, stats)
        pixels are flat list with values 0 to (2^bit_depth - 1)
    """
    if len(packet) < HEADER_SIZE:
        raise ValueError(f"Packet too short: {len(packet)} < {HEADER_SIZE}")

    # Parse header
    magic, version, width, height, bit_depth, flags = struct.unpack(
        HEADER_FORMAT, packet[:HEADER_SIZE])

    if magic != HEADER_MAGIC:
        raise ValueError(f"Invalid magic: {magic!r}, expected {HEADER_MAGIC!r}")

    is_raw = bool(flags & 0x02)
    direction = flags & 0x01

    compressed_data = packet[HEADER_SIZE:]
    expected_pixels = width * height

    if is_raw:
        # Decode raw packed pixels
        br = BitReader(compressed_data)
        pixels = []
        for _ in range(expected_pixels):
            if br.bits_remaining() >= bit_depth:
                pixels.append(br.read_bits(bit_depth))
            else:
                pixels.append(0)
    else:
        # Decode RLE
        stream = rle_vlq_decode(compressed_data, bit_depth, expected_pixels)

        # Pad if needed
        while len(stream) < expected_pixels:
            stream.append(0)
        stream = stream[:expected_pixels]

        # Inverse XOR
        pixels_2d = unflatten_row_major(stream, width, height)

        if direction == DIR_H_THEN_V:
            pixels_2d = inverse_xor_vertical(pixels_2d)
            pixels_2d = inverse_xor_horizontal(pixels_2d)
        else:
            pixels_2d = inverse_xor_horizontal(pixels_2d)
            pixels_2d = inverse_xor_vertical(pixels_2d)

        pixels = flatten_row_major(pixels_2d)

    stats = {
        'version': version,
        'direction': 'V-then-H' if direction == DIR_V_THEN_H else 'H-then-V',
        'is_raw_fallback': is_raw,
        'compressed_size': len(compressed_data),
        'packet_size': len(packet),
        'header_size': HEADER_SIZE,
        'compression_ratio': len(compressed_data) / expected_pixels if expected_pixels > 0 else 0
    }

    return pixels, width, height, bit_depth, stats
