"""
Meshtastic Image Encoder
Converts images to compressed Meshtastic-compatible text messages.

Encoding pipeline:
    1. Load/normalize image (RGB, handle transparency)
    2. Resize to target dimensions (center crop + LANCZOS)
    3. Optional 2x2 pixel block averaging
    4. Grayscale conversion + gamma-corrected quantization
    5. Compress using selected strategy (or auto-select best)
    6. Heatshrink2 secondary compression
    7. Base64 encode + split into message segments with SHA256 checksum
"""

from PIL import Image
import base64
import hashlib
import math
from typing import List, Tuple, Dict, Any
from .config import MESSAGE_PREFIX
from .models import ImageDimensions, CompressionConfig, SegmentConfig, CompressionStats
from .image_processor import ImageProcessor
from .compression import CompressionFactory


def encode_image_with_config(image: Image.Image, config: CompressionConfig, 
                           dimensions: ImageDimensions, segment_config: SegmentConfig = None,
                           gamma: float = 1.0, pixel_compress: bool = False) -> Tuple[List[str], CompressionStats]:
    """
    Modern encode function using configuration objects.
    
    Args:
        image: PIL Image to encode
        config: Compression configuration
        dimensions: Target dimensions
        segment_config: Segment configuration
        gamma: Gamma correction value (0.1-5.0, default 1.0)
        pixel_compress: Apply 2x2 pixel block averaging before quantization
        
    Returns:
        Tuple of (message_segments, compression_stats)
    """
    if segment_config is None:
        segment_config = SegmentConfig()
    
    # Preprocess image for compression strategies
    processed_image = _preprocess_image_for_compression(image, config, dimensions, gamma, pixel_compress)
    
    # Get compression strategy
    strategy = CompressionFactory.get_strategy(config.method)
    
    # Compress image
    compressed_data, stats = strategy.compress(processed_image, config)
    
    # Apply heatshrink compression if enabled
    if config.use_heatshrink:
        try:
            import heatshrink2
            compressed_data = heatshrink2.compress(compressed_data, window_sz2=11, lookahead_sz2=4)
        except ImportError:
            # Heatshrink not available, continue without it
            pass
    
    # Convert to base64
    base64_data = base64.b64encode(compressed_data).decode('ascii')
    stats.base64_encoded_chars = len(base64_data)
    
    # For 'best' encoding, resolve the actual winning method for the segment header
    actual_config = config
    if config.method == 'best' and stats.compression_method.startswith('best('):
        actual_method = stats.compression_method[5:-1]  # extract "xor_vlq_rle" from "best(xor_vlq_rle)"
        actual_config = CompressionConfig(
            method=actual_method,
            bit_depth=config.bit_depth,
            use_heatshrink=config.use_heatshrink
        )
    
    # Create message segments
    segments = _create_message_segments(
        base64_data, 
        dimensions, 
        actual_config, 
        segment_config.max_length
    )
    
    return segments, stats


def _preprocess_image_for_compression(image: Image.Image, config: CompressionConfig, dimensions: ImageDimensions, gamma: float = 1.0, pixel_compress: bool = False) -> Image.Image:
    """
    Preprocess image for compression strategies.
    
    Args:
        image: Original PIL Image
        config: Compression configuration
        dimensions: Target dimensions
        gamma: Gamma correction value (0.1-5.0, default 1.0)
        pixel_compress: Apply 2x2 pixel block averaging before quantization
        
    Returns:
        Processed PIL Image ready for compression
    """
    from .image_processor import ImageProcessor
    
    # Normalize image
    normalized = ImageProcessor.normalize_image(image)
    
    # Resize to target dimensions
    resized = ImageProcessor.resize_with_aspect_ratio(normalized, dimensions)
    
    # Convert to grayscale
    grayscale = resized.convert('L')
    
    # Apply 2x2 pixel compression if requested (before quantization)
    if pixel_compress:
        grayscale = ImageProcessor.pixel_compress_2x2(grayscale)
    
    # Quantize with gamma
    quantized = ImageProcessor.quantize_image(grayscale, config, gamma)
    
    return quantized


def encode_image(image: Image.Image, bit_depth: int, target_width: int = 128, target_height: int = 64, 
                compression_method: str = 'tile_rle', max_segment_length: int = 220,
                gamma: float = 1.0, pixel_compress: bool = False) -> Tuple[List[str], Dict[str, Any]]:
    """
    Legacy encode function for backward compatibility.
    
    Args:
        image: PIL Image to encode
        bit_depth: Bit depth (1, 2, or 4)
        target_width: Target image width
        target_height: Target image height
        compression_method: Compression method
        max_segment_length: Maximum length per message segment
        gamma: Gamma correction value (0.1-5.0, default 1.0)
        pixel_compress: Apply 2x2 pixel block averaging before quantization
        
    Returns:
        Tuple of (message_segments, compression_stats_dict)
    """
    # Create configuration objects
    config = CompressionConfig(method=compression_method, bit_depth=bit_depth)
    dimensions = ImageDimensions(target_width, target_height)
    segment_config = SegmentConfig(max_segment_length)
    
    # Use modern implementation
    segments, stats = encode_image_with_config(image, config, dimensions, segment_config, gamma, pixel_compress)
    
    # Convert stats back to dictionary for backward compatibility
    stats_dict = {
        'compression_method': stats.compression_method,
        'compression_ratio': stats.compression_ratio,
        'unique_tiles': stats.unique_tiles if stats.unique_tiles is not None else 'N/A',
        'total_tiles': stats.total_tiles if stats.total_tiles is not None else 'N/A',
        'base64_encoded_chars': stats.base64_encoded_chars
    }
    
    return segments, stats_dict


def _create_message_segments(base64_data: str, dimensions: ImageDimensions, 
                           config: CompressionConfig, max_segment_length: int) -> List[str]:
    """Create message segments from base64 data with checksum.
    
    Distributes data evenly across segments so all segments are
    approximately the same length, rather than filling each to max
    and leaving a short final segment.
    """
    # Compute checksum: SHA256 of the raw compressed bytes, first 4 bytes as hex (8 chars)
    raw_bytes = base64.b64decode(base64_data.encode('ascii'))
    checksum = hashlib.sha256(raw_bytes).hexdigest()[:8]
    
    # Format: IMG{w}x{h}:{method}{depth}:{checksum}:{seg}/{total}:{data}
    header_base = f"{MESSAGE_PREFIX}{dimensions.width}x{dimensions.height}:{config.method_code}{config.bit_depth}:{checksum}:"
    
    # Calculate overhead for segment numbering
    # For single segment: "0:" = 2 chars
    # For multi segment: "NN/TT:" where NN and TT grow with segment count
    # Use conservative estimate first to determine segment count
    numbering_estimate = 8  # covers up to "999/999:"
    max_data_per_segment = max_segment_length - len(header_base) - numbering_estimate
    
    if max_data_per_segment <= 0:
        raise ValueError(f"Segment length {max_segment_length} too small for header")
    
    # Single segment case
    single_overhead = len(header_base) + 2  # "0:"
    if len(base64_data) <= max_segment_length - single_overhead:
        return [f"{header_base}0:{base64_data}"]
    
    # Calculate number of segments needed
    total_segments = math.ceil(len(base64_data) / max_data_per_segment)
    
    # Recalculate with actual numbering width
    numbering_width = len(f"{total_segments - 1}/{total_segments}:")
    max_data_per_segment = max_segment_length - len(header_base) - numbering_width
    total_segments = math.ceil(len(base64_data) / max_data_per_segment)
    
    # Recalculate again in case total_segments digit count changed
    numbering_width = len(f"{total_segments - 1}/{total_segments}:")
    max_data_per_segment = max_segment_length - len(header_base) - numbering_width
    total_segments = math.ceil(len(base64_data) / max_data_per_segment)
    
    # Distribute data evenly: each segment gets floor or ceil share
    data_len = len(base64_data)
    base_size = data_len // total_segments
    remainder = data_len % total_segments
    
    segments = []
    pos = 0
    for i in range(total_segments):
        # First 'remainder' segments get one extra character
        chunk_size = base_size + (1 if i < remainder else 0)
        segment_data = base64_data[pos:pos + chunk_size]
        pos += chunk_size
        
        segment_msg = f"{header_base}{i}/{total_segments}:{segment_data}"
        segments.append(segment_msg)
    
    return segments


def prepare_image_for_encoding(image_file: Any, bit_depth: int = 1, target_width: int = 128, target_height: int = 64,
                              gamma: float = 1.0) -> Tuple[Image.Image, Image.Image, Dict[str, Any]]:
    """
    Legacy function for backward compatibility.
    
    Args:
        image_file: File object or path to image
        bit_depth: Target bit depth
        target_width: Target image width
        target_height: Target image height
        gamma: Gamma correction value (0.1-5.0, default 1.0)
        
    Returns:
        Tuple of (original_image, processed_image, preparation_stats_dict)
    """
    # Create configuration objects - use rle_nibble as default since it works with any dimensions
    config = CompressionConfig(method='rle_nibble', bit_depth=bit_depth)
    dimensions = ImageDimensions(target_width, target_height)
    
    # Use modern implementation
    original, processed, stats = ImageProcessor.prepare_image_for_encoding(image_file, config, dimensions, gamma)
    
    # Convert stats to dictionary for backward compatibility
    stats_dict = {
        'original_size': stats.original_size,
        'target_size': stats.target_size,
        'original_mode': stats.original_mode,
        'bit_depth': stats.bit_depth,
        'quantization_levels': stats.quantization_levels
    }
    
    return original, processed, stats_dict


# ============================================================================
# LIBRARY API - Simple functions for external library usage  
# ============================================================================

def encode_image_simple(image: Image.Image, bit_depth: int = 1, width: int = 64, height: int = 64, 
                       compression_method: str = 'rle_nibble', segment_length: int = 220) -> List[str]:
    """
    Simple library API to encode a PIL Image to Meshtastic message segments.
    
    Args:
        image: PIL Image object
        bit_depth: Bit depth (1, 2, or 4)  
        width: Target width
        height: Target height
        compression_method: 'tile_rle', 'rle_nibble', or 'rle_nibble_xor'
        segment_length: Maximum segment length
        
    Returns:
        List of message segments ready for transmission
        
    Example:
        >>> from PIL import Image
        >>> from run.encoder import encode_image_simple
        >>> img = Image.open('test.png')
        >>> segments = encode_image_simple(img, bit_depth=1, width=64, height=64)
        >>> print(f"Created {len(segments)} segments")
    """
    # Use the existing encode_image function which accepts PIL Image directly
    segments, _ = encode_image(image, bit_depth, width, height, compression_method, segment_length)
    return segments


def encode_image_file(image_path: str, bit_depth: int = 1, width: int = 64, height: int = 64,
                     compression_method: str = 'rle_nibble', segment_length: int = 220) -> Dict[str, Any]:
    """
    Simple library API to encode an image file to Meshtastic message segments with stats.
    
    Args:
        image_path: Path to image file
        bit_depth: Bit depth (1, 2, or 4)
        width: Target width  
        height: Target height
        compression_method: 'tile_rle', 'rle_nibble', or 'rle_nibble_xor'
        segment_length: Maximum segment length
        
    Returns:
        Dictionary containing:
        - segments: List of message segments
        - compression_stats: Compression statistics
        - preparation_stats: Image preparation statistics
        
    Example:
        >>> from run.encoder import encode_image_file
        >>> result = encode_image_file('test.png', bit_depth=1, width=64, height=64)
        >>> segments = result['segments']
        >>> print(f"Compression ratio: {result['compression_stats']['compression_ratio']:.2f}")
    """
    with open(image_path, 'rb') as f:
        original_image, processed_image, prep_stats = prepare_image_for_encoding(f, bit_depth, width, height)
    
    segments, compression_stats = encode_image(processed_image, bit_depth, width, height, compression_method, segment_length)
    
    return {
        'segments': segments,
        'compression_stats': compression_stats,
        'preparation_stats': prep_stats,
        'original_image': original_image,
        'processed_image': processed_image
    }


