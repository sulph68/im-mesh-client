"""
Image processing services for the Meshtastic Image Encoder/Decoder.
"""

from PIL import Image
from typing import Any, Union, Tuple
from .models import ImageDimensions, CompressionConfig, PreparationStats


class ImageProcessor:
    """Service for image processing operations."""
    
    @staticmethod
    def pixels_to_levels(pixels: list, bit_depth: int) -> list:
        """Convert 0-255 pixel values to 0-(2^bit_depth - 1) range.
        
        Args:
            pixels: list of ints in 0-255 range
            bit_depth: 1, 2, or 4
            
        Returns:
            list of ints in 0 to (2^bit_depth - 1) range
        """
        max_val = (1 << bit_depth) - 1
        if max_val == 0:
            return [1 if p > 127 else 0 for p in pixels]
        return [round(p * max_val / 255.0) for p in pixels]
    
    @staticmethod
    def levels_to_pixels(pixels: list, bit_depth: int) -> list:
        """Convert 0-(2^bit_depth - 1) pixel values to 0-255 range.
        
        Args:
            pixels: list of ints in 0 to (2^bit_depth - 1) range
            bit_depth: 1, 2, or 4
            
        Returns:
            list of ints in 0-255 range
        """
        max_val = (1 << bit_depth) - 1
        if max_val == 0:
            return [0] * len(pixels)
        return [round(p * 255.0 / max_val) for p in pixels]
    
    @staticmethod
    def load_image(image_source: Union[str, object]) -> Image.Image:
        """
        Load image from file path or file-like object.
        
        Args:
            image_source: File path string or file-like object
            
        Returns:
            PIL Image object
        """
        if hasattr(image_source, 'read'):
            # File-like object
            return Image.open(image_source)
        else:
            # File path
            return Image.open(image_source)
    
    @staticmethod
    def normalize_image(image: Image.Image) -> Image.Image:
        """
        Normalize image to RGB format, handling transparency.
        
        Args:
            image: PIL Image object
            
        Returns:
            RGB PIL Image
        """
        if image.mode in ('RGBA', 'LA'):
            # Handle transparency by creating white background
            background = Image.new('RGB', image.size, (255, 255, 255))
            if image.mode == 'RGBA':
                background.paste(image, mask=image.split()[-1])
            else:
                background.paste(image, mask=image.split()[-1])
            return background
        elif image.mode != 'RGB':
            return image.convert('RGB')
        return image
    
    @staticmethod
    def resize_with_aspect_ratio(image: Image.Image, dimensions: ImageDimensions) -> Image.Image:
        """
        Resize image to target dimensions using center crop to maintain quality.
        
        Args:
            image: PIL Image object
            dimensions: Target dimensions
            
        Returns:
            Resized PIL Image
        """
        target_ratio = dimensions.aspect_ratio
        current_ratio = image.width / image.height
        
        # Determine crop dimensions
        if current_ratio > target_ratio:
            # Image is wider than target - crop width
            new_width = int(image.height * target_ratio)
            new_height = image.height
            left = (image.width - new_width) // 2
            top = 0
            right = left + new_width
            bottom = image.height
        else:
            # Image is taller than target - crop height  
            new_width = image.width
            new_height = int(image.width / target_ratio)
            left = 0
            top = (image.height - new_height) // 2
            right = image.width
            bottom = top + new_height
        
        # Crop and resize
        cropped = image.crop((left, top, right, bottom))
        return cropped.resize((dimensions.width, dimensions.height), Image.Resampling.LANCZOS)
    
    @staticmethod
    def quantize_image(image: Image.Image, config: CompressionConfig, gamma: float = 1.0) -> Image.Image:
        """
        Quantize grayscale image to specified bit depth with optional gamma correction.
        
        Args:
            image: Grayscale PIL Image
            config: Compression configuration
            gamma: Gamma correction value (0.1-5.0, default 1.0 = no correction)
                   Values < 1.0 brighten the image (more detail in shadows)
                   Values > 1.0 darken the image (more detail in highlights)
            
        Returns:
            Quantized PIL Image
        """
        if image.mode != 'L':
            image = image.convert('L')
        
        levels = config.quantization_levels
        
        # Create quantization mapping with gamma correction
        quantization_map = []
        
        for i in range(256):
            # Apply gamma correction: normalize to 0-1, apply gamma, scale back
            normalized = i / 255.0
            gamma_corrected = pow(normalized, gamma)
            
            # Quantize to target levels
            level = min(int(gamma_corrected * levels), levels - 1)
            # Scale back to 0-255 range
            output_value = int((level * 255) / (levels - 1)) if levels > 1 else 0
            quantization_map.append(output_value)
        
        return image.point(quantization_map)
    
    @staticmethod
    def pixel_compress_2x2(image: Image.Image) -> Image.Image:
        """
        2x2 pixel block averaging compression.
        
        Each 2x2 block of pixels is averaged into a single pixel, then
        scaled back up to the original dimensions. This smooths out
        high-frequency detail and noise, which improves compression
        ratios at the cost of some sharpness.
        
        Applied after resize to target dimensions but before quantization,
        so the output image has the same dimensions as the input.
        
        Args:
            image: Grayscale PIL Image
            
        Returns:
            Smoothed PIL Image at the same dimensions
        """
        if image.mode != 'L':
            image = image.convert('L')
        
        w, h = image.size
        # Downscale by 2x using BOX filter (exact 2x2 averaging)
        half_w = max(1, w // 2)
        half_h = max(1, h // 2)
        downscaled = image.resize((half_w, half_h), Image.Resampling.BOX)
        # Scale back up to original size using NEAREST to preserve the blocky look
        return downscaled.resize((w, h), Image.Resampling.NEAREST)
    
    @classmethod
    def prepare_image_for_encoding(cls, image_source: Any, config: CompressionConfig, 
                                 dimensions: ImageDimensions, gamma: float = 1.0) -> Tuple[Image.Image, Image.Image, PreparationStats]:
        """
        Complete image preparation pipeline for encoding.
        
        Args:
            image_source: File object or path to image
            config: Compression configuration
            dimensions: Target dimensions
            gamma: Gamma correction value (0.1-5.0, default 1.0)
            
        Returns:
            Tuple of (original_image, processed_image, preparation_stats)
        """
        # Load and normalize image
        image = cls.load_image(image_source)
        normalized = cls.normalize_image(image)
        
        # Store original image (normalized but unresized)
        original_image = normalized.copy()
        original_size = image.size
        
        # Resize to target dimensions
        resized = cls.resize_with_aspect_ratio(normalized, dimensions)
        
        # Convert to grayscale and quantize with gamma
        grayscale = resized.convert('L')
        quantized = cls.quantize_image(grayscale, config, gamma)
        
        # Create statistics
        stats = PreparationStats(
            original_size=original_size,
            target_size=(dimensions.width, dimensions.height),
            original_mode=image.mode,
            bit_depth=config.bit_depth,
            quantization_levels=config.quantization_levels
        )
        
        return original_image, quantized, stats