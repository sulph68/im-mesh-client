"""
Compression strategies for different encoding methods.
"""

from abc import ABC, abstractmethod
from PIL import Image
from typing import Tuple, Any
from .models import CompressionConfig, CompressionStats
from .image_processor import ImageProcessor
from .tiles import split_tiles, compress_tile_palette, deduplicate_tiles, serialize_tiles
from .rle import rle_encode
from .rle_nibble import create_rle_nibble_packet


class CompressionStrategy(ABC):
    """Abstract base class for compression strategies."""
    
    @abstractmethod
    def compress(self, image: Image.Image, config: CompressionConfig) -> Tuple[bytes, CompressionStats]:
        """
        Compress image using this strategy.
        
        Args:
            image: PIL Image to compress
            config: Compression configuration
            
        Returns:
            Tuple of (compressed_data, compression_stats)
        """
        pass
    
    @property
    @abstractmethod
    def method_name(self) -> str:
        """Get the method name for this strategy."""
        pass


class TileRLEStrategy(CompressionStrategy):
    """Tile + RLE compression strategy."""
    
    @property
    def method_name(self) -> str:
        return "tile_rle"
    
    def compress(self, image: Image.Image, config: CompressionConfig) -> Tuple[bytes, CompressionStats]:
        """Compress using tile + RLE method."""
        pixels = list(image.getdata())
        converted_pixels = ImageProcessor.pixels_to_levels(pixels, config.bit_depth)
        
        # Split into tiles
        tiles = split_tiles(converted_pixels, image.width, image.height)
        
        # Compress each tile with palette compression
        compressed_tiles = []
        for tile in tiles:
            compressed_tile = compress_tile_palette(tile)
            compressed_tiles.append(compressed_tile)
        
        # Deduplicate tiles  
        unique_tiles, reference_map = deduplicate_tiles([tile['data'] for tile in compressed_tiles])
        
        # Calculate tile parameters
        tile_size = 8 if image.width >= 64 else 4
        tiles_x = image.width // tile_size
        tiles_y = image.height // tile_size
        
        # Create proper tile data structure for serialization
        tile_data = {
            'unique_tiles': [{'data': tile} for tile in unique_tiles],
            'reference_map': reference_map,
            'total_tiles': len(tiles),
            'tile_size': tile_size,
            'tiles_x': tiles_x,
            'tiles_y': tiles_y
        }
        
        # Serialize and apply RLE compression
        from .rle import rle_encode
        serialized_data = serialize_tiles(tile_data)
        compressed_data = rle_encode(serialized_data)
        
        # Calculate compression ratio
        original_size = image.width * image.height * config.bit_depth / 8
        compression_ratio = len(compressed_data) / original_size
        
        stats = CompressionStats(
            compression_method=self.method_name,
            compression_ratio=compression_ratio,
            unique_tiles=len(unique_tiles),
            total_tiles=len(tiles),
            base64_encoded_chars=0,  # Will be set later
            uses_heatshrink=config.use_heatshrink
        )
        
        return compressed_data, stats


class RLENibbleStrategy(CompressionStrategy):
    """RLE Nibble compression strategy."""
    
    @property
    def method_name(self) -> str:
        return "rle_nibble"
    
    def compress(self, image: Image.Image, config: CompressionConfig, dimensions: Any = None) -> Tuple[bytes, CompressionStats]:
        """Compress using RLE nibble method."""
        pixels = list(image.getdata())
        converted_pixels = ImageProcessor.pixels_to_levels(pixels, config.bit_depth)
        
        width, height = image.width, image.height
        
        # Apply RLE nibble encoding
        compressed_data = create_rle_nibble_packet(converted_pixels, width, height, config.bit_depth, use_row_xor=False)
        
        # Calculate compression ratio
        original_size = len(pixels) * config.bit_depth / 8
        compression_ratio = len(compressed_data) / original_size
        
        stats = CompressionStats(
            compression_method=self.method_name,
            compression_ratio=compression_ratio,
            unique_tiles=None,  # N/A for pixel-stream methods
            total_tiles=None,   # N/A for pixel-stream methods
            base64_encoded_chars=0,  # Will be set later
            uses_heatshrink=config.use_heatshrink
        )
        
        return compressed_data, stats


class RLENibbleXORStrategy(CompressionStrategy):
    """RLE Nibble XOR compression strategy."""
    
    @property
    def method_name(self) -> str:
        return "rle_nibble_xor"
    
    def compress(self, image: Image.Image, config: CompressionConfig) -> Tuple[bytes, CompressionStats]:
        """Compress using RLE nibble XOR method."""
        pixels = list(image.getdata())
        width, height = image.size
        converted_pixels = ImageProcessor.pixels_to_levels(pixels, config.bit_depth)
        
        # Let create_rle_nibble_packet handle the XOR preprocessing
        compressed_data = create_rle_nibble_packet(converted_pixels, width, height, config.bit_depth, use_row_xor=True)
        
        # Calculate compression ratio
        original_size = len(pixels) * config.bit_depth / 8
        compression_ratio = len(compressed_data) / original_size
        
        stats = CompressionStats(
            compression_method=self.method_name,
            compression_ratio=compression_ratio,
            unique_tiles=None,  # N/A for pixel-stream methods
            total_tiles=None,   # N/A for pixel-stream methods
            base64_encoded_chars=0,  # Will be set later
            uses_heatshrink=config.use_heatshrink
        )
        
        return compressed_data, stats


class XORVLQRLEStrategy(CompressionStrategy):
    """XOR Horizontal -> XOR Vertical -> Bit-level VLQ RLE compression strategy."""
    
    @property
    def method_name(self) -> str:
        return "xor_vlq_rle"
    
    def compress(self, image: Image.Image, config: CompressionConfig) -> Tuple[bytes, CompressionStats]:
        """Compress using XOR + VLQ RLE method."""
        from .xor_vlq_rle import encode_xor_vlq
        
        pixels = list(image.getdata())
        width, height = image.size
        converted_pixels = ImageProcessor.pixels_to_levels(pixels, config.bit_depth)
        
        # Encode (includes header with dimensions)
        compressed_data = encode_xor_vlq(converted_pixels, width, height, config.bit_depth)
        
        # Calculate compression ratio
        original_size = len(pixels) * config.bit_depth / 8
        compression_ratio = len(compressed_data) / original_size if original_size > 0 else 0
        
        stats = CompressionStats(
            compression_method=self.method_name,
            compression_ratio=compression_ratio,
            unique_tiles=None,
            total_tiles=None,
            base64_encoded_chars=0,
            uses_heatshrink=config.use_heatshrink
        )
        
        return compressed_data, stats


class BestEncodingStrategy(CompressionStrategy):
    """Tries all strategies and picks the one producing the smallest final output.
    
    Compares post-heatshrink sizes (when heatshrink is enabled) because the
    ranking can differ from pre-heatshrink sizes -- different compression
    methods produce different byte patterns that heatshrink handles with
    varying effectiveness.
    """
    
    @property
    def method_name(self) -> str:
        return "best"
    
    def compress(self, image: Image.Image, config: CompressionConfig) -> Tuple[bytes, CompressionStats]:
        """Compress using whichever method produces smallest final output.
        
        When heatshrink is enabled, each candidate is compressed through
        heatshrink before size comparison, ensuring the true smallest
        transmittable payload wins.
        """
        candidates = ['rle_nibble', 'rle_nibble_xor', 'xor_vlq_rle']
        # Only include tile_rle if dimensions are divisible by tile size
        w, h = image.size
        tile_size = 8 if w >= 64 else 4
        if w % tile_size == 0 and h % tile_size == 0:
            candidates.insert(0, 'tile_rle')
        
        # Try heatshrink import once
        hs_available = False
        if config.use_heatshrink:
            try:
                import heatshrink2
                hs_available = True
            except ImportError:
                pass
        
        best_data = None
        best_final_size = None
        best_stats = None
        best_method = None
        
        for method_name in candidates:
            try:
                strategy = CompressionFactory.get_strategy(method_name)
                trial_config = CompressionConfig(
                    method=method_name,
                    bit_depth=config.bit_depth,
                    use_heatshrink=config.use_heatshrink
                )
                data, stats = strategy.compress(image, trial_config)
                
                # Compare on post-heatshrink size when heatshrink is enabled
                if hs_available:
                    final_data = heatshrink2.compress(data, window_sz2=11, lookahead_sz2=4)
                    final_size = len(final_data)
                else:
                    final_size = len(data)
                
                if best_final_size is None or final_size < best_final_size:
                    best_data = data
                    best_final_size = final_size
                    best_stats = stats
                    best_method = method_name
            except Exception:
                continue
        
        if best_data is None:
            raise ValueError("All compression methods failed")
        
        # Update stats to reflect best method chosen
        best_stats.compression_method = f"best({best_method})"
        return best_data, best_stats


class CompressionFactory:
    """Factory for creating compression strategies."""
    
    _strategies = {
        'tile_rle': TileRLEStrategy,
        'rle_nibble': RLENibbleStrategy,
        'rle_nibble_xor': RLENibbleXORStrategy,
        'xor_vlq_rle': XORVLQRLEStrategy,
        'best': BestEncodingStrategy
    }
    
    @classmethod
    def get_strategy(cls, method: str) -> CompressionStrategy:
        """Get compression strategy for method."""
        if method not in cls._strategies:
            raise ValueError(f"Unknown compression method: {method}")
        return cls._strategies[method]()