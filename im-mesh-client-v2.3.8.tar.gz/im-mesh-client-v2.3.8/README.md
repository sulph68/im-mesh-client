# Im Mesh Client

A web-based Meshtastic mesh radio client for messaging, image transfer, and node management. Supports multi-tenant operation where multiple browser sessions connect to different Meshtastic nodes simultaneously via TCP or Serial.

This project was created using AI within [PAVE](https://github.com/cnrai/pave-dist).

## Features

- **Multi-tenant**: Multiple browser sessions can connect to different Meshtastic nodes simultaneously
- **TCP & Serial**: Connect to Meshtastic nodes via TCP/IP or local serial device
- **Text Messaging**: Send and receive text messages on channels or direct to nodes
- **Binary Messaging**: Custom binary app-to-app communication over the mesh (PRIVATE_APP)
- **Image Encoding**: Encode images for transmission over Meshtastic with multiple sizes and encoding modes
- **Image Reassembly**: Automatically reassemble received image segments back into images (checksum-based grouping)
- **Node Management**: View all mesh nodes with details, positions, battery, signal info
- **Channel Config**: Read channel configuration from connected nodes
- **Node Map**: Interactive Leaflet map showing node positions with clustering
- **Real-time Updates**: WebSocket-based live message delivery with heartbeat monitoring
- **ACK Tracking**: Visual acknowledgment status for sent messages with retry support
- **Message Search**: Search through message history per channel/node
- **Message Management**: Delete individual messages or clear entire chat history
- **Message Persistence**: All messages stored in browser IndexedDB, preserved across server restarts
- **HTTPS by Default**: Self-signed certificate auto-generation
- **PWA Support**: Installable as a Progressive Web App with offline caching
- **Mobile Optimized**: Responsive design with touch-friendly mobile layout

## Quick Start

```bash
# Install dependencies
pip3 install -r requirements.txt

# Start the server (HTTPS, auto-generates certificate)
./start_server.sh

# Or start without SSL
./start_server.sh --no-ssl

# Or start with custom port
./start_server.sh --port 9443
```

Then open your browser to `https://localhost:8082` (accept the self-signed certificate warning).

## Stopping the Server

```bash
# Press CTRL-C in the terminal, or:
./stop_server.sh

# Or kill directly:
pkill -f "python3 main.py"
```

## Connection Types

### TCP Connection
Enter the hostname/IP and port of your Meshtastic node's TCP interface (default port: 4403).

### Serial Connection
Select "Serial" on the login screen and enter the device path:
- Linux: `/dev/ttyUSB0`, `/dev/ttyACM0`
- macOS: `/dev/cu.usbmodem*`
- Windows: `COM3`, `COM4`

## Requirements

- Python 3.9+
- Meshtastic node with TCP or Serial interface enabled
- Modern web browser (Chrome, Firefox, Safari, Edge)

## Dependencies

- `meshtastic` - Official Meshtastic Python library
- `fastapi` - Web framework
- `uvicorn` - ASGI server
- `pyserial` - Serial port access
- `Pillow` - Image processing
- `pypubsub` - Internal event system
- `aiosqlite` - Async SQLite for session databases
- `heatshrink2` - Compression for image encoding

## Image Encoding

Supported image sizes for mesh transmission:

| Size | Segments | Orientation |
|------|----------|-------------|
| 128x64 | 4 | Landscape |
| 96x96 | 4 | Square large |
| 96x48 | 3 | Landscape |
| 64x32 | 2 | Landscape small |
| 64x64 | 3 | Square medium |
| 48x48 | 2 | Square small |
| 32x32 | 2 | Square tiny |

Encoding modes: Tile RLE, RLE Nibble, RLE Nibble XOR (default). Lowercase method codes enable heatshrink compression.

### Segment Format

Image data is split into text segments for transmission over LoRa:

```
IMG{width}x{height}:{method}{bitdepth}:{checksum}:{seg}/{total}:{base64data}
```

- **checksum**: SHA256 of compressed data (first 4 bytes = 8 hex chars)
- Enables automatic grouping and deduplication of segments
- Legacy format (without checksum) has been removed as of v2.3

Example: `IMG96x48:x1:e5bbd113:0/2:pNNo8BsEwg...`

## Configuration

Settings can be configured via:
1. `settings.json` (auto-created on first run)
2. Environment variables (`WEB_PORT`, `SSL_ENABLED`, etc.)
3. Command-line flags (`--port`, `--no-ssl`, `--cert`, `--key`)

## Architecture

### Message Flow

```
Meshtastic Radio
    |
meshtastic_client_real.py  (TCP/Serial connection, _on_receive callback)
    |
packet_processor.py        (dedup, normalize, build packet dict)
    |
gateway.py                 (session callback dispatch)
    |
packet_handler.py          (route by portnum: text, position, nodeinfo, routing)
    |
message_router.py          (notify WS handlers, buffer in _recent_messages)
    |
websocket_api_multitenant.py  (deliver to browser via WebSocket)
    |
Browser JS                 (app_data.js -> app_messages.js -> DOM)
```

On WebSocket reconnect, `_flush_buffered_messages()` delivers any messages that arrived while the connection was down. Browser-side deduplication prevents duplicate rendering.

### Storage

- **Server-side**: SQLite for session metadata and fragment reassembly state only
- **Client-side**: Browser IndexedDB for all messages (via message_db.js), localStorage for session state and preferences. Data is preserved across server restarts and browser refreshes.

### Multi-Tenant Sessions

Each browser tab can connect to a different Meshtastic node. Sessions are identified by UUID and mapped to `host:port` pairs. The session_id is reused across reconnects to preserve message history.

## Project Structure

```
mesh_client/
├── main.py                        # Application entry point with SIGINT handling
├── start_server.sh                # Startup script with SSL/cert management
├── stop_server.sh                 # Graceful shutdown script
├── requirements.txt               # Python dependencies
├── settings.json                  # Runtime configuration (auto-created)
├── core/                          # Core business logic
│   ├── gateway.py                 # Connection & message flow coordinator
│   ├── meshtastic_client.py       # Client factory (real/mock)
│   ├── meshtastic_client_real.py  # Real Meshtastic TCP/Serial client
│   ├── packet_processor.py        # Packet receive, dedup & normalization
│   ├── node_data.py               # Node/channel data extraction
│   ├── packet_handler.py          # Packet type dispatcher (text, position, etc.)
│   ├── fragment_reassembler.py    # Binary image segment reassembly
│   ├── message_router.py          # WebSocket message routing with buffer
│   ├── session_manager.py         # Multi-tenant session management
│   └── constants.py               # Shared constants
├── api/                           # REST & WebSocket API
│   ├── rest_api_multitenant.py    # FastAPI app setup & middleware
│   ├── websocket_api_multitenant.py # WebSocket handler with buffer flush
│   ├── models.py                  # Pydantic request/response models
│   └── routes/                    # Route handlers
│       ├── sessions.py            # Session CRUD
│       ├── messages.py            # Send/receive messages
│       ├── nodes.py               # Node list & details
│       ├── channels.py            # Channel configuration
│       └── encoding.py            # Image encode/decode API
├── storage/                       # Database layer
│   ├── database.py                # SQLite wrapper
│   └── node_store.py              # Node data persistence
├── encoding/                      # Image codec adapters
│   ├── encoder_adapter.py         # Adapter to mesh_image encoder
│   └── decoder_adapter.py         # Adapter to mesh_image decoder
├── config/
│   └── settings.py                # Configuration loading & SSL management
├── web/static/                    # Frontend (single-page application)
│   ├── index.html                 # HTML shell
│   ├── storage.js                 # MeshtasticStorage (localStorage wrapper)
│   ├── css/                       # Stylesheets
│   │   ├── base.css               # Variables, theme, reset
│   │   ├── layout.css             # Grid layout
│   │   ├── components.css         # Buttons, inputs, modals
│   │   ├── panels.css             # Node list, channels, sessions
│   │   └── mobile.css             # Mobile responsive overrides
│   ├── js/                        # JavaScript modules
│   │   ├── app_core.js            # MeshtasticClient class & initialization
│   │   ├── app_init.js            # DOM setup & event binding
│   │   ├── app_connection.js      # Login, WebSocket, heartbeat, reconnect
│   │   ├── app_sessions.js        # Session management, auto-restore
│   │   ├── app_data.js            # WS message handler, data loading
│   │   ├── app_messages.js        # Message rendering, dedup, ACK display
│   │   ├── app_nodes.js           # Node list, favorites, map
│   │   ├── app_images.js          # Image encode/decode, segment detection, grouping, reassembly
│   │   ├── app_ui.js              # Channel selection, toasts, status
│   │   └── message_db.js          # IndexedDB persistent message storage
│   ├── sw.js                      # Service worker for PWA
│   └── manifest.json              # PWA manifest
├── mesh_image/                    # Image encoder/decoder library (synced from ~/mesh_image)
├── releases/                      # Distribution packages
│   └── im-mesh-client-v2.3.4/    # Current release
├── guides/                        # Development documentation
│   ├── instructions.txt           # Master specification
│   ├── additional_instructions.txt # Multi-tenant requirements
│   └── issues.txt                 # Current issues tracker
└── checkpoint/                    # Session checkpoint documentation
```

## License

Private - All rights reserved.

## Version History

### v2.3.5 (Current)
- **Non-blocking ACK for image segments**: `send_image_segments()` no longer holds `_operation_lock` for the entire multi-segment sequence; each segment acquires/releases the lock individually, allowing ACK callbacks and other operations to proceed between segments
- **ACK timeout extended to 60s**: Changed from 15s to 60s to account for LoRa propagation delays on longer hops
- **Segment group delete**: Grouped image segments now have a delete button (x) that removes all segments sharing the same checksum from both DOM and IndexedDB
- **CRITICAL: Reliable message receive**: `PacketHandler._handle_text_message()` now prefers the already-decoded text from `PacketProcessorMixin` instead of re-decoding raw payload bytes, preventing silent message loss when payload is None or gets mangled by hex-decode attempts
- **Non-blocking node tracking**: `node_store.mark_node_seen()` runs as fire-and-forget task so database I/O never blocks the queue worker from processing the next message
- **Segment group delete button styling**: Uses correct `btn-delete-msg` CSS class positioned as direct child of group box
- Version bumped: index.html v=56, sw.js im-mesh-v58, display v2.3.5

### v2.3.4
- **CRITICAL: Connection stability fix**: Device was losing connection when multiple concurrent operations accessed the Meshtastic radio
- **3-tier lock hierarchy**: Added `_operation_lock` (Gateway), `_interface_lock` (all reads+writes), `_connection_lock` (connect/disconnect lifecycle)
- **Serialized radio access**: ALL radio operations (send, query nodes, get channels, refresh, reboot) are now queued and executed one at a time
- **No duplicate TCP connections**: `connect()` now closes any existing interface before creating a new one; `_ensure_connected()` no longer attempts its own reconnection (deferred to `_manage_connection` background task)
- **Protected reads**: `get_node_list()`, `get_channel_info()`, `get_node_info()`, `get_device_settings()` now acquire `_interface_lock` (previously unprotected)
- **Periodic refresh skip**: Background node refresh skips when another operation holds the lock, preventing queue buildup
- **Async get_node_list()**: Changed from sync to async to support lock acquisition
- Version bumped: display v2.3.4

### v2.3.3
- **Image encoder UI**: Added XOR VLQ RLE and Auto Best encoding methods, gamma slider (0.1-5.0), 2x2 pixel compression checkbox
- **Live preview**: Encoding settings changes trigger automatic re-encode with live preview and segment count update
- **Auto image size**: Automatically selects closest image size option matching source image aspect ratio
- **V/v method code support**: Fixed `_isImageSegment` and `_parseImageSegment` regexes to recognize XOR VLQ RLE segments
- **Encoder adapter**: Passes gamma and pixel_compress through to mesh_image library, shows actual method for "best" mode
- **Default encoding**: Changed default from rle_nibble_xor to "best" (auto-select smallest output)
- **Settings modal**: Updated with new encoding methods matching encoder modal
- Version bumped: index.html v=54, sw.js im-mesh-v56, display v2.3.3

### v2.3.2
- **mesh_image sync**: Bundled mesh_image updated with XOR+VLQ RLE compression, best_encoding auto-select, gamma correction, arbitrary dimensions, 2x2 pixel compression
- **mesh_image cleanup**: Removed 820+ lines dead code, DRY helpers, type hints cleanup, fixed deleted validation module import
- **decoder_adapter**: Updated regexes for V/v method code support

### v2.3.1
- **Dead code removal**: Removed `_archive/` directory (-2,257 lines), dead CSS selectors (-230 lines), unused `storage.js` methods (-200 lines)
- **storage.js cleanup**: Removed 17 unused methods (addFavorite, removeFavorite, clearAll, exportData, getDeviceConfig, setDeviceConfig, getSessionInfo, setSessionInfo, getStats, getStatsAsync, searchAllMessagesAsync, removeNode, removeChannel, updateMessageAsync, addMessage sync, getMessages sync)
- **CSS cleanup**: Removed 22 dead selectors from panels.css (binary-message, fragments-panel, session-details, seg-select, etc.)
- **Release cleanup**: Removed old v2.2.4.4 release, keeping only v2.3.1
- Total codebase: ~10,789 lines frontend + ~6,615 lines backend

### v2.3
- **Portnum classification**: Always-process (1, 5, 288), rate-limited (2, 3, 4, 67), ignored (6-12, 32-34, 64-66, 68-76, 256, 257)
- **Custom image portnum**: Changed from 256 (PRIVATE_APP) to 288 (CUSTOM_IMAGE_APP)
- **Legacy format removal**: Checksum-less image segments no longer supported; all segments require 8-char hex checksum
- **Connection management**: Auto-reconnect always enabled with `_user_disconnected` flag to prevent reconnect on explicit disconnect
- **Scrollable connect screen**: Login panel scrolls on small screens instead of overflowing
- **Fresh UI on new connection**: `showMainApp()` clears nodes, channels, messages, stats, debug log
- **Device reboot button**: Added to settings modal, wired to `POST /api/device/reboot`
- **ACK tracking**: Portnum 5 (ROUTING_APP) properly handled for message acknowledgment status
- **Packet filtering**: Rate-limited housekeeping portnums (NodeInfo, Position, Telemetry) processed only on node refresh interval
- **Per-segment resend buttons**: Individual resend for each image segment
- **Grouped segment display**: Image segments grouped in a single message box with segment labels
- **Cross-sender reassembly**: Image segments can be reassembled from different senders
- **Own node filtered from node list**: Connected node no longer appears in All Nodes
- Full checkpoint document (checkpoint/v2.3_checkpoint.md)

### v2.2.4
- Collapsible Channels/Nodes panels with persistent state
- Channel labels: "Ch N: Name" format
- Auto-reassemble complete images by checksum
- Compact node cards (2-line layout)
- Clear chat dropdown with time-based options
- Messages >12h hidden with "Load older messages" on scroll
- Periodic node refresh (configurable 5-60min)
- Non-blocking packet callbacks
- Full checkpoint document (checkpoint/v2.2.4_checkpoint.md)

### v2.2.3
- Refactored image segment code: removed 445 lines of dead code from app_messages.js
- Image detection/parsing/grouping/reassembly consolidated in app_images.js
- app_messages.js now only handles rendering, delegates image logic to app_images.js
- Full checkpoint document (checkpoint/v2.2.3_checkpoint.md)

### v2.2.2
- SHA256 checksum added to image segment format for automatic grouping
- Checksum-based segment grouping replaces manual checkbox selection
- Fixed "Copy Payload" button copying wrong/truncated data
- Fixed segment text truncation (80-char limit removed)
- decoder_adapter.py updated for new checksum format
- 96x96 added to supported image sizes

### v2.2.1
- Image encoding UI with preview
- Segment rendering with labels and copy buttons
- Node detail panel with traceroute

### v2.2.0
- Multi-file JS refactor (monolith split into 10 modules)
- CSS split into 5 themed files
- IndexedDB message storage (message_db.js)
- Message deduplication
- WebSocket reconnection with missed message fetch

### v2.1.1
- Bug fixes for session restore
- Node list stability improvements

### v2.1.0
- Initial multi-tenant release
- TCP/Serial connection support
- Channel and DM messaging
- Basic image encoding/decoding
