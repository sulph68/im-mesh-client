"""
Packet handler for interpreting and processing Meshtastic packets.

Handles different packet types and routes them appropriately.

Uses an async priority queue so incoming packets are enqueued instantly
(never blocking the receive path) and processed sequentially by a
background worker task.  Priority levels ensure that user-facing messages
(text, binary, routing/ACK) are handled before background housekeeping
(position, nodeinfo, telemetry).
"""

import asyncio
import logging
import base64
import time
from datetime import datetime
from typing import Dict, Any, Optional
from .constants import (
    PortNum, is_broadcast, normalize_node_id,
    ALWAYS_PROCESS_PORTNUMS, IGNORED_PORTNUMS, RATE_LIMITED_PORTNUMS,
)
from .fragment_reassembler import FragmentReassembler
from .message_router import MessageRouter
from storage.node_store import NodeStore
from encoding.decoder_adapter import decoder_adapter

logger = logging.getLogger(__name__)

# Priority levels (lower number = higher priority)
PRIORITY_HIGH = 1    # TEXT_MESSAGE_APP, CUSTOM_IMAGE_APP (binary), ROUTING_APP
PRIORITY_NORMAL = 2  # Unknown / unclassified portnums
PRIORITY_LOW = 3     # POSITION_APP, NODEINFO_APP, TELEMETRY_APP, REMOTE_HARDWARE_APP

# Map portnums to priority levels
_PORTNUM_PRIORITY = {
    PortNum.TEXT_MESSAGE_APP: PRIORITY_HIGH,
    PortNum.CUSTOM_IMAGE_APP: PRIORITY_HIGH,
    PortNum.ROUTING_APP: PRIORITY_HIGH,
    PortNum.REMOTE_HARDWARE_APP: PRIORITY_LOW,
    PortNum.POSITION_APP: PRIORITY_LOW,
    PortNum.NODEINFO_APP: PRIORITY_LOW,
    PortNum.TELEMETRY_APP: PRIORITY_LOW,
}


class PacketHandler:
    """
    Handles interpretation and processing of Meshtastic packets.
    
    Routes different packet types (TEXT_MESSAGE_APP, BINARY_MESSAGE_APP, etc.)
    to appropriate handlers and manages fragment detection.
    
    Incoming packets are placed on an asyncio.PriorityQueue so the caller
    (pypubsub thread -> asyncio dispatch) returns immediately.  A single
    background worker drains the queue and processes packets one at a time,
    ensuring ordered, non-blocking handling without overwhelming the
    single-threaded Meshtastic device.
    
    Packet filtering policy:
    - ALWAYS_PROCESS_PORTNUMS (1, 5, 288): processed immediately
    - IGNORED_PORTNUMS (6-12, 32-34, 64-66, 68-76, 256, 257): silently dropped
    - RATE_LIMITED_PORTNUMS (2, 3, 4, 67): only processed when the node refresh
      interval has elapsed since the last processing of that portnum
    """
    
    # Monotonic counter for stable ordering of same-priority packets (FIFO)
    _seq = 0
    
    def __init__(self, node_store: NodeStore,
                 message_router: MessageRouter, fragment_reassembler: FragmentReassembler,
                 node_refresh_interval: int = 15):
        """
        Args:
            node_store: Node storage backend
            message_router: Message routing backend
            fragment_reassembler: Fragment reassembly backend
            node_refresh_interval: Minutes between processing rate-limited
                portnums (POSITION, NODEINFO, TELEMETRY).  Default 15.
                Clamped to 5-60 range.
        """
        self.node_store = node_store
        self.message_router = message_router
        self.fragment_reassembler = fragment_reassembler
        self._queue: asyncio.PriorityQueue = asyncio.PriorityQueue(maxsize=500)
        self._worker_task: Optional[asyncio.Task] = None
        self._running = False
        # Rate-limiting: track last processing time per rate-limited portnum
        self._refresh_interval_secs = max(5, min(60, node_refresh_interval)) * 60
        self._last_rate_limited_time: Dict[int, float] = {}  # portnum -> monotonic timestamp

    # ----- Queue lifecycle -----

    async def start(self) -> None:
        """Start the background queue worker."""
        if self._running:
            return
        self._running = True
        self._worker_task = asyncio.create_task(self._queue_worker())
        logger.info("PacketHandler priority queue worker started")

    async def stop(self) -> None:
        """Stop the background queue worker and drain remaining packets."""
        self._running = False
        if self._worker_task:
            self._worker_task.cancel()
            try:
                await self._worker_task
            except asyncio.CancelledError:
                pass
            self._worker_task = None
        # Drain any remaining items so the queue is clean
        while not self._queue.empty():
            try:
                self._queue.get_nowait()
            except asyncio.QueueEmpty:
                break
        logger.info("PacketHandler priority queue worker stopped")

    def queue_size(self) -> int:
        """Return current number of packets waiting in the queue."""
        return self._queue.qsize()

    # ----- Enqueue (called from asyncio dispatch, returns instantly) -----

    async def handle_packet(self, packet: Dict[str, Any]) -> None:
        """Enqueue a packet for priority-based processing.
        
        This method returns immediately.  The actual processing happens
        in the background worker task, ensuring the caller (and therefore
        the Meshtastic receive path) is never blocked.
        
        Args:
            packet: Normalized packet dict from PacketProcessorMixin
        """
        try:
            portnum = self._extract_portnum(packet)
            priority = _PORTNUM_PRIORITY.get(portnum, PRIORITY_NORMAL)
            PacketHandler._seq += 1
            seq = PacketHandler._seq

            # PriorityQueue sorts by tuple: (priority, sequence, packet)
            self._queue.put_nowait((priority, seq, packet))
            
            from_node = packet.get('from_node', '?')
            qsize = self._queue.qsize()
            if qsize > 10:
                logger.info(f"Queued pkt from {from_node} portnum={portnum} prio={priority} qsize={qsize}")
            else:
                logger.debug(f"Queued pkt from {from_node} portnum={portnum} prio={priority} qsize={qsize}")

        except asyncio.QueueFull:
            logger.error("Packet queue overflow - packet dropped")
        except (KeyError, TypeError, ValueError) as e:
            logger.error(f"Error enqueuing packet: {e}")

    # ----- Background worker -----

    async def _queue_worker(self) -> None:
        """Background task that processes queued packets sequentially.
        
        Packets are dequeued in priority order (high-priority first) and
        processed one at a time.  Packet classification (portnum filtering,
        node-seen tracking) runs inline, but the final message routing
        (WebSocket broadcast) is fired as a separate task so the queue
        drains without blocking on network I/O.
        """
        logger.info("PacketHandler queue worker running")
        while self._running:
            try:
                priority, seq, packet = await asyncio.wait_for(
                    self._queue.get(), timeout=5.0
                )
                await self._process_packet(packet)
                self._queue.task_done()
            except asyncio.TimeoutError:
                continue  # No packets for 5s, loop to check self._running
            except asyncio.CancelledError:
                break
            except Exception as e:  # Broad: keep queue worker alive on unexpected errors
                logger.exception(f"Error in queue worker: {e}")

    @staticmethod
    def _extract_portnum(packet: Dict[str, Any]) -> Optional[int]:
        """Extract portnum from a packet dict for priority classification."""
        decoded = packet.get('decoded', {})
        if not decoded:
            return None
        return decoded.get('portnum')

    async def _process_packet(self, packet: Dict[str, Any]) -> None:
        """
        Process a single packet from the priority queue.
        
        Applies portnum filtering policy:
        - ALWAYS_PROCESS_PORTNUMS: handled immediately
        - IGNORED_PORTNUMS: silently dropped (should already be filtered
          upstream in PacketProcessorMixin, but double-checked here)
        - RATE_LIMITED_PORTNUMS: only processed when the node refresh
          interval has elapsed since the last processing of that portnum
        - Unknown portnums: dropped with debug log
        
        Args:
            packet: Raw packet data from Meshtastic device
        """
        try:
            # Extract basic packet info
            from_node = packet.get('from_node') or packet.get('from', 'unknown')
            to_node = packet.get('to')
            channel = packet.get('channel', 0)
            hop_limit = packet.get('hop_limit')
            want_ack = packet.get('want_ack', False)
            rx_snr = packet.get('rx_snr')
            rx_rssi = packet.get('rx_rssi')
            rx_time = packet.get('rx_time', datetime.now())
            from_name = packet.get('from_name')
            from_short = packet.get('from_short')
            
            # Normalize node IDs to canonical '!hex' format
            from_node = normalize_node_id(from_node) if from_node else from_node
            to_node = normalize_node_id(to_node) if to_node else to_node
            
            # Extract decoded payload
            decoded = packet.get('decoded', {})
            if not decoded:
                logger.debug(f"Packet from {from_node} has no decoded payload")
                return
            
            portnum = decoded.get('portnum')
            payload = decoded.get('payload')
            
            # CRITICAL: PacketProcessorMixin already decoded the text and
            # stored it in decoded['text'] and packet['decoded_text'].
            # Prefer the already-decoded text over raw payload bytes to
            # avoid re-decoding failures, hex-mangling, or None payload.
            decoded_text = decoded.get('text') or packet.get('decoded_text')
            
            if portnum is None:
                logger.debug(f"Packet from {from_node} has no portnum")
                return
            
            # --- Portnum filtering policy ---
            
            # 1. Always ignore internal portnums
            if portnum in IGNORED_PORTNUMS:
                logger.debug(f"Ignoring internal portnum {portnum} from {from_node}")
                return
            
            # 2. Rate-limit housekeeping portnums (position, nodeinfo, telemetry)
            if portnum in RATE_LIMITED_PORTNUMS:
                now = time.monotonic()
                last_time = self._last_rate_limited_time.get(portnum, 0)
                elapsed = now - last_time
                if elapsed < self._refresh_interval_secs:
                    remaining = int(self._refresh_interval_secs - elapsed)
                    logger.debug(f"Rate-limited portnum {portnum} from {from_node} "
                                 f"(next in {remaining}s)")
                    return
                # Interval elapsed - process and update timestamp
                self._last_rate_limited_time[portnum] = now
                logger.info(f"Processing rate-limited portnum {portnum} from {from_node} "
                            f"(interval {self._refresh_interval_secs}s elapsed)")
            
            # 3. Always-process portnums pass through without checks
            # 4. Unknown portnums: drop with debug log
            if portnum not in ALWAYS_PROCESS_PORTNUMS and portnum not in RATE_LIMITED_PORTNUMS:
                logger.debug(f"Dropping unknown portnum {portnum} from {from_node}")
                return
            
            # Update node last seen (fire-and-forget so it never blocks
            # message processing in the queue worker)
            asyncio.create_task(self._safe_mark_seen(from_node))
            
            logger.info(f"PacketHandler: from={from_node} to={to_node} ch={channel} portnum={portnum}")
            
            # Handle different port numbers
            if portnum == PortNum.TEXT_MESSAGE_APP:
                await self._handle_text_message(
                    from_node, to_node, channel, decoded_text, payload, rx_time,
                    rx_snr, rx_rssi, from_name=from_name
                )
            elif portnum == PortNum.CUSTOM_IMAGE_APP:
                await self._handle_binary_message(
                    from_node, to_node, channel, payload, rx_time, rx_snr, rx_rssi,
                    from_name=from_name
                )
            elif portnum == PortNum.POSITION_APP:
                await self._handle_position_update(from_node, decoded, rx_time)
            elif portnum == PortNum.NODEINFO_APP:
                await self._handle_node_info(from_node, decoded, rx_time)
            elif portnum == PortNum.ROUTING_APP:
                await self._handle_routing_packet(from_node, to_node, decoded, rx_time)
            elif portnum == PortNum.TELEMETRY_APP:
                logger.debug(f"Telemetry from {from_node} (processed on refresh interval)")
                # Telemetry data is informational; update node last-seen only
                
        except (KeyError, TypeError, ValueError, AttributeError) as e:
            logger.error(f"Error handling packet: {e}")
    
    async def _safe_mark_seen(self, from_node: str) -> None:
        """Fire-and-forget wrapper for node_store.mark_node_seen.
        
        Runs as a separate task so database I/O never blocks the
        queue worker from processing the next message.
        """
        try:
            await self.node_store.mark_node_seen(from_node)
        except Exception as e:
            logger.debug(f"mark_node_seen failed for {from_node}: {e}")

    async def _safe_route(self, route_fn, message_data: Dict[str, Any], label: str) -> None:
        """Fire-and-forget wrapper for message routing.
        
        Runs as a separate asyncio task so the queue worker is never
        blocked on WebSocket broadcast I/O.  This allows the next
        queued packet to be processed immediately, preventing message
        loss when consecutive messages arrive faster than the WebSocket
        can deliver them.
        """
        try:
            await route_fn(message_data)
        except Exception as e:
            logger.warning(f"Route failed ({label}): {e}")

    @staticmethod
    def _is_readable_text(text: str) -> bool:
        """Check if text is human-readable (not encrypted/garbled data).

        Returns False if more than 30% of characters are non-printable,
        which indicates encrypted data that could not be decrypted.
        """
        if not text:
            return False
        non_printable = sum(
            1 for ch in text
            if (ord(ch) < 32 and ord(ch) not in (9, 10, 13))
            or 0xD800 <= ord(ch) <= 0xDFFF
            or ord(ch) == 0xFFFD
        )
        return (non_printable / len(text)) < 0.3

    async def _handle_text_message(self, from_node: str, to_node: Optional[str],
                                  channel: int, decoded_text, payload, rx_time,
                                  rx_snr: Optional[float], rx_rssi: Optional[int],
                                  from_name: Optional[str] = None) -> None:
        """Handle text message packets.
        
        Args:
            decoded_text: Already-decoded text from PacketProcessorMixin (preferred).
            payload: Raw payload bytes/string (fallback if decoded_text is None).
        """
        try:
            # CRITICAL: Prefer the already-decoded text from PacketProcessorMixin.
            # It has already been validated as readable. Re-decoding raw payload
            # risks hex-mangling, None payload, or double-decode failures.
            text = decoded_text
            
            if not text:
                # Fallback: decode from raw payload (rare - should not normally happen)
                if isinstance(payload, bytes):
                    try:
                        text = payload.decode('utf-8')
                    except UnicodeDecodeError:
                        logger.debug(f"Dropping non-UTF-8 text from {from_node} ({len(payload)} bytes)")
                        return
                elif isinstance(payload, str):
                    text = payload
                else:
                    logger.debug(f"No decoded text and no usable payload from {from_node}")
                    return
            
            if not text:
                logger.debug(f"Empty text message from {from_node}, dropping")
                return

            # Validate text is readable, not garbled encrypted data
            if not self._is_readable_text(text):
                logger.debug(f"Dropping garbled/encrypted text from {from_node} len={len(text)}")
                return
            
            # Create message data
            message_data = {
                'timestamp': rx_time.isoformat() if hasattr(rx_time, 'isoformat') else str(rx_time),
                'from_node': from_node,
                'from_name': from_name or from_node,
                'to_node': to_node,
                'channel': channel,
                'portnum': PortNum.TEXT_MESSAGE_APP,
                'payload': base64.b64encode(payload).decode('ascii') if isinstance(payload, bytes) else (str(payload) if payload else text),
                'message_type': 'text',
                'decoded_text': text,
                'rx_snr': rx_snr,
                'rx_rssi': rx_rssi,
                'is_broadcast': is_broadcast(to_node),
                'is_fragment': False
            }
            
            # Route to handlers as fire-and-forget task so the queue worker
            # is not blocked on WebSocket I/O during broadcast.
            asyncio.create_task(self._safe_route(
                self.message_router.route_text_message, message_data,
                f"text from {from_node}"
            ))
            
            logger.info(f"Text message from {from_node} len={len(text)}: {text[:50]}{'...' if len(text) > 50 else ''}")
            
        except (KeyError, TypeError, ValueError, UnicodeDecodeError) as e:
            logger.error(f"Error handling text message: {e}")
    
    async def _handle_binary_message(self, from_node: str, to_node: Optional[str],
                                   channel: int, payload, rx_time,
                                   rx_snr: Optional[float], rx_rssi: Optional[int],
                                   from_name: Optional[str] = None) -> None:
        """Handle binary message packets."""
        try:
            # Convert payload to string if needed
            if isinstance(payload, bytes):
                payload_str = payload.decode('utf-8', errors='ignore')
            elif isinstance(payload, str):
                # Might be hex-encoded
                try:
                    payload_str = bytes.fromhex(payload).decode('utf-8', errors='ignore')
                except ValueError:
                    payload_str = payload
            else:
                payload_str = str(payload)
            
            # Check if this might be an image message fragment
            is_image_fragment = decoder_adapter.is_image_message(payload_str)
            
            # Determine if this is a fragment
            is_fragment, fragment_info = await self._detect_fragment(payload_str)
            
            # Create base message data
            message_data = {
                'timestamp': rx_time.isoformat() if hasattr(rx_time, 'isoformat') else str(rx_time),
                'from_node': from_node,
                'from_name': from_name or from_node,
                'to_node': to_node,
                'channel': channel,
                'portnum': PortNum.CUSTOM_IMAGE_APP,
                'payload': payload_str,
                'message_type': 'binary',
                'rx_snr': rx_snr,
                'rx_rssi': rx_rssi,
                'is_broadcast': is_broadcast(to_node),
                'is_fragment': is_fragment
            }
            
            # Add fragment information if detected
            if is_fragment and fragment_info:
                message_data.update({
                    'fragment_id': fragment_info['fragment_id'],
                    'fragment_total': fragment_info['total_segments'],
                    'fragment_index': fragment_info['segment_index']
                })
            
            # Handle fragments (messages stored client-side in localStorage)
            if is_fragment:
                # Process through fragment reassembler
                complete_message = await self.fragment_reassembler.process_fragment(message_data)
                
                if complete_message:
                    # Fragment is complete, try to decode if it's an image
                    if is_image_fragment:
                        asyncio.create_task(self._safe_route(
                            self._handle_complete_image_message, complete_message,
                            f"image_complete from {from_node}"
                        ))
                    else:
                        asyncio.create_task(self._safe_route(
                            self.message_router.route_binary_complete, complete_message,
                            f"binary_complete from {from_node}"
                        ))
                
                # Also route the fragment itself
                asyncio.create_task(self._safe_route(
                    self.message_router.route_binary_message, message_data,
                    f"binary fragment from {from_node}"
                ))
            else:
                # Single binary message
                asyncio.create_task(self._safe_route(
                    self.message_router.route_binary_message, message_data,
                    f"binary from {from_node}"
                ))
            
            logger.info(f"Binary message from {from_node} ({len(payload_str)} chars)"
                       f"{' [Fragment]' if is_fragment else ''}"
                       f"{' [Image]' if is_image_fragment else ''}")
            
        except (KeyError, TypeError, ValueError, UnicodeDecodeError) as e:
            logger.error(f"Error handling binary message: {e}")
    
    async def _detect_fragment(self, payload: str) -> tuple[bool, Optional[Dict[str, Any]]]:
        """
        Detect if payload is a fragment of a larger message.
        
        Args:
            payload: Message payload string
            
        Returns:
            Tuple of (is_fragment, fragment_info)
        """
        try:
            # Check for image message format (IMG{width}x{height}:...)
            if payload.startswith('IMG') and ':' in payload:
                parts = payload.split(':')
                if len(parts) >= 3:
                    # Parse segment info: {segment_index}/{total_segments}
                    segment_part = parts[2]
                    if '/' in segment_part:
                        segment_index_str, total_segments_str = segment_part.split('/')
                        try:
                            segment_index = int(segment_index_str)
                            total_segments = int(total_segments_str)
                            
                            if total_segments > 1:
                                # Generate fragment ID from the message header
                                fragment_id = f"{parts[0]}_{parts[1]}"  # IMG{dimensions}_{method}
                                
                                return True, {
                                    'fragment_id': fragment_id,
                                    'segment_index': segment_index,
                                    'total_segments': total_segments
                                }
                        except ValueError:
                            pass
            
            # Add other fragment detection patterns here
            
            return False, None
            
        except (ValueError, IndexError, TypeError) as e:
            logger.error(f"Error detecting fragment: {e}")
            return False, None
    
    async def _handle_complete_image_message(self, complete_message: Dict[str, Any]) -> None:
        """Handle a completed image message for decoding."""
        try:
            payload = complete_message.get('payload', '')
            
            # Split payload back into segments
            # This is a simplified approach - in reality, we'd need to properly
            # reconstruct the original segments from the concatenated payload
            segments = [payload]  # For now, treat as single segment
            
            # Try to decode the image
            decode_result = decoder_adapter.decode_segments(segments)
            
            if decode_result['success']:
                # Add decoded image data to the message
                complete_message['decoded_image'] = decode_result['image_data']
                complete_message['decode_stats'] = decode_result['stats']
                complete_message['message_type'] = 'image_complete'
                
                logger.info(f"Successfully decoded image from {complete_message['from_node']}")
            else:
                complete_message['decode_error'] = decode_result['error']
                logger.warning(f"Failed to decode image: {decode_result['error']}")
            
            # Route the complete image message
            await self.message_router.route_message(complete_message)
            
        except (KeyError, TypeError, ValueError) as e:
            logger.error(f"Error handling complete image message: {e}")
    
    async def _handle_position_update(self, from_node: str, decoded: Dict[str, Any], rx_time: datetime) -> None:
        """Handle position update packets."""
        try:
            # Extract position data
            latitude = decoded.get('latitude')
            longitude = decoded.get('longitude')
            altitude = decoded.get('altitude')
            
            if latitude is not None and longitude is not None:
                # Update node position
                await self.node_store.update_node_position(from_node, latitude, longitude, altitude)
                
                # Route position update
                position_data = {
                    'node_id': from_node,
                    'latitude': latitude,
                    'longitude': longitude,
                    'altitude': altitude,
                    'timestamp': rx_time
                }
                
                await self.message_router.route_message({
                    'message_type': 'position_update',
                    'position_data': position_data,
                    'timestamp': rx_time
                })
                
                logger.debug(f"Position update from {from_node}: {latitude}, {longitude}")
            
        except (KeyError, TypeError, ValueError) as e:
            logger.error(f"Error handling position update: {e}")
    
    async def _handle_node_info(self, from_node: str, decoded: Dict[str, Any], rx_time: datetime) -> None:
        """Handle node info packets."""
        try:
            # Extract node information
            user_info = decoded.get('user', {})
            
            node_data = {
                'node_id': from_node,
                'short_name': user_info.get('shortName'),
                'long_name': user_info.get('longName'),
                'hw_model': user_info.get('hwModel'),
                'macaddr': user_info.get('macaddr'),
                'last_seen': rx_time
            }
            
            # Update node information
            await self.node_store.upsert_node(node_data)
            
            # Route node update
            await self.message_router.route_node_update(node_data)
            
            logger.info(f"Node info update: {from_node} ({node_data.get('short_name', 'Unknown')})")
            
        except (KeyError, TypeError, ValueError) as e:
            logger.error(f"Error handling node info: {e}")
    
    async def _handle_routing_packet(self, from_node: str, to_node: str, decoded: Dict[str, Any], rx_time) -> None:
        """Handle routing packets (ack/nak responses).
        
        When we send a message with wantAck=True, two ACK packets arrive:
        
        1. **Node ACK** (self-ACK): from our own node to our own node
           (from_node == to_node == our node). This confirms the local radio
           transmitted the packet and heard a radio-level ACK.
        
        2. **Destination ACK** (remote ACK): from the remote node to our node
           (from_node == remote node, to_node == our node). This confirms
           the destination node received and processed the message.
        
        The iOS Meshtastic client shows these as "Sent" vs "Delivered".
        We replicate this with an `ack_type` field: 'node' or 'destination'.
        """
        try:
            request_id = decoded.get('request_id')
            error_reason = decoded.get('error_reason', 'NONE')
            ack_received = decoded.get('ack_received', str(error_reason) == 'NONE')
            
            # Determine ACK type: node (self) vs destination (remote)
            # Node ACK: from_node == to_node (our radio echoing back the ACK)
            # Destination ACK: from_node != to_node (remote node responding)
            if from_node and to_node and from_node == to_node:
                ack_type = 'node'
            else:
                ack_type = 'destination'
            
            ack_data = {
                'message_type': 'ack',
                'from_node': from_node,
                'request_id': request_id,
                'error_reason': str(error_reason),
                'ack_received': ack_received,
                'ack_type': ack_type,
                'timestamp': rx_time.isoformat() if hasattr(rx_time, 'isoformat') else str(rx_time)
            }
            
            # Route ack to WebSocket clients so the UI can update sent messages.
            # Fire-and-forget so the queue worker is not blocked.
            asyncio.create_task(self._safe_route(
                self.message_router.route_message, ack_data,
                f"ack from {from_node} reqId={request_id}"
            ))
            
            status = 'ACK' if ack_received else f'NAK ({error_reason})'
            type_label = 'NODE-ACK' if ack_type == 'node' else 'DEST-ACK'
            logger.info(f"Routing {status} [{type_label}] from {from_node} for packetId={request_id}")
            
        except (KeyError, TypeError, AttributeError) as e:
            logger.error(f"Error handling routing packet: {e}")