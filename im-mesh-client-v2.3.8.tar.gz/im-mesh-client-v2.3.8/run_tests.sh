#!/bin/bash

# Meshtastic Web Client Test Runner

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

echo -e "${BLUE}🧪 Meshtastic Web Client Test Suite${NC}"
echo "========================================="

# Check if server is running
echo -e "${YELLOW}Checking server status...${NC}"
if curl -s http://localhost:8082/api/health > /dev/null 2>&1; then
    echo -e "${GREEN}✓ Server is running${NC}"
    SERVER_WAS_RUNNING=true
else
    echo -e "${YELLOW}⚠️  Server not running, starting for tests...${NC}"
    SERVER_WAS_RUNNING=false
    
    # Start server
    cd /home/cnrai/mesh_client
    ./start_server.sh > test_server.log 2>&1 &
    SERVER_PID=$!
    
    # Wait for server to start
    echo -e "${YELLOW}Waiting for server startup...${NC}"
    for i in {1..15}; do
        if curl -s http://localhost:8082/api/health > /dev/null 2>&1; then
            echo -e "${GREEN}✓ Server started successfully${NC}"
            break
        fi
        sleep 1
    done
fi

# Install test dependencies
echo -e "${YELLOW}Installing test dependencies...${NC}"
pip3 install --user -q pytest pytest-asyncio httpx 2>/dev/null || pip install --user -q pytest pytest-asyncio httpx 2>/dev/null

# Run tests based on argument
TEST_TYPE=${1:-"all"}

case $TEST_TYPE in
    "unit")
        echo -e "${BLUE}Running Unit Tests...${NC}"
        python3 -m pytest tests/unit/ -v --tb=short
        ;;
    "integration") 
        echo -e "${BLUE}Running Integration Tests...${NC}"
        python3 -m pytest tests/integration/ -v --tb=short -s
        ;;
    "ui")
        echo -e "${BLUE}Running UI Tests...${NC}"
        echo -e "${YELLOW}Note: UI tests require WebDriver (Chrome/Firefox)${NC}"
        python3 -m pytest tests/ui/ -v --tb=short
        ;;
    "backend")
        echo -e "${BLUE}Running Backend Tests (Unit + Integration)...${NC}"
        python3 -m pytest tests/unit/ tests/integration/ -v --tb=short
        ;;
    "all")
        echo -e "${BLUE}Running All Tests...${NC}"
        python3 -m pytest tests/ -v --tb=short
        ;;
    *)
        echo -e "${RED}Unknown test type: $TEST_TYPE${NC}"
        echo "Usage: $0 [unit|integration|ui|backend|all]"
        exit 1
        ;;
esac

TEST_EXIT_CODE=$?

# Cleanup if we started the server
if [ "$SERVER_WAS_RUNNING" = false ]; then
    echo -e "${YELLOW}Stopping test server...${NC}"
    cd /home/cnrai/mesh_client
    ./stop_server.sh > /dev/null 2>&1
fi

# Summary
echo ""
echo "========================================="
if [ $TEST_EXIT_CODE -eq 0 ]; then
    echo -e "${GREEN}🎉 All Tests Passed!${NC}"
else
    echo -e "${RED}❌ Some Tests Failed${NC}"
fi
echo -e "${BLUE}Test Type: $TEST_TYPE${NC}"
echo "========================================="

exit $TEST_EXIT_CODE