"""
core/variable_substitution.py — Template variable substitution for messages.

Supports two variable namespaces:

  {{VARIABLE}}    — attributes of the node that triggered the action
                    (available in Auto Responder fixed responses)

  {{S_VARIABLE}}  — attributes of the own/local gateway node
                    (available in both Auto Responder and Scheduler messages)

Unresolved variables (node data missing or field not available) are left as-is,
except for LONG_NAME and SHORT_NAME on a known-but-unnamed trigger node — those
fall back to ``[??] Meshtastic XXXX <XXXX@!nodeid>`` / ``XXXX`` respectively.

Full variable reference:
  LONG_NAME  — Node long name
  SHORT_NAME — Node short name
  ID         — Node ID (e.g. !a1b2c3d4)
  SNR        — Signal-to-noise ratio (dB)
  RSSI       — Received signal strength (dBm)
  HOPS       — Hops away (0 = direct)
  ROLE       — Node role
  HARDWARE   — Hardware model
  BATTERY    — Battery level (%)
  VOLTAGE    — Battery voltage (V)
  CH_UTIL    — Channel utilisation (%)
  AIR_TX     — Air TX utilisation (%)
  UPTIME     — Uptime (seconds)
  LAT        — GPS latitude
  LON        — GPS longitude
  ALT        — GPS altitude (m)

Prefix each name with S_ to reference the own node instead of the trigger node,
e.g. {{S_LONG_NAME}}, {{S_BATTERY}}.
"""

import re
from typing import Optional, Dict, Any

# ---------------------------------------------------------------------------
# Variable extractors: each takes a node dict and returns a string value.
# ---------------------------------------------------------------------------

def _dm(node: dict) -> dict:
    """Return deviceMetrics sub-dict (empty if absent)."""
    return node.get('deviceMetrics') or {}

def _pos(node: dict) -> dict:
    """Return position sub-dict (empty if absent)."""
    return node.get('position') or {}

def _fmt_float(val, digits: int = 2) -> str:
    if val is None or val == '':
        return ''
    try:
        return f"{float(val):.{digits}f}"
    except (TypeError, ValueError):
        return str(val)

def _str(val) -> str:
    if val is None:
        return ''
    return str(val)


_EXTRACTORS: Dict[str, Any] = {
    'LONG_NAME':  lambda n: _str(n.get('longName') or n.get('long_name')),
    'SHORT_NAME': lambda n: _str(n.get('shortName') or n.get('short_name')),
    'ID':         lambda n: _str(n.get('id') or n.get('num')),
    'SNR':        lambda n: _fmt_float(n.get('snr'), 1),
    'RSSI':       lambda n: _str(n.get('rssi')),
    'HOPS':       lambda n: _str(n.get('hopsAway')),
    'ROLE':       lambda n: _str(n.get('role')),
    'HARDWARE':   lambda n: _str(n.get('hwModel') or n.get('hw_model')),
    'BATTERY':    lambda n: _str(_dm(n).get('batteryLevel')),
    'VOLTAGE':    lambda n: _fmt_float(_dm(n).get('voltage'), 2),
    'CH_UTIL':    lambda n: _fmt_float(_dm(n).get('channelUtilization'), 1),
    'AIR_TX':     lambda n: _fmt_float(_dm(n).get('airUtilTx'), 2),
    'UPTIME':     lambda n: _str(_dm(n).get('uptimeSeconds')),
    'LAT':        lambda n: _fmt_float(_pos(n).get('latitude'), 6),
    'LON':        lambda n: _fmt_float(_pos(n).get('longitude'), 6),
    'ALT':        lambda n: _str(_pos(n).get('altitude')),
}

# Regex: matches {{VARIABLE}} or {{S_VARIABLE}}
_PATTERN = re.compile(r'\{\{(S_)?([A-Z_]+)\}\}')


def build_node_vars(node: Optional[dict]) -> Dict[str, str]:
    """
    Build a flat variable dict from a node data dict.
    Returns {VARIABLE_NAME: resolved_value, ...} with empty strings for missing values.
    """
    if not node:
        return {k: '' for k in _EXTRACTORS}
    return {k: fn(node) for k, fn in _EXTRACTORS.items()}


def _unknown_node_fallback(var_name: str, node: dict) -> Optional[str]:
    """Build a human-readable fallback for an unknown-node name variable.

    Returns a formatted string when the node dict is present but the requested
    name field is empty (node is in the database but has no display name yet, or
    a forced refresh has not yet returned data).

    Returns None when no fallback can be constructed (node ID unavailable).
    """
    raw_id = str(node.get('id') or node.get('num') or '').strip()
    if not raw_id:
        return None
    last4 = raw_id.lstrip('!').upper()[-4:]
    if var_name == 'LONG_NAME':
        return f'[??] Meshtastic {last4}'
    if var_name == 'SHORT_NAME':
        return last4
    return None


def resolve_variables(text: str,
                      trigger_node: Optional[dict] = None,
                      own_node: Optional[dict] = None,
                      incoming_message: str = '') -> str:
    """
    Resolve {{VARIABLE}}, {{S_VARIABLE}}, and {{MESSAGE}} placeholders in *text*.

    - {{VARIABLE}}   → replaced using trigger_node data (if provided)
    - {{S_VARIABLE}} → replaced using own_node data (if provided)
    - {{MESSAGE}}    → replaced with the raw incoming message text

    If the node dict is None, or the field is empty, the placeholder is left as-is.
    For LONG_NAME and SHORT_NAME, when the trigger node is known but its name
    fields are empty, a human-readable fallback of the form
    ``[??] Meshtastic XXXX <XXXX@!nodeid>`` / ``XXXX`` is used instead of the
    raw placeholder literal.
    """
    if '{{' not in text:
        return text

    trigger_vars = build_node_vars(trigger_node) if trigger_node else {}
    own_vars = build_node_vars(own_node) if own_node else {}

    def _replace(m: re.Match) -> str:
        is_own = bool(m.group(1))  # 'S_' prefix present
        var_name = m.group(2)

        # Special top-level variable — not node-derived
        if var_name == 'MESSAGE' and not is_own:
            return incoming_message if incoming_message else m.group(0)

        extractor = _EXTRACTORS.get(var_name)
        if extractor is None:
            return m.group(0)  # unknown variable — leave as-is

        if is_own:
            if own_node is None:
                return m.group(0)
            val = own_vars.get(var_name, '')
        else:
            if trigger_node is None:
                return m.group(0)
            val = trigger_vars.get(var_name, '')

        if val:
            return val

        # Empty value — attempt human-readable fallback for name variables
        # to avoid sending raw {{LONG_NAME}} / {{SHORT_NAME}} literals.
        if not is_own and trigger_node is not None:
            fallback = _unknown_node_fallback(var_name, trigger_node)
            if fallback is not None:
                return fallback

        return m.group(0)

    return _PATTERN.sub(_replace, text)


# ---------------------------------------------------------------------------
# Human-readable variable reference (used for README and UI hints)
# ---------------------------------------------------------------------------

VARIABLE_REFERENCE = [
    ('MESSAGE',    'The incoming message text (trigger message)'),
    ('LONG_NAME',  'Node long name'),
    ('SHORT_NAME', 'Node short name'),
    ('ID',         'Node ID (e.g. !a1b2c3d4)'),
    ('SNR',        'Signal-to-noise ratio (dB)'),
    ('RSSI',       'Received signal strength (dBm)'),
    ('HOPS',       'Hops away from gateway (0 = direct)'),
    ('ROLE',       'Node role'),
    ('HARDWARE',   'Hardware model'),
    ('BATTERY',    'Battery level (%)'),
    ('VOLTAGE',    'Battery voltage (V)'),
    ('CH_UTIL',    'Channel utilisation (%)'),
    ('AIR_TX',     'Air TX utilisation (%)'),
    ('UPTIME',     'Uptime in seconds'),
    ('LAT',        'GPS latitude'),
    ('LON',        'GPS longitude'),
    ('ALT',        'GPS altitude (m)'),
]
