"""
core/auto_responder.py — Auto responder engine.

Handles incoming messages for configured conversations, invokes responder
scripts, and returns response text. Eliza 1966 is used as final fallback.

Usage:
    from core.auto_responder import AutoResponder
    ar = AutoResponder(settings)
    parts = await ar.respond(
        folder_name="3d8309d0",   # or "ch0_longfast"
        sender_id="!3d8309d0",
        message="Hello"
    )
    # parts is List[str] or None (None = no auto response configured)
    # Multiple parts are produced when the response exceeds the mesh char limit.
"""

import asyncio
import logging
import os
import re
import subprocess
from typing import List, Optional

from .auto_responder_config import (
    ensure_conversation_folder, append_to_conversation, format_sender_display,
    read_conversation, is_conversation_enabled,
    get_global_enabled, read_conv_config,
)
from .message_splitter import split_message
from .path_utils import resolve_project_path
from .variable_substitution import resolve_variables
from .constants import DEFAULT_CHAR_LIMIT

logger = logging.getLogger(__name__)

try:
    from core.eliza_chatbot import eliza_respond as _eliza_respond
    _ELIZA_AVAILABLE = True
except ImportError:
    _eliza_respond = None
    _ELIZA_AVAILABLE = False


class AutoResponder:
    def __init__(self, settings: dict) -> None:
        """
        Args:
            settings: The auto_responder section of settings.json
        """
        self._working_dir = resolve_project_path(
            settings.get('working_directory', './auto_responder')
        )
        self._history_context = settings.get('history_context', 20)
        self._max_lines = settings.get('max_lines', 5)
        self._prefix = settings.get('responder_prefix', '')
        self._eliza_prefix = settings.get('eliza_1966_prefix', 'Eliza (1966)')
        # Restrict AR to a specific Meshtastic host (optional). Empty = any host.
        self._host = settings.get('host', '')

    async def respond(self, folder_name: str, sender_id: str, message: str,
                      trigger_node_data: dict = None,
                      own_node_data: dict = None,
                      node_list: list = None,
                      char_limit: int = DEFAULT_CHAR_LIMIT) -> Optional[List[str]]:
        """Process an incoming message for a conversation.

        Returns a list of message parts to send (split to fit the mesh char
        limit), or None if no responder is configured.

        Args:
            trigger_node_data: Full node dict for the node that sent the message.
                               Used for {{VARIABLE}} substitution in fixed responses.
            own_node_data:     Own gateway node dict.
                               Used for {{S_VARIABLE}} substitution.
            node_list:         All known nodes (list of dicts).  Used to substitute
                               !nodeid references in script output with display names.
        """
        # Respect runtime global enable/disable toggle
        if not get_global_enabled(self._working_dir):
            logger.debug(f"[AR] Global AR disabled for folder {folder_name}")
            return None

        if not is_conversation_enabled(self._working_dir, folder_name):
            logger.debug(f"[AR] Conversation disabled for folder {folder_name}")
            return None

        folder_path = ensure_conversation_folder(self._working_dir, folder_name)

        # Check trigger config — skip response if regex doesn't match
        conv_config = read_conv_config(folder_path)
        trigger_mode = conv_config.get('trigger', 'always')
        
        if trigger_mode == 'regex':
            pattern = conv_config.get('pattern', '').strip()
            if pattern:
                try:
                    match = re.search(pattern, message, re.IGNORECASE)
                    if match:
                        logger.info(f"[AR] Regex MATCHED in folder {folder_name}: pattern='{pattern}', message='{message[:50]}...'")
                    else:
                        logger.debug(f"[AR] Regex NO MATCH in folder {folder_name}: pattern='{pattern}', message='{message[:50]}...'")
                        return None
                except re.error as e:
                    logger.warning(f"[AR] Regex error in {folder_name}: {e}")
                    return None
        else:
            logger.debug(f"[AR] Folder {folder_name} trigger mode: {trigger_mode} (not regex)")

        # Log incoming message using formatted display name
        display_name = format_sender_display(sender_id, trigger_node_data)
        append_to_conversation(folder_path, display_name, message, self._history_context)
        logger.debug(f"[AR] Processing folder {folder_name} for message: '{message[:50]}...'")

        # Find and run responder
        response_parts = await self._invoke(folder_path, conv_config,
                                            trigger_node_data=trigger_node_data,
                                            own_node_data=own_node_data,
                                            node_list=node_list,
                                            incoming_message=message,
                                            char_limit=char_limit)

        # Log full response text
        if response_parts is not None:
            append_to_conversation(folder_path, 'responder',
                                   '\n'.join(response_parts), self._history_context)
            logger.info(f"[AR] Response generated for folder {folder_name}: {len(response_parts)} parts")
        else:
            logger.debug(f"[AR] No response for folder {folder_name}")

        return response_parts

    async def _invoke(self, folder_path: str, conv_config: dict,
                      trigger_node_data: dict = None, own_node_data: dict = None,
                      node_list: list = None,
                      incoming_message: str = '',
                      char_limit: int = DEFAULT_CHAR_LIMIT) -> Optional[List[str]]:
        """Find and run the applicable responder. Returns list of message parts or None."""
        responder_mode = conv_config.get('responder_mode', 'eliza') if conv_config else 'eliza'

        if responder_mode == 'fixed':
            fixed_text = (conv_config or {}).get('fixed_response', '').strip()
            if not fixed_text:
                return None
            resolved = resolve_variables(fixed_text,
                                         trigger_node=trigger_node_data,
                                         own_node=own_node_data,
                                         incoming_message=incoming_message)
            return split_message(resolved, char_limit)

        if responder_mode == 'eliza':
            return self._run_eliza(folder_path, incoming_message=incoming_message)

        # Script mode: try per-conversation script, then global fallback, then Eliza
        # 1. Per-conversation script
        per_conv = os.path.join(folder_path, 'responder')
        if os.path.isfile(per_conv) and os.access(per_conv, os.X_OK):
            return await self._run_script(per_conv, folder_path, node_list=node_list, char_limit=char_limit)
        if os.path.isfile(per_conv) and not os.access(per_conv, os.X_OK):
            logger.warning("Responder script exists but is not executable (chmod +x needed): %s", per_conv)

        # 2. Global fallback script
        global_script = os.path.join(self._working_dir, 'responder')
        if os.path.isfile(global_script) and os.access(global_script, os.X_OK):
            return await self._run_script(global_script, folder_path, node_list=node_list, char_limit=char_limit)
        if os.path.isfile(global_script) and not os.access(global_script, os.X_OK):
            logger.warning("Global responder script exists but is not executable (chmod +x needed): %s", global_script)

        # 3. Eliza fallback (script mode but no script found)
        logger.info("No executable responder script found for %s — falling back to Eliza", folder_path)
        return self._run_eliza(folder_path, incoming_message=incoming_message)

    @staticmethod
    def _substitute_node_ids(text: str, node_list: list) -> str:
        """Replace !hexid tokens in text with node display names from node_list.

        Replacement priority: long_name > short_name > keep original.
        """
        if not text or not node_list:
            return text

        # Build lookup: nodeid (with !) → display name
        lookup = {}
        for node in node_list:
            raw_id = str(node.get('id') or node.get('num') or '')
            if not raw_id:
                continue
            nid = raw_id if raw_id.startswith('!') else f'!{raw_id}'
            long_name = (node.get('longName') or node.get('long_name') or '').strip()
            short_name = (node.get('shortName') or node.get('short_name') or '').strip()
            if long_name:
                lookup[nid] = long_name
            elif short_name:
                lookup[nid] = short_name

        if not lookup:
            return text

        def _replace(match):
            return lookup.get(match.group(0), match.group(0))

        return re.sub(r'![0-9a-fA-F]{6,8}', _replace, text)

    async def _run_script(self, script_path: str, folder_path: str, node_list: list = None, char_limit: int = DEFAULT_CHAR_LIMIT):
        """Execute responder script; split long output into mesh-safe parts, or fall back to Eliza on error."""
        try:
            logger.info("Invoking responder script: %s (cwd=%s)", script_path, folder_path)
            loop = asyncio.get_event_loop()
            result = await loop.run_in_executor(
                None,
                lambda: subprocess.run(
                    [script_path],
                    shell=False,
                    capture_output=True,
                    text=True,
                    timeout=30,
                    cwd=folder_path,
                )
            )
            if result.stderr.strip():
                logger.warning("Responder script STDERR [%s]:\n%s", script_path, result.stderr.strip())
            if result.returncode > 0:
                logger.warning("Responder script exited with status %d — falling back to Eliza", result.returncode)
                logger.info("Responder script STDOUT [%s]:\n%s", script_path, result.stdout.strip())
                return self._run_eliza(folder_path)
            if result.stdout.strip():
                logger.info("Responder script STDOUT [%s]:\n%s", script_path, result.stdout.strip())
            lines = [l for l in result.stdout.strip().splitlines()
                     if l.strip()][:self._max_lines]
            logger.info("Script produced %d usable line(s) (max_lines=%d)", len(lines), self._max_lines)
            if not lines:
                return self._run_eliza(folder_path)
            # Each output line is auto-split to fit the byte limit
            parts: List[str] = []
            for line in lines:
                line = self._substitute_node_ids(line, node_list or [])
                if self._prefix:
                    line = f"{self._prefix} {line}"
                parts.extend(split_message(line, char_limit))
            return parts if parts else self._run_eliza(folder_path)
        except subprocess.TimeoutExpired:
            logger.warning("Responder script timed out: %s", script_path)
            return self._run_eliza(folder_path)
        except Exception as e:
            logger.error("Responder script error: %s", e)
            return self._run_eliza(folder_path)

    def _run_eliza(self, folder_path: str, incoming_message: str = '') -> Optional[List[str]]:
        """Run Eliza on the last message in conversation.txt.

        Falls back to `incoming_message` directly when the conversation file is
        empty or missing — this handles the first-ever test-trigger call before
        any history has been written.
        """
        if not _ELIZA_AVAILABLE:
            logger.warning("nltk not installed, no Eliza fallback")
            return None
        try:
            msg = ''
            content = read_conversation(folder_path)
            if content:
                lines = content.strip().splitlines()
                last_line = lines[-1] if lines else ''
                # Support pipe-separated format: TIMESTAMP|SENDER|MESSAGE
                parts = last_line.split('|', 2)
                if len(parts) == 3:
                    msg = parts[2].strip()
                elif ': ' in last_line:
                    msg = last_line.split(': ', 1)[1]
                else:
                    msg = last_line
            # Fall back to the raw incoming message if conversation file is empty
            if not msg:
                msg = incoming_message
            if not msg:
                return None
            response = _eliza_respond(msg)
            if self._eliza_prefix:
                return [f"{self._eliza_prefix}: {response}"]
            return [response]
        except Exception as e:
            logger.error("Eliza error: %s", e)
            return None
