"""
Message router for distributing messages to appropriate handlers.

Routes messages to WebSocket clients, storage, and other components.
"""

import asyncio
import collections
import logging
import hashlib
from typing import Dict, Any, List, Set, Callable
from datetime import datetime

from .constants import MAX_RECENT_MESSAGES

logger = logging.getLogger(__name__)

class MessageRouter:
    """
    Central message routing system.
    
    Distributes messages to WebSocket clients, database storage,
    and other registered handlers based on message type and routing rules.
    
    Maintains a rolling buffer of recent messages so clients can
    fetch any messages missed during a WebSocket disconnection.
    """
    
    # Use shared constant from core.constants
    # MAX_RECENT_MESSAGES imported at module level
    
    def __init__(self):
        self.websocket_clients: Set[Any] = set()  # WebSocket connections
        self.message_handlers: Dict[str, List[Callable]] = {}
        self.broadcast_handlers: List[Callable] = []
        self.persistent_message_handlers: Dict[str, List[Callable]] = {}
        self.persistent_broadcast_handlers: List[Callable] = []
        self._recent_messages: List[Dict[str, Any]] = []  # Rolling buffer

        # Small ring buffer for assembled image_complete events (max 5).
        # Kept separate from _recent_messages to avoid polluting the text/binary
        # buffer with large base64 payloads.  Flushed to reconnecting browsers
        # via _flush_buffered_messages in WebSocketAPI.
        self._image_complete_history: collections.deque = collections.deque(maxlen=5)
    
    @staticmethod
    def compute_message_id(message: Dict[str, Any]) -> str:
        """
        Compute a stable message_id for deduplication.
        
        Uses packet_id if available, otherwise generates a deterministic digest
        from stable message fields to ensure identical messages can be deduplicated.
        """
        # If packet_id is present, use it as the primary id (most reliable)
        if 'packet_id' in message and message['packet_id'] is not None:
            return f"pkt_{message['packet_id']}"
        
        # Otherwise, compute a stable hash from message content
        # Use fields that are stable and present in routed messages
        stable_fields = (
            message.get('message_type', 'unknown'),
            str(message.get('from_node', '')),
            str(message.get('channel', 0)),
            message.get('text') or message.get('decoded', {}).get('text', ''),
        )
        
        content_str = '|'.join(str(f) for f in stable_fields)
        digest = hashlib.sha256(content_str.encode()).hexdigest()[:16]
        return f"msg_{digest}"
        
    def register_websocket(self, websocket) -> None:
        """Register a WebSocket client for message broadcasting."""
        self.websocket_clients.add(websocket)
        logger.debug(f"WebSocket client registered, total: {len(self.websocket_clients)}")
    
    def unregister_websocket(self, websocket) -> None:
        """Unregister a WebSocket client."""
        self.websocket_clients.discard(websocket)
        logger.debug(f"WebSocket client unregistered, remaining: {len(self.websocket_clients)}")
    
    def register_handler(self, message_type: str, handler: Callable[[Dict[str, Any]], None]) -> None:
        """
        Register a handler for specific message types.
        
        Args:
            message_type: Type of message to handle
            handler: Callable that processes the message
        """
        if message_type not in self.message_handlers:
            self.message_handlers[message_type] = []
        
        self.message_handlers[message_type].append(handler)
        logger.info(f"Registered handler for '{message_type}' (total: {len(self.message_handlers[message_type])})")

    def register_persistent_handler(self, message_type: str, handler: Callable[[Dict[str, Any]], None]) -> None:
        """Register a handler that survives websocket handler replacement."""
        if message_type not in self.persistent_message_handlers:
            self.persistent_message_handlers[message_type] = []
        self.persistent_message_handlers[message_type].append(handler)
        logger.info(
            f"Registered persistent handler for '{message_type}' "
            f"(total: {len(self.persistent_message_handlers[message_type])})"
        )
    
    def subscribe(self, message_type: str, handler: Callable[[Dict[str, Any]], None]) -> None:
        """
        Subscribe to messages of a specific type (alias for register_handler).
        
        Args:
            message_type: Type of message to subscribe to
            handler: Callable that processes the message
        """
        self.register_handler(message_type, handler)
    
    def clear_handlers(self) -> None:
        """Clear all registered handlers. Used when WebSocket reconnects to avoid stale closures."""
        count = sum(len(v) for v in self.message_handlers.values()) + len(self.broadcast_handlers)
        self.message_handlers.clear()
        self.broadcast_handlers.clear()
        if count > 0:
            logger.info(f"Cleared {count} message handlers")
    
    def register_broadcast_handler(self, handler: Callable[[Dict[str, Any]], None]) -> None:
        """Register a handler that receives all messages."""
        self.broadcast_handlers.append(handler)
        logger.debug("Registered broadcast handler")

    def register_persistent_broadcast_handler(self, handler: Callable[[Dict[str, Any]], None]) -> None:
        """Register a broadcast handler that survives websocket replacement."""
        self.persistent_broadcast_handlers.append(handler)
        logger.debug("Registered persistent broadcast handler")
    
    async def route_message(self, message: Dict[str, Any]) -> None:
        """
        Route a message to appropriate handlers.
        
        Args:
            message: Message dictionary to route
        """
        try:
            message_type = message.get('message_type', 'unknown')
            
            # Add routing metadata
            message['routed_at'] = datetime.now().isoformat()
            
            # Compute stable message_id for deduplication (attach to message early)
            if 'message_id' not in message:
                message['message_id'] = self.compute_message_id(message)
            
            # Buffer user-facing message types for missed-message retrieval.
            # CRITICAL: Do NOT buffer binary_complete or image_complete in
            # _recent_messages — these contain concatenated payloads from
            # fragment_reassembler.  Buffering here would pollute the text/binary
            # buffer and /api/messages/recent with large base64 blobs.
            # image_complete is buffered separately in _image_complete_history.
            if message_type in ('text', 'binary', 'ack',
                                'node_update', 'position_update'):
                self._recent_messages.append(message)
                if len(self._recent_messages) > MAX_RECENT_MESSAGES:
                    self._recent_messages = self._recent_messages[-MAX_RECENT_MESSAGES:]

            # Buffer assembled images so reconnecting browsers get them.
            if message_type == 'image_complete':
                self._image_complete_history.append(message)
            
            # Route to specific handlers
            handler_count = len(self.message_handlers.get(message_type, []))
            if message_type in ('text', 'binary', 'binary_complete', 'ack'):
                logger.info(f"Routing {message_type} from {message.get('from_node', '?')} "
                           f"(handlers={handler_count})")
            
            has_ephemeral = message_type in self.message_handlers
            has_persistent = message_type in self.persistent_message_handlers

            if has_ephemeral:
                for i, handler in enumerate(self.message_handlers[message_type]):
                    try:
                        if asyncio.iscoroutinefunction(handler):
                            await handler(message)
                        else:
                            handler(message)
                    except Exception as e:  # Broad: unknown handler signatures
                        logger.warning(f"Error in message handler for {message_type}: {e}", exc_info=True)
            if has_persistent:
                for handler in self.persistent_message_handlers[message_type]:
                    try:
                        if asyncio.iscoroutinefunction(handler):
                            await handler(message)
                        else:
                            handler(message)
                    except Exception as e:
                        logger.warning(f"Error in persistent message handler for {message_type}: {e}", exc_info=True)
            elif message_type in ('text', 'binary', 'binary_complete', 'ack') and not has_ephemeral and not has_persistent:
                logger.warning(f"No handlers for message_type={message_type} - message buffered for later delivery")
            
            # Route to broadcast handlers
            for handler in self.broadcast_handlers:
                try:
                    if asyncio.iscoroutinefunction(handler):
                        await handler(message)
                    else:
                        handler(message)
                except Exception as e:  # Broad: unknown handler signatures
                    logger.warning(f"Error in broadcast handler: {e}")
            for handler in self.persistent_broadcast_handlers:
                try:
                    if asyncio.iscoroutinefunction(handler):
                        await handler(message)
                    else:
                        handler(message)
                except Exception as e:
                    logger.warning(f"Error in persistent broadcast handler: {e}")
            
            # NOTE: _broadcast_to_websockets() removed - it was a redundant
            # legacy path.  Session-specific WebSocket delivery is handled by
            # the handlers registered in WebSocketAPI._setup_session_callbacks().
            # Calling both caused double-delivery of every message.
            
            logger.debug(f"Routed {message_type} message from {message.get('from_node', 'unknown')}")
            
        except (KeyError, TypeError, ValueError) as e:
            logger.error(f"Error routing message: {e}", exc_info=True)
    
    def get_messages_for_host(self, host: str, port: int) -> List[Dict[str, Any]]:
        """
        Return all buffered messages for a specific host:port.
        
        Filters _recent_messages by source_host and source_port.
        Messages without source metadata (received from device) are included
        for all hosts (device messages should broadcast to all sessions).
        
        Args:
            host: Meshtastic host address
            port: Meshtastic port number
            
        Returns:
            List of messages matching the host, or all messages if no source metadata
        """
        filtered = []
        device_msgs = 0
        host_msgs = 0
        
        for msg in self._recent_messages:
            msg_host = msg.get('source_host')
            msg_port = msg.get('source_port')
            msg_type = msg.get('message_type', 'unknown')
            from_node = msg.get('from_node', '?')
            
            # Messages without source metadata = received from device, show to all sessions
            if msg_host is None and msg_port is None:
                filtered.append(msg)
                device_msgs += 1
                continue
            
            # Messages with source metadata = scheduled/AR/user-sent, filter by host
            if msg_host == host and msg_port == port:
                filtered.append(msg)
                host_msgs += 1
        
        logger.debug(f"get_messages_for_host({host}:{port}): {device_msgs} device msgs, {host_msgs} host-specific msgs, "
                     f"total {len(filtered)} returned (buffer size: {len(self._recent_messages)})")
        
        return filtered
    
    async def route_text_message(self, message: Dict[str, Any]) -> None:
        """Route a text message."""
        message['message_type'] = 'text'
        await self.route_message(message)
    
    async def route_binary_message(self, message: Dict[str, Any]) -> None:
        """Route a binary message."""
        message['message_type'] = 'binary'
        await self.route_message(message)
    
    async def route_binary_complete(self, message: Dict[str, Any]) -> None:
        """Route a completed binary message."""
        message['message_type'] = 'binary_complete'
        await self.route_message(message)
    
    async def route_node_update(self, node_info: Dict[str, Any]) -> None:
        """Route a node information update."""
        message = {
            'message_type': 'node_update',
            'node_info': node_info,
            'timestamp': datetime.now().isoformat()
        }
        await self.route_message(message)
    
    async def route_fragment_progress(self, fragment_key: str, fragment_info: Dict[str, Any]) -> None:
        """Route fragment progress update."""
        message = {
            'message_type': 'fragment_progress',
            'fragment_key': fragment_key,
            'fragment_info': {
                'fragment_id': fragment_info['fragment_id'],
                'from_node': fragment_info['from_node'],
                'total_segments': fragment_info['total_segments'],
                'received_count': fragment_info['received_count'],
                'progress_percent': (fragment_info['received_count'] / fragment_info['total_segments']) * 100,
                'updated_at': fragment_info['updated_at'].isoformat()
            },
            'timestamp': datetime.now().isoformat()
        }
        await self.route_message(message)
    
    async def route_connection_status(self, connected: bool, info: Dict[str, Any] = None) -> None:
        """Route connection status update."""
        message = {
            'message_type': 'connection_status',
            'connected': connected,
            'connection_info': info or {},
            'timestamp': datetime.now().isoformat()
        }
        await self.route_message(message)
    
    async def route_error(self, error_type: str, error_message: str, details: Dict[str, Any] = None) -> None:
        """Route error message."""
        message = {
            'message_type': 'error',
            'error_type': error_type,
            'error_message': error_message,
            'details': details or {},
            'timestamp': datetime.now().isoformat()
        }
        await self.route_message(message)
    
    async def get_stats(self) -> Dict[str, Any]:
        """Get routing statistics."""
        return {
            'websocket_clients': len(self.websocket_clients),
            'message_handlers': {
                msg_type: len(handlers) 
                for msg_type, handlers in self.message_handlers.items()
            },
            'broadcast_handlers': len(self.broadcast_handlers),
            'persistent_message_handlers': {
                msg_type: len(handlers)
                for msg_type, handlers in self.persistent_message_handlers.items()
            },
            'persistent_broadcast_handlers': len(self.persistent_broadcast_handlers),
            'recent_message_buffer': len(self._recent_messages)
        }
    
    def get_messages_since(self, since_iso: str) -> List[Dict[str, Any]]:
        """
        Return buffered messages routed after the given ISO timestamp.
        Used by clients to retrieve messages missed during a WebSocket disconnect.
        
        Args:
            since_iso: ISO-format timestamp string (e.g. from routed_at)
            
        Returns:
            List of message dicts routed after the given time
        """
        result = []
        for msg in self._recent_messages:
            routed_at = msg.get('routed_at', '')
            if routed_at > since_iso:
                result.append(msg)
        return result
    
    def get_image_complete_history(self) -> List[Dict[str, Any]]:
        """
        Return buffered image_complete events (up to last 5).
        Used to deliver assembled images to reconnecting browsers.
        Does NOT drain the buffer — safe to call multiple times.
        """
        return list(self._image_complete_history)

    async def broadcast_system_message(self, message: str, level: str = 'info') -> None:
        """Broadcast a system message to all clients."""
        system_message = {
            'message_type': 'system',
            'level': level,
            'message': message,
            'timestamp': datetime.now().isoformat()
        }
        
        await self.route_message(system_message)
