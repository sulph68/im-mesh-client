"""Persistent backend service gateway/session management."""

import asyncio
import logging
from dataclasses import dataclass
from typing import Dict, Optional

from core.network_utils import hosts_match
from core.session_manager import SessionManager, Session

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class ServiceEndpoint:
    name: str
    host: str
    port: int


class ServiceGatewayManager:
    """Owns long-lived backend sessions for service hosts."""

    def __init__(self, session_manager: SessionManager, raw_settings: dict):
        self.session_manager = session_manager
        self.raw_settings = raw_settings
        self._sessions: Dict[str, Session] = {}
        self._started = False
        self._watchdog_task: Optional[asyncio.Task] = None
        self._watchdog_interval = 180
        self._health: Dict[str, bool] = {}

    @staticmethod
    def _split_host_port(host: str, fallback_port: int) -> tuple[str, int]:
        host = (host or '').strip()
        if ':' in host and not host.startswith('serial://'):
            maybe_host, maybe_port = host.rsplit(':', 1)
            if maybe_port.isdigit():
                return maybe_host, int(maybe_port)
        return host or 'localhost', fallback_port

    def _build_endpoints(self) -> list[ServiceEndpoint]:
        meshtastic = self.raw_settings.get('meshtastic', {})
        base_host = meshtastic.get('host', 'localhost')
        base_port = int(meshtastic.get('port', 4403))
        endpoints = [
            ServiceEndpoint('meshtastic', *self._split_host_port(base_host, base_port))
        ]

        for name in ('sched_message', 'auto_responder', 'telegram'):
            section = self.raw_settings.get(name, {})
            if not section.get('enabled', False):
                continue
            svc_host = section.get('host', base_host)
            host, port = self._split_host_port(svc_host, base_port)
            endpoints.append(ServiceEndpoint(name, host, port))

        return endpoints

    async def start(self, websocket_api=None) -> None:
        """Create/reuse persistent sessions and register persistent handlers."""
        if self._started:
            return

        from api.ws_handlers import WebSocketHandlersMixin

        endpoints = self._build_endpoints()
        host_sessions: Dict[tuple[str, int], Session] = {}
        for endpoint in endpoints:
            host_key = (endpoint.host, endpoint.port)
            session = host_sessions.get(host_key)
            if session is None:
                session_id = await self.session_manager.create_session(
                    meshtastic_host=endpoint.host,
                    meshtastic_port=endpoint.port,
                    persistent=True,
                )
                session = await self.session_manager.get_session(session_id)
                host_sessions[host_key] = session
            if session is None:
                logger.warning("Service session missing after creation: %s", endpoint)
                continue

            session.persistent = True
            session.gateway.auto_reconnect = True
            session.gateway.reconnect_delay = 180
            self._sessions[endpoint.name] = session

            if not session.gateway.running:
                await session.start()

            if websocket_api and isinstance(websocket_api, WebSocketHandlersMixin):
                router = session.gateway.message_router
                if endpoint.name == 'auto_responder' and websocket_api.auto_responder:
                    websocket_api._register_ar_handler(session, router, persistent=True)
                if endpoint.name == 'telegram' and websocket_api.telegram_forwarder:
                    websocket_api._register_tg_handler(session, router, persistent=True)

            logger.info(
                "Service session ready: %s => %s:%s (persistent=%s)",
                endpoint.name, endpoint.host, endpoint.port, session.persistent
            )
            self._health[endpoint.name] = bool(session.gateway.meshtastic_client.is_connected())

        self._started = True
        if self._watchdog_task is None:
            self._watchdog_task = asyncio.create_task(self._watchdog_loop())

    async def _restart_session(self, name: str, session: Session) -> None:
        """Cleanly restart a service session."""
        logger.warning("Restarting service session %s (%s)", name, session.id)
        try:
            await session.gateway.stop()
        except Exception as e:
            logger.warning("Error stopping service session %s during restart: %s", name, e)
        try:
            await session.start()
        except Exception as e:
            logger.warning("Error starting service session %s during restart: %s", name, e)

    async def _watchdog_loop(self) -> None:
        """Periodic health check for persistent service sessions."""
        while self._started:
            try:
                await asyncio.sleep(self._watchdog_interval)
                for name, session in list(self._sessions.items()):
                    try:
                        connected = bool(session.gateway.meshtastic_client.is_connected())
                        previous = self._health.get(name)
                        if previous is None or previous != connected:
                            logger.info(
                                "Service host %s (%s) is now %s",
                                name,
                                f"{session.settings.meshtastic.host}:{session.settings.meshtastic.port}",
                                "connected" if connected else "disconnected",
                            )
                        self._health[name] = connected
                        if not connected:
                            await self._restart_session(name, session)
                            self._health[name] = bool(session.gateway.meshtastic_client.is_connected())
                    except Exception as e:
                        logger.warning("Service watchdog error for %s: %s", name, e)
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.warning("Service watchdog loop error: %s", e)

    async def shutdown(self) -> None:
        """Best-effort shutdown for service sessions."""
        self._started = False
        if self._watchdog_task is not None:
            self._watchdog_task.cancel()
            try:
                await self._watchdog_task
            except asyncio.CancelledError:
                pass
            self._watchdog_task = None
        for name, session in list(self._sessions.items()):
            try:
                logger.info("Stopping service session %s (%s)", name, session.id)
                await session.stop()
            except Exception as e:
                logger.warning("Error stopping service session %s: %s", name, e)
        self._sessions.clear()
        self._started = False

    def get_session(self, name: str) -> Optional[Session]:
        return self._sessions.get(name)

    def get_session_for_host(self, host: str, port: int) -> Optional[Session]:
        for session in self._sessions.values():
            if hosts_match(session.settings.meshtastic.host, host) and session.settings.meshtastic.port == port:
                return session
        return None

    def get_scheduler_session(self) -> Optional[Session]:
        return self._sessions.get('sched_message') or self._sessions.get('meshtastic')
