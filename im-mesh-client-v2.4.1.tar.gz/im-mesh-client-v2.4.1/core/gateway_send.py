"""
Send methods mixin for the Gateway.

Extracted from gateway.py to keep the core file focused on connection lifecycle.
GatewaySendMixin is mixed into Gateway and relies on attributes set by Gateway.__init__:
    self._operation_lock, self._last_send_time, self._message_delay,
    self._segment_delay, self.meshtastic_client, self.message_router
"""

import asyncio
import logging
import time
from datetime import datetime
from typing import Optional, Dict, Any, List

from .constants import PortNum
from .log_utils import tagged_logger

logger = logging.getLogger(__name__)


class GatewaySendMixin:
    """Send-path methods: text, binary, image segments, and inter-send pacing."""

    @property
    def _log(self):
        if not hasattr(self, '_gw_send_log'):
            tag = f"{self.settings.meshtastic.host}:{self.settings.meshtastic.port}"
            self._gw_send_log = tagged_logger(logger, tag)
        return self._gw_send_log

    @_log.setter
    def _log(self, value):
        self._gw_send_log = value
    
    def _get_source_host_port(self) -> tuple:
        """Return (host, port) for message routing metadata."""
        try:
            return (self.settings.meshtastic.host, self.settings.meshtastic.port)
        except (AttributeError, TypeError):
            return (None, None)

    async def _retry_after_reconnect(self, send_fn, op_label: str):
        """Wrapper: call ``send_fn()``, and if it fails because the TCP connection
        just dropped, wait 3 s for the auto-reconnect then retry once.

        ``send_fn`` must be a zero-arg async callable that acquires
        ``_operation_lock`` internally (so the lock is NOT held during the
        sleep, allowing ``_manage_connection`` to reconnect).

        Returns the result dict on success, or ``None`` on failure.
        """
        result = await send_fn()
        if result and isinstance(result, dict) and result.get('success'):
            return result

        # Connection may have dropped during the send (stale TCP after long idle).
        # Sleep outside the lock so _manage_connection can reconnect, then retry once.
        if not self.meshtastic_client.is_connected():
            self._log.info(f"Send failed ({op_label}) — stale connection; waiting 3s for reconnect...")
            await asyncio.sleep(3)
            if self.meshtastic_client.is_connected():
                result = await send_fn()
                if result and isinstance(result, dict) and result.get('success'):
                    return result

        return None

    async def _pace_send(self) -> None:
        """Enforce minimum inter-send delay before a radio transmission.
        
        Must be called INSIDE _operation_lock.  Sleeps if the last send was
        less than _message_delay seconds ago, then updates the timestamp.
        
        The delay is configurable via settings.json `meshtastic.message_delay`
        (default 5 s).  The LoRa radio is half-duplex; sending a new packet
        while the firmware is still in a TX+ACK retransmit cycle for the
        previous packet causes the new packet to be silently dropped by the
        firmware's TX queue.
        """
        now = time.monotonic()
        elapsed = now - self._last_send_time
        if elapsed < self._message_delay:
            gap = self._message_delay - elapsed
            self._log.info(f"SEND PACE: waiting {gap:.1f}s (last send {elapsed:.1f}s ago)")
            await asyncio.sleep(gap)
        self._last_send_time = time.monotonic()

    @staticmethod
    def _resolve_firmware_ack(want_ack: bool, to_node: Optional[str]) -> bool:
        """Decide whether to pass wantAck to the Meshtastic firmware.
        
        Always passes through the caller's want_ack value.  Both broadcast
        and direct messages use firmware-level ACK when requested.
        
        For DIRECT messages the firmware sends two ACKs:
          1. Self-ACK (implicit): from our own node confirming radio TX
          2. Remote ACK: from the destination node confirming receipt
        
        For BROADCAST messages the firmware still requests ACK, though
        only the first receiver to respond will ACK (others are suppressed
        by the LoRa collision avoidance window).  Combined with the 5-second
        MIN_SEND_INTERVAL pacing, this provides reasonable reliability
        without the retransmit storm that occurred at 2s pacing.
        
        Returns:
            True to tell firmware to use reliable delivery, False otherwise.
        """
        return want_ack

    async def _do_send_text(self, text: str, to_node: Optional[str],
                            channel: int, fw_ack: bool, portnum: int):
        """Acquire lock, pace, and send one text message. Used by _retry_after_reconnect."""
        async with self._operation_lock:
            await self._pace_send()
            return await self.meshtastic_client.send_text_message(
                text, to_node, channel, fw_ack, portnum
            )

    async def send_text_message(self, text: str, to_node: Optional[str] = None,
                               channel: int = 0, want_ack: bool = False,
                               portnum: int = 1) -> Dict[str, Any]:
        """
        Send a text message through the gateway.
        
        Acquires _operation_lock to serialize radio access.
        Uses the existing persistent TCP connection.
        Enforces inter-send pacing to prevent firmware TX queue overflow.
        Retries once on stale-connection failure (first send after long idle).
        
        Args:
            text: Message text to send
            to_node: Target node ID (None for broadcast)
            channel: Channel number
            want_ack: Whether to request acknowledgment
            
        Returns:
            dict with 'success' and 'packet_id' keys, or False on failure
        """
        try:
            if not await self._ensure_connected():
                return False
            
            fw_ack = self._resolve_firmware_ack(want_ack, to_node)
            dest_label = f"node {to_node}" if to_node else "broadcast"
            self._log.info(f"SEND TEXT: '{text[:50]}' to {dest_label} ch={channel} "
                        f"portnum={portnum} want_ack={want_ack} fw_ack={fw_ack}")
            
            result = await self._retry_after_reconnect(
                lambda: self._do_send_text(text, to_node, channel, fw_ack, portnum),
                f"text to {dest_label}"
            )
            
            # result is either {'success': True, 'packet_id': <id>} or None
            if result and isinstance(result, dict) and result.get('success'):
                packet_id = result.get('packet_id')
                self._log.info(f"Sent text message: '{text[:50]}{'...' if len(text) > 50 else ''}' "
                            f"(packetId={packet_id}) fw_ack={fw_ack}")
                return {'success': True, 'packet_id': packet_id}
            else:
                await self.message_router.route_error(
                    'send_error', 'Failed to send text message'
                )
                return False
            
        except (ConnectionError, OSError, RuntimeError, TypeError) as e:
            self._log.warning(f"Error sending text message: {e}")
            await self.message_router.route_error('send_error', str(e))
            return False

    async def _do_send_binary(self, data: str, to_node: Optional[str],
                              channel: int, fw_ack: bool):
        """Acquire lock, pace, and send one binary message. Used by _retry_after_reconnect."""
        async with self._operation_lock:
            await self._pace_send()
            return await self.meshtastic_client.send_binary_message(
                data=data.encode('utf-8'),
                to_node=to_node,
                channel=channel,
                portnum=PortNum.CUSTOM_IMAGE_APP,
                want_ack=fw_ack
            )

    async def send_binary_message(self, data: str, to_node: Optional[str] = None,
                                channel: int = 0, want_ack: bool = False) -> Dict[str, Any]:
        """
        Send a single binary message via portnum 288 (CUSTOM_IMAGE_APP).
        
        Acquires _operation_lock to serialize radio access.
        Enforces inter-send pacing to prevent firmware TX queue overflow.
        Retries once on stale-connection failure (first send after long idle).
        
        Args:
            data: Text payload to send as binary (UTF-8 encoded)
            to_node: Target node ID (None for broadcast)
            channel: Channel number
            want_ack: Whether to request acknowledgment
            
        Returns:
            dict with 'success' and 'packet_id' keys, or False on failure
        """
        try:
            if not await self._ensure_connected():
                return False
            
            fw_ack = self._resolve_firmware_ack(want_ack, to_node)
            dest_label = f"node {to_node}" if to_node else "broadcast"
            self._log.info(f"SEND BINARY: {len(data)} chars to {dest_label} ch={channel} "
                        f"want_ack={want_ack} fw_ack={fw_ack}")
            
            result = await self._retry_after_reconnect(
                lambda: self._do_send_binary(data, to_node, channel, fw_ack),
                f"binary to {dest_label}"
            )
            
            if result and isinstance(result, dict) and result.get('success'):
                packet_id = result.get('packet_id')
                self._log.info(f"Sent binary message: {len(data)} chars "
                            f"(packetId={packet_id}) fw_ack={fw_ack}")
                return {'success': True, 'packet_id': packet_id}
            else:
                await self.message_router.route_error(
                    'send_error', 'Failed to send binary message'
                )
                return False
            
        except (ConnectionError, OSError, RuntimeError, TypeError) as e:
            self._log.warning(f"Error sending binary message: {e}")
            await self.message_router.route_error('send_error', str(e))
            return False

    async def _send_one_segment(self, segment: str, index: int, total: int,
                                to_node: Optional[str], channel: int,
                                use_binary: bool) -> Optional[int]:
        """Send a single image segment and notify progress.
        
        Acquires _operation_lock only for the actual send, then releases it
        so ACK callbacks and other operations can proceed between segments.
        Uses _pace_send() and _resolve_firmware_ack() for reliability.
        
        Returns:
            packet_id on success, None on failure.
        """
        fw_ack = self._resolve_firmware_ack(True, to_node)
        async with self._operation_lock:
            await self._pace_send()
            if use_binary:
                result = await self.meshtastic_client.send_binary_message(
                    data=segment.encode('utf-8'),
                    to_node=to_node, channel=channel,
                    portnum=PortNum.CUSTOM_IMAGE_APP, want_ack=fw_ack
                )
            else:
                result = await self.meshtastic_client.send_text_message(
                    text=segment, to_node=to_node,
                    channel=channel, want_ack=fw_ack
                )
        
        send_ok = result and isinstance(result, dict) and result.get('success')
        packet_id = result.get('packet_id') if isinstance(result, dict) else None
        
        if not send_ok:
            self._log.warning(f"Failed to send segment {index + 1}/{total}")
            await self.message_router.route_error(
                'send_error', f'Failed to send segment {index + 1}/{total}'
            )
            return None
        
        # Notify progress (messages stored client-side in localStorage)
        source_host, source_port = self._get_source_host_port()
        await self.message_router.route_message({
            'message_type': 'send_progress',
            'segment_index': index,
            'total_segments': total,
            'progress_percent': ((index + 1) / total) * 100,
            'packet_id': packet_id,
            'timestamp': datetime.now().isoformat(),
            'source_host': source_host,
            'source_port': source_port,
        })
        
        return packet_id

    async def send_image_segments(self, segments: List[str], to_node: Optional[str] = None,
                                 channel: int = 0, delay_ms: int = 0,
                                 send_method: str = 'text') -> bool:
        """
        Send image segments with wantAck=True and minimum inter-segment spacing.
        
        Each segment acquires _operation_lock individually (inside
        _send_one_segment), then releases it.  The inter-segment delay
        runs WITHOUT the lock held, so ACK callbacks and other queued
        operations (node queries, channel reads) can proceed between
        segments.  This prevents the radio from appearing "stuck" during
        a long multi-segment image send.
        
        Args:
            segments: List of image message segments (text format)
            to_node: Target node ID (None for broadcast)
            channel: Channel number
            delay_ms: Delay between segments in milliseconds.  0 means use the
                      configured `encoding.segment_delay` (default 15 s).
                      A minimum of 3000 ms is always enforced.
            send_method: 'text' or 'binary' (CUSTOM_IMAGE_APP portnum 288)
            
        Returns:
            True if all segments sent successfully
        """
        try:
            if not await self._ensure_connected():
                return False

            # Use segment_delay from settings unless caller passes an explicit value.
            default_ms = self._segment_delay * 1000
            actual_delay = max(delay_ms if delay_ms > 0 else default_ms, 3000)
            use_binary = send_method == 'binary'
            success_count = 0
            
            for i, segment in enumerate(segments):
                packet_id = await self._send_one_segment(
                    segment, i, len(segments), to_node, channel, use_binary
                )
                if packet_id is not None:
                    success_count += 1
                
                # Wait between segments (skip after last).
                # Lock is NOT held during this delay, allowing ACK
                # callbacks and other operations to proceed.
                if i < len(segments) - 1:
                    self._log.info(f"Waiting {actual_delay}ms before next segment ({i+2}/{len(segments)})")
                    await asyncio.sleep(actual_delay / 1000.0)
            
            # Send completion status
            source_host, source_port = self._get_source_host_port()
            await self.message_router.route_message({
                'message_type': 'send_complete',
                'segments_sent': success_count,
                'total_segments': len(segments),
                'success': success_count == len(segments),
                'timestamp': datetime.now().isoformat(),
                'source_host': source_host,
                'source_port': source_port,
            })
            
            self._log.info(f"Sent {success_count}/{len(segments)} image segments")
            return success_count == len(segments)
            
        except (ConnectionError, OSError, RuntimeError, TypeError) as e:
            self._log.warning(f"Error sending image segments: {e}")
            await self.message_router.route_error('send_error', str(e))
            return False
