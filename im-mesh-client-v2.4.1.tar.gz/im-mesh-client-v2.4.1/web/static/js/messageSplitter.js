// messageSplitter.js — Frontend mirror of core/message_splitter.py splitting logic.
// Provides splitMessage(text) -> array of ready-to-send strings, and wires up #splitPreview.
//
// Constants (must mirror core/message_splitter.py):
//   SPLIT_THRESHOLD  — max bytes before splitting is triggered (220)
//   PREFIX_OVERHEAD  — bytes reserved for "[N/N] " prefix (10)
//   CHUNK_MAX        — max content bytes per chunk = SPLIT_THRESHOLD - PREFIX_OVERHEAD (210)
//
// A common mistake is setting CHUNK_MAX = SPLIT_THRESHOLD (220).  That fills the content
// window to 220 chars and then adds the "[1/2] " prefix, producing a 226+ byte string
// that the Meshtastic firmware rejects with TOO_LARGE.  Later chunks (tiny overflow
// content) are well under 220 bytes and succeed, which is the reported symptom.

(function () {
    'use strict';

    const SPLIT_THRESHOLD = 220;
    const PREFIX_OVERHEAD = 10;           // "[9999/9999] " worst-case prefix bytes
    const CHUNK_MAX = SPLIT_THRESHOLD - PREFIX_OVERHEAD;  // 210 content chars

    /**
     * Split a message into chunks for Meshtastic transmission.
     * Returns an array of strings (already-formatted chunks with [n/x] prefix where needed).
     * If text.length <= SPLIT_THRESHOLD, returns [text].
     * Splits preferentially at word boundaries; falls back to hard split if no space found.
     */
    function splitMessage(text) {
        if (!text || text.length <= SPLIT_THRESHOLD) {
            return [text || ''];
        }

        var chunks = [];
        var remaining = text;
        while (remaining.length > 0) {
            if (remaining.length <= CHUNK_MAX) {
                chunks.push(remaining);
                break;
            }
            // Find last space at or before CHUNK_MAX (word-boundary split)
            var splitPos = remaining.lastIndexOf(' ', CHUNK_MAX);
            if (splitPos > 0) {
                chunks.push(remaining.slice(0, splitPos));
                remaining = remaining.slice(splitPos + 1); // skip the space
            } else {
                // No space found — hard split at CHUNK_MAX
                chunks.push(remaining.slice(0, CHUNK_MAX));
                remaining = remaining.slice(CHUNK_MAX);
            }
        }

        var total = chunks.length;
        return chunks.map(function (chunk, idx) {
            return '[' + (idx + 1) + '/' + total + '] ' + chunk;
        });
    }

    /** Auto-resize a textarea to fit its content (up to max-height). */
    function autoResize(textarea) {
        textarea.style.height = 'auto';
        textarea.style.height = Math.min(textarea.scrollHeight, 200) + 'px';
    }

    /**
     * Wire up the split preview and auto-resize to the #messageInput element.
     */
    function initSplitPreview() {
        var input = document.getElementById('messageInput');
        var preview = document.getElementById('splitPreview');
        if (!input || !preview) return;

        input.addEventListener('input', function () {
            // Auto-resize textarea
            if (input.tagName === 'TEXTAREA') {
                autoResize(input);
            }

            var text = input.value;
            if (text.length > SPLIT_THRESHOLD) {
                var parts = splitMessage(text);
                preview.textContent = 'Will be sent in ' + parts.length + ' parts';
                preview.style.display = 'block';
            } else {
                preview.style.display = 'none';
                preview.textContent = '';
            }
        });
    }

    // Expose globally for use in app_messages.js send handler
    window.MeshSplitter = { splitMessage: splitMessage, SPLIT_THRESHOLD: SPLIT_THRESHOLD };

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initSplitPreview);
    } else {
        initSplitPreview();
    }
})();
