"""
WebSocket handler registration mixin for WebSocketAPI.

Contains _register_ws_subscriptions, _register_ar_handler, _register_tg_handler.
These methods define and register inner callback closures for each event type.
They access self.auto_responder, self.telegram_forwarder, self.scheduler
which are set in WebSocketAPI.__init__.
"""

import json
import logging
import asyncio
import base64
from typing import Any
from datetime import datetime

from core.session_manager import Session
from core.network_utils import hosts_match

logger = logging.getLogger(__name__)


class WebSocketHandlersMixin:
    """Mixin providing handler registration methods for WebSocketAPI."""

    def _register_ws_subscriptions(self, session: Session, message_router) -> None:
        """Register the core WebSocket forwarding subscriptions on the message router."""
        def _make_ws_callback(ws_type: str, log_detail: bool = False):
            """Create a WebSocket forwarding callback for a message type."""
            async def callback(data):
                try:
                    if log_detail:
                        msg_type = data.get('message_type', 'unknown')
                        from_node = data.get('from_node', 'unknown')
                        preview = (data.get('decoded_text', '') or '')[:50]
                        session_host = getattr(getattr(session.settings, 'meshtastic', None), 'host', '?')
                        session_port = getattr(getattr(session.settings, 'meshtastic', None), 'port', '?')
                        logger.info(f"[{session_host}:{session_port}] WS routing {msg_type} from {from_node} to session {session.id}: {preview}")
                    await self._send_to_session(session.id, {
                        'type': ws_type,
                        'data': data
                    })
                    # Per-WS send-time is updated inside _send_to_session; no mark_delivered needed here.
                except Exception as e:  # Broad: unknown user callback types
                    logger.error(f"Error in {ws_type} callback: {e}")
            return callback

        # Map: router event -> (WS type, log detail)
        # NOTE: 'text_sent' and 'binary_sent' are NOT subscribed here.
        # The browser JS already displays sent messages from the REST API response.
        subscriptions = [
            ('text',              'message',           True),
            ('binary',            'message',           True),
            ('binary_complete',   'binary_complete',   False),
            ('image_complete',    'image_complete',    False),
            ('ack',               'ack',               False),
            ('node_update',       'node_update',       False),
            ('position_update',   'node_update',       False),
            ('fragment_progress', 'fragment_progress', False),
            ('connection_status', 'connection_status', False),
        ]

        # Build new handler dict FIRST, then swap atomically.
        # This prevents the window where handlers=0 during WS reconnect.
        new_handlers = {}
        for router_event, ws_type, log_detail in subscriptions:
            new_handlers[router_event] = [_make_ws_callback(ws_type, log_detail)]

        # Atomic swap: replace entire dict in one operation
        message_router.message_handlers = new_handlers
        message_router.broadcast_handlers = []

    def _register_ar_handler(self, session: Session, message_router, persistent: bool = False) -> None:
        """Register the AutoResponder broadcast handler on the message router."""
        # Only register AR for the configured host (if a host restriction is set).
        # This prevents AR from firing on every session in a multi-device setup.
        ar_host = getattr(self.auto_responder, '_host', '')
        session_host = getattr(session.settings.meshtastic, 'host', '') if hasattr(session, 'settings') else ''
        ar_host_matches = (
            not ar_host
            or hosts_match(ar_host, session_host)
        )
        if not ar_host_matches:
            return

        async def _ar_handler(message):
            if message.get('message_type') != 'text':
                return
            try:
                text = message.get('decoded_text', '')
                from_node = message.get('from_node', '')
                channel = message.get('channel', 0)
                is_broadcast = message.get('is_broadcast', False)
                if not (text and from_node):
                    return
                    
                logger.info(f"[AR] Handler called: from_node={from_node}, channel={channel}, is_broadcast={is_broadcast}, "
                           f"text_preview='{text[:50]}...', session={session.id}")
                
                from core.auto_responder_config import (
                    get_node_folder_name, find_channel_folder_names,
                    find_node_folder_names, find_own_node_folder_names,
                    read_conv_config, ensure_conversation_folder,
                )

                # Fetch node data for variable substitution (only when needed)
                # We do a best-effort lookup; failure is non-fatal
                trigger_node_data = None
                own_node_data = None
                nodes = []
                try:
                    nodes = await session.gateway.get_node_list()
                    trigger_node_data = next(
                        (n for n in nodes if (n.get('id') or n.get('num') or '') == from_node),
                        None
                    )
                    # Unknown sender: force a full node-DB refresh from the device,
                    # then retry the lookup once so we use fresh data if available.
                    if trigger_node_data is None and hasattr(session.gateway, 'refresh_node_data'):
                        try:
                            await session.gateway.refresh_node_data()
                            nodes = await session.gateway.get_node_list()
                            trigger_node_data = next(
                                (n for n in nodes if (n.get('id') or n.get('num') or '') == from_node),
                                None
                            )
                        except Exception as re_exc:
                            logger.debug(f"[ws] ar force-refresh failed: {re_exc}")
                    # If still unknown, build a minimal stub so variable substitution
                    # can generate the [??] Meshtastic fallback instead of raw {{...}}.
                    if trigger_node_data is None and from_node:
                        trigger_node_data = {'id': from_node}
                    conn_status = await session.gateway.get_connection_status()
                    own_node_data = conn_status if conn_status.get('connected') else None
                except Exception as e:
                    logger.debug(f"[ws] ar node/status fetch: {e}")
                folder_name = None
                to_node = None
                parts = None
                if is_broadcast:
                    # Channel message — find ALL matching ch{n}_* folders, fire first match
                    folder_names = find_channel_folder_names(
                        self.auto_responder._working_dir, channel
                    )
                    logger.info(f"[AR] Broadcast on ch{channel}: found {len(folder_names)} folder candidates: {folder_names}")
                    for candidate in folder_names:
                        logger.debug(f"[AR] Testing candidate folder: {candidate}")
                        result = await self.auto_responder.respond(
                            folder_name=candidate, sender_id=from_node, message=text,
                            trigger_node_data=trigger_node_data, own_node_data=own_node_data,
                            node_list=nodes,
                            char_limit=session.gateway.char_limit,
                        )
                        if result is not None:
                            logger.info(f"[AR] Folder matched: {candidate}, response parts: {len(result)}")
                            folder_name = candidate
                            parts = result
                            break
                    if not folder_name:
                        logger.debug(f"[AR] No folder matched for broadcast on ch{channel}")
                        return
                    if parts:
                        msg_delay = session.gateway.msg_delay
                        for idx, part in enumerate(parts):
                            if idx > 0:
                                await asyncio.sleep(msg_delay)
                            logger.debug(f"[AR] Sending broadcast response part {idx+1}/{len(parts)}")
                            await session.gateway.send_text_message(
                                text=part, to_node=None, channel=channel, want_ack=False
                            )
                else:
                    # Direct message — check sender-specific rules first,
                    # then fall back to own_node catch-all rules.
                    sender_folders = find_node_folder_names(
                        self.auto_responder._working_dir, from_node
                    )
                    logger.info(f"[AR] Direct message from {from_node}: found {len(sender_folders)} sender-specific folders: {sender_folders}")
                    for candidate in sender_folders:
                        logger.debug(f"[AR] Testing sender folder: {candidate}")
                        result = await self.auto_responder.respond(
                            folder_name=candidate, sender_id=from_node, message=text,
                            trigger_node_data=trigger_node_data, own_node_data=own_node_data,
                            node_list=nodes,
                            char_limit=session.gateway.char_limit,
                        )
                        if result is not None:
                            logger.info(f"[AR] Sender folder matched: {candidate}, response parts: {len(result)}")
                            folder_name = candidate
                            to_node = from_node
                            parts = result
                            break
                    # If no sender-specific rule fired, try own_node catch-all
                    if not folder_name:
                        own_folders = find_own_node_folder_names(
                            self.auto_responder._working_dir
                        )
                        logger.info(f"[AR] No sender folder matched, trying {len(own_folders)} own_node folders: {own_folders}")
                        for candidate in own_folders:
                            logger.debug(f"[AR] Testing own_node folder: {candidate}")
                            result = await self.auto_responder.respond(
                                folder_name=candidate, sender_id=from_node, message=text,
                                trigger_node_data=trigger_node_data, own_node_data=own_node_data,
                                node_list=nodes,
                                char_limit=session.gateway.char_limit,
                            )
                            if result is not None:
                                logger.info(f"[AR] Own_node folder matched: {candidate}, response parts: {len(result)}")
                                folder_name = candidate
                                to_node = from_node
                                parts = result
                                break
                    if not folder_name:
                        logger.debug(f"[AR] No folder matched for direct message from {from_node}")
                        return
                    if parts:
                        msg_delay = session.gateway.msg_delay
                        for idx, part in enumerate(parts):
                            if idx > 0:
                                await asyncio.sleep(msg_delay)
                            await session.gateway.send_text_message(
                                text=part, to_node=from_node, channel=channel, want_ack=False
                            )
                if parts and folder_name:
                    # Read label from conv config for display
                    try:
                        fp = ensure_conversation_folder(self.auto_responder._working_dir, folder_name)
                        cfg = read_conv_config(fp)
                        label = cfg.get('label') or folder_name
                    except Exception:
                        label = folder_name
                    fired_at = datetime.now().isoformat()
                    for idx, part in enumerate(parts):
                        msg_data = {
                            'text': part,
                            'from': f'You \U0001f916 Responder - {label}',
                            'from_node': None,
                            'to_node': to_node,
                            'channel': channel,
                            'is_broadcast': to_node is None,
                            'timestamp': fired_at,
                            'ar_response': True,
                            'ar_key': f"{folder_name}_{fired_at}_{from_node}_{idx}",
                            'triggered_by': text[:80],
                        }
                        # Cache so the browser gets it on reconnect if currently offline.
                        # Skip caching when WS is active — live delivery already shows
                        # the message; caching it would cause duplicates on page reload
                        # once dedup sets are cleared.
                        is_browser_online = bool(self.session_connections.get(session.id))
                        if not is_browser_online:
                            # Add host/port metadata for routing
                            msg_data['source_host'] = session.gateway.settings.meshtastic.host
                            msg_data['source_port'] = session.gateway.settings.meshtastic.port
                            self._cache_ar_message(session.id, msg_data)
                        # Send ar_message so the browser shows it in the message panel
                        await self._send_to_session(session.id, {
                            'type': 'ar_message',
                            'data': msg_data,
                        })
                    # Also log to comm panel
                    await self._send_to_session(session.id, {
                        'type': 'ar_action',
                        'data': {
                            'from_node': from_node,
                            'channel': channel,
                            'triggered_by': text[:80],
                            'response_sent': True,
                            'parts_count': len(parts),
                        }
                    })
                    # Publish ar_sent to MessageRouter so TF handler picks it up
                    if parts:
                        try:
                            local_id = None
                            local_long = None
                            local_short = None
                            mc = session.gateway.meshtastic_client
                            if mc and mc.my_node_info and isinstance(mc.my_node_info, dict):
                                node_num = mc.my_node_info.get('nodeNum') or mc.my_node_info.get('num')
                                if node_num:
                                    local_id = f"!{node_num:08x}"
                            if local_id and mc and mc.nodes_db and local_id in mc.nodes_db:
                                nd = mc.nodes_db[local_id]
                                local_long = nd.get('long_name')
                                local_short = nd.get('short_name')
                            ch_name = None
                            try:
                                if mc and mc.channels_db:
                                    ch_name = mc.channels_db.get(channel, {}).get('name') or f"ch{channel}"
                            except Exception:
                                ch_name = f"ch{channel}"
                            source_host = session.gateway.settings.meshtastic.host
                            source_port = session.gateway.settings.meshtastic.port
                            for idx, ar_part in enumerate(parts):
                                await message_router.route_message({
                                    'message_type': 'ar_sent',
                                    'text': ar_part,
                                    'from_node': local_id,
                                    'from_name': local_long,
                                    'from_short': local_short,
                                    'to_node': to_node,
                                    'channel': channel,
                                    'channel_name': ch_name,
                                    'direction': 'sent',
                                    'timestamp': fired_at,
                                    'ar_label': label,
                                    'source_host': source_host,
                                    'source_port': source_port,
                                })
                        except Exception as tg_err:
                            logger.warning("AR MessageRouter publish error: %s", tg_err)
            except Exception as e:
                logger.error("AutoResponder handler error: %s", e)
        if persistent:
            message_router.register_persistent_broadcast_handler(_ar_handler)
        else:
            message_router.broadcast_handlers.append(_ar_handler)

    def _register_tg_handler(self, session: Session, message_router, persistent: bool = False) -> None:
        """Register the Telegram Forwarder handler on the message router."""
        import re
        _tg_dir = self.telegram_forwarder._telegram_dir

        # Only observe messages for the session whose host matches telegram.host
        _tg_host_raw = getattr(self.telegram_forwarder, '_host', '127.0.0.1')
        _tg_host = _tg_host_raw.rsplit(':', 1)[0] if ':' in _tg_host_raw else _tg_host_raw
        _session_host = getattr(getattr(session.settings, 'meshtastic', None), 'host', '') or ''
        if not hosts_match(_tg_host, _session_host):
            logger.debug(
                "TelegramForwarder: skipping handler registration — host mismatch "
                "(tg.host=%r, session.host=%r)", _tg_host, _session_host
            )
            return

        def _get_channel_name(channel_idx: int) -> str:
            """Look up the human-readable channel name from the gateway's channels_db."""
            try:
                mc = session.gateway.meshtastic_client
                if mc and mc.channels_db:
                    return mc.channels_db.get(channel_idx, {}).get('name') or f"ch{channel_idx}"
            except Exception as e:
                logger.debug(f"[ws] get_channel_name ch{channel_idx}: {e}")
            return f"ch{channel_idx}"

        def _fmt_sender(from_node: str, hint_name: str = '') -> str:
            """Return 'LongName <short@!nodeid>' for a node, using nodes_db when available."""
            try:
                mc = session.gateway.meshtastic_client
                if mc and mc.nodes_db:
                    nd = mc.nodes_db.get(from_node, {})
                    long_name = nd.get('long_name') or hint_name or from_node
                    short_name = nd.get('short_name') or from_node[-4:]
                    return f"{long_name} <{short_name}@{from_node}>"
            except Exception as e:
                logger.debug(f"[ws] fmt_sender {from_node}: {e}")
            return hint_name or from_node

        def _conv_matches(conv_key: str, channel_idx: int, from_node: str, to_node: str, is_broadcast: bool = True):
            """Return (matched, direction, is_channel) for a TF conv config against a message.

            Node-based configs (key not starting with 'ch') only match DM messages.
            When is_broadcast=True the message is a channel broadcast, and a node-key
            config must NOT match — otherwise one AR reply would fire once per TF config
            that happens to share the same node key.

            Special key '__own_node__' matches any DM addressed to this node (catch-all).
            It is a last-resort — the caller decides whether to fire it only when no
            other config already matched.
            """
            # Own-node catch-all: deferred to caller for last-resort logic
            if conv_key == '__own_node__':
                if is_broadcast:
                    return False, None, False
                # Check if message is addressed to our own node
                try:
                    mc = session.gateway.meshtastic_client
                    own_num = mc.my_node_info.get('nodeNum', 0) if mc and mc.my_node_info else 0
                    own_hex = f'!{own_num:08x}' if own_num else ''
                    to_norm = (to_node or '').lstrip('!').lower()
                    own_norm = own_hex.lstrip('!').lower()
                    if own_norm and to_norm == own_norm:
                        return True, 'received', False
                except Exception as e:
                    logger.debug(f"[ws] conv_matches own_node check: {e}")
                return False, None, False
            ch_m = re.match(r'^ch(\d+)', conv_key)
            if ch_m:
                if int(ch_m.group(1)) == channel_idx:
                    return True, 'received', True
                return False, None, True
            # Node-based config: only applies to DMs, not channel broadcasts
            if is_broadcast:
                return False, None, False
            key_norm = conv_key.lstrip('!').lower()
            from_norm = (from_node or '').lstrip('!').lower()
            to_norm = (to_node or '').lstrip('!').lower()
            if key_norm and (key_norm == from_norm or (to_norm and key_norm == to_norm)):
                direction = 'received' if key_norm == from_norm else 'sent'
                return True, direction, False
            return False, None, False

        # Pending image queue: key = (conv_key, fragment_id)
        # value = {'total': N, 'received': M, 'ts': float}
        _tg_pending_images = {}

        async def _tg_message_handler(message):
            """
            Unified TF handler — handles incoming text, all sent types, binary image
            segments, and assembled image_complete events.

            Registered via register_handler (not broadcast_handlers) to prevent
            double-firing: each type fires exactly once.
            """
            msg_type = message.get('message_type', '')
            try:
                from telegram_forwarder.telegram_forwarder import list_conversation_configs

                # ---- Image segment tracking (binary) ----
                if msg_type == 'binary':
                    payload = message.get('decoded', {}).get('payload', '') or ''
                    if not payload.startswith('IMG'):
                        return  # non-image binary — ignore
                    fragment_id = message.get('fragment_id', '')
                    from_node = message.get('from_node', '')
                    channel_idx = int(message.get('channel', 0))
                    total = int(message.get('fragment_total', 0))
                    configs = list_conversation_configs(_tg_dir)
                    for config in configs:
                        if not config.get('enabled'):
                            continue
                        conv_key = config.get('conversation_key', '')
                        matched, _, _ = _conv_matches(conv_key, channel_idx, from_node, '',
                                                         message.get('is_broadcast', True))
                        if not matched:
                            continue
                        key = (conv_key, fragment_id)
                        if key not in _tg_pending_images:
                            _tg_pending_images[key] = {
                                'total': total, 'received': 0,
                                'ts': asyncio.get_event_loop().time()
                            }
                            # Schedule 3-minute timeout per (conv_key, fragment_id)
                            async def _img_timeout(ck=conv_key, fid=fragment_id, tot=total):
                                await asyncio.sleep(180)
                                entry = _tg_pending_images.pop((ck, fid), None)
                                if entry:
                                    rcv = entry.get('received', 0)
                                    # Extract checksum from fragment_id (last 8 hex chars)
                                    cs = fid[-8:] if len(fid) >= 8 else fid
                                    await self.telegram_forwarder.forward_text(
                                        ck,
                                        f"Incomplete image segments received. (checksum:{cs} {rcv}/{tot})"
                                    )
                            asyncio.create_task(_img_timeout())
                        else:
                            _tg_pending_images[key]['received'] = \
                                _tg_pending_images[key].get('received', 0) + 1
                    return

                # ---- Assembled image forwarding (image_complete) ----
                if msg_type == 'image_complete':
                    decoded_image = message.get('decoded_image')
                    if not decoded_image:
                        return
                    import base64
                    fragment_id = message.get('fragment_id', '')
                    from_node = message.get('from_node', '')
                    from_name_hint = message.get('from_name', '')
                    channel_idx = int(message.get('channel', 0))
                    channel_name = _get_channel_name(channel_idx)
                    configs = list_conversation_configs(_tg_dir)
                    for config in configs:
                        if not config.get('enabled'):
                            continue
                        conv_key = config.get('conversation_key', '')
                        matched, _, is_ch = _conv_matches(conv_key, channel_idx, from_node, '',
                                                          message.get('is_broadcast', False))
                        if not matched:
                            continue
                        # Cancel the timeout by removing from pending queue
                        _tg_pending_images.pop((conv_key, fragment_id), None)
                        try:
                            image_bytes = base64.b64decode(decoded_image)
                        except Exception:
                            image_bytes = decoded_image if isinstance(decoded_image, bytes) else None
                        if not image_bytes:
                            continue
                        label = channel_name if is_ch else "DM"
                        caption = f"[{label}] Image from {_fmt_sender(from_node, from_name_hint)}"
                        await self.telegram_forwarder.forward_image(
                            conv_key=conv_key,
                            image_data=image_bytes,
                            caption=caption,
                        )
                    return

                # ---- Text / sent-message forwarding ----
                if msg_type not in ('text', 'text_sent', 'ar_sent', 'scheduled_sent'):
                    return

                from_node = message.get('from_node', '')
                to_node = message.get('to_node', '')
                channel_idx = int(message.get('channel', 0))
                # is_broadcast: True means channel message (not a DM).
                # Sent messages with no to_node are also channel broadcasts.
                is_broadcast = message.get('is_broadcast', not bool(to_node))
                # incoming: decoded_text; sent types: text
                text = message.get('decoded_text') or message.get('text', '')
                from_name = message.get('from_name', '') or from_node
                from_short = message.get('from_short', '')

                if not text:
                    return

                # IMG segments arrive as text portnum — suppress raw forwarding and queue them.
                if text.startswith('IMG') and ':' in text:
                    img_parts = text.split(':')
                    if len(img_parts) >= 5 and '/' in img_parts[3]:
                        try:
                            seg_idx_s, seg_total_s = img_parts[3].split('/', 1)
                            seg_idx = int(seg_idx_s)
                            seg_total = int(seg_total_s)
                            checksum = img_parts[2]
                            frag_id = f"{img_parts[0]}_{img_parts[1]}_{checksum}"
                            img_configs = list_conversation_configs(_tg_dir)
                            for img_cfg in img_configs:
                                if not img_cfg.get('enabled'):
                                    continue
                                ck = img_cfg.get('conversation_key', '')
                                img_matched, _, _ = _conv_matches(ck, channel_idx, from_node, '', is_broadcast)
                                if not img_matched:
                                    continue
                                img_key = (ck, frag_id)
                                if img_key not in _tg_pending_images:
                                    _tg_pending_images[img_key] = {
                                        'total': seg_total,
                                        'segments': {},
                                        'from_node': from_node,
                                        'channel': channel_idx,
                                        'ts': asyncio.get_event_loop().time(),
                                    }
                                    async def _txt_img_timeout(ck2=ck, fid2=frag_id, tot2=seg_total):
                                        await asyncio.sleep(180)
                                        entry2 = _tg_pending_images.pop((ck2, fid2), None)
                                        if entry2:
                                            rcv2 = len(entry2.get('segments', {}))
                                            cs2 = fid2.rsplit('_', 1)[-1]
                                            await self.telegram_forwarder.forward_text(
                                                ck2,
                                                f"Incomplete image segments received. "
                                                f"(checksum:{cs2} {rcv2}/{tot2})"
                                            )
                                    asyncio.create_task(_txt_img_timeout())
                                q = _tg_pending_images[img_key]
                                q['segments'][seg_idx] = text
                                if len(q['segments']) >= q['total']:
                                    segs_list = [q['segments'][i] for i in range(q['total'])]
                                    _tg_pending_images.pop(img_key, None)
                                    try:
                                        from encoding.decoder_adapter import DecoderAdapter
                                        da = DecoderAdapter()
                                        dec = da.decode_segments(segs_list)
                                        ch_lbl = _get_channel_name(channel_idx)
                                        img_label = ch_lbl if is_broadcast else "DM"
                                        if dec.get('success') and dec.get('image_data'):
                                            import base64 as _b64
                                            img_bytes = _b64.b64decode(dec['image_data'])
                                            caption = f"[{img_label}] Image from {_fmt_sender(from_node)}"
                                            await self.telegram_forwarder.forward_image(
                                                conv_key=ck,
                                                image_data=img_bytes,
                                                caption=caption,
                                            )
                                        else:
                                            await self.telegram_forwarder.forward_text(
                                                ck,
                                                f"[{img_label}] Image from {_fmt_sender(from_node)} (decode failed)"
                                            )
                                    except Exception as _de:
                                        logger.warning("TF IMG text-portnum decode error: %s", _de)
                        except (ValueError, IndexError):
                            pass
                    return  # never forward raw IMG segment text to Telegram

                # For sent messages the direction is already decided by source
                direction_override = message.get('direction')  # 'sent' or 'received'

                configs = list_conversation_configs(_tg_dir)
                logger.info(
                    "TelegramForwarder[%s]: %d config(s) for msg from=%s ch=%d text=%r",
                    msg_type, len(configs), from_node, channel_idx, text[:60]
                )

                channel_name = message.get('channel_name') or _get_channel_name(channel_idx)

                # Separate out own_node catch-all configs — fire them last-resort only
                own_node_configs = [c for c in configs if c.get('conversation_key') == '__own_node__']
                regular_configs = [c for c in configs if c.get('conversation_key') != '__own_node__']
                regular_matched = False

                async def _forward_config(config, matched, direction, is_ch):
                    conv_key = config.get('conversation_key', '')
                    to_long = None
                    to_short = None
                    try:
                        mc = session.gateway.meshtastic_client
                        if mc and to_node and mc.nodes_db:
                            nd = mc.nodes_db.get(to_node, {})
                            to_long = nd.get('long_name')
                            to_short = nd.get('short_name')
                    except Exception as e:
                        logger.debug(f"[ws] tg node lookup {to_node}: {e}")
                    await self.telegram_forwarder.forward_message(
                        conv_key=conv_key,
                        text=text,
                        direction=direction,
                        from_long=from_name,
                        from_short=from_short,
                        from_node_id=from_node,
                        to_long=to_long,
                        to_short=to_short,
                        to_node_id=to_node or None,
                        channel_name=channel_name if is_ch else None,
                    )

                for config in regular_configs:
                    conv_key = config.get('conversation_key', '')
                    if not config.get('enabled'):
                        logger.debug("TelegramForwarder: config %r disabled, skipping", conv_key)
                        continue

                    matched, direction, is_ch = _conv_matches(conv_key, channel_idx, from_node, to_node, is_broadcast)
                    if direction_override:
                        direction = direction_override
                    if not matched:
                        logger.debug(
                            "TelegramForwarder: config %r no match for ch%d from=%s",
                            conv_key, channel_idx, from_node
                        )
                        continue

                    regular_matched = True
                    logger.info(
                        "TelegramForwarder: config %r MATCHED — forwarding %s msg to chat_id=%s",
                        conv_key, direction, config.get('chat_id', '?')
                    )
                    await _forward_config(config, matched, direction, is_ch)

                # Fire own_node catch-all only if no regular config matched
                if not regular_matched:
                    for config in own_node_configs:
                        if not config.get('enabled'):
                            continue
                        matched, direction, is_ch = _conv_matches('__own_node__', channel_idx, from_node, to_node, is_broadcast)
                        if direction_override:
                            direction = direction_override
                        if not matched:
                            continue
                        logger.info(
                            "TelegramForwarder: own_node catch-all MATCHED — forwarding to chat_id=%s",
                            config.get('chat_id', '?')
                        )
                        await _forward_config(config, matched, direction, is_ch)

            except Exception as e:
                logger.error("TelegramForwarder message handler error: %s", e, exc_info=True)

        # Register handler for each type exactly once — do NOT use broadcast_handlers
        # (which fires for ALL types, causing double-sends with register_handler).
        for _type in ('text', 'text_sent', 'ar_sent', 'scheduled_sent',
                      'binary', 'image_complete'):
            if persistent:
                message_router.register_persistent_handler(_type, _tg_message_handler)
            else:
                message_router.register_handler(_type, _tg_message_handler)
