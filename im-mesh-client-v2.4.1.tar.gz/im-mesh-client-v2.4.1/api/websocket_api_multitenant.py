"""
WebSocket API for Multi-Tenant Meshtastic Web Client.

Provides real-time updates for individual sessions with proper isolation.
Each WebSocket connection is associated with a specific session.
"""

import json
import logging
import re
import asyncio
import base64
import collections
from typing import Dict, List, Set, Optional, Any
from fastapi import WebSocket, WebSocketDisconnect
from datetime import datetime

from core.session_manager import SessionManager, Session
from core.message_splitter import split_message
from .ws_session import WebSocketSessionMixin
from .ws_handlers import WebSocketHandlersMixin

logger = logging.getLogger(__name__)

_UUID_RE = re.compile(r'^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$', re.IGNORECASE)


def _json_serialize(obj):
    """Custom JSON serializer that handles bytes, datetime, and other non-serializable types."""
    if isinstance(obj, bytes):
        return base64.b64encode(obj).decode('ascii')
    if isinstance(obj, datetime):
        return obj.isoformat()
    if isinstance(obj, set):
        return list(obj)
    raise TypeError(f"Object of type {type(obj).__name__} is not JSON serializable")

class WebSocketAPI(WebSocketSessionMixin, WebSocketHandlersMixin):
    """
    WebSocket API with session support.
    
    Manages WebSocket connections and routes real-time updates
    to appropriate session subscribers.
    """
    
    def __init__(self, session_manager: SessionManager, auto_responder=None, telegram_forwarder=None, scheduler=None):
        self.session_manager = session_manager
        self.auto_responder = auto_responder
        self.telegram_forwarder = telegram_forwarder
        self.scheduler = scheduler
        
        # Track connections by session
        self.session_connections: Dict[str, Set[WebSocket]] = {}
        
        # Track session for each connection
        self.connection_sessions: Dict[WebSocket, str] = {}
        
        # Track last successful WS send time per WebSocket connection for flush dedup.
        # Keyed by WebSocket object so each browser tab has its own independent cutoff.
        self._last_ws_send_time: Dict[WebSocket, str] = {}

        # Ring buffer for AR messages sent while browser was offline (mirrors scheduler._history)
        self._ar_history: Dict[str, collections.deque] = {}
    
    def _cache_ar_message(self, session_id: str, msg_data: dict):
        """Cache an AR message in the per-session ring buffer (max 50 entries)."""
        if session_id not in self._ar_history:
            self._ar_history[session_id] = collections.deque(maxlen=50)
        self._ar_history[session_id].append(msg_data)

    def _drain_ar_history(self, session_id: str) -> List[dict]:
        """Return and clear the AR message buffer for a session."""
        buf = self._ar_history.pop(session_id, collections.deque())
        return list(buf)

    async def handle_websocket(self, websocket: WebSocket, session_id: Optional[str] = None):
        """
        Handle WebSocket connection for a specific session.
        
        Args:
            websocket: WebSocket connection
            session_id: Session ID to associate with connection
        """
        await websocket.accept()
        
        # If no session ID provided, negotiate from first message
        if not session_id:
            session_id = await self._negotiate_auth(websocket)
            if not session_id:
                return
        
        # Verify session exists
        session = await self.session_manager.get_session(session_id)
        if not session:
            await websocket.send_text(json.dumps({
                'type': 'error',
                'message': 'Session not found'
            }))
            await websocket.close()
            return
        
        # Register connection with session
        self._add_connection(session_id, websocket)
        
        try:
            # Send initial connection confirmation
            await websocket.send_text(json.dumps({
                'type': 'connected',
                'session_id': session_id,
                'timestamp': datetime.now().isoformat()
            }))
            
            # Setup message router callback for this session
            await self._setup_session_callbacks(session, websocket)
            
            # Send auth_success so the JS client triggers loadInitialData()
            await websocket.send_text(json.dumps({
                'type': 'auth_success',
                'session_id': session_id,
                'timestamp': datetime.now().isoformat()
            }))
            
            # Flush any buffered messages that arrived while this WS was disconnected.
            # Pass the websocket so the flush uses its own per-connection last-send-time
            # rather than a shared session timestamp.
            await self._flush_buffered_messages(session, session_id, websocket)
            
            # Listen for messages from client
            await self._handle_client_messages(websocket, session)
            
        except WebSocketDisconnect:
            logger.info(f"WebSocket disconnected for session {session_id}")
        except (ConnectionError, RuntimeError) as e:
            logger.warning(f"WebSocket error for session {session_id}: {e}")
        finally:
            # Cleanup connection
            self._remove_connection(session_id, websocket)
    
    def _add_connection(self, session_id: str, websocket: WebSocket):
        """Add WebSocket connection to session tracking."""
        if session_id not in self.session_connections:
            self.session_connections[session_id] = set()
        
        self.session_connections[session_id].add(websocket)
        self.connection_sessions[websocket] = session_id
        
        logger.info(f"Added WebSocket connection for session {session_id}")
    
    def _remove_connection(self, session_id: str, websocket: WebSocket):
        """Remove WebSocket connection from session tracking."""
        if session_id in self.session_connections:
            self.session_connections[session_id].discard(websocket)

            # Remove empty session sets
            if not self.session_connections[session_id]:
                del self.session_connections[session_id]

        self.connection_sessions.pop(websocket, None)
        self._last_ws_send_time.pop(websocket, None)

        logger.info(f"Removed WebSocket connection for session {session_id}")
    
    async def _setup_session_callbacks(self, session: Session, websocket: WebSocket):
        """Setup callbacks for session events.

        Subscribes to all message types that the packet_handler and message_router emit.

        CRITICAL: Handler replacement must be ATOMIC.  Previously we called
        clear_handlers() then registered new ones.  If a fire-and-forget route
        task (asyncio.create_task) ran between clear and register, it would find
        handlers=0 and silently drop the message.  Now we build the new handler
        dict first and swap it in one assignment.
        """
        message_router = session.gateway.message_router
        self._register_ws_subscriptions(session, message_router)
        logger.info(f"Session {session.id} WebSocket callbacks registered")

    async def _send_to_session(self, session_id: str, message: Dict[str, Any]):
        """Send message to all WebSocket connections for a session."""
        msg_type = message.get('type', '?')
        # Use WARNING for user-facing types so drops are visible in logs
        _important = msg_type in ('message', 'text', 'binary', 'ack', 'binary_complete', 'image_complete')
        if session_id not in self.session_connections:
            if _important:
                logger.warning(f"WS DROP: No connections for session {session_id}, "
                              f"type={msg_type} (message buffered only)")
            else:
                logger.debug(f"No WS connections for session {session_id}, "
                            f"message type={msg_type}")
            return
        
        connections = self.session_connections[session_id]
        if not connections:
            if _important:
                logger.warning(f"WS DROP: Empty connection set for session {session_id}, "
                              f"type={msg_type} (message buffered only)")
            else:
                logger.debug(f"Empty WS connection set for session {session_id}, "
                            f"message type={msg_type}")
            return
        
        # Add timestamp to message
        message['timestamp'] = datetime.now().isoformat()
        
        # Serialize with custom handler for bytes/datetime
        try:
            message_json = json.dumps(message, default=_json_serialize)
        except (TypeError, ValueError) as e:
            logger.warning(f"Error serializing WebSocket message: {e}")
            return
        
        # Send to all connections for this session; record per-WS send time on success
        disconnected_connections = []
        sent_ok = False
        now_iso = datetime.now().isoformat()
        for websocket in list(self.session_connections.get(session_id, set())):
            try:
                await websocket.send_text(message_json)
                sent_ok = True
                self._last_ws_send_time[websocket] = now_iso
            except (ConnectionError, RuntimeError) as e:
                logger.warning(f"Error sending WebSocket message: {e}")
                disconnected_connections.append(websocket)

        if not sent_ok and _important:
            logger.warning(f"WS SEND FAILED: type={msg_type} session={session_id} "
                          f"({len(disconnected_connections)} disconnected)")
        elif sent_ok and _important:
            logger.info(f"WS SENT OK: type={msg_type} session={session_id} "
                       f"({len(message_json)} bytes)")

        # Clean up disconnected connections
        for websocket in disconnected_connections:
            self._remove_connection(session_id, websocket)
    
    async def broadcast_to_all_sessions(self, message: Dict[str, Any]):
        """Broadcast message to all active sessions."""
        for session_id in list(self.session_connections.keys()):
            await self._send_to_session(session_id, message)
    
    async def get_session_connection_count(self, session_id: str) -> int:
        """Get number of active WebSocket connections for a session."""
        return len(self.session_connections.get(session_id, set()))

    def is_session_connected(self, session_id: str) -> bool:
        """Return True if at least one WebSocket is connected for the session."""
        return bool(self.session_connections.get(session_id))
    
    async def get_total_connection_count(self) -> int:
        """Get total number of active WebSocket connections."""
        return sum(len(connections) for connections in self.session_connections.values())
    
    async def disconnect_session(self, session_id: str):
        """Disconnect all WebSocket connections for a session."""
        if session_id in self.session_connections:
            connections = list(self.session_connections[session_id])
            
            for websocket in connections:
                try:
                    await websocket.send_text(json.dumps({
                        'type': 'session_closed',
                        'message': 'Session has been closed'
                    }))
                    await websocket.close()
                except (ConnectionError, RuntimeError) as e:
                    logger.warning(f"Error closing WebSocket: {e}")
            
            # Clear all connections for this session
            self.session_connections.pop(session_id, None)
            
            # Clean up connection tracking
            for websocket in connections:
                self.connection_sessions.pop(websocket, None)
    
    async def shutdown(self):
        """Shutdown all WebSocket connections."""
        logger.info("Shutting down WebSocket API...")
        
        # Close all connections
        all_connections = []
        for connections in self.session_connections.values():
            all_connections.extend(connections)
        
        for websocket in all_connections:
            try:
                await websocket.send_text(json.dumps({
                    'type': 'shutdown',
                    'message': 'Server is shutting down'
                }))
                await websocket.close()
            except (ConnectionError, RuntimeError) as e:
                logger.warning(f"Error closing WebSocket during shutdown: {e}")
        
        # Clear all tracking
        self.session_connections.clear()
        self.connection_sessions.clear()
        
        logger.info("WebSocket API shutdown complete")
