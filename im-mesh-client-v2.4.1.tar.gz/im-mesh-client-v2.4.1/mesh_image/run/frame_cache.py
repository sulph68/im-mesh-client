"""
Frame cache for keyframe/delta image transmission.

Stores decoded I-frame pixel data indexed by checksum for P-frame reconstruction.
Includes a pending queue for P-frames that arrive before their reference I-frame.
"""

from typing import Optional, Tuple, List, Dict, Any
from collections import OrderedDict


class FrameCache:
    """LRU cache for decoded I-frame pixel data.
    
    Stores pixel arrays (quantized level values, not 0-255) along with
    dimensions and bit depth so P-frames can reconstruct against them.
    
    Also maintains a pending queue for P-frames whose reference I-frame
    has not yet been received.
    
    Args:
        max_entries: Maximum number of I-frames to cache (default 10).
        max_pending: Maximum number of pending P-frames to buffer (default 20).
    """
    
    def __init__(self, max_entries: int = 10, max_pending: int = 20):
        if max_entries < 1:
            raise ValueError("max_entries must be >= 1")
        if max_pending < 0:
            raise ValueError("max_pending must be >= 0")
        self.max_entries = max_entries
        self.max_pending = max_pending
        self._cache: OrderedDict[str, Dict[str, Any]] = OrderedDict()
        self._pending: List[Dict[str, Any]] = []
    
    def store(self, checksum: str, pixels: list, width: int, height: int, bit_depth: int) -> None:
        """Store an I-frame's pixel data in the cache.
        
        Args:
            checksum: 8-char hex checksum of the compressed I-frame data.
            pixels: List of quantized pixel level values (0 to 2^bit_depth - 1).
            width: Image width.
            height: Image height.
            bit_depth: Bit depth (1, 2, or 4).
        """
        # If already cached, move to end (most recent)
        if checksum in self._cache:
            self._cache.move_to_end(checksum)
            self._cache[checksum] = {
                'pixels': pixels,
                'width': width,
                'height': height,
                'bit_depth': bit_depth
            }
            return
        
        # Evict oldest if at capacity
        while len(self._cache) >= self.max_entries:
            self._cache.popitem(last=False)
        
        self._cache[checksum] = {
            'pixels': pixels,
            'width': width,
            'height': height,
            'bit_depth': bit_depth
        }
    
    def get(self, checksum: str) -> Optional[Dict[str, Any]]:
        """Retrieve an I-frame's data by checksum.
        
        Args:
            checksum: 8-char hex checksum.
            
        Returns:
            Dict with keys {pixels, width, height, bit_depth} or None if not found.
            Accessing an entry moves it to most-recent position (LRU update).
        """
        if checksum not in self._cache:
            return None
        self._cache.move_to_end(checksum)
        return self._cache[checksum]
    
    def has(self, checksum: str) -> bool:
        """Check if a checksum is in the cache without updating LRU order."""
        return checksum in self._cache
    
    def add_pending(self, ref_checksum: str, segments: list, metadata: dict) -> None:
        """Buffer a P-frame that is waiting for its reference I-frame.
        
        Args:
            ref_checksum: Checksum of the needed reference I-frame.
            segments: The raw message segment strings for this P-frame.
            metadata: Parsed metadata (width, height, mode, etc).
        """
        # Evict oldest pending if at capacity
        while len(self._pending) >= self.max_pending:
            self._pending.pop(0)
        
        self._pending.append({
            'ref_checksum': ref_checksum,
            'segments': segments,
            'metadata': metadata
        })
    
    def get_pending(self, ref_checksum: str) -> List[Dict[str, Any]]:
        """Retrieve and remove all pending P-frames for a given reference checksum.
        
        Args:
            ref_checksum: Checksum of the I-frame that just arrived.
            
        Returns:
            List of pending P-frame entries (each has segments and metadata).
        """
        matched = [p for p in self._pending if p['ref_checksum'] == ref_checksum]
        self._pending = [p for p in self._pending if p['ref_checksum'] != ref_checksum]
        return matched
    
    @property
    def size(self) -> int:
        """Number of I-frames currently cached."""
        return len(self._cache)
    
    @property
    def pending_count(self) -> int:
        """Number of P-frames waiting for their reference."""
        return len(self._pending)
    
    @property
    def checksums(self) -> List[str]:
        """List of cached checksums in LRU order (oldest first)."""
        return list(self._cache.keys())
    
    def clear(self) -> None:
        """Clear all cached frames and pending queue."""
        self._cache.clear()
        self._pending.clear()
    
    def __repr__(self) -> str:
        return (f"FrameCache(cached={self.size}/{self.max_entries}, "
                f"pending={self.pending_count}/{self.max_pending})")
