"""
Value objects and data classes for the Meshtastic Image Encoder/Decoder.
"""

from dataclasses import dataclass
from enum import Enum
from typing import Tuple, Optional
from .config import IMAGE_SIZES, SUPPORTED_BIT_DEPTHS, COMPRESSION_METHODS


class FrameType(Enum):
    """Frame type for keyframe/delta encoding."""
    I_FRAME = 'I'  # Keyframe: full image, no dependencies
    P_FRAME = 'P'  # Delta frame: XOR difference from reference I-frame


@dataclass(frozen=True)
class FrameInfo:
    """Metadata about a frame's type and checksum references.
    
    For I-frames: curr_checksum is the frame's own checksum, ref_checksum is None.
    For P-frames: curr_checksum is the delta payload checksum,
                  ref_checksum is the referenced I-frame's checksum.
    """
    frame_type: FrameType
    curr_checksum: str
    ref_checksum: Optional[str] = None  # Only set for P-frames
    
    def __post_init__(self):
        if self.frame_type == FrameType.P_FRAME and not self.ref_checksum:
            raise ValueError("P-frames must have a ref_checksum")
        if self.frame_type == FrameType.I_FRAME and self.ref_checksum:
            raise ValueError("I-frames must not have a ref_checksum")
    
    @property
    def checksum_field(self) -> str:
        """Format checksum for message segment header.
        
        I-frame: 'ABCD1234'
        P-frame: 'ABCD1234-5678EF90'
        """
        if self.frame_type == FrameType.P_FRAME:
            return f"{self.curr_checksum}-{self.ref_checksum}"
        return self.curr_checksum
    
    @classmethod
    def from_checksum_field(cls, checksum_str: str) -> 'FrameInfo':
        """Parse a checksum field string into a FrameInfo.
        
        Args:
            checksum_str: Either '8hexchars' (I-frame) or '8hexchars-8hexchars' (P-frame)
        """
        if '-' in checksum_str:
            parts = checksum_str.split('-', 1)
            return cls(
                frame_type=FrameType.P_FRAME,
                curr_checksum=parts[0],
                ref_checksum=parts[1]
            )
        return cls(
            frame_type=FrameType.I_FRAME,
            curr_checksum=checksum_str
        )


@dataclass(frozen=True)
class ImageDimensions:
    """Value object representing image dimensions."""
    width: int
    height: int
    
    @classmethod
    def from_string(cls, size_string: str) -> 'ImageDimensions':
        """Create ImageDimensions from string like '128x64'. Supports preset and custom sizes."""
        if size_string in IMAGE_SIZES:
            width, height = IMAGE_SIZES[size_string]
            return cls(width, height)
        # Support arbitrary WxH format
        if 'x' in size_string:
            try:
                parts = size_string.lower().split('x')
                width, height = int(parts[0]), int(parts[1])
                if width > 0 and height > 0 and width <= 1024 and height <= 1024:
                    return cls(width, height)
            except (ValueError, IndexError):
                pass
        raise ValueError(f"Unsupported image size: {size_string}")
    
    @property
    def aspect_ratio(self) -> float:
        """Calculate aspect ratio."""
        return self.width / self.height
    
    def __str__(self) -> str:
        return f"{self.width}x{self.height}"


@dataclass(frozen=True)
class CompressionConfig:
    """Configuration for compression settings."""
    method: str
    bit_depth: int
    use_heatshrink: bool = True
    
    def __post_init__(self):
        if self.method not in COMPRESSION_METHODS:
            raise ValueError(f"Unsupported compression method: {self.method}")
        if self.bit_depth not in SUPPORTED_BIT_DEPTHS:
            raise ValueError(f"Unsupported bit depth: {self.bit_depth}")
    
    @property
    def method_code(self) -> str:
        """Get method code for message format."""
        code = COMPRESSION_METHODS[self.method]
        return code.lower() if self.use_heatshrink else code.upper()
    
    @property
    def quantization_levels(self) -> int:
        """Get number of quantization levels."""
        return 2 ** self.bit_depth


@dataclass
class PreparationStats:
    """Statistics from image preparation process."""
    original_size: Tuple[int, int]
    target_size: Tuple[int, int]
    original_mode: str
    bit_depth: int
    quantization_levels: int


@dataclass
class CompressionStats:
    """Statistics from compression process."""
    compression_method: str
    compression_ratio: float
    unique_tiles: Optional[int]
    total_tiles: Optional[int]
    base64_encoded_chars: int
    uses_heatshrink: bool = True
    
    @property
    def tile_efficiency(self) -> Optional[float]:
        """Calculate tile compression efficiency."""
        if self.unique_tiles is None or self.total_tiles is None:
            return None
        return self.unique_tiles / self.total_tiles if self.total_tiles > 0 else 0


@dataclass
class SegmentConfig:
    """Configuration for message segmentation."""
    max_length: int = 220
    
    def __post_init__(self):
        if not (200 <= self.max_length <= 300):
            raise ValueError("Segment length must be between 200 and 300 characters")
    
    @property
    def max_data_per_segment(self) -> int:
        """Calculate maximum data length per segment (excluding header)."""
        # Reserve space for header: IMG{w}x{h}:{method}{mode}:{seg}/{total}:
        # Approximate overhead: 25 characters
        return self.max_length - 25