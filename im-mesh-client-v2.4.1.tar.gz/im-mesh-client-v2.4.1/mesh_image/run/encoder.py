"""
Meshtastic Image Encoder
Converts images to compressed Meshtastic-compatible text messages.

Encoding pipeline:
    1. Load/normalize image (RGB, handle transparency)
    2. Resize to target dimensions (center crop + LANCZOS)
    3. Optional 2x2 pixel block averaging
    4. Grayscale conversion + gamma-corrected quantization
    5. Compress using selected strategy (or auto-select best)
    6. Heatshrink2 secondary compression
    7. Base64 encode + split into message segments with SHA256 checksum
"""

from PIL import Image
import base64
import hashlib
import math
from typing import List, Tuple, Dict, Any, Optional
from .config import MESSAGE_PREFIX
from .models import ImageDimensions, CompressionConfig, SegmentConfig, CompressionStats, FrameType, FrameInfo
from .image_processor import ImageProcessor
from .compression import CompressionFactory


def encode_image_with_config(image: Image.Image, config: CompressionConfig, 
                           dimensions: ImageDimensions, segment_config: SegmentConfig = None,
                           gamma: float = 1.0, pixel_compress: bool = False) -> Tuple[List[str], CompressionStats]:
    """
    Modern encode function using configuration objects.
    
    Args:
        image: PIL Image to encode
        config: Compression configuration
        dimensions: Target dimensions
        segment_config: Segment configuration
        gamma: Gamma correction value (0.1-5.0, default 1.0)
        pixel_compress: Apply 2x2 pixel block averaging before quantization
        
    Returns:
        Tuple of (message_segments, compression_stats)
    """
    if segment_config is None:
        segment_config = SegmentConfig()
    
    # Preprocess image for compression strategies
    processed_image = _preprocess_image_for_compression(image, config, dimensions, gamma, pixel_compress)
    
    # Get compression strategy
    strategy = CompressionFactory.get_strategy(config.method)
    
    # Compress image
    compressed_data, stats = strategy.compress(processed_image, config)
    
    # Apply heatshrink compression if enabled
    if config.use_heatshrink:
        try:
            import heatshrink2
            compressed_data = heatshrink2.compress(compressed_data, window_sz2=11, lookahead_sz2=4)
        except ImportError:
            # Heatshrink not available, continue without it
            pass
    
    # Convert to base64
    base64_data = base64.b64encode(compressed_data).decode('ascii')
    stats.base64_encoded_chars = len(base64_data)
    
    # For 'best' encoding, resolve the actual winning method for the segment header
    actual_config = config
    if config.method == 'best' and stats.compression_method.startswith('best('):
        actual_method = stats.compression_method[5:-1]  # extract "xor_vlq_rle" from "best(xor_vlq_rle)"
        actual_config = CompressionConfig(
            method=actual_method,
            bit_depth=config.bit_depth,
            use_heatshrink=config.use_heatshrink
        )
    
    # Create message segments
    segments = _create_message_segments(
        base64_data, 
        dimensions, 
        actual_config, 
        segment_config.max_length
    )
    
    return segments, stats


def _compute_delta_pixels(current_pixels: list, reference_pixels: list) -> list:
    """Compute XOR delta between current and reference pixel arrays.
    
    Args:
        current_pixels: Quantized pixel levels for current image.
        reference_pixels: Quantized pixel levels for reference I-frame.
        
    Returns:
        List of XOR delta values (same length as inputs).
        
    Raises:
        ValueError: If pixel arrays have different lengths.
    """
    if len(current_pixels) != len(reference_pixels):
        raise ValueError(
            f"Pixel array length mismatch: current={len(current_pixels)}, "
            f"reference={len(reference_pixels)}")
    return [c ^ r for c, r in zip(current_pixels, reference_pixels)]


def _get_quantized_pixels(image: Image.Image, config: CompressionConfig,
                          dimensions: ImageDimensions, gamma: float = 1.0,
                          pixel_compress: bool = False) -> list:
    """Preprocess image and return quantized pixel level values.
    
    Returns pixel values in 0..(2^bit_depth - 1) range, ready for
    compression or delta computation.
    """
    processed = _preprocess_image_for_compression(image, config, dimensions, gamma, pixel_compress)
    raw_pixels = list(processed.getdata())
    return ImageProcessor.pixels_to_levels(raw_pixels, config.bit_depth)


def _compress_pixels(pixels: list, width: int, height: int, config: CompressionConfig) -> Tuple[bytes, CompressionStats]:
    """Compress a pixel array using the configured strategy.
    
    Creates a temporary grayscale image from the pixel levels, then
    runs it through the standard compression pipeline.
    
    Args:
        pixels: Quantized pixel level values.
        width: Image width.
        height: Image height.
        config: Compression configuration.
        
    Returns:
        Tuple of (compressed_data, compression_stats).
    """
    # Build a grayscale image from level values scaled back to 0-255
    scaled = ImageProcessor.levels_to_pixels(pixels, config.bit_depth)
    img = Image.new('L', (width, height))
    img.putdata(scaled)
    
    strategy = CompressionFactory.get_strategy(config.method)
    return strategy.compress(img, config)


def _apply_heatshrink(data: bytes, config: CompressionConfig) -> bytes:
    """Apply heatshrink compression if enabled and available."""
    if config.use_heatshrink:
        try:
            import heatshrink2
            return heatshrink2.compress(data, window_sz2=11, lookahead_sz2=4)
        except ImportError:
            pass
    return data


def _compute_checksum(compressed_bytes: bytes) -> str:
    """Compute 8-char hex checksum (first 4 bytes of SHA-256)."""
    return hashlib.sha256(compressed_bytes).hexdigest()[:8]


def encode_p_frame(
    current_image: Image.Image,
    reference_image: Image.Image,
    config: CompressionConfig,
    dimensions: ImageDimensions,
    segment_config: SegmentConfig = None,
    gamma: float = 1.0,
    pixel_compress: bool = False,
    ref_checksum: str = None
) -> Tuple[List[str], CompressionStats, FrameInfo]:
    """Encode a P-frame (delta) against a reference I-frame.
    
    Computes pixel-level XOR between the current image and the reference,
    then compresses the delta. If the P-frame compressed size is >= the
    I-frame compressed size, automatically falls back to I-frame encoding
    (adaptive switching).
    
    Args:
        current_image: The new image to encode.
        reference_image: The reference I-frame image (same dimensions/bit_depth).
        config: Compression settings.
        dimensions: Target dimensions (must match reference).
        segment_config: Segment configuration (default: SegmentConfig()).
        gamma: Gamma correction value.
        pixel_compress: Apply 2x2 block averaging before quantization.
        ref_checksum: Checksum of the reference I-frame's compressed data.
                      If None, computed from the reference image.
    
    Returns:
        Tuple of (segments, stats, frame_info).
        frame_info.frame_type is P_FRAME normally, or I_FRAME if adaptive switch occurred.
    """
    if segment_config is None:
        segment_config = SegmentConfig()
    
    # Preprocess both images to quantized pixel levels
    current_pixels = _get_quantized_pixels(current_image, config, dimensions, gamma, pixel_compress)
    reference_pixels = _get_quantized_pixels(reference_image, config, dimensions, gamma, pixel_compress)
    
    # Compute delta (XOR)
    delta_pixels = _compute_delta_pixels(current_pixels, reference_pixels)
    
    # Compress delta pixels
    p_compressed, p_stats = _compress_pixels(
        delta_pixels, dimensions.width, dimensions.height, config)
    
    # Compress current pixels (for adaptive comparison and possible I-frame fallback)
    i_compressed, i_stats = _compress_pixels(
        current_pixels, dimensions.width, dimensions.height, config)
    
    # Apply heatshrink for fair size comparison
    p_final = _apply_heatshrink(p_compressed, config)
    i_final = _apply_heatshrink(i_compressed, config)
    
    # Adaptive switching: if P-frame is not smaller, send I-frame instead
    if len(p_final) >= len(i_final):
        # Fall back to I-frame
        base64_data = base64.b64encode(i_final).decode('ascii')
        i_stats.base64_encoded_chars = len(base64_data)
        
        # Resolve actual method for 'best' encoding
        actual_config = config
        if config.method == 'best' and i_stats.compression_method.startswith('best('):
            actual_method = i_stats.compression_method[5:-1]
            actual_config = CompressionConfig(
                method=actual_method, bit_depth=config.bit_depth,
                use_heatshrink=config.use_heatshrink)
        
        checksum = _compute_checksum(i_final)
        segments = _create_message_segments(
            base64_data, dimensions, actual_config, segment_config.max_length)
        
        frame_info = FrameInfo(FrameType.I_FRAME, checksum)
        return segments, i_stats, frame_info
    
    # P-frame is smaller -- use it
    base64_data = base64.b64encode(p_final).decode('ascii')
    p_stats.base64_encoded_chars = len(base64_data)
    
    # Compute ref_checksum from reference image if not provided
    if ref_checksum is None:
        ref_final = _apply_heatshrink(i_compressed, config)
        ref_checksum = _compute_checksum(ref_final)
    
    # Resolve actual method for 'best' encoding
    actual_config = config
    if config.method == 'best' and p_stats.compression_method.startswith('best('):
        actual_method = p_stats.compression_method[5:-1]
        actual_config = CompressionConfig(
            method=actual_method, bit_depth=config.bit_depth,
            use_heatshrink=config.use_heatshrink)
    
    curr_checksum = _compute_checksum(p_final)
    segments = _create_message_segments(
        base64_data, dimensions, actual_config, segment_config.max_length,
        ref_checksum=ref_checksum)
    
    frame_info = FrameInfo(FrameType.P_FRAME, curr_checksum, ref_checksum)
    return segments, p_stats, frame_info


def _preprocess_image_for_compression(image: Image.Image, config: CompressionConfig, dimensions: ImageDimensions, gamma: float = 1.0, pixel_compress: bool = False) -> Image.Image:
    """
    Preprocess image for compression strategies.
    
    Args:
        image: Original PIL Image
        config: Compression configuration
        dimensions: Target dimensions
        gamma: Gamma correction value (0.1-5.0, default 1.0)
        pixel_compress: Apply 2x2 pixel block averaging before quantization
        
    Returns:
        Processed PIL Image ready for compression
    """
    from .image_processor import ImageProcessor
    
    # Normalize image
    normalized = ImageProcessor.normalize_image(image)
    
    # Resize to target dimensions
    resized = ImageProcessor.resize_with_aspect_ratio(normalized, dimensions)
    
    # Convert to grayscale
    grayscale = resized.convert('L')
    
    # Apply 2x2 pixel compression if requested (before quantization)
    if pixel_compress:
        grayscale = ImageProcessor.pixel_compress_2x2(grayscale)
    
    # Quantize with gamma
    quantized = ImageProcessor.quantize_image(grayscale, config, gamma)
    
    return quantized


def encode_image(image: Image.Image, bit_depth: int, target_width: int = 128, target_height: int = 64, 
                compression_method: str = 'tile_rle', max_segment_length: int = 220,
                gamma: float = 1.0, pixel_compress: bool = False) -> Tuple[List[str], Dict[str, Any]]:
    """
    Legacy encode function for backward compatibility.
    
    Args:
        image: PIL Image to encode
        bit_depth: Bit depth (1, 2, or 4)
        target_width: Target image width
        target_height: Target image height
        compression_method: Compression method
        max_segment_length: Maximum length per message segment
        gamma: Gamma correction value (0.1-5.0, default 1.0)
        pixel_compress: Apply 2x2 pixel block averaging before quantization
        
    Returns:
        Tuple of (message_segments, compression_stats_dict)
    """
    # Create configuration objects
    config = CompressionConfig(method=compression_method, bit_depth=bit_depth)
    dimensions = ImageDimensions(target_width, target_height)
    segment_config = SegmentConfig(max_segment_length)
    
    # Use modern implementation
    segments, stats = encode_image_with_config(image, config, dimensions, segment_config, gamma, pixel_compress)
    
    # Convert stats back to dictionary for backward compatibility
    stats_dict = {
        'compression_method': stats.compression_method,
        'compression_ratio': stats.compression_ratio,
        'unique_tiles': stats.unique_tiles if stats.unique_tiles is not None else 'N/A',
        'total_tiles': stats.total_tiles if stats.total_tiles is not None else 'N/A',
        'base64_encoded_chars': stats.base64_encoded_chars
    }
    
    return segments, stats_dict


def _create_message_segments(base64_data: str, dimensions: ImageDimensions, 
                           config: CompressionConfig, max_segment_length: int,
                           ref_checksum: str = None) -> List[str]:
    """Create message segments from base64 data with checksum.
    
    Distributes data evenly across segments so all segments are
    approximately the same length, rather than filling each to max
    and leaving a short final segment.
    
    Args:
        base64_data: Base64-encoded compressed payload.
        dimensions: Image dimensions.
        config: Compression configuration.
        max_segment_length: Maximum characters per segment.
        ref_checksum: If provided, emit P-frame checksum format (CURR-REF).
    
    Returns:
        List of message segment strings.
    """
    # Compute checksum: SHA256 of the raw compressed bytes, first 4 bytes as hex (8 chars)
    raw_bytes = base64.b64decode(base64_data.encode('ascii'))
    checksum = hashlib.sha256(raw_bytes).hexdigest()[:8]
    
    # For P-frames, use extended checksum format: CURR-REF
    checksum_field = f"{checksum}-{ref_checksum}" if ref_checksum else checksum
    
    # Format: IMG{w}x{h}:{method}{depth}:{checksum}:{seg}/{total}:{data}
    header_base = f"{MESSAGE_PREFIX}{dimensions.width}x{dimensions.height}:{config.method_code}{config.bit_depth}:{checksum_field}:"
    
    # Calculate overhead for segment numbering
    # For single segment: "0:" = 2 chars
    # For multi segment: "NN/TT:" where NN and TT grow with segment count
    # Use conservative estimate first to determine segment count
    numbering_estimate = 8  # covers up to "999/999:"
    max_data_per_segment = max_segment_length - len(header_base) - numbering_estimate
    
    if max_data_per_segment <= 0:
        raise ValueError(f"Segment length {max_segment_length} too small for header")
    
    # Single segment case
    single_overhead = len(header_base) + 2  # "0:"
    if len(base64_data) <= max_segment_length - single_overhead:
        return [f"{header_base}0:{base64_data}"]
    
    # Calculate number of segments needed
    total_segments = math.ceil(len(base64_data) / max_data_per_segment)
    
    # Recalculate with actual numbering width
    numbering_width = len(f"{total_segments - 1}/{total_segments}:")
    max_data_per_segment = max_segment_length - len(header_base) - numbering_width
    total_segments = math.ceil(len(base64_data) / max_data_per_segment)
    
    # Recalculate again in case total_segments digit count changed
    numbering_width = len(f"{total_segments - 1}/{total_segments}:")
    max_data_per_segment = max_segment_length - len(header_base) - numbering_width
    total_segments = math.ceil(len(base64_data) / max_data_per_segment)
    
    # Distribute data evenly: each segment gets floor or ceil share
    data_len = len(base64_data)
    base_size = data_len // total_segments
    remainder = data_len % total_segments
    
    segments = []
    pos = 0
    for i in range(total_segments):
        # First 'remainder' segments get one extra character
        chunk_size = base_size + (1 if i < remainder else 0)
        segment_data = base64_data[pos:pos + chunk_size]
        pos += chunk_size
        
        segment_msg = f"{header_base}{i}/{total_segments}:{segment_data}"
        segments.append(segment_msg)
    
    return segments


def prepare_image_for_encoding(image_file: Any, bit_depth: int = 1, target_width: int = 128, target_height: int = 64,
                              gamma: float = 1.0) -> Tuple[Image.Image, Image.Image, Dict[str, Any]]:
    """
    Legacy function for backward compatibility.
    
    Args:
        image_file: File object or path to image
        bit_depth: Target bit depth
        target_width: Target image width
        target_height: Target image height
        gamma: Gamma correction value (0.1-5.0, default 1.0)
        
    Returns:
        Tuple of (original_image, processed_image, preparation_stats_dict)
    """
    # Create configuration objects - use rle_nibble as default since it works with any dimensions
    config = CompressionConfig(method='rle_nibble', bit_depth=bit_depth)
    dimensions = ImageDimensions(target_width, target_height)
    
    # Use modern implementation
    original, processed, stats = ImageProcessor.prepare_image_for_encoding(image_file, config, dimensions, gamma)
    
    # Convert stats to dictionary for backward compatibility
    stats_dict = {
        'original_size': stats.original_size,
        'target_size': stats.target_size,
        'original_mode': stats.original_mode,
        'bit_depth': stats.bit_depth,
        'quantization_levels': stats.quantization_levels
    }
    
    return original, processed, stats_dict


# ============================================================================
# LIBRARY API - Simple functions for external library usage  
# ============================================================================

def encode_image_simple(image: Image.Image, bit_depth: int = 1, width: int = 64, height: int = 64, 
                       compression_method: str = 'rle_nibble', segment_length: int = 220) -> List[str]:
    """
    Simple library API to encode a PIL Image to Meshtastic message segments.
    
    Args:
        image: PIL Image object
        bit_depth: Bit depth (1, 2, or 4)  
        width: Target width
        height: Target height
        compression_method: 'tile_rle', 'rle_nibble', or 'rle_nibble_xor'
        segment_length: Maximum segment length
        
    Returns:
        List of message segments ready for transmission
        
    Example:
        >>> from PIL import Image
        >>> from run.encoder import encode_image_simple
        >>> img = Image.open('test.png')
        >>> segments = encode_image_simple(img, bit_depth=1, width=64, height=64)
        >>> print(f"Created {len(segments)} segments")
    """
    # Use the existing encode_image function which accepts PIL Image directly
    segments, _ = encode_image(image, bit_depth, width, height, compression_method, segment_length)
    return segments


def encode_image_file(image_path: str, bit_depth: int = 1, width: int = 64, height: int = 64,
                     compression_method: str = 'rle_nibble', segment_length: int = 220) -> Dict[str, Any]:
    """
    Simple library API to encode an image file to Meshtastic message segments with stats.
    
    Args:
        image_path: Path to image file
        bit_depth: Bit depth (1, 2, or 4)
        width: Target width  
        height: Target height
        compression_method: 'tile_rle', 'rle_nibble', or 'rle_nibble_xor'
        segment_length: Maximum segment length
        
    Returns:
        Dictionary containing:
        - segments: List of message segments
        - compression_stats: Compression statistics
        - preparation_stats: Image preparation statistics
        
    Example:
        >>> from run.encoder import encode_image_file
        >>> result = encode_image_file('test.png', bit_depth=1, width=64, height=64)
        >>> segments = result['segments']
        >>> print(f"Compression ratio: {result['compression_stats']['compression_ratio']:.2f}")
    """
    # Load the original image for encoding (encode_image handles full preprocessing)
    original_image_raw = Image.open(image_path)
    original_image_raw.load()  # Ensure loaded before any file handle issues
    
    # Get preparation stats and preview via prepare_image_for_encoding
    original_image, processed_image, prep_stats = prepare_image_for_encoding(
        image_path, bit_depth, width, height)
    
    # Encode from the raw original to avoid double preprocessing
    segments, compression_stats = encode_image(
        original_image_raw, bit_depth, width, height, compression_method, segment_length)
    
    return {
        'segments': segments,
        'compression_stats': compression_stats,
        'preparation_stats': prep_stats,
        'original_image': original_image,
        'processed_image': processed_image
    }


