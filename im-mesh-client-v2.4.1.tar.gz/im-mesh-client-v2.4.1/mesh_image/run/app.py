"""
Flask web application for Meshtastic Image Encoder/Decoder.
"""

import os
import io
import base64
from flask import Flask, render_template, request, jsonify, send_from_directory
from PIL import Image
from .encoder import prepare_image_for_encoding, encode_image, encode_p_frame
from .decoder import decode_messages
from .frame_cache import FrameCache
from .models import CompressionConfig, ImageDimensions, SegmentConfig
from .config import IMAGE_SIZES, SUPPORTED_BIT_DEPTHS, COMPRESSION_METHODS, SUPPORTED_IMAGE_FORMATS, MIN_SEGMENT_LENGTH, MAX_SEGMENT_LENGTH

app = Flask(__name__, template_folder='../templates')

# Sample images directory
SAMPLE_IMAGES_DIR = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'sample_images')

@app.route('/')
def index():
    """Main page."""
    return render_template('index.html')

@app.route('/encode')
def encode_page():
    """Image encoder page."""
    return render_template('encoder.html')

@app.route('/decode')
def decode_page():
    """Image decoder page."""
    return render_template('decoder.html')

@app.route('/api/sample_images')
def api_sample_images():
    """Get list of sample images."""
    try:
        if os.path.exists(SAMPLE_IMAGES_DIR):
            images = [f for f in os.listdir(SAMPLE_IMAGES_DIR) 
                     if f.lower().endswith(SUPPORTED_IMAGE_FORMATS)]
            return jsonify(sorted(images))
        return jsonify([])
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/encode', methods=['POST'])
def api_encode():
    """API endpoint for image encoding."""
    try:
        # Determine if using sample image or uploaded file
        sample_image = request.form.get('sample_image')
        if sample_image:
            # Use sample image
            sample_path = os.path.join(SAMPLE_IMAGES_DIR, sample_image)
            if not os.path.exists(sample_path):
                return jsonify({'success': False, 'error': 'Sample image not found'})
            image_data = sample_path
        else:
            # Handle file upload
            if 'image' not in request.files:
                return jsonify({'success': False, 'error': 'No image file provided'})
            
            image_file = request.files['image']
            if image_file.filename == '':
                return jsonify({'success': False, 'error': 'No image file selected'})
            
            image_data = image_file
        
        # Validate segment length
        try:
            segment_length = int(request.form.get('segment_length', 220))
            if not (MIN_SEGMENT_LENGTH <= segment_length <= MAX_SEGMENT_LENGTH):
                return jsonify({'success': False, 'error': f'Segment length must be {MIN_SEGMENT_LENGTH}-{MAX_SEGMENT_LENGTH}'})
        except (ValueError, TypeError) as e:
            return jsonify({'success': False, 'error': f'Invalid segment length: {e}'})
        
        # Parse gamma value
        try:
            gamma = float(request.form.get('gamma', 1.0))
            gamma = max(0.1, min(5.0, gamma))  # Clamp to 0.1-5.0
        except (ValueError, TypeError):
            gamma = 1.0
        
        # Parse pixel_compress flag
        pixel_compress = request.form.get('pixel_compress', 'false').lower() in ('true', '1', 'on', 'yes')
        
        # Validate bit depth
        try:
            bit_depth = int(request.form.get('bit_depth', 1))
            if bit_depth not in SUPPORTED_BIT_DEPTHS:
                return jsonify({'success': False, 'error': f'Unsupported bit depth: {bit_depth}. Supported: {SUPPORTED_BIT_DEPTHS}'})
        except (ValueError, TypeError):
            return jsonify({'success': False, 'error': 'Invalid bit depth'})
        
        # Validate compression method
        compression_method = request.form.get('compression_method', 'tile_rle')
        if compression_method not in COMPRESSION_METHODS:
            return jsonify({'success': False, 'error': f'Unsupported compression method: {compression_method}'})
        
        # Validate image size (preset or custom WxH)
        image_size = request.form.get('image_size', '128x64')
        if image_size == 'custom':
            try:
                custom_w = int(request.form.get('custom_width', 128))
                custom_h = int(request.form.get('custom_height', 64))
                if custom_w < 8 or custom_w > 1024 or custom_h < 8 or custom_h > 1024:
                    return jsonify({'success': False, 'error': 'Custom dimensions must be 8-1024'})
                image_size = f'{custom_w}x{custom_h}'
            except (ValueError, TypeError):
                return jsonify({'success': False, 'error': 'Invalid custom dimensions'})
        
        if image_size in IMAGE_SIZES:
            target_width, target_height = IMAGE_SIZES[image_size]
        else:
            try:
                parts = image_size.lower().split('x')
                target_width, target_height = int(parts[0]), int(parts[1])
                if not (8 <= target_width <= 1024 and 8 <= target_height <= 1024):
                    return jsonify({'success': False, 'error': f'Dimensions must be 8-1024, got {target_width}x{target_height}'})
            except (ValueError, IndexError):
                return jsonify({'success': False, 'error': f'Unsupported image size: {image_size}'})
        
        # Prepare image with gamma
        try:
            original_image, processed_image, prep_stats = prepare_image_for_encoding(
                image_data, bit_depth, target_width, target_height, gamma)
        except Exception as e:
            return jsonify({'success': False, 'error': f'Image processing error: {str(e)}'})
        
        # Check for keyframe (P-frame encoding)
        keyframe_image_name = request.form.get('keyframe_image')
        keyframe_checksum = request.form.get('keyframe_checksum')
        frame_type_result = 'I'
        ref_checksum_result = None
        
        if keyframe_image_name:
            # P-frame encoding against a keyframe
            keyframe_path = os.path.join(SAMPLE_IMAGES_DIR, keyframe_image_name)
            if not os.path.exists(keyframe_path):
                return jsonify({'success': False, 'error': 'Keyframe image not found'})
            
            try:
                keyframe_img = Image.open(keyframe_path)
                keyframe_img.load()
            except Exception as e:
                return jsonify({'success': False, 'error': f'Keyframe load error: {str(e)}'})
            
            try:
                config = CompressionConfig(method=compression_method, bit_depth=bit_depth)
                dims = ImageDimensions(target_width, target_height)
                seg_config = SegmentConfig(segment_length)
                
                # Use original image_data for encoding (not pre-processed)
                if isinstance(image_data, str):
                    current_img = Image.open(image_data)
                else:
                    current_img = Image.open(image_data)
                current_img.load()
                
                segments, compression_stats_obj, frame_info = encode_p_frame(
                    current_img, keyframe_img, config, dims, seg_config,
                    gamma=gamma, pixel_compress=pixel_compress,
                    ref_checksum=keyframe_checksum)
                
                frame_type_result = frame_info.frame_type.value
                ref_checksum_result = frame_info.ref_checksum
                
                compression_stats = {
                    'compression_method': compression_stats_obj.compression_method,
                    'compression_ratio': compression_stats_obj.compression_ratio,
                    'unique_tiles': compression_stats_obj.unique_tiles if compression_stats_obj.unique_tiles is not None else 'N/A',
                    'total_tiles': compression_stats_obj.total_tiles if compression_stats_obj.total_tiles is not None else 'N/A',
                    'base64_encoded_chars': compression_stats_obj.base64_encoded_chars
                }
            except Exception as e:
                return jsonify({'success': False, 'error': f'P-frame encoding error: {str(e)}'})
        else:
            # Standard I-frame encoding
            # Encode image with gamma=1.0 since gamma was already applied by prepare_image_for_encoding
            try:
                segments, compression_stats = encode_image(
                    processed_image, bit_depth, target_width, target_height, 
                    compression_method, segment_length, gamma=1.0, pixel_compress=pixel_compress)
            except Exception as e:
                return jsonify({'success': False, 'error': f'Encoding error: {str(e)}'})
        
        # Convert original image to base64 for display
        original_img_buffer = io.BytesIO()
        original_image.save(original_img_buffer, format='PNG')
        original_img_base64 = base64.b64encode(original_img_buffer.getvalue()).decode('ascii')
        
        # Build preview image that reflects what was actually encoded
        # If pixel_compress is on, apply 2x2 averaging so preview matches encoded output
        from .image_processor import ImageProcessor
        preview_image = processed_image
        if pixel_compress:
            gray = preview_image.convert('L') if preview_image.mode != 'L' else preview_image
            preview_image = ImageProcessor.pixel_compress_2x2(gray)
        
        # Convert processed/preview image to base64 for display
        processed_img_buffer = io.BytesIO()
        preview_image.save(processed_img_buffer, format='PNG')
        processed_img_base64 = base64.b64encode(processed_img_buffer.getvalue()).decode('ascii')
        
        # Add gamma and pixel_compress to prep stats
        prep_stats['gamma'] = gamma
        prep_stats['pixel_compress'] = pixel_compress
        
        return jsonify({
            'success': True,
            'segments': segments,
            'original_image': original_img_base64,
            'processed_image': processed_img_base64,
            'compression_stats': compression_stats,
            'preparation_stats': prep_stats,
            'frame_type': frame_type_result,
            'ref_checksum': ref_checksum_result
        })
        
    except Exception as e:
        return jsonify({'success': False, 'error': f'Server error: {str(e)}'})

@app.route('/api/decode', methods=['POST'])
def api_decode():
    """API endpoint for image decoding. Supports P-frame with keyframe reference."""
    try:
        # Get messages from JSON request
        request_data = request.get_json()
        if not request_data or 'messages' not in request_data:
            return jsonify({'success': False, 'error': 'No messages provided'})
        
        messages = request_data['messages']
        if not messages:
            return jsonify({'success': False, 'error': 'Empty message list'})
        
        # Build frame cache if keyframe data provided
        frame_cache = None
        keyframe_b64 = request_data.get('keyframe_data')
        keyframe_checksum = request_data.get('keyframe_checksum')
        
        if keyframe_b64:
            try:
                keyframe_bytes = base64.b64decode(keyframe_b64)
                keyframe_img = Image.open(io.BytesIO(keyframe_bytes))
                keyframe_img.load()
            except Exception as e:
                return jsonify({'success': False, 'error': f'Invalid keyframe image: {str(e)}'})
            
            frame_cache = FrameCache()
            
            # Determine ref_checksum from the P-frame segments if not provided
            if not keyframe_checksum:
                from .decoder import parse_message
                parsed = parse_message(messages[0])
                if parsed.get('valid') and parsed.get('ref_checksum'):
                    keyframe_checksum = parsed['ref_checksum']
            
            if keyframe_checksum:
                # Get dimensions and bit depth from segments
                from .decoder import parse_message
                parsed = parse_message(messages[0])
                width = parsed.get('width', 64)
                height = parsed.get('height', 64)
                mode = parsed.get('mode', 2)
                
                from .encoder import _get_quantized_pixels
                config = CompressionConfig(method='rle_nibble', bit_depth=mode)
                dims = ImageDimensions(width, height)
                pixels = _get_quantized_pixels(keyframe_img, config, dims)
                frame_cache.store(keyframe_checksum, pixels, width, height, mode)
        
        try:
            decoded_image, decode_stats = decode_messages(messages, frame_cache=frame_cache)
        except Exception as e:
            return jsonify({'success': False, 'error': f'Decoding error: {str(e)}'})
        
        # Check if decoding was successful
        if decoded_image is None or not decode_stats.get('success', False):
            return jsonify({
                'success': False, 
                'error': decode_stats.get('error', 'Decoding failed - image could not be reconstructed'),
                'ref_checksum': decode_stats.get('ref_checksum'),
                'frame_type': decode_stats.get('frame_type')
            })
        
        # Convert decoded image to base64
        img_buffer = io.BytesIO()
        decoded_image.save(img_buffer, format='PNG')
        img_base64 = base64.b64encode(img_buffer.getvalue()).decode('ascii')
        
        return jsonify({
            'success': True,
            'image_data': img_base64,
            'decode_stats': decode_stats
        })
        
    except Exception as e:
        return jsonify({'success': False, 'error': f'Server error: {str(e)}'})

@app.route('/sample_images/<filename>')
def serve_sample_image(filename):
    """Serve sample image files."""
    return send_from_directory(SAMPLE_IMAGES_DIR, filename)


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8081, debug=True)