"""
Meshtastic Image Encoder/Decoder Package

Provides compression and encoding of grayscale images into text segments
suitable for transmission over Meshtastic mesh radio networks.

Compression methods:
    - xor_vlq_rle: XOR H->V -> bit-level VLQ RLE (best for most images)
    - tile_rle: 8x8 tile palette + byte RLE (requires tile-aligned dims)
    - rle_nibble: Nibble-packed RLE on raw pixel stream
    - rle_nibble_xor: Nibble-packed RLE with row-wise XOR preprocessing
    - best: Auto-selects smallest output across all methods
"""

__version__ = "3.0.0"
__author__ = "Meshtastic Image System"